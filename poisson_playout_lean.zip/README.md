# Poisson playout for contextual bandits

A Lean 4 formalization of the expected-regret upper bound for Poisson playout. Start with `PoissonAudit/InitializedRegret.lean` and the theorem `PoissonAudit.initialized_upper_bound`. It bounds both expected regret and the total modeled work of the learner that computes the tuning and samples its pool counts using exponential waiting times.

For a nonempty finite class of $N$ measurable policies, $K\ge 2$ actions, $T\ge 1$ rounds, and any supplied $L\ge\log(2N)$, the theorem gives

$$
\mathbb E\left[\sum_{t=1}^T c_t(x_t,A_t)-\min_{\pi}\sum_{t=1}^T c_t(x_t,\pi(x_t))\right]
\le 38e\sqrt{KTL}\,\log(2KT).
$$

The contexts are independent draws from an arbitrary probability measure on a measurable space. Each loss function is measurable, takes values in the unit interval and is fixed before play. The oracle returns the exact minimum cost of a finite list of context–cost examples over the policy class. The array sampler uses this scalar interface and independent auxiliary draws. Its history update takes the observed scalar loss. The regret calculation separately tracks true policy losses to evaluate the hindsight comparator.

## Build and verify

Install Lean through elan. From the project directory run

```sh
lake exe cache get
python3 verify.py
```

The toolchain and dependency revisions are pinned. The script runs the default Lake build, checks the project sources for proof placeholders and comments, and checks Lean's axiom reports for the public results. To inspect the declarations interactively, import `PoissonAudit`. Run `lake env lean CheckAxioms.lean` for the axiom reports alone.

## Proof map

| File in `PoissonAudit/` | Result |
| --- | --- |
| `InitializedRegret.lean` | Joint regret and total work theorem for the initialized learner with waiting-time sampling. |
| `Initialization.lean`, `CeilingSearch.lean` | Counted parameter evaluation, terminating comparison-based ceiling searches, and the total polynomial budget. |
| `ExponentialCounts.lean`, `WaitingSampler.lean` | Exact capped count law for the finite exponential sampler, preservation of the training and trial laws under count clipping, equality of the played distributions, and per-round costs. |
| `OracleRegret.lean` | Expected regret of the original-context oracle sampler, starting with an empty history. |
| `ManuscriptOracle.lean` | Equality of the sampler's joint choice/action law with the analyzed kernel, scalar feedback, winner tie-breaking, and per-round work. |
| `Manuscript.lean` | Manuscript tuning and the arbitrary-context regret bound. |
| `ContextRows.lean`, `ContextTransfer.lean`, `SchedulePayoff.lean` | Transfer from finite prediction signatures to general measurable spaces while retaining the actual context-dependent losses. |
| `FiniteUpperBound.lean`, `FiniteRegret.lean`, `RoundBound.lean` | Finite-context expected regret, telescoping, and the approximation cost. |
| `GradientBound.lean`, `Optimization.lean`, `EmpiricalVariance.lean`, `PoissonCap.lean` | Gradient second moment, stochastic optimization, empirical frequencies, and overflow. |
| `ManuscriptResources.lean`, `CountedProgramCertificate.lean` | Polynomial online work budget, query counts and lengths, and auxiliary sample counts. |

## Relation to the manuscript

The regret proof uses the displayed precision, iteration count, trial count, step size, pool cap, and unrounded importance-weighted feedback. It uses a weaker scale-comparison estimate than the manuscript's KL argument. This adds at most $2\sqrt{(n+1)K}$ across the horizon, where $n$ is the Poisson mean. The proof absorbs this term into the displayed regret rate. The manuscript's sharper intermediate $1/T$ oracle-round error requires a separate argument.

The implementation keeps a running average of the pre-update iterates. The instrumented winner routine makes an extra baseline query and takes the least action whose boosted value equals the baseline plus one. `manuscript_winner` proves that this selects the least action maximizing the boosted table, as in the paper after negating the minimization queries. The instrumented query budget therefore uses $K+1$ calls per winner.

The initialization program evaluates the printed formulas in the paper's exact-real model. It charges logarithms and square roots as primitive operations and uses the fixed constant $e$. Each of its three integer ceilings is obtained by comparisons and increments. The proof uses the mathematical ceiling as a termination measure and proves the number of operations performed by the search.

For each pool, the count routine reads at most $M_{\max}+1$ independent rate-one exponential waiting times. It returns the exact count through $M_{\max}$ and uses $M_{\max}+1$ as the overflow code. Lean proves equality with the pushforward of a Poisson count under this clipping rule, including the overflow mass. The learner uses these waiting-time distributions for both training and trials. The probability model still supplies the elementary random draws, the independent context samples and the exact value oracle.

The total budget, including setup and waiting-time work, is bounded by $(2+K+T+2L)^{521}$. The exponent is a coarse polynomial certificate. The online query, arithmetic and allocation bounds describe the instrumented exact-real algorithm.

Third-party proof attribution and license terms appear in `THIRD_PARTY_NOTICE.md` and `THIRD_PARTY_LICENSE.txt`.
