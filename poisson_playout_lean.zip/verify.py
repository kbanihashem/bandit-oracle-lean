from pathlib import Path
import re
import subprocess

root = Path(__file__).resolve().parent
sources = sorted((root / "PoissonAudit").rglob("*.lean")) + [
    root / "PoissonAudit.lean", root / "CheckAxioms.lean"
]
for source in sources:
    term = re.search(r"--|/-|-/|\b(?:sorry|admit|sorryAx|axiom|unsafe|native_decide)\b", source.read_text())
    if term:
        raise SystemExit(f"{source}: unexpected {term.group()!r}")

subprocess.run(["lake", "build"], cwd=root, check=True)
report = subprocess.run(["lake", "env", "lean", "CheckAxioms.lean"], cwd=root, text=True,
                        capture_output=True, check=True).stdout
print(report)
expected = re.findall(r"^#print axioms (\S+)", (root / "CheckAxioms.lean").read_text(), re.M)
allowed = {"propext", "Classical.choice", "Quot.sound"}
for theorem in expected:
    result = re.search(r"'" + re.escape(theorem) + r"' depends on axioms:\s*\[([^\]]*)\]", report)
    if result:
        extra = {a.strip() for a in result[1].split(",") if a.strip()} - allowed
        if extra:
            raise SystemExit(f"{theorem} has unexpected axioms {extra}")
    elif f"'{theorem}' does not depend on any axioms" not in report:
        raise SystemExit(f"Missing axiom report for {theorem}")
print(f"Verified {len(sources)} Lean files and {len(expected)} public results.")
