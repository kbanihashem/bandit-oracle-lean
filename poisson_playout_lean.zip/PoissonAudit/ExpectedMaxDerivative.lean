module

public import PoissonAudit.FiniteMaxDerivative

public section

open MeasureTheory Set Filter
open scoped BigOperators Topology

namespace PoissonAudit

noncomputable section

theorem hasDerivAt_expected_lineMax {Omega P : Type*} [MeasurableSpace Omega]
    [Fintype P] [Nonempty P] [MeasurableSpace P] [MeasurableSingletonClass P]
    (mu : Measure Omega) (A B : P → Omega → ℝ)
    (hAi : ∀ p, Integrable (A p) mu) (hBi : ∀ p, Integrable (B p) mu)
    (hBm : ∀ p, Measurable (B p)) (w : Omega → P) (hwm : Measurable w)
    (hw : ∀ᵐ omega ∂mu, ∀ p, A p omega ≤ A (w omega) omega)
    (hties : ∀ᵐ omega ∂mu, ∀ p, A p omega = A (w omega) omega → B p omega = B (w omega) omega) :
    HasDerivAt (fun t : ℝ => ∫ omega, lineMax (fun p => A p omega) (fun p => B p omega) t ∂mu)
      (∫ omega, B (w omega) omega ∂mu) 0 := by
  classical
  have hFi (t : ℝ) : Integrable
      (fun omega => lineMax (fun p => A p omega) (fun p => B p omega) t) mu := by
    apply integrable_finset_max mu Finset.univ Finset.univ_nonempty
    intro p _
    exact (hAi p).add ((hBi p).const_mul t)
  have hjoint : Measurable (fun v : Omega × P => B v.2 v.1) :=
    measurable_from_prod_countable_left hBm
  have hgrad : AEStronglyMeasurable (fun omega => B (w omega) omega) mu :=
    (hjoint.comp (measurable_id.prodMk hwm)).aestronglyMeasurable
  have hd : ∀ᵐ omega ∂mu, HasDerivAt
      (fun t : ℝ => lineMax (fun p => A p omega) (fun p => B p omega) t)
        (B (w omega) omega) 0 := by
    filter_upwards [hw, hties] with omega hmax htie
    exact hasDerivAt_lineMax _ _ (w omega) hmax htie
  have h := hasDerivAt_integral_of_dominated_loc_of_lip
    (μ := mu) (x₀ := (0 : ℝ)) (s := Set.univ)
    (bound := fun omega => ∑ p, |B p omega|)
    (F := fun t omega => lineMax (fun p => A p omega) (fun p => B p omega) t)
    (F' := fun omega => B (w omega) omega)
    Filter.univ_mem
    (Filter.Eventually.of_forall fun t => (hFi t).aestronglyMeasurable)
    (hFi 0) hgrad
    (Filter.Eventually.of_forall fun omega => (lineMax_lipschitz (fun p => A p omega) (fun p => B p omega)).lipschitzOnWith)
    (integrable_finsetSum _ fun p _ => (hBi p).abs) hd
  exact h.2

end

end PoissonAudit
