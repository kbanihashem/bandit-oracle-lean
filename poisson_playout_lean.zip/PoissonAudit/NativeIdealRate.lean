module
public import PoissonAudit.NativeTuning
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem native_ideal_square_root_regret (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (hK : 0 < K) (costs : List (X → Fin K → ℝ))
    (hT : 0 < costs.length) (hc0 : ∀ c ∈ costs, ∀ x a, 0 ≤ c x a)
    (hc1 : ∀ c ∈ costs, ∀ x a, c x a ≤ 1) :
    ∃ (r : NNReal) (lam B gamma : ℝ) (hB : 1 ≤ B) (hg : 0 < gamma) (hgs : gamma ≤ 1 / 2),
      (∫ path, banditPathLoss costs path + treeBestScore (banditPathTrueScore predict costs (fun _ => 0) path)
        ∂(nativeIdealLaw r D predict lam B gamma hB hK hg (by linarith) costs).toMeasure) ≤
          60 * Real.exp 1 * Real.sqrt ((K : ℝ) * costs.length * Real.log (2 * Fintype.card P)) *
            Real.log (2 * (K : ℝ) * costs.length) := by
  let k : ℝ := K
  let t : ℝ := costs.length
  let z := Real.log (Fintype.card P)
  let L := 2 * Real.log (2 * Fintype.card P)
  let B := k * (t + 1)
  let gamma := 1 / (t + 1)
  let ell := 1 + Real.log B
  let A := Real.sqrt (k * t * L)
  let n := A / (k * ell)
  let lam := 4 * A / k
  have hk : 1 ≤ k := by dsimp [k]; exact_mod_cast hK
  have ht : 1 ≤ t := by dsimp [t]; exact_mod_cast hT
  have hN : (1 : ℝ) ≤ Fintype.card P := by exact_mod_cast Fintype.card_pos (α := P)
  have hN0 : (0 : ℝ) < Fintype.card P := by linarith
  have hz : 0 ≤ z := Real.log_nonneg hN
  have hlog2 : (1 : ℝ) / 2 ≤ Real.log 2 := by
    have h := Real.one_sub_inv_le_log_of_pos (by norm_num : (0 : ℝ) < 2)
    norm_num at h ⊢
    exact h
  have hlog : Real.log (2 * (Fintype.card P : ℝ)) = Real.log 2 + z := by
    dsimp [z]
    exact Real.log_mul (by norm_num) hN0.ne'
  have hL : 1 ≤ L := by dsimp [L]; rw [hlog]; linarith
  have hzL : z ≤ L := by dsimp [L]; rw [hlog]; linarith
  have hs := concrete_tuning hk ht hL hz hzL
  change 0 < n ∧ 0 < lam ∧ 1 ≤ B ∧ 0 < gamma ∧ gamma ≤ 1 / 2 ∧ k / gamma = B ∧
    4 * n * ell = lam ∧ _ at hs
  obtain ⟨hn, hlam, hB, hg, hgs, hcap, hrate, hbound⟩ := hs
  let r : NNReal := Real.toNNReal n
  have hrval : (r : ℝ) = n := Real.coe_toNNReal n hn.le
  have hr : 0 < (r : ℝ) := by rw [hrval]; exact hn
  have hellid : explorationLog K gamma = ell := explorationLog_tuned hK ht
  have hparam : 4 * (r : ℝ) * explorationLog K gamma ≤ lam := by rw [hrval, hellid, hrate]
  have hreg := native_ideal_expected_regret r hr D predict lam B gamma hK hg hgs hlam hB
    (by change k / gamma ≤ B; exact hcap.le) hparam costs hc0 hc1
  refine ⟨r, lam, B, gamma, hB, hg, hgs, ?_⟩
  have hb : 6 * (r : ℝ) * K + lam * K * Real.log B + costs.length * nativeRoundSlack P r K lam B gamma ≤
      10 * Real.exp 1 * A * ell := by
    unfold nativeRoundSlack
    rw [hrval]
    exact hbound
  have hbase : 0 ≤ k * t * Real.log (2 * (Fintype.card P : ℝ)) := by
    have hlog0 : 0 ≤ Real.log (2 * (Fintype.card P : ℝ)) := by rw [hlog]; linarith
    positivity
  let R := Real.sqrt (k * t * Real.log (2 * (Fintype.card P : ℝ)))
  have hR : 0 ≤ R := Real.sqrt_nonneg _
  have hR2 : R ^ 2 = k * t * Real.log (2 * (Fintype.card P : ℝ)) := Real.sq_sqrt hbase
  have hA0 : 0 ≤ A := Real.sqrt_nonneg _
  have hA2 : A ^ 2 = k * t * L := Real.sq_sqrt (by positivity)
  have hAR : A ≤ 2 * R := by dsimp [L] at hA2; nlinarith
  have hell : 0 ≤ ell := by
    have hB' : 0 ≤ Real.log B := Real.log_nonneg hB
    dsimp [ell]
    linarith
  have hlogs : ell ≤ 3 * Real.log (2 * k * t) := tuning_log_bound hk ht
  have hm := mul_le_mul hAR hlogs hell (by positivity : 0 ≤ 2 * R)
  have hfinal := mul_le_mul_of_nonneg_left hm (by positivity : 0 ≤ 10 * Real.exp 1)
  have heq : 10 * Real.exp 1 * (2 * R * (3 * Real.log (2 * k * t))) =
      60 * Real.exp 1 * R * Real.log (2 * k * t) := by ring
  rw [heq] at hfinal
  have hbfinal : 10 * Real.exp 1 * A * ell ≤ 60 * Real.exp 1 * R * Real.log (2 * k * t) := by
    convert! hfinal using 1 <;> ring
  exact hreg.trans (hb.trans hbfinal)
end
end PoissonAudit
