module
public import PoissonAudit.NativeCappedRegret
public import PoissonAudit.FiniteOutcomeLaw
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def nativeCappedLaw (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta gamma : ℝ) (hB : 1 ≤ B) (hK : 0 < K)
    (hg0 : 0 ≤ gamma) (hg1 : gamma ≤ 1) (costs : List (X → Fin K → ℝ)) :
    PMF (outcomePaths (NativeFiniteOutcome K delta) costs) :=
  outcomePathLaw (fun x => (D {x}).toReal) (fun _ => ENNReal.toReal_nonneg) (context_mass_sum D)
    (nativeFiniteOutcomeWeight r D predict lam B eps delta gamma hB)
    (nativeFiniteOutcomeUpdate predict delta gamma)
    (nativeFiniteOutcomeWeight_nonneg r D predict lam B eps delta gamma hB hg0 hg1)
    (nativeFiniteOutcomeWeight_sum r D predict lam B eps delta gamma hB hK) costs (fun _ => 0)

theorem native_capped_expected_regret (r : NNReal) (hr : 0 < (r : ℝ)) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta gamma : ℝ)
    (hlam : 0 < lam) (hB : 1 ≤ B) (heps : 0 < eps) (hd : 0 < delta) (hK : 0 < K)
    (hg : 0 < gamma) (hgsmall : gamma ≤ 1 / 2) (hcap : (K : ℝ) / gamma ≤ B)
    (hlamBudget : 4 * (r : ℝ) * explorationLog K gamma ≤ lam)
    (hepsBudget : eps ≤ lam * delta ^ 2 / (32 * B ^ 2 * ((r : ℝ) + 1) ^ 2 * K))
    (costs : List (X → Fin K → ℝ)) (hc0 : ∀ c ∈ costs, ∀ x a, 0 ≤ c x a)
    (hc1 : ∀ c ∈ costs, ∀ x a, c x a ≤ 1) :
    (∫ path, outcomePathLoss Prod.snd costs path + treeBestScore (outcomePathTrueScore predict costs (fun _ => 0) path)
      ∂(nativeCappedLaw r D predict lam B eps delta gamma hB hK hg.le (by linarith) costs).toMeasure) ≤
        6 * (r : ℝ) * K + lam * K * Real.log B + costs.length * (nativeRoundSlack P r K lam B gamma + (1 + K / gamma) * delta) := by
  unfold nativeCappedLaw
  rw [integral_outcomePath_regret]
  exact native_capped_finite_context_regret r hr D predict lam B eps delta gamma hlam hB heps hd hK hg hgsmall hcap hlamBudget hepsBudget costs hc0 hc1
end
end PoissonAudit
