module

public import PoissonAudit.FiniteMaxDerivative
public import PoissonAudit.Winner
public import Mathlib.Analysis.Calculus.Deriv.Shift
public import Mathlib.MeasureTheory.Integral.DivergenceTheorem

public section

open MeasureTheory Set Filter
open scoped BigOperators Topology

namespace PoissonAudit

noncomputable section

variable {P : Type*} [Fintype P] [Nonempty P] [LinearOrder P]

@[expose] def lineWinner (A B : P → ℝ) (t : ℝ) : P :=
  winner (fun p => A p + t * B p)

theorem hasDerivAt_lineMax_at (A B : P → ℝ) (t : ℝ)
    (hties : ∀ p, A p + t * B p = A (lineWinner A B t) + t * B (lineWinner A B t) →
      B p = B (lineWinner A B t)) :
    HasDerivAt (lineMax A B) (B (lineWinner A B t)) t := by
  have h := hasDerivAt_lineMax (fun p => A p + t * B p) B (lineWinner A B t)
    (winner_maximizes (fun p => A p + t * B p)) hties
  have h' : HasDerivAt (lineMax (fun p => A p + t * B p) B) (B (lineWinner A B t)) (t - t) := by
    simpa using h
  have hc := h'.comp_sub_const t t
  convert! hc using 1
  · funext u
    unfold lineMax
    apply Finset.sup'_congr Finset.univ_nonempty rfl
    intro p _
    ring

@[expose] def lineCrossings (A B : P → ℝ) : Set ℝ :=
  Set.range (fun pq : P × P => (A pq.2 - A pq.1) / (B pq.1 - B pq.2))

theorem lineCrossings_countable (A B : P → ℝ) : (lineCrossings A B).Countable :=
  (Set.finite_range _).countable

theorem hasDerivAt_lineMax_off_crossings (A B : P → ℝ) (t : ℝ)
    (ht : t ∉ lineCrossings A B) :
    HasDerivAt (lineMax A B) (B (lineWinner A B t)) t := by
  apply hasDerivAt_lineMax_at
  intro p heq
  by_contra hne
  apply ht
  refine ⟨(p, lineWinner A B t), ?_⟩
  apply (div_eq_iff (sub_ne_zero.mpr hne)).mpr
  linarith

variable [MeasurableSpace P] [MeasurableSingletonClass P]

theorem measurable_lineWinner (A B : P → ℝ) : Measurable (lineWinner A B) :=
  measurable_winner (fun p t => A p + t * B p) (by intro p; fun_prop)

theorem intervalIntegrable_winner_slope (A B : P → ℝ) (a b : ℝ) :
    IntervalIntegrable (fun t => B (lineWinner A B t)) volume a b := by
  have hm : Measurable (fun t => B (lineWinner A B t)) :=
    (measurable_of_finite B).comp (measurable_lineWinner A B)
  apply (intervalIntegrable_const : IntervalIntegrable (fun _ : ℝ => ∑ p, |B p|) volume a b).mono_fun'
    hm.aestronglyMeasurable.restrict
  filter_upwards [] with t
  rw [Real.norm_eq_abs]
  exact Finset.single_le_sum (f := fun p : P => |B p|) (fun _ _ => abs_nonneg _)
    (Finset.mem_univ (lineWinner A B t))

theorem integral_winner_slope (A B : P → ℝ) (a b : ℝ) :
    (∫ t in a..b, B (lineWinner A B t)) = lineMax A B b - lineMax A B a := by
  exact integral_eq_of_hasDerivAt_off_countable (lineMax A B)
    (fun t => B (lineWinner A B t)) (lineCrossings_countable A B)
    (lineMax_lipschitz A B).continuous.continuousOn
    (fun t ht => hasDerivAt_lineMax_off_crossings A B t ht.2)
    (intervalIntegrable_winner_slope A B a b)

end

end PoissonAudit
