module

public import Mathlib.Analysis.Convex.Function
public import Mathlib.Tactic

public section

namespace PoissonAudit

theorem concave_origin_scaling (g : ℝ → ℝ)
    (hg : ConcaveOn ℝ (Set.Ici 0) g) (hg0 : g 0 = 0)
    {b theta : ℝ} (hb : 0 ≤ b) (ht0 : 0 ≤ theta) (ht1 : theta ≤ 1) :
    theta * g b ≤ g (theta * b) := by
  have h := hg.2 hb (show (0 : ℝ) ∈ Set.Ici 0 by simp)
    ht0 (sub_nonneg.mpr ht1) (show theta + (1 - theta) = 1 by ring)
  simpa [smul_eq_mul, hg0] using h

theorem perspective_ordered (g : ℝ → ℝ) (floor c s t : ℝ)
    (hf : 0 < floor) (hcs : 0 ≤ c) (hc1 : c ≤ 1)
    (hs : floor ≤ s) (hst : s ≤ t)
    (hmono : MonotoneOn g (Set.Ici 0))
    (hbound : ∀ b, 0 ≤ b → g b ≤ b)
    (hscale : ∀ b theta, 0 ≤ b → 0 ≤ theta → theta ≤ 1 →
      theta * g b ≤ g (theta * b)) :
    0 ≤ t * g (c / t) - s * g (c / s) ∧
      t * g (c / t) - s * g (c / s) ≤ (1 / floor) * (t - s) := by
  have hs0 : 0 < s := lt_of_lt_of_le hf hs
  have ht0 : 0 < t := lt_of_lt_of_le hs0 hst
  have hratio : s / t ≤ 1 := (div_le_one ht0).2 hst
  have hid : s / t * (c / s) = c / t := by
    field_simp [ne_of_gt hs0, ne_of_gt ht0]
  have hconc := hscale (c / s) (s / t) (div_nonneg hcs hs0.le)
    (div_nonneg hs0.le ht0.le) hratio
  rw [hid] at hconc
  have hconc' := mul_le_mul_of_nonneg_left hconc ht0.le
  have hmono' : g (c / t) ≤ g (c / s) :=
    hmono (div_nonneg hcs ht0.le) (div_nonneg hcs hs0.le)
      (div_le_div_of_nonneg_left hcs hs0 hst)
  have hsmall : g (c / t) ≤ 1 / floor := by
    calc
      _ ≤ c / t := hbound _ (div_nonneg hcs ht0.le)
      _ ≤ 1 / t := div_le_div_of_nonneg_right hc1 ht0.le
      _ ≤ 1 / floor := one_div_le_one_div_of_le hf (hs.trans hst)
  have hfirst : 0 ≤ t * g (c / t) - s * g (c / s) := by
    have heq : t * (s / t * g (c / s)) = s * g (c / s) := by
      field_simp
    rw [heq] at hconc'
    linarith
  constructor
  · exact hfirst
  · have h1 := mul_le_mul_of_nonneg_left hmono' hs0.le
    have h2 := mul_le_mul_of_nonneg_left hsmall (sub_nonneg.mpr hst)
    calc
      _ ≤ t * g (c / t) - s * g (c / t) := sub_le_sub_left h1 _
      _ = (t - s) * g (c / t) := by ring
      _ ≤ (t - s) * (1 / floor) := h2
      _ = _ := by ring

theorem perspective_lipschitz (g : ℝ → ℝ) (floor c s t : ℝ)
    (hf : 0 < floor) (hc0 : 0 ≤ c) (hc1 : c ≤ 1)
    (hs : floor ≤ s) (ht : floor ≤ t)
    (hmono : MonotoneOn g (Set.Ici 0))
    (hbound : ∀ b, 0 ≤ b → g b ≤ b)
    (hconc : ConcaveOn ℝ (Set.Ici 0) g) (hg0 : g 0 = 0) :
    |s * g (c / s) - t * g (c / t)| ≤ (1 / floor) * |s - t| := by
  have hscale : ∀ b theta : ℝ, 0 ≤ b → 0 ≤ theta → theta ≤ 1 →
      theta * g b ≤ g (theta * b) := by
    intro b theta hb ht0 ht1
    exact concave_origin_scaling g hconc hg0 hb ht0 ht1
  rcases le_total s t with hst | hts
  · obtain ⟨h0, h1⟩ := perspective_ordered g floor c s t hf hc0 hc1 hs hst
      hmono hbound hscale
    rw [abs_of_nonpos (by linarith), abs_of_nonpos (by linarith)]
    linarith
  · obtain ⟨h0, h1⟩ := perspective_ordered g floor c t s hf hc0 hc1 ht hts
      hmono hbound hscale
    rw [abs_of_nonneg h0, abs_of_nonneg (sub_nonneg.mpr hts)]
    exact h1

end PoissonAudit
