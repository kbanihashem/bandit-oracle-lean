module

public import PoissonAudit.CoordinateExperiment

public section

open MeasureTheory Set Filter
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X]
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]
    {n : ℕ}

theorem integrable_experimentMaximum (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin (n + 1)) (sigma : X × Fin (n + 1) → ℝ) (S : P → ℝ) (x : X) :
    Integrable (fun v => Finset.univ.sup' Finset.univ_nonempty (experimentScore predict sigma S x v))
      (insertedExperimentLaw r D (n + 1)) := by
  classical
  exact integrable_finset_max _ Finset.univ Finset.univ_nonempty
    (fun p v => experimentScore predict sigma S x v p)
    (fun p _ => integrable_experimentScore r D predict sigma S x p)

theorem restored_experimentMaximum (predict : P → X → Fin (n + 1))
    (sigma : X × Fin (n + 1) → ℝ) (S : P → ℝ) (x : X) (a : Fin (n + 1)) (s : ℝ)
    (v : ((Fin n → ℝ) × (ℕ × (ℕ → X × (Fin (n + 1) → ℝ)))) × ℝ) :
    Finset.univ.sup' Finset.univ_nonempty
      (experimentScore predict sigma (actionPenaltyScore predict S x a s) x (restoreExperimentEquiv a v)) =
    sampledGroupMaximum (coordinateBaseScore predict sigma S x a v.1)
      (actionPolicyGroup predict x a) (sigma (x, a) * v.2 - s) := by
  apply Finset.sup'_congr Finset.univ_nonempty rfl
  intro p _
  exact restored_experimentScore predict sigma S x a s v p

theorem insertedPotential_eq_thresholdPotential (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin (n + 1)) (sigma : X × Fin (n + 1) → ℝ) (S : P → ℝ)
    (x : X) (a : Fin (n + 1)) (hsigma : 0 < sigma (x, a))
    (hE : (actionPolicyGroup predict x a).Nonempty) (hEc : (actionPolicyGroup predict x a)ᶜ.Nonempty)
    (s : ℝ) :
    insertedPotential r D predict sigma (actionPenaltyScore predict S x a s) x -
      insertedPotential r D predict sigma S x =
      thresholdPotential (experimentRemainderLaw r D n)
        (experimentThreshold predict sigma S x a hE hEc) (sigma (x, a)) s := by
  classical
  let M := fun s v => Finset.univ.sup' Finset.univ_nonempty
    (experimentScore predict sigma (actionPenaltyScore predict S x a s) x v)
  have hM (s : ℝ) : Integrable (M s) (insertedExperimentLaw r D (n + 1)) :=
    integrable_experimentMaximum r D predict sigma _ x
  have heq0 : M 0 = fun v => Finset.univ.sup' Finset.univ_nonempty (experimentScore predict sigma S x v) := by
    unfold M
    rw [actionPenaltyScore_zero]
  have hmp := restoreExperimentEquiv_measurePreserving r D a
  calc
    _ = ∫ v, M s v - M 0 v ∂insertedExperimentLaw r D (n + 1) := by
      rw [integral_sub (hM s) (hM 0), heq0]
      rfl
    _ = ∫ v, M s (restoreExperimentEquiv a v) - M 0 (restoreExperimentEquiv a v)
        ∂(experimentRemainderLaw r D n).prod realLaplace :=
      (hmp.integral_comp' (fun v => M s v - M 0 v)).symm
    _ = _ := by
      apply integral_congr_ae
      filter_upwards [] with v
      unfold M
      rw [restored_experimentMaximum, restored_experimentMaximum]
      simp only [sub_zero]
      exact sampledGroupMaximum_increment _ _ hE hEc _ _ _ hsigma.ne'

theorem restored_experimentWinner (predict : P → X → Fin (n + 1))
    (sigma : X × Fin (n + 1) → ℝ) (S : P → ℝ) (x : X) (a : Fin (n + 1)) (s : ℝ)
    (v : ((Fin n → ℝ) × (ℕ × (ℕ → X × (Fin (n + 1) → ℝ)))) × ℝ) :
    experimentWinner predict sigma (actionPenaltyScore predict S x a s) x (restoreExperimentEquiv a v) =
      winner (fun p => coordinateBaseScore predict sigma S x a v.1 p +
        if p ∈ actionPolicyGroup predict x a then sigma (x, a) * v.2 - s else 0) := by
  apply congrArg winner
  funext p
  exact restored_experimentScore predict sigma S x a s v p

theorem restored_experimentAction_iff (predict : P → X → Fin (n + 1))
    (sigma : X × Fin (n + 1) → ℝ) (S : P → ℝ) (x : X) (a : Fin (n + 1)) (s : ℝ)
    (hsigma : 0 < sigma (x, a))
    (hE : (actionPolicyGroup predict x a).Nonempty) (hEc : (actionPolicyGroup predict x a)ᶜ.Nonempty)
    (v : ((Fin n → ℝ) × (ℕ × (ℕ → X × (Fin (n + 1) → ℝ)))) × ℝ)
    (hv : v.2 ≠ experimentThreshold predict sigma S x a hE hEc v.1 + s / sigma (x, a)) :
    experimentAction predict sigma (actionPenaltyScore predict S x a s) x (restoreExperimentEquiv a v) = a ↔
      experimentThreshold predict sigma S x a hE hEc v.1 + s / sigma (x, a) < v.2 := by
  unfold experimentAction
  rw [restored_experimentWinner, ← mem_actionPolicyGroup]
  exact winner_group_threshold _ _ hE hEc _ _ _ hsigma hv

end

end PoissonAudit
