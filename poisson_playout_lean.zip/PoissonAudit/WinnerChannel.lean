module

public import PoissonAudit.Winner
public import Mathlib.MeasureTheory.Integral.Prod

public section

open MeasureTheory
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {P Z Y : Type*} [Fintype P] [Nonempty P] [LinearOrder P]
  [MeasurableSpace Z] [MeasurableSpace Y]

@[expose] def winningIndicator (score : P → Z → ℝ) (p : P) (z : Z) : ℝ := by
  classical
  exact if IsWinner (fun q => score q z) p then 1 else 0

omit [Fintype P] [Nonempty P] [MeasurableSpace Z] in
theorem winningIndicator_mem_Icc (score : P → Z → ℝ) (p : P) (z : Z) :
    winningIndicator score p z ∈ Set.Icc 0 1 := by
  classical
  unfold winningIndicator
  split <;> norm_num

omit [Nonempty P] in
theorem measurable_winningIndicator (score : P → Z → ℝ)
    (hscore : ∀ p, Measurable (score p)) (p : P) :
    Measurable (winningIndicator score p) := by
  classical
  exact measurable_const.piecewise (measurable_winner_event score hscore p) measurable_const

omit [MeasurableSpace Z] in
theorem sum_winningIndicator (score : P → Z → ℝ) (z : Z) :
    ∑ p, winningIndicator score p z = 1 := by
  classical
  rw [Finset.sum_eq_single (winner (fun p => score p z))]
  · simp only [winningIndicator, winner_spec, ite_true]
  · intro b _ hb
    have hn : ¬IsWinner (fun q => score q z) b := by
      intro h
      exact hb (isWinner_unique h (winner_spec _))
    simp [winningIndicator, hn]
  · simp

@[expose] def winnerChannel (mu : Measure Y) (score : P → Z × Y → ℝ)
    (p : P) (z : Z) : ℝ := ∫ y, winningIndicator score p (z, y) ∂mu

omit [Nonempty P] in
theorem measurable_winnerChannel (mu : Measure Y) [SFinite mu]
    (score : P → Z × Y → ℝ) (hscore : ∀ p, Measurable (score p)) (p : P) :
    Measurable (winnerChannel mu score p) := by
  exact (measurable_winningIndicator score hscore p).stronglyMeasurable.integral_prod_right'.measurable

omit [Nonempty P] in
theorem integrable_winningIndicator_section (mu : Measure Y) [IsFiniteMeasure mu]
    (score : P → Z × Y → ℝ) (hscore : ∀ p, Measurable (score p)) (p : P) (z : Z) :
    Integrable (fun y => winningIndicator score p (z, y)) mu := by
  apply Integrable.of_mem_Icc 0 1
  · exact ((measurable_winningIndicator score hscore p).comp
      (measurable_const.prodMk measurable_id)).aemeasurable
  · exact Filter.Eventually.of_forall (fun y => winningIndicator_mem_Icc score p (z, y))

omit [Nonempty P] in
theorem winnerChannel_mem_Icc (mu : Measure Y) [IsProbabilityMeasure mu]
    (score : P → Z × Y → ℝ) (hscore : ∀ p, Measurable (score p)) (p : P) (z : Z) :
    winnerChannel mu score p z ∈ Set.Icc 0 1 := by
  constructor
  · exact integral_nonneg (fun y => (winningIndicator_mem_Icc score p (z, y)).1)
  · have h := integral_mono (integrable_winningIndicator_section mu score hscore p z)
      (integrable_const (1 : ℝ)) (fun y => (winningIndicator_mem_Icc score p (z, y)).2)
    change (∫ y, winningIndicator score p (z, y) ∂mu) ≤ 1
    simpa only [integral_const, probReal_univ, one_smul] using h

theorem sum_winnerChannel (mu : Measure Y) [IsProbabilityMeasure mu]
    (score : P → Z × Y → ℝ) (hscore : ∀ p, Measurable (score p)) (z : Z) :
    ∑ p, winnerChannel mu score p z = 1 := by
  unfold winnerChannel
  rw [← integral_finsetSum _ (fun p _ => integrable_winningIndicator_section mu score hscore p z)]
  simp only [sum_winningIndicator]
  simp

end

end PoissonAudit
