module
public import PoissonAudit.ScaleMinimizer
public section
open Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section

@[expose] def boxClip (B x : ℝ) : ℝ := min B (max 1 x)

theorem boxClip_mem (B : ℝ) (hB : 1 ≤ B) (x : ℝ) : 1 ≤ boxClip B x ∧ boxClip B x ≤ B := by
  unfold boxClip
  exact ⟨le_min hB (le_max_left _ _), min_le_left _ _⟩

theorem boxClip_distance (B x s : ℝ) (hs : 1 ≤ s) (hsB : s ≤ B) :
    (boxClip B x - s) ^ 2 ≤ (x - s) ^ 2 := by
  unfold boxClip
  rcases le_total x 1 with hx | hx
  · rw [max_eq_left hx, min_eq_right (hs.trans hsB)]
    nlinarith
  · rw [max_eq_right hx]
    rcases le_total x B with hxb | hxb
    · rw [min_eq_right hxb]
    · rw [min_eq_left hxb]
      nlinarith

@[expose] def boxGradientStep {Q : Type*} (sigma v : Q → ℝ) (B eta : ℝ) : Q → ℝ :=
  fun j => boxClip B (sigma j - eta * v j)

@[expose] def weightedSquareDistance {Q : Type*} [Fintype Q] (w s t : Q → ℝ) : ℝ :=
  ∑ j, w j * (s j - t j) ^ 2

theorem boxGradientStep_feasible {Q : Type*} (sigma v : Q → ℝ) (B eta : ℝ) (hB : 1 ≤ B) :
    boxGradientStep sigma v B eta ∈ scaleBox Q B := by
  exact ⟨fun j => (boxClip_mem B hB _).1, fun j => (boxClip_mem B hB _).2⟩

theorem boxGradientStep_descent {Q : Type*} [Fintype Q] (w sigma v s : Q → ℝ)
    (hw : ∀ j, 0 ≤ w j) (B eta : ℝ) (hs : s ∈ scaleBox Q B) :
    weightedSquareDistance w (boxGradientStep sigma v B eta) s ≤
      weightedSquareDistance w sigma s - 2 * eta * (∑ j, w j * v j * (sigma j - s j)) +
        eta ^ 2 * ∑ j, w j * (v j) ^ 2 := by
  classical
  have h := Finset.sum_le_sum (s := Finset.univ) fun j _ => mul_le_mul_of_nonneg_left
    (boxClip_distance B (sigma j - eta * v j) (s j) (hs.1 j) (hs.2 j)) (hw j)
  calc
    _ ≤ ∑ j, w j * (sigma j - eta * v j - s j) ^ 2 := h
    _ = _ := by
      simp only [weightedSquareDistance, Finset.mul_sum, ← Finset.sum_sub_distrib, ← Finset.sum_add_distrib]
      apply Finset.sum_congr rfl
      intro j _
      ring
end
end PoissonAudit
