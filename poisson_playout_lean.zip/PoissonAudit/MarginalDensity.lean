module

public import PoissonAudit.WinnerInformation
public import Mathlib.MeasureTheory.Integral.Prod

public section

open MeasureTheory ProbabilityTheory
open scoped ENNReal

namespace PoissonAudit

noncomputable section

theorem fst_withDensity {A B : Type*} [MeasurableSpace A] [MeasurableSpace B]
    (mu : Measure A) (nu : Measure B) [SigmaFinite mu] [SigmaFinite nu]
    (f : A × B → ENNReal) (hf : Measurable f) :
    ((mu.prod nu).withDensity f).fst =
      mu.withDensity (fun a => ∫⁻ b, f (a, b) ∂nu) := by
  ext E hE
  rw [Measure.fst_apply hE, withDensity_apply _ (measurable_fst hE), withDensity_apply _ hE]
  have he : Prod.fst ⁻¹' E = E ×ˢ (Set.univ : Set B) := by ext p; simp
  rw [he, ← Measure.prod_restrict, Measure.restrict_univ]
  exact lintegral_prod f hf.aemeasurable

@[expose] def eventSectionMass {A B : Type*} [MeasurableSpace B]
    (nu : Measure B) (E : Set (A × B)) (a : A) : ENNReal :=
  ∫⁻ b, E.indicator (fun _ => (1 : ENNReal)) (a, b) ∂nu

set_option maxHeartbeats 1000000 in

theorem fst_conditioned_product {A B : Type*} [MeasurableSpace A] [MeasurableSpace B]
    (mu : Measure A) (nu : Measure B) [IsProbabilityMeasure mu] [IsProbabilityMeasure nu]
    (E : Set (A × B)) (hE : MeasurableSet E) :
    ((mu.prod nu)[|E]).fst =
      mu.withDensity (fun a => (mu.prod nu E)⁻¹ * eventSectionMass nu E a) := by
  have hind : Measurable (E.indicator (fun _ => (1 : ENNReal))) := measurable_const.indicator hE
  have heq : (mu.prod nu)[|E] = (mu.prod nu).withDensity
      (fun p => (mu.prod nu E)⁻¹ * E.indicator (fun _ => (1 : ENNReal)) p) := by
    change _ = (mu.prod nu).withDensity
      (((mu.prod nu E)⁻¹) • E.indicator (fun _ => (1 : ENNReal)))
    rw [withDensity_smul _ hind]
    change _ = ((mu.prod nu E)⁻¹) • (mu.prod nu).withDensity (E.indicator 1)
    rw [withDensity_indicator_one hE]
    rfl
  rw [heq]
  calc
    _ = mu.withDensity (fun a => ∫⁻ b,
        (mu.prod nu E)⁻¹ * E.indicator (fun _ => (1 : ENNReal)) (a, b) ∂nu) :=
      fst_withDensity mu nu _ (by fun_prop)
    _ = _ := by
      congr 1
      funext a
      exact lintegral_const_mul _ (hind.comp (measurable_const.prodMk measurable_id))

end

end PoissonAudit
