module
public import PoissonAudit.NativeIdealRate
public import PoissonAudit.VariationalTranslation
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def nativeRoundFunctional (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B : ℝ) (hB : 1 ≤ B) (S : P → ℝ) (x : X)
    (c q : Fin K → ℝ) : ℝ :=
  (∑ a, q a * c a) + ∑ a, q a * (nativeVariationalValue r D predict lam B hB
    (actionPenaltyScore predict S x a (c a / q a)) - nativeVariationalValue r D predict lam B hB S)

theorem native_probability_perturbation (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B gamma : ℝ) (hlam : 0 ≤ lam) (hB : 1 ≤ B)
    (hK : 0 < K) (hg : 0 < gamma) (S : P → ℝ) (x : X) (c q q' : Fin K → ℝ)
    (hc0 : ∀ a, 0 ≤ c a) (hc1 : ∀ a, c a ≤ 1)
    (hq : ∀ a, gamma / K ≤ q a) (hq' : ∀ a, gamma / K ≤ q' a) :
    |nativeRoundFunctional r D predict lam B hB S x c q - nativeRoundFunctional r D predict lam B hB S x c q'| ≤
      (1 + K / gamma) * ∑ a, |q a - q' a| := by
  classical
  let R := nativeVariationalValue r D predict lam B hB
  let f : Fin K → P → ℝ := fun a p => if predict p x = a then 1 else 0
  have hf0 (a : Fin K) (p : P) : 0 ≤ f a p := by dsimp [f]; split_ifs <;> norm_num
  have hf1 (a : Fin K) (p : P) : f a p ≤ 1 := by dsimp [f]; split_ifs <;> norm_num
  have heq (a : Fin K) (b : ℝ) : actionPenaltyScore predict S x a b = fun p => S p - b * f a p := by
    funext p
    simp only [actionPenaltyScore, actionSlope, f]
    split_ifs <;> ring
  have h := variational_one_step_probability_lipschitz (markedPoolLaw r (contextLaplaceLaw D K))
    (poissonCoefficient predict) (integrable_poissonCoefficient r D predict) (fun j => (D {j.1}).toReal)
    (fun _ => ENNReal.toReal_nonneg) lam B hlam hB S f q q' c (gamma / K)
    (div_pos hg (by exact_mod_cast hK)) hq hq' hc0 hc1 hf0 hf1
  have hphi (v : Fin K → ℝ) : nativeRoundFunctional r D predict lam B hB S x c v =
      (∑ a, v a * c a) - ∑ a, v a * lossDrop R S (f a) (c a / v a) := by
    unfold nativeRoundFunctional
    simp_rw [heq]
    unfold lossDrop
    change (∑ a, v a * c a) + ∑ a, v a * (R (fun p => S p - (c a / v a) * f a p) - R S) = _
    congr 1
    rw [← Finset.sum_neg_distrib]
    apply Finset.sum_congr rfl
    intro a _
    ring
  have hfloor : 1 / (gamma / (K : ℝ)) = K / gamma := by field_simp
  rw [hphi q, hphi q']
  dsimp only at h
  rw [hfloor] at h
  convert! h using 1
end
end PoissonAudit
