module
public import PoissonAudit.NativeCappedLaw
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
universe u v

@[expose] def ContextTranscript (X : Type u) (O : Type v) : ℕ → Type (max u v)
  | 0 => ULift.{max u v} Unit
  | n + 1 => X × O × ContextTranscript X O n

instance contextTranscript_measurableSpace (X : Type u) (O : Type v) [MeasurableSpace X] [MeasurableSpace O]
    (n : ℕ) : MeasurableSpace (ContextTranscript X O n) := by
  induction n with
  | zero => exact inferInstanceAs (MeasurableSpace (ULift.{max u v} Unit))
  | succ n ih => letI := ih; exact inferInstanceAs (MeasurableSpace (X × O × ContextTranscript X O n))

variable {X Y O A P : Type*} [MeasurableSpace X] [MeasurableSpace Y] [MeasurableSingletonClass Y] [Fintype Y]
    [MeasurableSpace O] [MeasurableSingletonClass O] [Fintype O]
    [Fintype A] [Fintype P] [Nonempty P]

@[expose] def transcriptToOutcomePath (f : X → Y) : (costs : List (Y → A → ℝ)) →
    ContextTranscript X O costs.length → outcomePaths O costs
  | [], _ => fun i => Fin.elim0 i
  | _ :: cs, path => (f path.1, path.2.1, transcriptToOutcomePath f cs path.2.2)

theorem measurable_transcriptToOutcomePath (f : X → Y) (hf : Measurable f) (costs : List (Y → A → ℝ)) :
    Measurable (transcriptToOutcomePath (O := O) f costs) := by
  induction costs with
  | nil => exact measurable_const
  | cons c cs ih =>
    let pack : Y × O × outcomePaths O cs → outcomePaths O (c :: cs) := fun z => z
    have hpack : Measurable pack := measurable_of_finite pack
    have hp : Measurable (fun path : ContextTranscript X O (c :: cs).length =>
        (f path.1, path.2.1, transcriptToOutcomePath f cs path.2.2)) :=
      (hf.comp measurable_fst).prodMk ((measurable_fst.comp measurable_snd).prodMk (ih.comp (measurable_snd.comp measurable_snd)))
    exact hpack.comp hp

theorem quotient_branch_map {Z W : Type*} [MeasurableSpace Z] [MeasurableSpace W]
    (D : Measure X) (f : X → Y) (hf : Measurable f) (y : Y) (o : O) (mu : Measure Z) [SFinite mu]
    (g : Z → W) (hg : Measurable g) :
    ((D.restrict (f ⁻¹' {y})).prod mu).map (fun z => (f z.1, o, g z.2)) =
      (D.map f) {y} • (mu.map g).map (fun z => (y, o, z)) := by
  have hpair : Measurable (Prod.map f g) := hf.prodMap hg
  have hembed : Measurable (fun z : Y × W => (z.1, o, z.2)) :=
    measurable_fst.prodMk (measurable_const.prodMk measurable_snd)
  have hmk : Measurable (Prod.mk y : W → Y × W) := measurable_const.prodMk measurable_id
  change ((D.restrict (f ⁻¹' {y})).prod mu).map ((fun z : Y × W => (z.1, o, z.2)) ∘ Prod.map f g) = _
  rw [← Measure.map_map hembed hpair, ← Measure.map_prod_map _ _ hf hg,
    ← Measure.restrict_map hf (measurableSet_singleton y), Measure.restrict_singleton,
    Measure.prod_smul_left, Measure.map_smul _ hembed.aemeasurable, Measure.dirac_prod,
    Measure.map_map hembed hmk]
  rfl

@[expose] def contextTranscriptBranch (n : ℕ) (o : O) (z : X × ContextTranscript X O n) : ContextTranscript X O (n + 1) :=
  (z.1, o, z.2)

theorem measurable_contextTranscriptBranch (n : ℕ) (o : O) : Measurable (contextTranscriptBranch (X := X) n o) := by
  change Measurable (fun z : X × ContextTranscript X O n => (z.1, o, z.2))
  exact measurable_fst.prodMk (measurable_const.prodMk measurable_snd)

@[expose] def liftedContextLaw (D : Measure X) (f : X → Y) (w : (P → ℝ) → Y → O → ℝ)
    (U : (P → ℝ) → Y → (A → ℝ) → O → P → ℝ) :
    (costs : List (Y → A → ℝ)) → (P → ℝ) → Measure (ContextTranscript X O costs.length)
  | [], _ => Measure.dirac (ULift.up ())
  | c :: cs, S => ∑ y, ∑ o, ENNReal.ofReal (w S y o) •
      (((D.restrict (f ⁻¹' {y})).prod (liftedContextLaw D f w U cs (U S y (c y) o))).map
        (contextTranscriptBranch cs.length o))
end
end PoissonAudit
