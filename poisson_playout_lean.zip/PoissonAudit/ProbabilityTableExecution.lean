module
public import PoissonAudit.CountedProgramCertificate
public section
open scoped BigOperators
namespace PoissonAudit
noncomputable section

@[expose] def executeIndicatorSum {K : ℕ} (a : Fin K) : List (Fin K) → ℝ × ℕ
  | [] => (0, 0)
  | b :: bs =>
    let tail := executeIndicatorSum a bs
    (tail.1 + if b = a then 1 else 0, tail.2 + 4)

theorem executeIndicatorSum_correct {K : ℕ} (a : Fin K) (xs : List (Fin K)) :
    executeIndicatorSum a xs = ((xs.map (actionIndicator a)).sum, 4 * xs.length) := by
  induction xs with
  | nil => simp [executeIndicatorSum]
  | cons b bs ih =>
    simp only [executeIndicatorSum, ih, List.map_cons, List.sum_cons, List.length_cons, actionIndicator]
    congr 1
    ring

@[expose] def executeProbabilityTable (K : ℕ) (gamma : ℝ) (m : ℕ) : EmpiricalChoice K m → Vector ℝ K × ℕ
  | none => (Vector.ofFn (fun _ => 1 / K), 4 * K)
  | some u =>
    let runs := Vector.ofFn (fun a : Fin K => executeIndicatorSum a (List.ofFn u))
    (Vector.ofFn (fun a => (1 - gamma) * ((runs.get a).1 / m) + gamma / K),
      ∑ a : Fin K, ((runs.get a).2 + 12))

@[expose] def probabilityTableAllocation (K m : ℕ) : EmpiricalChoice K m → ℕ
  | none => K
  | some _ => 4 * K * (m + 1)

theorem executeProbabilityTable_allocation (K : ℕ) (gamma : ℝ) (m : ℕ) (choice : EmpiricalChoice K m) :
    probabilityTableAllocation K m choice ≤ (executeProbabilityTable K gamma m choice).2 := by
  cases choice with
  | none => dsimp only [probabilityTableAllocation, executeProbabilityTable]; omega
  | some u =>
    dsimp only [probabilityTableAllocation, executeProbabilityTable]
    simp only [vectorGet_ofFn, executeIndicatorSum_correct, List.length_ofFn, Finset.sum_const,
      Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, Nat.cast_id]
    nlinarith

theorem executeProbabilityTable_values (K : ℕ) (gamma : ℝ) (m : ℕ) (choice : EmpiricalChoice K m) :
    vectorValues (executeProbabilityTable K gamma m choice).1 = choiceProbability K gamma m choice := by
  cases choice with
  | none =>
    rw [executeProbabilityTable, vectorValues_ofFn]
    funext a
    rfl
  | some u =>
    dsimp only [executeProbabilityTable]
    rw [vectorValues_ofFn]
    funext a
    simp only [vectorGet_ofFn, executeIndicatorSum_correct, List.map_ofFn, List.sum_ofFn]
    rfl

theorem executeProbabilityTable_work (K : ℕ) (gamma : ℝ) (m : ℕ) (choice : EmpiricalChoice K m) :
    (executeProbabilityTable K gamma m choice).2 ≤ 16 * K * (m + 1) := by
  cases choice with
  | none => dsimp only [executeProbabilityTable]; nlinarith
  | some u =>
    dsimp only [executeProbabilityTable]
    simp only [vectorGet_ofFn, executeIndicatorSum_correct, List.length_ofFn, Finset.sum_const,
      Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, Nat.cast_id]
    nlinarith

theorem executeProbabilityTable_probability (K : ℕ) (hK : 0 < K) (gamma : ℝ) (hg : 0 < gamma)
    (hgs : gamma ≤ 1) (m : ℕ) (hm : 0 < m) (choice : EmpiricalChoice K m) :
    (∀ a, 0 < vectorValues (executeProbabilityTable K gamma m choice).1 a) ∧
      (∑ a, vectorValues (executeProbabilityTable K gamma m choice).1 a) = 1 := by
  rw [executeProbabilityTable_values]
  exact ⟨choiceProbability_pos hK gamma hg hgs m hm choice, choiceProbability_sum hK gamma m hm choice⟩
end
end PoissonAudit
