module
public import PoissonAudit.ScaledLaplaceTest
public import PoissonAudit.MarkedPoisson
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section

@[expose] def consVector {n : ℕ} (v : ℝ × (Fin n → ℝ)) : Fin (n + 1) → ℝ := Fin.cons v.1 v.2

theorem measurable_consVector (n : ℕ) : Measurable (@consVector n) := by
  apply Measurable.of_eval
  intro i
  refine Fin.cases ?_ (fun j => ?_) i
  · exact measurable_fst
  · exact (measurable_pi_apply j).comp measurable_snd

theorem consVector_split_zero {n : ℕ} (z : Fin (n + 1) → ℝ) : consVector (splitMark 0 z) = z := by
  funext i
  refine Fin.cases ?_ (fun j => ?_) i <;> simp [consVector, splitMark]

theorem iid_laplace_cons_integral {n : ℕ} (F : (Fin (n + 1) → ℝ) → ℝ) :
    (∫ z, F z ∂iidPool realLaplace (n + 1)) = ∫ v, F (consVector v) ∂realLaplace.prod (iidPool realLaplace n) := by
  have h := iid_split_integral realLaplace (0 : Fin (n + 1)) (fun v => F (consVector v))
  simpa only [consVector_split_zero] using h

@[expose] def scaleVector {n : ℕ} (s z : Fin n → ℝ) : Fin n → ℝ := fun i => s i * z i

theorem measurable_scaleVector {n : ℕ} (s : Fin n → ℝ) : Measurable (scaleVector s) := by
  apply Measurable.of_eval
  intro i
  exact measurable_const.mul (measurable_pi_apply i)

theorem scaleVector_cons {n : ℕ} (s : Fin (n + 1) → ℝ) (v : ℝ × (Fin n → ℝ)) :
    scaleVector s (consVector v) = consVector (s 0 * v.1, scaleVector (fun i => s i.succ) v.2) := by
  funext i
  refine Fin.cases ?_ (fun j => ?_) i <;> rfl

theorem iid_laplace_vector_test_stability (n : ℕ) (s t : Fin n → ℝ)
    (hs : ∀ i, 1 ≤ s i) (ht : ∀ i, 1 ≤ t i) (F : (Fin n → ℝ) → ℝ)
    (hF : Measurable F) (hbound : ∀ z, |F z| ≤ 1) :
    |(∫ z, F (scaleVector s z) ∂iidPool realLaplace n) -
      (∫ z, F (scaleVector t z) ∂iidPool realLaplace n)| ≤ 2 * ∑ i, |s i - t i| := by
  induction n with
  | zero =>
    have heq : scaleVector s = scaleVector t := by funext z i; exact Fin.elim0 i
    rw [heq]
    simp
  | succ n ih =>
    let H : ℝ × (Fin n → ℝ) → ℝ := fun v => F (consVector (s 0 * v.1, scaleVector (fun i => s i.succ) v.2))
    let T : ℝ × (Fin n → ℝ) → ℝ := fun v => F (consVector (t 0 * v.1, scaleVector (fun i => s i.succ) v.2))
    let G : ℝ × (Fin n → ℝ) → ℝ := fun v => F (consVector (t 0 * v.1, scaleVector (fun i => t i.succ) v.2))
    have hHm : Measurable H := hF.comp ((measurable_consVector n).comp
      ((measurable_const.mul measurable_fst).prodMk ((measurable_scaleVector _).comp measurable_snd)))
    have hTm : Measurable T := hF.comp ((measurable_consVector n).comp
      ((measurable_const.mul measurable_fst).prodMk ((measurable_scaleVector _).comp measurable_snd)))
    have hGm : Measurable G := hF.comp ((measurable_consVector n).comp
      ((measurable_const.mul measurable_fst).prodMk ((measurable_scaleVector _).comp measurable_snd)))
    have hHi : Integrable H (realLaplace.prod (iidPool realLaplace n)) := Integrable.of_bound hHm.aestronglyMeasurable 1
      (Filter.Eventually.of_forall fun v => by simpa only [Real.norm_eq_abs] using hbound _)
    have hTi : Integrable T (realLaplace.prod (iidPool realLaplace n)) := Integrable.of_bound hTm.aestronglyMeasurable 1
      (Filter.Eventually.of_forall fun v => by simpa only [Real.norm_eq_abs] using hbound _)
    have hGi : Integrable G (realLaplace.prod (iidPool realLaplace n)) := Integrable.of_bound hGm.aestronglyMeasurable 1
      (Filter.Eventually.of_forall fun v => by simpa only [Real.norm_eq_abs] using hbound _)
    have hhead (y : Fin n → ℝ) : |(∫ x, H (x, y) ∂realLaplace) - (∫ x, T (x, y) ∂realLaplace)| ≤ 2 * |s 0 - t 0| := by
      let f := fun z : ℝ => F (consVector (z, scaleVector (fun i => s i.succ) y))
      have hm : Measurable f := hF.comp ((measurable_consVector n).comp (measurable_id.prodMk measurable_const))
      exact scaled_laplace_test_stability (hs 0) (ht 0) f hm (fun z => hbound _)
    have htail (x : ℝ) : |(∫ y, T (x, y) ∂iidPool realLaplace n) - (∫ y, G (x, y) ∂iidPool realLaplace n)| ≤
        2 * ∑ i : Fin n, |s i.succ - t i.succ| := by
      let f := fun z : Fin n → ℝ => F (consVector (t 0 * x, z))
      have hm : Measurable f := hF.comp ((measurable_consVector n).comp (measurable_const.prodMk measurable_id))
      exact ih (fun i => s i.succ) (fun i => t i.succ) (fun i => hs i.succ) (fun i => ht i.succ) f hm (fun z => hbound _)
    have h := product_test_difference_bound realLaplace (iidPool realLaplace n) H T G hHi hTi hGi
      (2 * |s 0 - t 0|) (2 * ∑ i : Fin n, |s i.succ - t i.succ|) hhead htail
    rw [iid_laplace_cons_integral, iid_laplace_cons_integral]
    simp only [scaleVector_cons]
    change |(∫ v, H v ∂realLaplace.prod (iidPool realLaplace n)) -
      (∫ v, G v ∂realLaplace.prod (iidPool realLaplace n))| ≤ _
    rw [Fin.sum_univ_succ]
    nlinarith
end
end PoissonAudit
