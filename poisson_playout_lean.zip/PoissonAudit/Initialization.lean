module
public import PoissonAudit.CeilingSearch
public import PoissonAudit.ManuscriptOracle
public section
namespace PoissonAudit
noncomputable section

structure InitializedPlan where
  params : BanditParameters
  iterations : ℕ
  trials : ℕ
  cap : ℕ
  step : ℝ

@[expose] def specifiedPlan (K T : ℕ) (L : ℝ) : InitializedPlan :=
  let p := manuscriptPlan K T L
  let J := paperIterations K p.r p.lam p.B p.eps
  let m := paperTrials K p.delta
  ⟨p,J,m,paperCap p.r (J+m) p.delta,paperStep K p.r p.lam p.B p.eps⟩

private def instruction {α : Type} (v : α) : StateM ℕ α := fun w => (v,w+1)

private def searchInstruction (x : ℝ) : StateM ℕ ℕ := fun w =>
  let result := ceilingSearch x 0
  (result.1,w+result.2)

def initializePlan (K T : ℕ) (L : ℝ) : StateM ℕ InitializedPlan := do
  let k ← instruction ((K : ℝ))
  let t ← instruction ((T : ℝ))
  let t1 ← instruction (t+1)
  let gamma ← instruction (1/t1)
  let B ← instruction (k*t1)
  let kt ← instruction (k*t)
  let ktL ← instruction (kt*L)
  let A ← instruction (Real.sqrt ktL)
  let logB ← instruction (Real.log B)
  let ell ← instruction (1+logB)
  let den ← instruction (k*ell)
  let rate ← instruction (A/den)
  let r ← instruction (Real.toNNReal rate)
  let num ← instruction (4*A)
  let lam ← instruction (num/k)
  let kg ← instruction (k/gamma)
  let onekg ← instruction (1+kg)
  let dDen ← instruction (t*onekg)
  let delta ← instruction (1/dDen)
  let delta2 ← instruction (delta^2)
  let eNum ← instruction (lam*delta2)
  let B2 ← instruction (B^2)
  let eDen0 ← instruction (32*B2)
  let r1 ← instruction ((r : ℝ)+1)
  let eDen ← instruction (eDen0*r1)
  let eps ← instruction (eNum/eDen)
  let sqrtK ← instruction (Real.sqrt k)
  let diameter ← instruction (B*sqrtK)
  let r2 ← instruction ((r : ℝ)^2)
  let rTerm ← instruction (4*r2)
  let lam2 ← instruction (lam^2)
  let lamTerm ← instruction (2*lam2)
  let gTerm ← instruction (rTerm+lamTerm)
  let gSq ← instruction (k*gTerm)
  let G ← instruction (Real.sqrt gSq)
  let D2 ← instruction (diameter^2)
  let GG ← instruction (G^2)
  let jNum ← instruction (D2*GG)
  let eps2 ← instruction (eps^2)
  let jArg ← instruction (jNum/eps2)
  let j0 ← searchInstruction (jArg)
  let J ← instruction (max 1 j0)
  let mNum ← instruction (16*k)
  let mArg ← instruction (mNum/delta2)
  let m ← searchInstruction (mArg)
  let Jreal ← instruction ((J : ℝ))
  let sqrtJ ← instruction (Real.sqrt Jreal)
  let etaDen ← instruction (G*sqrtJ)
  let eta ← instruction (diameter/etaDen)
  let count ← instruction (J+m)
  let countReal ← instruction ((count : ℝ))
  let cNum ← instruction (4*countReal)
  let cArg ← instruction (cNum/delta)
  let cLog ← instruction (Real.log cArg)
  let e1 ← instruction (Real.exp 1 - 1)
  let cTerm ← instruction (e1*(r : ℝ))
  let cTotal ← instruction (cTerm+cLog)
  let cap ← searchInstruction (cTotal)
  return ⟨⟨r,lam,B,gamma,eps,delta⟩,J,m,cap,eta⟩

private theorem searchInstruction_eq (x : ℝ) :
    searchInstruction x = fun w => (⌈x⌉₊,w+(2*⌈x⌉₊+1)) := by
  funext w
  simp [searchInstruction,ceilingSearch_spec x 0 (Nat.zero_le _)]

private def jArgument (K : ℕ) (p : BanditParameters) :=
  (paperDiameter K p.B)^2 * (paperGradientSize K p.r p.lam)^2 / p.eps^2

def setupWork (K T : ℕ) (L : ℝ) :=
  let a := specifiedPlan K T L
  2*(⌈jArgument K a.params⌉₊ + a.trials + a.cap) + 58

theorem initializePlan_spec (K T : ℕ) (L : ℝ) :
    (initializePlan K T L).run 0 = (specifiedPlan K T L,setupWork K T L) := by
  unfold initializePlan
  simp only [searchInstruction_eq]
  simp only [StateT.run,StateT.bind,StateT.pure,bind,pure,instruction,StateT.instMonad]
  apply Prod.ext
  · rfl
  dsimp [setupWork,specifiedPlan,manuscriptPlan,jArgument,paperIterations,paperTrials,paperCap,paperStep,paperGradientSize,paperDiameter]
  omega

def totalWork (K T : ℕ) (L : ℝ) :=
  let a := specifiedPlan K T L
  let waits := (a.iterations+a.trials)*(a.cap+1)
  ((initializePlan K T L).run 0).2 +
    T*(onlineWorkBudget T K a.cap a.iterations a.trials + 8*waits)

theorem totalWork_polynomial (K T : ℕ) (hK : 2 ≤ K) (hT : 0 < T) (L : ℝ) (hL : 1/2 ≤ L) :
    PowerBound (2+(K : ℝ)+T+2*L) 521 (totalWork K T L) := by
  let a := specifiedPlan K T L
  let J := a.iterations
  let m := a.trials
  let cap := a.cap
  let W := onlineWorkBudget T K cap J m
  let waits := (J+m)*(cap+1)
  have hJ : 1 ≤ J := le_max_left ..
  have hn : ⌈jArgument K a.params⌉₊ ≤ J := le_max_right ..
  have hw := capped_waiting_time_budget K cap J m (by omega)
  have hwW : waits ≤ W := by unfold W onlineWorkBudget; dsimp [waits]; omega
  have hcm : J+m ≤ waits := by
    dsimp [waits]; nlinarith
  have hcap : cap ≤ waits := by
    dsimp [waits]
    have := Nat.mul_le_mul_right (cap+1) (show 1 ≤ J+m by omega)
    omega
  have hs : setupWork K T L ≤ 58+4*W := by
    change 2*(⌈jArgument K a.params⌉₊ + m + cap)+58 ≤ _
    omega
  have htw : W ≤ T*W := by simpa using Nat.mul_le_mul_right W hT
  have hscaled := Nat.mul_le_mul_left T hwW
  have hcharge : totalWork K T L ≤ 58+13*(T*W) := by
    unfold totalWork
    rw [initializePlan_spec]
    change setupWork K T L + T*(W+8*waits) ≤ _
    nlinarith only [hs,htw,hscaled]
  let H := 2+(K : ℝ)+T+2*L
  have hH : 2 ≤ H := by dsimp [H]; linarith [Nat.cast_nonneg (α := ℝ) K,Nat.cast_nonneg (α := ℝ) T]
  have hp : PowerBound H 512 ((T*W : ℕ) : ℝ) := by
    rw [Nat.cast_mul]
    exact manuscript_online_budget K T hK hT L hL
  have hc := powerBound_const hH 6
  have hw' := powerBound_scale hH hp 4
  have hb := powerBound_add hH hc hw'
  have hh : ((totalWork K T L : ℕ) : ℝ) ≤ 58+13*((T*W : ℕ) : ℝ) := by exact_mod_cast hcharge
  have hh' : ((totalWork K T L : ℕ) : ℝ) ≤ (2 : ℝ)^6 + 2^4*((T*W : ℕ) : ℝ) := by
    linarith [Nat.cast_nonneg (α := ℝ) (T*W)]
  exact powerBound_mono (by linarith) (powerBound_le hb (Nat.cast_nonneg _) hh') (by decide)

end
end PoissonAudit
