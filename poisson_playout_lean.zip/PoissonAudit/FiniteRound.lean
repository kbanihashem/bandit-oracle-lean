module
public import PoissonAudit.NativeCappedLaw
public import PoissonAudit.Optimization
public import PoissonAudit.PoissonCap
public import PoissonAudit.FiniteChoiceMixture
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]


@[expose] def paperDiameter (K : ℕ) (B : ℝ) := B * Real.sqrt K
@[expose] def paperGradientSize (K : ℕ) (r : NNReal) (lam : ℝ) := Real.sqrt (K * (4 * (r : ℝ)^2 + 2 * lam^2))
@[expose] def paperIterations (K : ℕ) (r : NNReal) (lam B eps : ℝ) :=
  max 1 ⌈(paperDiameter K B)^2 * (paperGradientSize K r lam)^2 / eps^2⌉₊
@[expose] def paperStep (K : ℕ) (r : NNReal) (lam B eps : ℝ) :=
  paperDiameter K B / (paperGradientSize K r lam * Real.sqrt (paperIterations K r lam B eps))
@[expose] def paperTrials (K : ℕ) (δ : ℝ) := ⌈16 * (K : ℝ) / δ^2⌉₊
@[expose] def paperCap (r : NNReal) (count : ℕ) (δ : ℝ) := ⌈(Real.exp 1 - 1) * (r : ℝ) + Real.log (4 * count / δ)⌉₊

theorem paperTrials_pos (K : ℕ) (hk : 0 < K) (δ : ℝ) (hd : 0 < δ) : 0 < paperTrials K δ :=
  Nat.ceil_pos.mpr (by positivity)

theorem paper_scale_accuracy (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eps : ℝ)
    (hlam : 0 < lam) (hB : 1 ≤ B) (heps : 0 < eps) (hK : 0 < K)
    (s : NativeScaleBox X K B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun q => (D {q.1}).toReal) lam B) (scaleBox (X × Fin K) B) s.val)
    :
    (∫ state, weightedSquareDistance (fun q => (D {q.1}).toReal) state.2.val s.val
      ∂nativeSGDStateLaw r D predict S lam B (paperStep K r lam B eps) hB (paperIterations K r lam B eps)) ≤
        2 * B ^ 2 * eps / lam := by
  let mu := nativeSGDStateLaw r D predict S lam B (paperStep K r lam B eps) hB (paperIterations K r lam B eps)
  let dist := fun state : NativeSGDState X K B => weightedSquareDistance (fun q => (D {q.1}).toReal) state.2.val s.val
  let gap := fun state : NativeSGDState X K B => nativeBoxObjective r D predict S lam B state.2 - nativeBoxObjective r D predict S lam B s
  have hd : Continuous dist := by
    apply continuous_finsetSum
    intro q _
    exact continuous_const.mul ((((continuous_apply q).comp (continuous_subtype_val.comp continuous_snd)).sub continuous_const).pow 2)
  have hg : Continuous gap := ((continuous_nativeBoxObjective r D predict S lam B hB).comp continuous_snd).sub continuous_const
  have hdi : Integrable dist mu := integrable_continuous_nativeSGDState B mu _ hd
  have hgi : Integrable gap mu := integrable_continuous_nativeSGDState B mu _ hg
  have hp (state : NativeSGDState X K B) : lam / (2 * B ^ 2) * dist state ≤ gap state := by
    have h := scaleObjective_quadratic_growth (markedPoolLaw r (contextLaplaceLaw D K)) S
      (poissonCoefficient predict) (integrable_poissonCoefficient r D predict) (fun q => (D {q.1}).toReal)
      (fun _ => ENNReal.toReal_nonneg) lam B hlam.le hB s.val state.2.val s.property state.2.property hmin
    have heq : (∑ q : X × Fin K, (D {q.1}).toReal * (s.val q - state.2.val q) ^ 2) = dist state := by
      apply Finset.sum_congr rfl
      intro q _
      change (D {q.1}).toReal * (s.val q - state.2.val q) ^ 2 = (D {q.1}).toReal * (state.2.val q - s.val q) ^ 2
      ring
    rw [heq] at h
    exact h
  have h := integral_mono (hdi.const_mul (lam / (2 * B ^ 2))) hgi hp
  change (∫ state, lam / (2 * B ^ 2) * dist state ∂mu) ≤ ∫ state, gap state ∂mu at h
  rw [integral_const_mul] at h
  have he := paper_sgd_objective_accuracy r D predict S lam B eps hlam hB heps hK s
  change (∫ state, gap state ∂mu) ≤ eps at he
  have ht := h.trans he
  have hB0 : 0 < B := by linarith
  apply (le_div_iff₀ hlam).mpr
  have hm := mul_le_mul_of_nonneg_left ht (by positivity : 0 ≤ 2 * B ^ 2)
  field_simp at hm
  nlinarith

theorem paper_mean_action_accuracy (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eps delta : ℝ)
    (hlam : 0 < lam) (hB : 1 ≤ B) (heps : 0 < eps) (hd : 0 < delta) (hK : 0 < K)
    (s : NativeScaleBox X K B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun q => (D {q.1}).toReal) lam B) (scaleBox (X × Fin K) B) s.val)
    (hepsBudget : eps ≤ lam * delta ^ 2 / (32 * B ^ 2 * ((r : ℝ) + 1) ^ 2 * K))
    :
    (∫ state, nativeMeanActionError r D predict S state.2.val s.val
      ∂nativeSGDStateLaw r D predict S lam B (paperStep K r lam B eps) hB (paperIterations K r lam B eps)) ≤ delta / 2 := by
  let mu := nativeSGDStateLaw r D predict S lam B (paperStep K r lam B eps) hB (paperIterations K r lam B eps)
  let dist := fun state : NativeSGDState X K B => weightedSquareDistance (fun q => (D {q.1}).toReal) state.2.val s.val
  let C : ℝ := 4 * ((r : ℝ) + 1) ^ 2 * K / delta
  have hC : 0 ≤ C := by dsimp [C]; positivity
  have hdcont : Continuous dist := by
    apply continuous_finsetSum
    intro q _
    exact continuous_const.mul ((((continuous_apply q).comp (continuous_subtype_val.comp continuous_snd)).sub continuous_const).pow 2)
  have hdi : Integrable dist mu := integrable_continuous_nativeSGDState B mu _ hdcont
  have hp (state : NativeSGDState X K B) : nativeMeanActionError r D predict S state.2.val s.val ≤ delta / 4 + C * dist state :=
    native_action_error_young r D predict S state.2.val s.val state.2.property.1 s.property.1 delta hd
  have hi := integral_mono (integrable_nativeMeanActionError_state r D predict S B s mu)
    ((integrable_const (delta / 4)).add (hdi.const_mul C)) hp
  change _ ≤ ∫ state, delta / 4 + C * dist state ∂mu at hi
  rw [integral_add (integrable_const _) (hdi.const_mul C), integral_const, probReal_univ, one_smul, integral_const_mul] at hi
  have hs := paper_scale_accuracy r D predict S lam B eps hlam hB heps hK s hmin
  change (∫ state, dist state ∂mu) ≤ 2 * B ^ 2 * eps / lam at hs
  have hm := mul_le_mul_of_nonneg_left hs hC
  have hscalar : C * (2 * B ^ 2 * eps / lam) ≤ delta / 4 := by
    have hB0 : 0 < B := by linarith
    have hc0 : 0 < (r : ℝ) + 1 := by positivity
    have hden : 0 < 32 * B ^ 2 * ((r : ℝ) + 1) ^ 2 * (K : ℝ) := by positivity
    have he := (le_div_iff₀ hden).mp hepsBudget
    apply (le_div_iff₀ (by norm_num : (0 : ℝ) < 4)).mpr
    have heq : (C * (2 * B ^ 2 * eps / lam) * 4) * (delta * lam) =
        32 * B ^ 2 * ((r : ℝ) + 1) ^ 2 * K * eps := by dsimp [C]; field_simp <;> ring
    have hscaled : (C * (2 * B ^ 2 * eps / lam) * 4) * (delta * lam) ≤ delta * (delta * lam) := by
      rw [heq]
      nlinarith only [he]
    exact (mul_le_mul_iff_of_pos_right (mul_pos hd hlam)).mp hscaled
  linarith
theorem native_overflow_mass (r : NNReal) (D : Measure X) [IsProbabilityMeasure D] (cap : ℕ) :
    (insertedExperimentLaw r D K).real (nativeOverflowEvent cap) =
    (ProbabilityTheory.poissonMeasure r).real {n : ℕ | cap < n} := by
  let E := {n : ℕ | cap < n}
  have hE : MeasurableSet E := .of_discrete
  let f := E.indicator (fun _ : ℕ => (1 : ℝ))
  have hi : Integrable f (ProbabilityTheory.poissonMeasure r) := (integrable_const _).indicator hE
  rw [← integral_nativeOverflowStatistic]
  have hfun (v : NativeNoise X K) : boolStatistic (nativeOverflowBool cap v) = f v.2.1 := by
    by_cases h : cap < v.2.1 <;> simp [boolStatistic, nativeOverflowBool, E, f, Set.indicator, h]
  simp_rw [hfun]
  change (∫ v : NativeNoise X K, f v.2.1 ∂(laplaceMeasure K).prod (markedPoolLaw r (contextLaplaceLaw D K))) = _
  unfold markedPoolLaw
  rw [probability_integral_snd (laplaceMeasure K) _ _ (hi.comp_fst (markSequence (contextLaplaceLaw D K)))]
  change (∫ v, f v.1 ∂(ProbabilityTheory.poissonMeasure r).prod (markSequence (contextLaplaceLaw D K))) = _
  rw [probability_integral_fst _ _ _ hi]
  simp [f, integral_indicator_const _ hE, E]

theorem paper_native_construction_overflow_budget (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ) (hB : 1 ≤ B) (cap : ℕ) (J : ℕ) :
    (∫ state : NativeFlaggedState X K B, boolStatistic state.2
      ∂nativeFlaggedStateLaw r D predict S lam B eta hB cap J) ≤ J * ((ProbabilityTheory.poissonMeasure r).real {n : ℕ | cap < n}) := by
  induction J with
  | zero => simp [nativeFlaggedStateLaw, boolStatistic]
  | succ j ih =>
    let mu := nativeFlaggedStateLaw r D predict S lam B eta hB cap j
    let noise := insertedExperimentLaw r D K
    let F := fun v : NativeFlaggedState X K B × NativeNoise X K => nativeFlaggedTransition r predict S lam B eta hB cap j v.1 v.2
    have hF : Measurable F := measurable_nativeFlaggedTransition r predict S lam B eta hB cap j
    have hiOld : Integrable (fun state : NativeFlaggedState X K B => boolStatistic state.2) mu := integrable_flagStatistic B mu
    have hiTail : Integrable (fun v : NativeNoise X K => boolStatistic (nativeOverflowBool cap v)) noise := integrable_nativeOverflowStatistic r D cap
    have hiNew : Integrable (fun v => boolStatistic (F v).2) (mu.prod noise) := by
      apply Integrable.of_bound ((measurable_of_finite boolStatistic).comp (measurable_snd.comp hF)).aestronglyMeasurable 1
      filter_upwards [] with v
      change ‖boolStatistic (F v).2‖ ≤ 1
      rw [Real.norm_eq_abs, abs_of_nonneg (boolStatistic_mem _).1]
      exact (boolStatistic_mem _).2
    have hp (v : NativeFlaggedState X K B × NativeNoise X K) : boolStatistic (F v).2 ≤
        boolStatistic v.1.2 + boolStatistic (nativeOverflowBool cap v.2) := by
      change boolStatistic (v.1.2 || nativeOverflowBool cap v.2) ≤ _
      cases h1 : v.1.2 <;> cases h2 : nativeOverflowBool cap v.2 <;> norm_num [boolStatistic]
    have h := integral_mono hiNew ((hiOld.comp_fst noise).add (hiTail.comp_snd mu)) hp
    change (∫ v, boolStatistic (F v).2 ∂mu.prod noise) ≤
      ∫ v, boolStatistic v.1.2 + boolStatistic (nativeOverflowBool cap v.2) ∂mu.prod noise at h
    rw [integral_add (hiOld.comp_fst noise) (hiTail.comp_snd mu),
      probability_integral_fst mu noise _ hiOld, probability_integral_snd mu noise _ hiTail,
      integral_nativeOverflowStatistic r D cap] at h
    rw [native_overflow_mass] at h
    change (∫ state, boolStatistic state.2 ∂mu) ≤ _ at ih
    change (∫ state, boolStatistic state.2 ∂(mu.prod noise).map F) ≤ _
    rw [integral_map (f := fun state : NativeFlaggedState X K B => boolStatistic state.2) hF.aemeasurable ((measurable_of_finite boolStatistic).comp measurable_snd).aestronglyMeasurable]
    simp only [Nat.cast_add, Nat.cast_one]
    nlinarith
theorem paper_native_enriched_trial_overflow_budget (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (cap m : ℕ) :
    (∫ u, boolStatistic (trialAnyOverflow u) ∂iidPool (nativeEnrichedLaw r D predict sigma S x cap).toMeasure m) ≤
      m * ((ProbabilityTheory.poissonMeasure r).real {n : ℕ | cap < n}) := by
  have h := integral_mono (μ := iidPool (nativeEnrichedLaw r D predict sigma S x cap).toMeasure m)
    Integrable.of_finite Integrable.of_finite trialAnyOverflow_bound
  rw [integral_finsetSum _ (fun _ _ => Integrable.of_finite)] at h
  have he (i : Fin m) : (∫ u : Fin m → Fin K × Bool, boolStatistic (u i).2 ∂iidPool (nativeEnrichedLaw r D predict sigma S x cap).toMeasure m) =
      (insertedExperimentLaw r D K).real (nativeOverflowEvent cap) := by
    rw [integral_iid_eval _ m i (fun b : Fin K × Bool => boolStatistic b.2) (measurable_of_finite _),
      nativeEnrichedLaw_overflow_mean r D predict sigma S x cap]
  simp only [he, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul] at h
  simpa only [native_overflow_mass] using h
theorem paper_native_capped_reference_error (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta gamma : ℝ) (hB : 1 ≤ B)
    (hK : 0 < K) (hg0 : 0 ≤ gamma) (hg1 : gamma ≤ 1) (cap J m : ℕ) (hm : 0 < m)
    (x : X) (ref : Fin K → ℝ) (href : ∀ a, 0 ≤ ref a) (hres : ∑ a, ref a = 1) :
    (∫ choice, ∑ a, |choiceProbability K gamma m choice a - ref a|
      ∂(nativeCappedChoiceLaw r D predict S lam B eta hB cap J m x).toMeasure) ≤
        K * Real.sqrt (1 / m) +
          (∫ state : NativeFlaggedState X K B, ∑ a, |nativeBanditProbability r D predict state.1.2.val S gamma x a - ref a|
            ∂nativeFlaggedStateLaw r D predict S lam B eta hB cap J) +
              2 * ((J + m : ℕ) * ((ProbabilityTheory.poissonMeasure r).real {n : ℕ | cap < n})) := by
  let mu := nativeFlaggedStateLaw r D predict S lam B eta hB cap J
  let err := fun state : NativeFlaggedState X K B => ∑ a, |nativeBanditProbability r D predict state.1.2.val S gamma x a - ref a|
  have hei : Integrable err mu := integrable_nativeMixtureError_flagged r D predict S B gamma x ref mu
  have hp (state : NativeFlaggedState X K B) :
      (∫ u, ∑ a, |choiceProbability K gamma m (cappedOutcomeChoice (state.2, u)) a - ref a|
        ∂iidPool (nativeEnrichedLaw r D predict state.1.2.val S x cap).toMeasure m) ≤
          K * Real.sqrt (1 / m) + err state + 2 * (boolStatistic state.2 + m * ((ProbabilityTheory.poissonMeasure r).real {n : ℕ | cap < n})) := by
    let nu := iidPool (nativeEnrichedLaw r D predict state.1.2.val S x cap).toMeasure m
    have h := integral_mono (μ := nu) Integrable.of_finite Integrable.of_finite
      (fun u => capped_choice_error hK gamma ref href hres state.2 u)
    change _ ≤ ∫ u, (∑ a, |empiricalMixture K gamma m (fun i => (u i).1) a - ref a|) +
      2 * (boolStatistic state.2 + boolStatistic (trialAnyOverflow u)) ∂nu at h
    rw [integral_add Integrable.of_finite Integrable.of_finite, integral_const_mul,
      integral_add (integrable_const _) Integrable.of_finite, integral_const, probReal_univ, one_smul] at h
    have he := native_enriched_reference_error r D predict state.1.2.val S gamma hg0 hg1 x cap m hm ref
    have hb := paper_native_enriched_trial_overflow_budget r D predict state.1.2.val S x cap m
    change _ ≤ K * Real.sqrt (1 / m) + err state at he
    change (∫ u, boolStatistic (trialAnyOverflow u) ∂nu) ≤ _ at hb
    change (∫ u, ∑ a, |empiricalMixture K gamma m (fun i => (u i).1) a - ref a| ∂nu) ≤ _ at he
    linarith
  rw [integral_nativeCappedChoiceLaw]
  have hi := integral_mono (nativeCappedKernel_test_integrable r D predict S lam B eta hB cap J m x
    (fun choice => ∑ a, |choiceProbability K gamma m choice a - ref a|))
    (((integrable_const _).add hei).add (((integrable_flagStatistic B mu).add (integrable_const _)).const_mul 2)) hp
  change _ ≤ ∫ state, K * Real.sqrt (1 / m) + err state + 2 * (boolStatistic state.2 + m * ((ProbabilityTheory.poissonMeasure r).real {n : ℕ | cap < n})) ∂mu at hi
  rw [integral_add (f := fun state => (K : ℝ) * Real.sqrt (1 / m) + err state)
    (g := fun state : NativeFlaggedState X K B => 2 * (boolStatistic state.2 + m * ((ProbabilityTheory.poissonMeasure r).real {n : ℕ | cap < n})))
    ((integrable_const _).add hei) (((integrable_flagStatistic B mu).add (integrable_const _)).const_mul 2),
    integral_add (f := fun _ => (K : ℝ) * Real.sqrt (1 / m)) (g := err) (integrable_const _) hei, integral_const_mul 2 (fun state : NativeFlaggedState X K B => boolStatistic state.2 + m * ((ProbabilityTheory.poissonMeasure r).real {n : ℕ | cap < n})),
    integral_add (f := fun state : NativeFlaggedState X K B => boolStatistic state.2)
      (g := fun _ => (m : ℝ) * ((ProbabilityTheory.poissonMeasure r).real {n : ℕ | cap < n})) (integrable_flagStatistic B mu) (integrable_const _)] at hi
  simp only [integral_const, probReal_univ, one_smul] at hi
  have hb := paper_native_construction_overflow_budget r D predict S lam B eta hB cap J
  change (∫ state, boolStatistic state.2 ∂mu) ≤ _ at hb
  change _ ≤ K * Real.sqrt (1 / m) + (∫ state, err state ∂mu) + _
  simp only [Nat.cast_add]
  nlinarith
theorem paper_native_capped_mean_reference_error (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta gamma : ℝ) (hB : 1 ≤ B)
    (hK : 0 < K) (hg0 : 0 ≤ gamma) (hg1 : gamma ≤ 1) (cap J m : ℕ) (hm : 0 < m)
    (s : NativeScaleBox X K B) :
    (∫ x, ∫ choice, ∑ a, |choiceProbability K gamma m choice a - nativeBanditProbability r D predict s.val S gamma x a|
      ∂(nativeCappedChoiceLaw r D predict S lam B eta hB cap J m x).toMeasure ∂D) ≤
        K * Real.sqrt (1 / m) +
          (∫ state : NativeSGDState X K B, nativeMeanActionError r D predict S state.2.val s.val
            ∂nativeSGDStateLaw r D predict S lam B eta hB J) +
              2 * ((J + m : ℕ) * ((ProbabilityTheory.poissonMeasure r).real {n : ℕ | cap < n})) := by
  let mu := nativeFlaggedStateLaw r D predict S lam B eta hB cap J
  let err := fun x (state : NativeFlaggedState X K B) => ∑ a,
    |nativeBanditProbability r D predict state.1.2.val S gamma x a - nativeBanditProbability r D predict s.val S gamma x a|
  have hei (x : X) : Integrable (err x) mu := integrable_nativeMixtureError_flagged r D predict S B gamma x _ mu
  have hp (x : X) := paper_native_capped_reference_error r D predict S lam B eta gamma hB hK hg0 hg1 cap J m hm x
    (nativeBanditProbability r D predict s.val S gamma x)
    (nativeBanditProbability_nonneg r D predict s.val S gamma hg0 hg1 x)
    (nativeBanditProbability_sum r D predict s.val S gamma hK x)
  have hi := integral_mono (μ := D) Integrable.of_finite Integrable.of_finite hp
  change _ ≤ ∫ x, K * Real.sqrt (1 / m) + (∫ state, err x state ∂mu) + 2 * ((J + m : ℕ) * ((ProbabilityTheory.poissonMeasure r).real {n : ℕ | cap < n})) ∂D at hi
  rw [integral_add Integrable.of_finite (integrable_const _),
    integral_add (integrable_const _) Integrable.of_finite] at hi
  simp only [integral_const, probReal_univ, one_smul] at hi
  rw [finite_integral_swap D mu err hei] at hi
  have hproj := nativeFlaggedStateLaw_projection r D predict S lam B eta hB cap J
  have hmean := integrable_nativeMeanActionError_state r D predict S B s
    (nativeSGDStateLaw r D predict S lam B eta hB J)
  have hmeanFlag := hproj.integrable_comp_of_integrable hmean
  have herrInt : Integrable (fun state : NativeFlaggedState X K B => ∫ x, err x state ∂D) mu := by
    have he (state : NativeFlaggedState X K B) : (∫ x, err x state ∂D) = ∑ x, (D {x}).toReal * err x state := by
      rw [integral_fintype Integrable.of_finite]; rfl
    simp_rw [he]
    exact integrable_finsetSum _ (fun x _ => (hei x).const_mul _)
  have herr := integral_mono herrInt hmeanFlag (fun state => native_mean_mixture_contract r D predict S state.1.2.val s.val gamma hg0 hg1)
  have hmap := integral_map hproj.measurable.aemeasurable
    (f := fun state : NativeSGDState X K B => nativeMeanActionError r D predict S state.2.val s.val)
    (by rw [hproj.map_eq]; exact hmean.aestronglyMeasurable)
  rw [hproj.map_eq] at hmap
  change (∫ state, nativeMeanActionError r D predict S state.2.val s.val ∂nativeSGDStateLaw r D predict S lam B eta hB J) =
    ∫ state : NativeFlaggedState X K B, nativeMeanActionError r D predict S state.1.2.val s.val ∂mu at hmap
  change (∫ state, ∫ x, err x state ∂D ∂mu) ≤
    (∫ state : NativeFlaggedState X K B, nativeMeanActionError r D predict S state.1.2.val s.val ∂mu) at herr
  rw [← hmap] at herr
  linarith


end
end PoissonAudit
