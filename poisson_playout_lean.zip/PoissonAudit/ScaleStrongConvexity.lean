module

public import PoissonAudit.LogStrongConvexity
public import PoissonAudit.VariationalConvexity

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {Omega P Q : Type*} [MeasurableSpace Omega]
    [Fintype P] [Nonempty P] [Fintype Q]

theorem scaleObjective_strong_jensen (mu : Measure Omega) [IsFiniteMeasure mu]
    (S : P → ℝ) (V : Omega → P → Q → ℝ)
    (hV : ∀ p j, Integrable (fun omega => V omega p j) mu)
    (w : Q → ℝ) (hw : ∀ j, 0 ≤ w j) (lam B : ℝ) (hlam : 0 ≤ lam) (hB : 1 ≤ B)
    (s t : Q → ℝ) (hs : s ∈ scaleBox Q B) (ht : t ∈ scaleBox Q B)
    (a b : ℝ) (ha : 0 ≤ a) (hb : 0 ≤ b) (hab : a + b = 1) :
    scaleObjective mu S V w lam B (a • s + b • t) ≤
      a * scaleObjective mu S V w lam B s + b * scaleObjective mu S V w lam B t -
        lam * a * b / (2 * B ^ 2) * ∑ j, w j * (s j - t j) ^ 2 := by
  classical
  have hpot := (convex_affinePoolPotential mu S V hV).2 (mem_univ s) (mem_univ t) ha hb hab
  have hsum := Finset.sum_le_sum (s := Finset.univ) fun j _ =>
    mul_le_mul_of_nonneg_left (log_ratio_strong_jensen hB ⟨hs.1 j, hs.2 j⟩ ⟨ht.1 j, ht.2 j⟩ ha hb hab) (hw j)
  have heq : (∑ j, w j * (a * Real.log (B / s j) + b * Real.log (B / t j) -
      a * b / (2 * B ^ 2) * (s j - t j) ^ 2)) =
      a * (∑ j, w j * Real.log (B / s j)) + b * (∑ j, w j * Real.log (B / t j)) -
        a * b / (2 * B ^ 2) * ∑ j, w j * (s j - t j) ^ 2 := by
    rw [Finset.mul_sum, Finset.mul_sum, Finset.mul_sum,
      ← Finset.sum_add_distrib, ← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro j _
    ring
  rw [heq] at hsum
  have hpen := mul_le_mul_of_nonneg_left hsum hlam
  unfold scaleObjective scalePenalty
  simp only [Pi.add_apply, Pi.smul_apply, smul_eq_mul] at *
  ring_nf at hpen hpot ⊢
  linarith

theorem scaleObjective_quadratic_growth (mu : Measure Omega) [IsFiniteMeasure mu]
    (S : P → ℝ) (V : Omega → P → Q → ℝ)
    (hV : ∀ p j, Integrable (fun omega => V omega p j) mu)
    (w : Q → ℝ) (hw : ∀ j, 0 ≤ w j) (lam B : ℝ) (hlam : 0 ≤ lam) (hB : 1 ≤ B)
    (s t : Q → ℝ) (hs : s ∈ scaleBox Q B) (ht : t ∈ scaleBox Q B)
    (hmins : IsMinOn (scaleObjective mu S V w lam B) (scaleBox Q B) s) :
    lam / (2 * B ^ 2) * (∑ j, w j * (s j - t j) ^ 2) ≤
      scaleObjective mu S V w lam B t - scaleObjective mu S V w lam B s := by
  let C := lam / (2 * B ^ 2) * ∑ j, w j * (s j - t j) ^ 2
  let gap := scaleObjective mu S V w lam B t - scaleObjective mu S V w lam B s
  have hgap : 0 ≤ gap := sub_nonneg.mpr (hmins ht)
  change C ≤ gap
  by_contra hbad
  have hCg : gap < C := lt_of_not_ge hbad
  have hC : 0 < C := lt_of_le_of_lt hgap hCg
  let theta := (C - gap) / (2 * C)
  have htheta : 0 < theta := div_pos (sub_pos.mpr hCg) (by positivity)
  have htheta1 : theta < 1 := by
    apply (div_lt_one (by positivity : 0 < 2 * C)).mpr
    linarith
  have hthetaeq : 2 * C * theta = C - gap := by
    dsimp [theta]
    field_simp
  have hcombo : (1 - theta) • s + theta • t ∈ scaleBox Q B :=
    (convex_Icc (1 : Q → ℝ) (fun _ => B)) hs ht (by linarith) htheta.le (by ring)
  have hmin := hmins hcombo
  change scaleObjective mu S V w lam B s ≤
    scaleObjective mu S V w lam B ((1 - theta) • s + theta • t) at hmin
  have hJ := scaleObjective_strong_jensen mu S V hV w hw lam B hlam hB s t hs ht
    (1 - theta) theta (by linarith) htheta.le (by ring)
  have hdiff : theta * (C * (1 - theta)) ≤ theta * gap := by
    dsimp [C, gap]
    ring_nf at hJ ⊢
    linarith [hJ, hmin]
  have hcancel := (mul_le_mul_iff_of_pos_left htheta).mp hdiff
  nlinarith

end

end PoissonAudit
