module

public import PoissonAudit.NativeActionEntropy
public import PoissonAudit.CurvatureEntropyAlgebra

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def oldCurvatureRatio (r : NNReal) (D : Measure X)
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) : ℝ :=
  if 0 < experimentProbability r D predict sigma S x a then
    experimentBeta r D predict sigma S x a / (sigma (x, a) * experimentProbability r D predict sigma S x a) else 0

theorem native_oldCurvatureRatio_bound (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (lam B : ℝ) (hlam : 0 < lam) (hB : 1 ≤ B)
    (hsigma : sigma ∈ scaleBox (X × Fin K) B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun j => (D {j.1}).toReal) lam B) (scaleBox (X × Fin K) B) sigma)
    (x : X) (a : Fin K) (hx : 0 < (D {x}).toReal) :
    oldCurvatureRatio r D predict sigma S x a ≤
      (4 * (r : ℝ) / lam) * actionEntropyCharge r D predict sigma S x a + 1 / B := by
  have hs : 0 < sigma (x, a) := by have h : (1 : ℝ) ≤ sigma (x, a) := hsigma.1 (x, a); linarith
  have hBp : 0 < B := by linarith
  have hD : 0 ≤ actionEntropyCharge r D predict sigma S x a := actionEntropyCharge_nonneg r D predict sigma S x a
  have hr : 0 ≤ (r : ℝ) := r.property
  have hcharge : 0 ≤ (4 * (r : ℝ) / lam) * actionEntropyCharge r D predict sigma S x a := by positivity
  unfold oldCurvatureRatio
  split_ifs with hp
  · by_cases hcap : sigma (x, a) = B
    · have hb := experimentBeta_le_probability r D predict sigma S x a
      have hratio : experimentBeta r D predict sigma S x a /
          (sigma (x, a) * experimentProbability r D predict sigma S x a) ≤ 1 / B := by
        rw [hcap]
        apply (div_le_iff₀ (mul_pos hBp hp)).mpr
        have heq : (1 / B) * (B * experimentProbability r D predict sigma S x a) =
            experimentProbability r D predict sigma S x a := by field_simp
        rwa [heq]
      linarith
    · have hinterior : sigma (x, a) < B := lt_of_le_of_ne (hsigma.2 (x, a)) hcap
      have hfo : lam ≤ (r : ℝ) * sigma (x, a) * experimentAlpha r D predict sigma S x a := by
        rw [experimentAlpha_eq_insertedAlpha]
        exact poisson_minimizer_first_order_lower r D predict sigma S lam B hB hsigma hmin (x, a) hinterior hx
      have hc := curvature_from_first_order hs hlam (experimentBeta_nonneg r D predict sigma S x a hs) hp hfo
      have hb := mul_le_mul_of_nonneg_left
        (native_alpha_beta_entropy_bound r D predict sigma S x a hs hp) (div_nonneg hr hlam.le)
      have heq : ((r : ℝ) / lam) * (4 * actionEntropyCharge r D predict sigma S x a) =
          (4 * (r : ℝ) / lam) * actionEntropyCharge r D predict sigma S x a := by ring
      rw [heq] at hb
      have h := hc.trans hb
      linarith [div_nonneg (by norm_num : (0 : ℝ) ≤ 1) hBp.le]
  · positivity

theorem ae_positive_context_mass (D : Measure X) [IsProbabilityMeasure D] :
    ∀ᵐ x ∂D, 0 < (D {x}).toReal := by
  apply ae_iff_of_countable.mpr
  intro x hx
  exact ENNReal.toReal_pos hx (measure_ne_top _ _)

theorem native_expected_old_curvature (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (lam B : ℝ) (hlam : 0 < lam) (hB : 1 ≤ B)
    (hsigma : sigma ∈ scaleBox (X × Fin K) B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun j => (D {j.1}).toReal) lam B) (scaleBox (X × Fin K) B) sigma) :
    (∫ x, ∑ a, oldCurvatureRatio r D predict sigma S x a ∂D) ≤
      4 * Real.log (Fintype.card P) / lam + K / B := by
  have hpoint : ∀ᵐ x ∂D, (∑ a, oldCurvatureRatio r D predict sigma S x a) ≤
      (4 * (r : ℝ) / lam) * (∑ a, actionEntropyCharge r D predict sigma S x a) + K / B := by
    filter_upwards [ae_positive_context_mass D] with x hx
    have h := Finset.sum_le_sum (s := Finset.univ) fun a _ => native_oldCurvatureRatio_bound r D predict sigma S lam B hlam hB hsigma hmin x a hx
    convert! h using 1
    rw [Finset.sum_add_distrib, ← Finset.mul_sum]
    simp [div_eq_mul_inv]
  have h := integral_mono_ae (μ := D) (f := fun x => ∑ a, oldCurvatureRatio r D predict sigma S x a)
    (g := fun x => (4 * (r : ℝ) / lam) * (∑ a, actionEntropyCharge r D predict sigma S x a) + K / B)
    Integrable.of_finite Integrable.of_finite hpoint
  rw [integral_add Integrable.of_finite (integrable_const _), integral_const_mul] at h
  simp only [integral_const, probReal_univ, one_smul] at h
  have hb := mul_le_mul_of_nonneg_left (poisson_actionEntropyCharge_budget r D predict sigma S) (div_nonneg (by norm_num : (0 : ℝ) ≤ 4) hlam.le)
  have heq : (4 / lam) * ((r : ℝ) * (∫ x, ∑ a, actionEntropyCharge r D predict sigma S x a ∂D)) =
      (4 * (r : ℝ) / lam) * (∫ x, ∑ a, actionEntropyCharge r D predict sigma S x a ∂D) := by ring
  rw [heq] at hb
  ring_nf at h hb ⊢
  linarith

end

end PoissonAudit
