module
public import PoissonAudit.LaplaceVectorStability
public import PoissonAudit.EmpiricalOutcomeLaw
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {Omega A : Type*} [MeasurableSpace Omega] [Fintype A] [MeasurableSpace A] [MeasurableSingletonClass A]

theorem integral_finite_outcome_test (mu : Measure Omega) [IsProbabilityMeasure mu]
    (W : Omega → A) (hW : Measurable W) (g : A → ℝ) :
    (∫ z, g (W z) ∂mu) = ∑ a, outcomeMass mu W a * g a := by
  have hmp := outcome_measurePreserving mu W hW
  have h := integral_map hmp.measurable.aemeasurable (f := g)
    (by rw [hmp.map_eq]; exact (measurable_of_finite g).aestronglyMeasurable)
  rw [hmp.map_eq, integral_actionPMF] at h
  exact h.symm

theorem outcome_l1_of_bounded_tests (mu nu : Measure Omega) [IsProbabilityMeasure mu] [IsProbabilityMeasure nu]
    (W V : Omega → A) (hW : Measurable W) (hV : Measurable V) (C : ℝ)
    (h : ∀ g : A → ℝ, (∀ a, |g a| ≤ 1) → |(∫ z, g (W z) ∂mu) - (∫ z, g (V z) ∂nu)| ≤ C) :
    (∑ a, |outcomeMass mu W a - outcomeMass nu V a|) ≤ C := by
  classical
  let g := fun a => if 0 ≤ outcomeMass mu W a - outcomeMass nu V a then (1 : ℝ) else -1
  have hg (a : A) : |g a| ≤ 1 := by dsimp [g]; split_ifs <;> norm_num
  have ht := h g hg
  rw [integral_finite_outcome_test mu W hW, integral_finite_outcome_test nu V hV] at ht
  have heq : (∑ a, outcomeMass mu W a * g a) - (∑ a, outcomeMass nu V a * g a) =
      ∑ a, |outcomeMass mu W a - outcomeMass nu V a| := by
    rw [← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro a _
    dsimp [g]
    split_ifs with ha
    · rw [abs_of_nonneg ha]
      ring
    · rw [abs_of_neg (lt_of_not_ge ha)]
      ring
  rw [heq, abs_of_nonneg (Finset.sum_nonneg fun a _ => abs_nonneg _)] at ht
  exact ht

theorem iid_laplace_outcome_l1_stability (n : ℕ) (s t : Fin n → ℝ)
    (hs : ∀ i, 1 ≤ s i) (ht : ∀ i, 1 ≤ t i) (W : (Fin n → ℝ) → A) (hW : Measurable W) :
    (∑ a, |outcomeMass (iidPool realLaplace n) (fun z => W (scaleVector s z)) a -
      outcomeMass (iidPool realLaplace n) (fun z => W (scaleVector t z)) a|) ≤ 2 * ∑ i, |s i - t i| := by
  apply outcome_l1_of_bounded_tests _ _ _ _ (hW.comp (measurable_scaleVector s)) (hW.comp (measurable_scaleVector t))
  intro g hg
  exact iid_laplace_vector_test_stability n s t hs ht (fun z => g (W z))
    ((measurable_of_finite g).comp hW) (fun z => hg (W z))
end
end PoissonAudit
