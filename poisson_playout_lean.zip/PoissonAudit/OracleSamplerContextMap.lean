module
public import PoissonAudit.OracleSamplerQueries
public import PoissonAudit.ContextMapLaw
public section
open MeasureTheory Set
namespace PoissonAudit
noncomputable section
variable {X Y : Type*} {K : ℕ}

theorem nativeTapeCountsBounded_context_map (f : X → Y) (cap j : ℕ) (tape : NativeNoiseTape X K j) :
    nativeTapeCountsBounded cap j (mapNativeNoiseTape f j tape) ↔ nativeTapeCountsBounded cap j tape := by
  induction j with
  | zero => rfl
  | succ j ih => simp only [nativeTapeCountsBounded, mapNativeNoiseTape, mapNativeNoise, ih]

theorem replayTrialAction_context_map (f : X → Y) (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracleX : List (CostExample X K) → ℝ)
    (oracleY : List (CostExample Y K) → ℝ) (hcompat : ∀ Q, oracleY (mapCostQuery f Q) = oracleX Q)
    (fallback : Fin K) (records : List (ReplayRecord X K)) (x : X) (v : NativeNoise X K) :
    replayTrialAction r lam B eta (mapCostQuery f history) oracleY fallback (records.map (mapReplayRecord f)) (f x) (mapNativeNoise f v) =
      replayTrialAction r lam B eta history oracleX fallback records x v := by
  let currentX := fun y => (replayAt r lam B eta history oracleX fallback records y).2
  let currentY := fun y => (replayAt r lam B eta (mapCostQuery f history) oracleY fallback (records.map (mapReplayRecord f)) y).2
  have hcurrent (y : X) : currentY (f y) = currentX y :=
    congrArg Prod.snd (replayAt_context_map f r lam B eta history oracleX oracleY hcompat fallback records y)
  have hrec := makeReplayRecord_context_map f currentX currentY hcurrent v
  change valueOracleAction oracleY fallback
    (mapCostQuery f history ++ (makeReplayRecord currentY (mapNativeNoise f v)).2) (f x)
    (fun a => currentY (f x) a * v.1 a) = valueOracleAction oracleX fallback
      (history ++ (makeReplayRecord currentX v).2) x (fun a => currentX x a * v.1 a)
  rw [hrec, hcurrent]
  change valueOracleAction oracleY fallback (mapCostQuery f history ++ mapCostQuery f (makeReplayRecord currentX v).2) (f x) _ = _
  rw [← mapCostQuery_append]
  exact valueOracleAction_context_map f oracleX oracleY hcompat fallback _ x _

theorem cappedOracleChoice_context_map (f : X → Y) (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracleX : List (CostExample X K) → ℝ)
    (oracleY : List (CostExample Y K) → ℝ) (hcompat : ∀ Q, oracleY (mapCostQuery f Q) = oracleX Q)
    (fallback : Fin K) (cap J m : ℕ) (tape : NativeNoiseTape X K J) (trials : Fin m → NativeNoise X K) (x : X) :
    cappedOracleChoice r lam B eta (mapCostQuery f history) oracleY fallback cap J m (mapNativeNoiseTape f J tape)
      (fun i => mapNativeNoise f (trials i)) (f x) = cappedOracleChoice r lam B eta history oracleX fallback cap J m tape trials x := by
  classical
  unfold cappedOracleChoice
  simp only [nativeTapeCountsBounded_context_map, mapNativeNoise]
  split_ifs
  · congr 1
    funext i
    rw [buildReplayRecords_context_map f r lam B eta history oracleX oracleY hcompat]
    exact replayTrialAction_context_map f r lam B eta history oracleX oracleY hcompat fallback _ x (trials i)
  · rfl
end
end PoissonAudit
