module

public import PoissonAudit.ScaleMinimizer
public import Mathlib.Analysis.Convex.SpecificFunctions.Basic

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

theorem log_ratio_convex {B s t a b : ℝ} (hB : 0 < B) (hs : 0 < s) (ht : 0 < t)
    (ha : 0 ≤ a) (hb : 0 ≤ b) (hab : a + b = 1) :
    Real.log (B / (a * s + b * t)) ≤ a * Real.log (B / s) + b * Real.log (B / t) := by
  have hm : 0 < a * s + b * t :=
    (convex_Ioi (0 : ℝ)) hs ht ha hb hab
  have hlog := strictConcaveOn_log_Ioi.concaveOn.2 hs ht ha hb hab
  simp only [smul_eq_mul] at hlog
  rw [Real.log_div hB.ne' hm.ne', Real.log_div hB.ne' hs.ne', Real.log_div hB.ne' ht.ne']
  have heq : (a + b) * Real.log B = Real.log B := by rw [hab, one_mul]
  nlinarith [heq]

theorem log_ratio_strictConvex {B s t a b : ℝ} (hB : 0 < B) (hs : 0 < s) (ht : 0 < t)
    (hst : s ≠ t) (ha : 0 < a) (hb : 0 < b) (hab : a + b = 1) :
    Real.log (B / (a * s + b * t)) < a * Real.log (B / s) + b * Real.log (B / t) := by
  have hm : 0 < a * s + b * t := by positivity
  have hlog := strictConcaveOn_log_Ioi.2 hs ht hst ha hb hab
  simp only [smul_eq_mul] at hlog
  rw [Real.log_div hB.ne' hm.ne', Real.log_div hB.ne' hs.ne', Real.log_div hB.ne' ht.ne']
  have heq : (a + b) * Real.log B = Real.log B := by rw [hab, one_mul]
  nlinarith [heq]

noncomputable section

variable {Omega P Q : Type*} [MeasurableSpace Omega]
    [Fintype P] [Nonempty P] [Fintype Q]

theorem strictConvex_scalePenalty (w : Q → ℝ) (hw : ∀ j, 0 < w j)
    (lam B : ℝ) (hlam : 0 < lam) (hB : 1 ≤ B) :
    StrictConvexOn ℝ (scaleBox Q B) (scalePenalty w lam B) := by
  classical
  refine ⟨convex_Icc 1 (fun _ => B), ?_⟩
  intro s hs t ht hst a b ha hb hab
  have hB0 : 0 < B := by linarith
  have hs0 (j : Q) : 0 < s j := by have h : (1 : ℝ) ≤ s j := hs.1 j; linarith
  have ht0 (j : Q) : 0 < t j := by have h : (1 : ℝ) ≤ t j := ht.1 j; linarith
  have hle (j : Q) : w j * Real.log (B / (a * s j + b * t j)) ≤
      a * (w j * Real.log (B / s j)) + b * (w j * Real.log (B / t j)) := by
    have h := mul_le_mul_of_nonneg_left (log_ratio_convex hB0 (hs0 j) (ht0 j) ha.le hb.le hab) (hw j).le
    convert h using 1
    ring
  obtain ⟨j, hj⟩ : ∃ j, s j ≠ t j := by
    by_contra h
    apply hst
    funext j
    exact not_not.mp (not_exists.mp h j)
  have hlt : w j * Real.log (B / (a * s j + b * t j)) <
      a * (w j * Real.log (B / s j)) + b * (w j * Real.log (B / t j)) := by
    have h := mul_lt_mul_of_pos_left (log_ratio_strictConvex hB0 (hs0 j) (ht0 j) hj ha hb hab) (hw j)
    convert h using 1
    ring
  have hsum := Finset.sum_lt_sum (s := Finset.univ) (fun j _ => hle j) ⟨j, Finset.mem_univ j, hlt⟩
  have h := mul_lt_mul_of_pos_left hsum hlam
  unfold scalePenalty
  simp only [Pi.add_apply, Pi.smul_apply, smul_eq_mul]
  convert h using 1
  simp only [Finset.sum_add_distrib, ← Finset.mul_sum]
  ring

theorem scale_minimizer_unique (mu : Measure Omega) [IsFiniteMeasure mu]
    (S : P → ℝ) (V : Omega → P → Q → ℝ)
    (hV : ∀ p j, Integrable (fun omega => V omega p j) mu)
    (w : Q → ℝ) (hw : ∀ j, 0 < w j) (lam B : ℝ) (hlam : 0 < lam) (hB : 1 ≤ B)
    (s t : Q → ℝ) (hs : s ∈ scaleBox Q B) (ht : t ∈ scaleBox Q B)
    (hmins : IsMinOn (scaleObjective mu S V w lam B) (scaleBox Q B) s)
    (hmint : IsMinOn (scaleObjective mu S V w lam B) (scaleBox Q B) t) : s = t := by
  have hc := (convex_affinePoolPotential mu S V hV).subset (by intro _ _; trivial)
    (convex_Icc 1 (fun _ => B))
  have hstrict := hc.add_strictConvexOn (strictConvex_scalePenalty w hw lam B hlam hB)
  exact hstrict.eq_of_isMinOn hmins hmint hs ht

end

end PoissonAudit
