module
public import PoissonAudit.ScaledLaplaceDensity
public section
open MeasureTheory Set
namespace PoissonAudit
noncomputable section

theorem scaled_laplace_test_stability {u v : ℝ} (hu : 1 ≤ u) (hv : 1 ≤ v)
    (F : ℝ → ℝ) (hF : Measurable F) (hbound : ∀ y, |F y| ≤ 1) :
    |(∫ z, F (u * z) ∂realLaplace) - (∫ z, F (v * z) ∂realLaplace)| ≤ 2 * |u - v| := by
  have hu0 : 0 < u := by linarith
  have hv0 : 0 < v := by linarith
  have hfi := (integrable_scaledLaplaceDensity hu0).bdd_mul hF.aestronglyMeasurable
    (Filter.Eventually.of_forall fun y => by simpa only [Real.norm_eq_abs] using hbound y)
  have hgi := (integrable_scaledLaplaceDensity hv0).bdd_mul hF.aestronglyMeasurable
    (Filter.Eventually.of_forall fun y => by simpa only [Real.norm_eq_abs] using hbound y)
  have hd := ((integrable_scaledLaplaceDensity hu0).sub (integrable_scaledLaplaceDensity hv0)).abs
  rw [integral_scaled_laplace_test hu0, integral_scaled_laplace_test hv0, ← integral_sub hfi hgi]
  calc
    _ ≤ ∫ y, |F y * scaledLaplaceDensity u y - F y * scaledLaplaceDensity v y| := abs_integral_le_integral_abs
    _ ≤ ∫ y, |scaledLaplaceDensity u y - scaledLaplaceDensity v y| := by
      apply integral_mono (hfi.sub hgi).abs hd
      intro y
      change |F y * scaledLaplaceDensity u y - F y * scaledLaplaceDensity v y| ≤ |scaledLaplaceDensity u y - scaledLaplaceDensity v y|
      rw [← mul_sub, abs_mul]
      exact mul_le_of_le_one_left (abs_nonneg _) (hbound y)
    _ ≤ _ := scaledLaplaceDensity_l1 hu hv

theorem probability_integral_difference_bound {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) [IsProbabilityMeasure mu] (f g : Omega → ℝ)
    (hf : Integrable f mu) (hg : Integrable g mu) (C : ℝ) (h : ∀ x, |f x - g x| ≤ C) :
    |(∫ x, f x ∂mu) - (∫ x, g x ∂mu)| ≤ C := by
  rw [← integral_sub hf hg]
  calc
    _ ≤ ∫ x, |f x - g x| ∂mu := abs_integral_le_integral_abs
    _ ≤ ∫ _x, C ∂mu := integral_mono (hf.sub hg).abs (integrable_const _) h
    _ = C := by simp only [integral_const, probReal_univ, one_smul]

theorem product_test_difference_bound {Omega Lambda : Type*}
    [MeasurableSpace Omega] [MeasurableSpace Lambda]
    (mu : Measure Omega) (nu : Measure Lambda) [IsProbabilityMeasure mu] [IsProbabilityMeasure nu]
    (H T G : Omega × Lambda → ℝ) (hH : Integrable H (mu.prod nu))
    (hT : Integrable T (mu.prod nu)) (hG : Integrable G (mu.prod nu)) (U V : ℝ)
    (hhead : ∀ y, |(∫ x, H (x, y) ∂mu) - (∫ x, T (x, y) ∂mu)| ≤ U)
    (htail : ∀ x, |(∫ y, T (x, y) ∂nu) - (∫ y, G (x, y) ∂nu)| ≤ V) :
    |(∫ z, H z ∂mu.prod nu) - (∫ z, G z ∂mu.prod nu)| ≤ U + V := by
  have h1 : |(∫ z, H z ∂mu.prod nu) - (∫ z, T z ∂mu.prod nu)| ≤ U := by
    rw [integral_prod_symm H hH, integral_prod_symm T hT]
    exact probability_integral_difference_bound nu _ _ hH.integral_prod_right hT.integral_prod_right U hhead
  have h2 : |(∫ z, T z ∂mu.prod nu) - (∫ z, G z ∂mu.prod nu)| ≤ V := by
    rw [integral_prod T hT, integral_prod G hG]
    exact probability_integral_difference_bound mu _ _ hT.integral_prod_left hG.integral_prod_left V htail
  exact (abs_sub_le _ _ _).trans (add_le_add h1 h2)
end
end PoissonAudit
