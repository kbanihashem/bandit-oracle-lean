module
public import PoissonAudit.FiniteRegret
public import PoissonAudit.FiniteChoiceMixture
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

private theorem paper_concrete_tuning {k t L z : ℝ} (hk : 1 ≤ k) (ht : 1 ≤ t) (hAinput : 1 ≤ k * t * L)
    (hz : 0 ≤ z) (hzL : z ≤ L) :
    let B := k * (t + 1)
    let gamma := 1 / (t + 1)
    let ell := 1 + Real.log B
    let A := Real.sqrt (k * t * L)
    let r := A / (k * ell)
    let lam := 4 * A / k
    0 < r ∧ 0 < lam ∧ 1 ≤ B ∧ 0 < gamma ∧ gamma ≤ 1 / 2 ∧ k / gamma = B ∧
      4 * r * ell = lam ∧
      (6 * r * k + lam * k * Real.log B +
        t * (gamma + (Real.exp 1 - 2) / (1 - gamma) * (4 * z / lam + k / B) +
          2 * Real.exp 1 * z / r) ≤ 10 * Real.exp 1 * A * ell) := by
  let B := k * (t + 1)
  let gamma := 1 / (t + 1)
  let ell := 1 + Real.log B
  let A := Real.sqrt (k * t * L)
  let r := A / (k * ell)
  let lam := 4 * A / k
  have hk0 : 0 < k := by linarith
  have ht0 : 0 < t := by linarith
  have ht1 : 0 < t + 1 := by linarith
  have hB : 1 ≤ B := by dsimp [B]; nlinarith
  have hB0 : 0 < B := by linarith
  have hell : 1 ≤ ell := by dsimp [ell]; linarith [Real.log_nonneg hB]
  have hell0 : 0 < ell := by linarith
  have hprod := hAinput
  have hA0 : 0 ≤ A := Real.sqrt_nonneg _
  have hA2 : A ^ 2 = k * t * L := Real.sq_sqrt (by linarith)
  have hA : 1 ≤ A := by nlinarith
  have hAp : 0 < A := by linarith
  have hr : 0 < r := div_pos hAp (mul_pos hk0 hell0)
  have hlam : 0 < lam := div_pos (by positivity) hk0
  have hg : 0 < gamma := one_div_pos.mpr ht1
  have hgs : gamma ≤ 1 / 2 := by dsimp [gamma]; apply (div_le_iff₀ ht1).mpr; linarith
  have hcap : k / gamma = B := by dsimp [gamma, B]; field_simp
  have hrate : 4 * r * ell = lam := by dsimp [r, lam]; field_simp
  have hlamK : lam * k = 4 * A := by dsimp [lam]; field_simp
  have hrK : r * k ≤ A := by
    have heq : r * k = A / ell := by dsimp [r]; field_simp
    rw [heq]
    apply (div_le_iff₀ hell0).mpr
    nlinarith
  have hTg : t * gamma ≤ 1 := by dsimp [gamma]; rw [mul_one_div]; apply (div_le_one ht1).mpr; linarith
  have hTB : t * k / B ≤ 1 := by apply (div_le_one hB0).mpr; dsimp [B]; nlinarith
  have hTL_eq : 4 * t * L / lam = A := by
    dsimp [lam]
    field_simp
    nlinarith [hA2]
  have hTn_eq : t * L / r = A * ell := by
    dsimp [r]
    field_simp
    nlinarith [hA2]
  have hTL : 4 * t * z / lam ≤ A := by
    rw [← hTL_eq]
    exact div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left hzL (by positivity)) hlam.le
  have hTn : t * z / r ≤ A * ell := by
    rw [← hTn_eq]
    exact div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left hzL ht0.le) hr.le
  refine ⟨hr, hlam, hB, hg, hgs, hcap, hrate, ?_⟩
  exact tuned_regret_charges ht0.le hk0 hz hA hell hr hlam hB0 hgs hTg hTB hTL hTn hrK hlamK (by change Real.log B ≤ 1 + Real.log B; linarith)


set_option maxHeartbeats 1400000 in
theorem finite_context_upper_bound (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (hK : 2 ≤ K) (costs : List (X → Fin K → ℝ))
    (hT : 0 < costs.length) (hc0 : ∀ c ∈ costs, ∀ x a, 0 ≤ c x a)
    (hc1 : ∀ c ∈ costs, ∀ x a, c x a ≤ 1)
    (L : ℝ) (hL : Real.log (2 * Fintype.card P) ≤ L) :
    let k : ℝ := K
    let t : ℝ := costs.length
    let γ := 1 / (t + 1)
    let B := k * (t + 1)
    let ℓ := 1 + Real.log B
    let A := Real.sqrt (k * t * L)
    let r := Real.toNNReal (A / (k * ℓ))
    let lam := 4 * A / k
    let δ := 1 / (t * (1 + k / γ))
    let ε := lam * δ^2 / (32 * B^2 * ((r : ℝ) + 1))
    ∃ (hB : 1 ≤ B) (hk : 0 < K) (hg : 0 ≤ γ) (hg1 : γ ≤ 1) (hd : 0 < δ),
      (∫ path, outcomePathLoss Prod.snd costs path +
        treeBestScore (outcomePathTrueScore predict costs (fun _ => 0) path)
        ∂(paperNativeCappedLaw r D predict lam B ε δ γ hB hk hg hg1 hd costs).toMeasure) ≤
        38 * Real.exp 1 * A * Real.log (2*k*t) := by
  intro k t γ B ℓ A r lam δ ε
  have hk2 : 2 ≤ k := by dsimp [k]; exact_mod_cast hK
  have ht : 1 ≤ t := by dsimp [t]; exact_mod_cast hT
  have hk : 1 ≤ k := by linarith
  have hk' : 0 < K := by omega
  have hN : (1 : ℝ) ≤ Fintype.card P := by exact_mod_cast Fintype.card_pos (α := P)
  have hlog2 : 1 / 2 ≤ Real.log 2 := by
    have h := Real.one_sub_inv_le_log_of_pos (by norm_num : (0 : ℝ) < 2)
    norm_num at h ⊢
    exact h
  have hl : 1 / 2 ≤ L := hlog2.trans ((Real.log_le_log (by norm_num) (by linarith : (2 : ℝ) ≤ 2 * Fintype.card P)).trans hL)
  let z := Real.log (Fintype.card P)
  have hz : 0 ≤ z := Real.log_nonneg hN
  have hzL : z ≤ L := (Real.log_le_log (by linarith : (0 : ℝ) < Fintype.card P) (by linarith : (Fintype.card P : ℝ) ≤ 2 * Fintype.card P)).trans hL
  have hkt : 2 ≤ k*t := by nlinarith only [hk2, mul_nonneg (by linarith only [hk] : 0 ≤ k) (sub_nonneg.mpr ht)]
  have hprod : 1 ≤ k*t*L := by nlinarith only [hl, mul_nonneg (sub_nonneg.mpr hkt) (by linarith only [hl] : 0 ≤ L)]
  have hs := paper_concrete_tuning hk ht hprod hz hzL
  dsimp only at hs
  obtain ⟨hn, hlam, hB, hg, hgs, hcap, hrate, hcharges⟩ := hs
  have hrval : (r : ℝ) = A / (k*ℓ) := Real.coe_toNNReal _ hn.le
  have hr : 0 < (r : ℝ) := hrval.symm ▸ hn
  have hden : 0 < t * (1+k/γ) := by positivity
  have hd : 0 < δ := one_div_pos.mpr hden
  have hBpos : 0 < B := by linarith
  have hε : 0 < ε := by dsimp [ε]; positivity
  have hexpl : explorationLog K γ = ℓ := explorationLog_tuned hk' ht
  have hstable : 4 * (r : ℝ) * explorationLog K γ ≤ lam := by rw [hexpl, hrval]; exact hrate.le
  refine ⟨hB,hk',hg.le,by linarith,hd,?_⟩
  have hreg := paperNative_capped_expected_regret r hr D predict lam B ε δ γ hlam hB hε hd hk' hg hgs hcap.le hstable (le_refl _) costs hc0 hc1
  have hbase : 6 * (r : ℝ) * k + lam*k*Real.log B + t * nativeRoundSlack P r K lam B γ ≤ 10 * Real.exp 1 * A * ℓ := by
    unfold nativeRoundSlack
    rw [hrval]
    exact hcharges
  let q := Real.sqrt (((r : ℝ)+1)*k)
  have had : t * (1+k/γ) * δ = 1 := by change _ * (1 / _) = 1; exact mul_one_div_cancel hden.ne'
  have hsum : t * ((1+k/γ) * (2*δ*q)) = 2*q := by
    linear_combination 2*q*had
  have hA2 : A^2 = k*t*L := Real.sq_sqrt (by linarith)
  have hA0 : 0 ≤ A := Real.sqrt_nonneg _
  have hA : 1 ≤ A := by nlinarith
  have hell : 1 ≤ ℓ := by dsimp [ℓ]; linarith [Real.log_nonneg hB]
  have hrk : (r : ℝ)*k ≤ A := by
    rw [hrval]
    have hk0 : 0 < k := by linarith
    have hℓ : 0 < ℓ := by linarith
    rw [show A / (k*ℓ) * k = A / ℓ by field_simp]
    exact div_le_self hA0 hell
  have hkA : k ≤ 2*A^2 := by
    rw [hA2]
    have h1 : 1/2 ≤ t*L := by nlinarith [mul_nonneg (sub_nonneg.mpr ht) (by linarith : 0 ≤ L)]
    nlinarith [mul_nonneg (by linarith : 0 ≤ k) (sub_nonneg.mpr h1)]
  have hq2 : q^2 = ((r : ℝ)+1)*k := Real.sq_sqrt (by positivity)
  have hq : q ≤ 2*A := by nlinarith only [hq2, hkA, hrk, hA, sq_nonneg (q - 2*A), mul_nonneg hA0 (sub_nonneg.mpr hA), Real.sqrt_nonneg (((r : ℝ)+1)*k)]
  have hell' := tuning_log_bound hk ht
  change ℓ ≤ 3 * Real.log (2*k*t) at hell'
  have he : 1 ≤ Real.exp 1 := by linarith [Real.add_one_le_exp (1 : ℝ)]
  have hlog : 1/2 ≤ Real.log (2*k*t) := hlog2.trans (Real.log_le_log (by norm_num) (by nlinarith))
  have heL : 1/2 ≤ Real.exp 1 * Real.log (2*k*t) := by nlinarith [mul_nonneg (sub_nonneg.mpr he) (by linarith : 0 ≤ Real.log (2*k*t))]
  have hsmall := mul_le_mul_of_nonneg_left heL hA0
  have hbig := mul_le_mul_of_nonneg_left hell' (by positivity : 0 ≤ 10 * Real.exp 1 * A)
  apply hreg.trans
  change 6*(r : ℝ)*k + lam*k*Real.log B + t*(nativeRoundSlack P r K lam B γ + (1+k/γ)*(2*δ*q)) ≤ _
  rw [mul_add, hsum]
  nlinarith only [hbase, hbig, hsmall, hq]

end
end PoissonAudit
