module
public import PoissonAudit.OracleSamplerContextMap
public section
open MeasureTheory Set
namespace PoissonAudit
noncomputable section
variable {X Y P : Type*} [MeasurableSpace X] [MeasurableSpace Y] [MeasurableSingletonClass Y] [Fintype Y] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem cappedOracleChoice_quotient_certificate (f : X → Y) (hf : Measurable f) (r : NNReal)
    (D : Measure X) [IsProbabilityMeasure D] (predictX : P → X → Fin K) (predictY : P → Y → Fin K)
    (hpredict : ∀ p x, predictY p (f x) = predictX p x)
    (history : List (CostExample X K)) (oracleX : List (CostExample X K) → ℝ)
    (horacleX : ∀ Q, oracleX Q = treeBestScore (queryScore predictX Q)) (fallback : Fin K)
    (lam B eta : ℝ) (hB : 1 ≤ B) (cap J m : ℕ) (x : X) :
    AEMeasurable (fun v : NativeNoiseTape X K J × (Fin m → NativeNoise X K) => cappedOracleChoice r lam B eta history oracleX fallback cap J m v.1 v.2 x)
      ((nativeNoiseTapeLaw r D J).prod (iidPool (insertedExperimentLaw r D K) m)) ∧
    ((nativeNoiseTapeLaw (K := K) r D J).prod (iidPool (insertedExperimentLaw r D K) m)).map
      (fun v => cappedOracleChoice r lam B eta history oracleX fallback cap J m v.1 v.2 x) =
        (nativeCappedChoiceLaw r (D.map f) predictY (queryScore predictY (mapCostQuery f history))
          lam B eta hB cap J m (f x)).toMeasure := by
  haveI : IsProbabilityMeasure (D.map f) := (Measure.isProbabilityMeasure_map_iff hf.aemeasurable).mpr inferInstance
  let oracleY := fun Q : List (CostExample Y K) => treeBestScore (queryScore predictY Q)
  have horacleY (Q : List (CostExample Y K)) : oracleY Q = treeBestScore (queryScore predictY Q) := rfl
  have hcompat (Q : List (CostExample X K)) : oracleY (mapCostQuery f Q) = oracleX Q := by
    have hs : queryScore predictY (mapCostQuery f Q) = queryScore predictX Q := funext (queryScore_context_map f predictX predictY hpredict Q)
    change treeBestScore (queryScore predictY (mapCostQuery f Q)) = _
    rw [hs, horacleX]
  let source := (nativeNoiseTapeLaw (K := K) r D J).prod (iidPool (insertedExperimentLaw r D K) m)
  let target := (nativeNoiseTapeLaw (K := K) r (D.map f) J).prod (iidPool (insertedExperimentLaw r (D.map f) K) m)
  let F := fun v : NativeNoiseTape X K J × (Fin m → NativeNoise X K) =>
    (mapNativeNoiseTape f J v.1, fun i => mapNativeNoise f (v.2 i))
  have htrials := measurePreserving_pi (fun _ : Fin m => insertedExperimentLaw r D K)
    (fun _ => insertedExperimentLaw r (D.map f) K) (fun _ => mapNativeNoise_measurePreserving f hf r D)
  have hF : MeasurePreserving F source target := (mapNativeNoiseTape_measurePreserving f hf r D J).prod htrials
  let histY := mapCostQuery f history
  let S := queryScore predictY histY
  let canonical := canonicalTapeChoice r predictY S lam B eta hB cap J m (f x)
  have heqY : (fun v : NativeNoiseTape Y K J × (Fin m → NativeNoise Y K) =>
      cappedOracleChoice r lam B eta histY oracleY fallback cap J m v.1 v.2 (f x)) =ᵐ[target] canonical := by
    filter_upwards [nativeSamplerGood_ae r (D.map f) predictY S lam B eta hB J m] with v hv
    exact cappedOracleChoice_eq_canonical r predictY histY oracleY horacleY fallback lam B eta hB cap J m (f x) v hv
  have hcanonical : MeasurePreserving canonical target
      (nativeCappedChoiceLaw r (D.map f) predictY S lam B eta hB cap J m (f x)).toMeasure :=
    canonicalTapeChoice_measurePreserving r (D.map f) predictY S lam B eta hB cap J m (f x)
  have heqX : (fun v : NativeNoiseTape X K J × (Fin m → NativeNoise X K) =>
      cappedOracleChoice r lam B eta history oracleX fallback cap J m v.1 v.2 x) =ᵐ[source] (canonical ∘ F) := by
    filter_upwards [hF.quasiMeasurePreserving.ae heqY] with v hv
    change _ = canonical (F v)
    rw [← hv]
    exact (cappedOracleChoice_context_map f r lam B eta history oracleX oracleY hcompat fallback cap J m v.1 v.2 x).symm
  refine ⟨(hcanonical.comp hF).aemeasurable.congr heqX.symm,?_⟩
  rw [Measure.map_congr heqX]
  exact (hcanonical.comp hF).map_eq

theorem cappedOracleChoice_quotient_law (f : X → Y) (hf : Measurable f) (r : NNReal)
    (D : Measure X) [IsProbabilityMeasure D] (predictX : P → X → Fin K) (predictY : P → Y → Fin K)
    (hpredict : ∀ p x, predictY p (f x) = predictX p x)
    (history : List (CostExample X K)) (oracleX : List (CostExample X K) → ℝ)
    (horacleX : ∀ Q, oracleX Q = treeBestScore (queryScore predictX Q)) (fallback : Fin K)
    (lam B eta : ℝ) (hB : 1 ≤ B) (cap J m : ℕ) (x : X) :
    ((nativeNoiseTapeLaw (K := K) r D J).prod (iidPool (insertedExperimentLaw r D K) m)).map
      (fun v => cappedOracleChoice r lam B eta history oracleX fallback cap J m v.1 v.2 x) =
        (nativeCappedChoiceLaw r (D.map f) predictY (queryScore predictY (mapCostQuery f history))
          lam B eta hB cap J m (f x)).toMeasure :=
  (cappedOracleChoice_quotient_certificate f hf r D predictX predictY hpredict history oracleX horacleX fallback lam B eta hB cap J m x).2

end
end PoissonAudit
