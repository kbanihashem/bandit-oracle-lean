module
public import PoissonAudit.OracleReplayQueries
public section
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X Y : Type*} {K : ℕ}

@[expose] def mapCostQuery (f : X → Y) (Q : List (CostExample X K)) : List (CostExample Y K) :=
  Q.map (fun q => (f q.1, q.2))

@[expose] def mapReplayRecord (f : X → Y) (record : ReplayRecord X K) : ReplayRecord Y K :=
  (record.1, mapCostQuery f record.2)

@[expose] def mapNativeNoise (f : X → Y) (v : NativeNoise X K) : NativeNoise Y K :=
  (v.1, v.2.1, fun i => (f (v.2.2 i).1, (v.2.2 i).2))

@[expose] def mapNativeNoiseTape (f : X → Y) : (j : ℕ) → NativeNoiseTape X K j → NativeNoiseTape Y K j
  | 0, _ => ULift.up ()
  | j + 1, tape => (mapNativeNoiseTape f j tape.1, mapNativeNoise f tape.2)

theorem mapCostQuery_append (f : X → Y) (Q R : List (CostExample X K)) :
    mapCostQuery f (Q ++ R) = mapCostQuery f Q ++ mapCostQuery f R := List.map_append

theorem mapCostQuery_designated (f : X → Y) (Q : List (CostExample X K)) (x : X) (v : Fin K → ℝ) :
    mapCostQuery f (Q ++ [(x, v)]) = mapCostQuery f Q ++ [(f x, v)] := by simp [mapCostQuery]

theorem mapCostQuery_boosted (f : X → Y) (Q : List (CostExample X K)) (x : X) (v : Fin K → ℝ) (a : Fin K) :
    mapCostQuery f (boostedDesignatedQuery Q x v a) = boostedDesignatedQuery (mapCostQuery f Q) (f x) v a := by
  simp [boostedDesignatedQuery, mapCostQuery]

theorem valueOracleAction_context_map (f : X → Y) (oracleX : List (CostExample X K) → ℝ)
    (oracleY : List (CostExample Y K) → ℝ) (hcompat : ∀ Q, oracleY (mapCostQuery f Q) = oracleX Q)
    (fallback : Fin K) (Q : List (CostExample X K)) (x : X) (v : Fin K → ℝ) :
    valueOracleAction oracleY fallback (mapCostQuery f Q) (f x) v = valueOracleAction oracleX fallback Q x v := by
  have hbase : oracleY (mapCostQuery f Q ++ [(f x, v)]) = oracleX (Q ++ [(x, v)]) := by
    rw [← mapCostQuery_designated, hcompat]
  have htable (a : Fin K) : oracleY (boostedDesignatedQuery (mapCostQuery f Q) (f x) v a) = oracleX (boostedDesignatedQuery Q x v a) := by
    rw [← mapCostQuery_boosted, hcompat]
  unfold valueOracleAction
  simp only [hbase, htable]

theorem replayLocalStep_context_map (f : X → Y) (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracleX : List (CostExample X K) → ℝ)
    (oracleY : List (CostExample Y K) → ℝ) (hcompat : ∀ Q, oracleY (mapCostQuery f Q) = oracleX Q)
    (fallback : Fin K) (j : ℕ) (record : ReplayRecord X K) (x : X) (state : ReplayLocalState K) :
    replayLocalStep r lam B eta (mapCostQuery f history) oracleY fallback j (mapReplayRecord f record) (f x) state =
      replayLocalStep r lam B eta history oracleX fallback j record x state := by
  unfold replayLocalStep
  have hQ : mapCostQuery f history ++ (mapReplayRecord f record).2 = mapCostQuery f (history ++ record.2) :=
    (mapCostQuery_append f history record.2).symm
  simp only [mapReplayRecord, ← mapCostQuery_append, valueOracleAction_context_map f oracleX oracleY hcompat]

theorem replayAt_context_map (f : X → Y) (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracleX : List (CostExample X K) → ℝ)
    (oracleY : List (CostExample Y K) → ℝ) (hcompat : ∀ Q, oracleY (mapCostQuery f Q) = oracleX Q)
    (fallback : Fin K) (records : List (ReplayRecord X K)) (x : X) :
    replayAt r lam B eta (mapCostQuery f history) oracleY fallback (records.map (mapReplayRecord f)) (f x) =
      replayAt r lam B eta history oracleX fallback records x := by
  induction records with
  | nil => rfl
  | cons record records ih =>
    simp only [List.map_cons, replayAt, List.length_map, ih]
    exact replayLocalStep_context_map f r lam B eta history oracleX oracleY hcompat fallback records.length record x _

theorem makeReplayRecord_context_map (f : X → Y) (currentX : X → Fin K → ℝ) (currentY : Y → Fin K → ℝ)
    (hcurrent : ∀ x, currentY (f x) = currentX x) (v : NativeNoise X K) :
    makeReplayRecord currentY (mapNativeNoise f v) = mapReplayRecord f (makeReplayRecord currentX v) := by
  apply Prod.ext
  · rfl
  · unfold makeReplayRecord mapReplayRecord mapCostQuery scaledPoolExamples
    simp only [List.map_ofFn]
    congr 1
    funext i
    apply Prod.ext
    · rfl
    · funext a
      change currentY (f (v.2.2 i).1) a * (v.2.2 i).2 a = currentX (v.2.2 i).1 a * (v.2.2 i).2 a
      rw [hcurrent]

theorem buildReplayRecords_context_map (f : X → Y) (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracleX : List (CostExample X K) → ℝ)
    (oracleY : List (CostExample Y K) → ℝ) (hcompat : ∀ Q, oracleY (mapCostQuery f Q) = oracleX Q)
    (fallback : Fin K) (j : ℕ) (tape : NativeNoiseTape X K j) :
    buildReplayRecords r lam B eta (mapCostQuery f history) oracleY fallback j (mapNativeNoiseTape f j tape) =
      (buildReplayRecords r lam B eta history oracleX fallback j tape).map (mapReplayRecord f) := by
  induction j with
  | zero => rfl
  | succ j ih =>
    simp only [mapNativeNoiseTape, buildReplayRecords, ih, List.map_cons]
    congr 1
    apply makeReplayRecord_context_map
    intro x
    exact congrArg Prod.fst (replayAt_context_map f r lam B eta history oracleX oracleY hcompat fallback _ x)

theorem queryScore_context_map {P : Type*} (f : X → Y) (predictX : P → X → Fin K) (predictY : P → Y → Fin K)
    (hpredict : ∀ p x, predictY p (f x) = predictX p x) (Q : List (CostExample X K)) (p : P) :
    queryScore predictY (mapCostQuery f Q) p = queryScore predictX Q p := by
  induction Q with
  | nil => rfl
  | cons q Q ih =>
    simp only [queryScore, mapCostQuery, List.map_cons, List.sum_cons] at ih ⊢
    rw [hpredict, ih]
end
end PoissonAudit
