module

public import Mathlib.Tactic

public section

open scoped BigOperators

namespace PoissonAudit

theorem midpoint_discrepancy {u v w m : ℝ}
    (hu : 0 ≤ u) (hv : 0 ≤ v) (hw : 0 ≤ w)
    (hm : Real.sqrt u * Real.sqrt v ≤ m) :
    (u + v) / 2 - m ≤
      (Real.sqrt u - Real.sqrt w) ^ 2 + (Real.sqrt v - Real.sqrt w) ^ 2 := by
  have hsu := Real.sq_sqrt hu
  have hsv := Real.sq_sqrt hv
  have hsw := Real.sq_sqrt hw
  nlinarith [sq_nonneg (Real.sqrt u + Real.sqrt v - 2 * Real.sqrt w)]

theorem scale_controls_update {n ell lam q sigma B : ℝ}
    (hn : 0 < n) (hell : 0 < ell) (hq : 0 < q)
    (hsigma : 0 ≤ sigma) (hsigmaB : sigma ≤ B)
    (hlam : 4 * n * ell ≤ lam)
    (hinterior : sigma < B → ∃ alpha : ℝ,
      alpha ≤ 2 * q * ell ∧ lam ≤ n * sigma * alpha)
    (hcap : 1 ≤ q * B) : 1 / q ≤ sigma := by
  apply (div_le_iff₀ hq).2
  by_cases hb : sigma = B
  · simpa [hb, mul_comm] using hcap
  · have hlt : sigma < B := lt_of_le_of_ne hsigmaB hb
    obtain ⟨alpha, halpha, hfo⟩ := hinterior hlt
    have hprod := mul_le_mul_of_nonneg_left halpha (mul_nonneg hn.le hsigma)
    have htwo : 2 ≤ q * sigma := by
      nlinarith [mul_pos hn hell]
    nlinarith

theorem loss_update_le_scale {q sigma c : ℝ}
    (hq : 0 < q) (hc : c ≤ 1) (hs : 1 / q ≤ sigma) : c / q ≤ sigma := by
  exact (div_le_div_of_nonneg_right hc hq.le).trans hs

theorem actionwise_information_charge {A : Type*} [Fintype A]
    (q b c D : A → ℝ) (I C : ℝ)
    (hcancel : ∀ a, q a * b a = c a)
    (hc : ∀ a, c a ≤ 1) (hD : ∀ a, 0 ≤ D a)
    (hbudget : ∑ a, D a ≤ I) (hC : 0 ≤ C) :
    ∑ a, q a * (C * b a * D a) ≤ C * I := by
  calc
    ∑ a, q a * (C * b a * D a) = C * ∑ a, c a * D a := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro a _
      rw [← hcancel a]
      ring
    _ ≤ C * ∑ a, D a := by
      apply mul_le_mul_of_nonneg_left _ hC
      exact Finset.sum_le_sum fun a _ => by nlinarith [hc a, hD a]
    _ ≤ C * I := mul_le_mul_of_nonneg_left hbudget hC

theorem one_round_identity {A : Type*} [Fintype A]
    (q p b c Fchange remainder insertion : A → ℝ)
    (hcancel : ∀ a, q a * b a = c a)
    (hdecomp : ∀ a,
      Fchange a = -b a * p a + remainder a + insertion a) :
    (∑ a, q a * c a) + (∑ a, q a * Fchange a) =
      (∑ a, (q a - p a) * c a) +
      (∑ a, q a * remainder a) + (∑ a, q a * insertion a) := by
  rw [← Finset.sum_add_distrib, ← Finset.sum_add_distrib,
    ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro a _
  rw [hdecomp a]
  linear_combination -p a * hcancel a

theorem exploration_charge {A : Type*} [Fintype A]
    (p uniform c : A → ℝ) (gamma : ℝ)
    (hgamma : 0 ≤ gamma)
    (hp : ∀ a, 0 ≤ p a) (hu : ∀ a, 0 ≤ uniform a)
    (husum : ∑ a, uniform a = 1)
    (hc0 : ∀ a, 0 ≤ c a) (hc1 : ∀ a, c a ≤ 1) :
    ∑ a, (((1 - gamma) * p a + gamma * uniform a) - p a) * c a ≤ gamma := by
  have hpc : 0 ≤ ∑ a, p a * c a :=
    Finset.sum_nonneg fun a _ => mul_nonneg (hp a) (hc0 a)
  have huc : ∑ a, uniform a * c a ≤ 1 := by
    calc
      _ ≤ ∑ a, uniform a := Finset.sum_le_sum fun a _ => by
        nlinarith [hu a, hc1 a]
      _ = 1 := husum
  calc
    _ = gamma * ((∑ a, uniform a * c a) - ∑ a, p a * c a) := by
      rw [mul_sub, Finset.mul_sum, Finset.mul_sum, ← Finset.sum_sub_distrib]
      apply Finset.sum_congr rfl
      intro a _
      ring
    _ ≤ gamma * 1 := mul_le_mul_of_nonneg_left (by linarith) hgamma
    _ = gamma := mul_one _

theorem one_round_bound {A : Type*} [Fintype A]
    (q p b c Fchange Rchange remainder insertion : A → ℝ)
    (gamma curvatureBudget insertionBudget : ℝ)
    (hq : ∀ a, 0 ≤ q a)
    (hcancel : ∀ a, q a * b a = c a)
    (hdecomp : ∀ a, Fchange a = -b a * p a + remainder a + insertion a)
    (henvelope : ∀ a, Rchange a ≤ Fchange a)
    (hexplore : ∑ a, (q a - p a) * c a ≤ gamma)
    (hcurv : ∑ a, q a * remainder a ≤ curvatureBudget)
    (hinsert : ∑ a, q a * insertion a ≤ insertionBudget) :
    (∑ a, q a * c a) + (∑ a, q a * Rchange a) ≤
      gamma + curvatureBudget + insertionBudget := by
  have he : ∑ a, q a * Rchange a ≤ ∑ a, q a * Fchange a :=
    Finset.sum_le_sum fun a _ => mul_le_mul_of_nonneg_left (henvelope a) (hq a)
  have hi := one_round_identity q p b c Fchange remainder insertion hcancel hdecomp
  linarith

theorem telescope (T : ℕ) (loss potential : ℕ → ℝ) (u benchmark : ℝ)
    (hstep : ∀ t < T, loss t + potential (t + 1) - potential t ≤ u)
    (hterminal : -benchmark ≤ potential T) :
    (∑ t ∈ Finset.range T, loss t) - benchmark ≤ potential 0 + T * u := by
  have hs : (∑ t ∈ Finset.range T, loss t) + potential T - potential 0 ≤ T * u := by
    clear hterminal
    induction T with
    | zero => simp
    | succ T ih =>
      have hi := ih (fun t ht => hstep t (Nat.lt_succ_of_lt ht))
      have hi' := hstep T (Nat.lt_succ_self T)
      rw [Finset.sum_range_succ]
      push_cast
      linarith
  linarith

theorem approximation_budget {T gamma K : ℝ} (hT : T ≠ 0)
    (hg : gamma ≠ 0) (hden : gamma + K ≠ 0) :
    T * (1 + K / gamma) * (gamma / (T * (gamma + K))) = 1 := by
  field_simp

end PoissonAudit
