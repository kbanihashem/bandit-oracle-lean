module

public import PoissonAudit.ThresholdCurvature
public import Mathlib.MeasureTheory.Integral.Prod

public section

open MeasureTheory Set Filter
open scoped Topology

namespace PoissonAudit

noncomputable section

@[expose] def thresholdIncrement (theta sigma z s : ℝ) : ℝ :=
  max (sigma * (z - theta) - s) 0 - max (sigma * (z - theta)) 0

@[expose] def thresholdSlope (theta sigma z s : ℝ) : ℝ :=
  if 0 < sigma * (z - theta) - s then -1 else 0

theorem thresholdIncrement_lipschitz (theta sigma z : ℝ) :
    LipschitzWith 1 (thresholdIncrement theta sigma z) := by
  apply LipschitzWith.of_dist_le_mul
  intro s t
  simp only [Real.dist_eq, NNReal.coe_one, one_mul]
  calc
    _ = |max (sigma * (z - theta) - s) 0 - max (sigma * (z - theta) - t) 0| := by
      congr 1
      unfold thresholdIncrement
      ring
    _ ≤ |(sigma * (z - theta) - s) - (sigma * (z - theta) - t)| := abs_max_sub_max_le_abs _ _ _
    _ = |s - t| := by rw [show (sigma * (z - theta) - s) - (sigma * (z - theta) - t) = -(s - t) by ring, abs_neg]

theorem abs_thresholdIncrement_le (theta sigma z s : ℝ) : |thresholdIncrement theta sigma z s| ≤ |s| := by
  have h := (thresholdIncrement_lipschitz theta sigma z).dist_le_mul s 0
  simpa [thresholdIncrement, Real.dist_eq] using h

theorem hasDerivAt_thresholdIncrement (theta sigma z s : ℝ)
    (hne : sigma * (z - theta) - s ≠ 0) :
    HasDerivAt (thresholdIncrement theta sigma z) (thresholdSlope theta sigma z s) s := by
  have hc : ContinuousAt (fun u : ℝ => sigma * (z - theta) - u) s := by fun_prop
  rcases lt_or_gt_of_ne hne with hneg | hpos
  · have hnear : ∀ᶠ u in 𝓝 s, sigma * (z - theta) - u < 0 :=
      hc.eventually_lt continuousAt_const hneg
    have heq : thresholdIncrement theta sigma z =ᶠ[𝓝 s] fun _ => -max (sigma * (z - theta)) 0 := by
      filter_upwards [hnear] with u hu
      simp [thresholdIncrement, max_eq_right hu.le]
    have hd := hasDerivAt_const s (-max (sigma * (z - theta)) 0)
    rw [thresholdSlope, if_neg (not_lt.mpr hneg.le)]
    exact hd.congr_of_eventuallyEq heq
  · have hnear : ∀ᶠ u in 𝓝 s, 0 < sigma * (z - theta) - u :=
      continuousAt_const.eventually_lt hc hpos
    have heq : thresholdIncrement theta sigma z =ᶠ[𝓝 s]
        fun u => (sigma * (z - theta) - u) - max (sigma * (z - theta)) 0 := by
      filter_upwards [hnear] with u hu
      simp [thresholdIncrement, max_eq_left hu.le]
    have hd := ((hasDerivAt_const s (sigma * (z - theta))).sub (hasDerivAt_id s)).sub_const
      (max (sigma * (z - theta)) 0)
    rw [thresholdSlope, if_pos hpos]
    convert! hd.congr_of_eventuallyEq heq using 1 <;> norm_num

theorem threshold_positive_iff (theta sigma z s : ℝ) (hsigma : 0 < sigma) :
    0 < sigma * (z - theta) - s ↔ theta + s / sigma < z := by
  constructor
  · intro h
    have hh : s / sigma < z - theta := (div_lt_iff₀ hsigma).mpr (by nlinarith)
    linarith
  · intro h
    have hh : s < (z - theta) * sigma := (div_lt_iff₀ hsigma).mp (by linarith : s / sigma < z - theta)
    nlinarith

theorem integral_negative_laplace_tail (t : ℝ) :
    (∫ z, (if t < z then (-1 : ℝ) else 0) ∂realLaplace) = -laplaceSurvival t := by
  rw [laplaceSurvival_eq_probability]
  have h := integral_indicator_const (-1 : ℝ) (μ := realLaplace) (s := Ioi t) measurableSet_Ioi
  convert! h using 1
  change _ = (realLaplace (Ioi t)).toReal * (-1)
  ring

@[expose] def thresholdPotential {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) (theta : Omega → ℝ) (sigma s : ℝ) : ℝ :=
  ∫ v : Omega × ℝ, thresholdIncrement (theta v.1) sigma v.2 s ∂mu.prod realLaplace

theorem measurable_random_thresholdIncrement {Omega : Type*} [MeasurableSpace Omega]
    (theta : Omega → ℝ) (htheta : Measurable theta) (sigma s : ℝ) :
    Measurable (fun v : Omega × ℝ => thresholdIncrement (theta v.1) sigma v.2 s) := by
  unfold thresholdIncrement
  fun_prop

theorem measurable_random_thresholdSlope {Omega : Type*} [MeasurableSpace Omega]
    (theta : Omega → ℝ) (htheta : Measurable theta) (sigma s : ℝ) :
    Measurable (fun v : Omega × ℝ => thresholdSlope (theta v.1) sigma v.2 s) := by
  unfold thresholdSlope
  apply Measurable.ite _ measurable_const measurable_const
  apply measurableSet_lt measurable_const
  exact (measurable_const.mul (measurable_snd.sub (htheta.comp measurable_fst))).sub_const s

theorem integrable_random_thresholdIncrement {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) [IsProbabilityMeasure mu] (theta : Omega → ℝ) (htheta : Measurable theta)
    (sigma s : ℝ) :
    Integrable (fun v : Omega × ℝ => thresholdIncrement (theta v.1) sigma v.2 s) (mu.prod realLaplace) := by
  apply Integrable.of_bound (measurable_random_thresholdIncrement theta htheta sigma s).aestronglyMeasurable |s|
  filter_upwards [] with v
  exact abs_thresholdIncrement_le (theta v.1) sigma v.2 s

theorem integrable_random_thresholdSlope {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) [IsProbabilityMeasure mu] (theta : Omega → ℝ) (htheta : Measurable theta)
    (sigma s : ℝ) :
    Integrable (fun v : Omega × ℝ => thresholdSlope (theta v.1) sigma v.2 s) (mu.prod realLaplace) := by
  apply Integrable.of_bound (measurable_random_thresholdSlope theta htheta sigma s).aestronglyMeasurable 1
  filter_upwards [] with v
  unfold thresholdSlope
  split <;> norm_num

theorem hasDerivAt_thresholdPotential {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) [IsProbabilityMeasure mu] (theta : Omega → ℝ) (htheta : Measurable theta)
    (sigma s : ℝ) (hsigma : 0 < sigma) :
    HasDerivAt (thresholdPotential mu theta sigma) (-thresholdProbability mu theta sigma s) s := by
  have hdiff : ∀ᵐ v : Omega × ℝ ∂mu.prod realLaplace,
      HasDerivAt (thresholdIncrement (theta v.1) sigma v.2) (thresholdSlope (theta v.1) sigma v.2 s) s := by
    have hne : ∀ᵐ v : Omega × ℝ ∂mu.prod realLaplace, v.2 ≠ theta v.1 + s / sigma := by
      apply (Measure.ae_prod_iff_ae_ae
        (measurableSet_eq_fun measurable_snd ((htheta.comp measurable_fst).add_const (s / sigma))).compl).mpr
      exact Filter.Eventually.of_forall fun omega => realLaplace.ae_ne (theta omega + s / sigma)
    filter_upwards [hne] with v hv
    apply hasDerivAt_thresholdIncrement
    intro heq
    have he : v.2 - theta v.1 = s / sigma := (eq_div_iff hsigma.ne').mpr (by nlinarith)
    exact hv (by linarith)
  have h := hasDerivAt_integral_of_dominated_loc_of_lip
    (μ := mu.prod realLaplace) (x₀ := s) (s := Set.univ)
    (F := fun u v => thresholdIncrement (theta v.1) sigma v.2 u)
    (F' := fun v => thresholdSlope (theta v.1) sigma v.2 s) (bound := fun _ => 1) Filter.univ_mem
    (Filter.Eventually.of_forall fun u => (integrable_random_thresholdIncrement mu theta htheta sigma u).aestronglyMeasurable)
    (integrable_random_thresholdIncrement mu theta htheta sigma s)
    (measurable_random_thresholdSlope theta htheta sigma s).aestronglyMeasurable
    (Filter.Eventually.of_forall fun v => by
      simpa using (thresholdIncrement_lipschitz (theta v.1) sigma v.2))
    (integrable_const _) hdiff
  have hint : (∫ v : Omega × ℝ, thresholdSlope (theta v.1) sigma v.2 s ∂mu.prod realLaplace) =
      -thresholdProbability mu theta sigma s := by
    rw [integral_prod _ (integrable_random_thresholdSlope mu theta htheta sigma s)]
    simp_rw [thresholdSlope, threshold_positive_iff _ _ _ _ hsigma, integral_negative_laplace_tail]
    exact integral_neg _
  rw [hint] at h
  exact h.2

end

end PoissonAudit
