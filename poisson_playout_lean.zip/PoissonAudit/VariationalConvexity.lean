module

public import PoissonAudit.VariationalPotential

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {Omega P Q : Type*} [MeasurableSpace Omega]
    [Fintype P] [Nonempty P] [Fintype Q]

omit [MeasurableSpace Omega] in
theorem affinePoolMax_joint_combo (V : Omega → P → Q → ℝ)
    (S T : P → ℝ) (s t : Q → ℝ) (a b : ℝ) (ha : 0 ≤ a) (hb : 0 ≤ b)
    (omega : Omega) :
    affinePoolMax (a • S + b • T) V (a • s + b • t) omega ≤
      a * affinePoolMax S V s omega + b * affinePoolMax T V t omega := by
  classical
  apply Finset.sup'_le
  intro p _
  have hs := Finset.le_sup' (s := Finset.univ) (f := fun p => S p + ∑ j, s j * V omega p j)
    (Finset.mem_univ p)
  have ht := Finset.le_sup' (s := Finset.univ) (f := fun p => T p + ∑ j, t j * V omega p j)
    (Finset.mem_univ p)
  have h := add_le_add (mul_le_mul_of_nonneg_left hs ha) (mul_le_mul_of_nonneg_left ht hb)
  convert h using 1
  · simp only [Pi.add_apply, Pi.smul_apply, smul_eq_mul, add_mul, Finset.sum_add_distrib,
      mul_assoc, ← Finset.mul_sum]
    ring
  · rfl

theorem affinePoolPotential_joint_combo (mu : Measure Omega) [IsFiniteMeasure mu]
    (V : Omega → P → Q → ℝ) (hV : ∀ p j, Integrable (fun omega => V omega p j) mu)
    (S T : P → ℝ) (s t : Q → ℝ) (a b : ℝ) (ha : 0 ≤ a) (hb : 0 ≤ b) :
    affinePoolPotential mu (a • S + b • T) V (a • s + b • t) ≤
      a * affinePoolPotential mu S V s + b * affinePoolPotential mu T V t := by
  have h := integral_mono
    (integrable_affinePoolMax mu _ V hV _)
    (((integrable_affinePoolMax mu S V hV s).const_mul a).add
      ((integrable_affinePoolMax mu T V hV t).const_mul b))
    (affinePoolMax_joint_combo V S T s t a b ha hb)
  have heq : (∫ omega, a * affinePoolMax S V s omega + b * affinePoolMax T V t omega ∂mu) =
      a * affinePoolPotential mu S V s + b * affinePoolPotential mu T V t := by
    rw [integral_add ((integrable_affinePoolMax mu S V hV s).const_mul a)
      ((integrable_affinePoolMax mu T V hV t).const_mul b), integral_const_mul, integral_const_mul]
    rfl
  simp only [Pi.add_apply] at h
  rw [heq] at h
  exact h

theorem convex_scalePenalty (w : Q → ℝ) (hw : ∀ j, 0 ≤ w j)
    (lam B : ℝ) (hlam : 0 ≤ lam) (hB : 1 ≤ B) :
    ConvexOn ℝ (scaleBox Q B) (scalePenalty w lam B) := by
  classical
  refine ⟨convex_Icc 1 (fun _ => B), ?_⟩
  intro s hs t ht a b ha hb hab
  have hB0 : 0 < B := by linarith
  have hs0 (j : Q) : 0 < s j := by have h : (1 : ℝ) ≤ s j := hs.1 j; linarith
  have ht0 (j : Q) : 0 < t j := by have h : (1 : ℝ) ≤ t j := ht.1 j; linarith
  have hsum := Finset.sum_le_sum (s := Finset.univ) fun j _ =>
    mul_le_mul_of_nonneg_left (log_ratio_convex hB0 (hs0 j) (ht0 j) ha hb hab) (hw j)
  have h := mul_le_mul_of_nonneg_left hsum hlam
  unfold scalePenalty
  simp only [Pi.add_apply, Pi.smul_apply, smul_eq_mul]
  convert h using 1
  simp only [mul_add, Finset.sum_add_distrib, mul_left_comm (w _), ← Finset.mul_sum]
  ring

theorem convex_variationalValue (mu : Measure Omega) [IsFiniteMeasure mu]
    (V : Omega → P → Q → ℝ) (hV : ∀ p j, Integrable (fun omega => V omega p j) mu)
    (w : Q → ℝ) (hw : ∀ j, 0 ≤ w j) (lam B : ℝ) (hlam : 0 ≤ lam) (hB : 1 ≤ B) :
    ConvexOn ℝ Set.univ (variationalValue mu V hV w lam B hB) := by
  refine ⟨convex_univ, ?_⟩
  intro S _ T _ a b ha hb hab
  let s := optimalScale mu V hV w lam B hB S
  let t := optimalScale mu V hV w lam B hB T
  have hs := (optimalScale_spec mu V hV w lam B hB S).1
  have ht := (optimalScale_spec mu V hV w lam B hB T).1
  have hcombo : a • s + b • t ∈ scaleBox Q B :=
    (convex_Icc (1 : Q → ℝ) (fun _ => B)) hs ht ha hb hab
  have hpen := (convex_scalePenalty w hw lam B hlam hB).2 hs ht ha hb hab
  have hpot := affinePoolPotential_joint_combo mu V hV S T s t a b ha hb
  calc
    _ ≤ scaleObjective mu (a • S + b • T) V w lam B (a • s + b • t) :=
      variationalValue_le mu V hV w lam B hB _ _ hcombo
    _ ≤ a • scaleObjective mu S V w lam B s + b • scaleObjective mu T V w lam B t := by
      unfold scaleObjective
      simp only [smul_eq_mul] at *
      nlinarith
    _ = _ := rfl

end

end PoissonAudit
