module

public import PoissonAudit.CorrelationAlgebra

public section

namespace PoissonAudit

theorem unnormalized_sign_pinsker {p beta D : ℝ} (hp : 0 < p) (hD : 0 ≤ D)
    (hvar : ∀ t : ℝ, 0 < t → t * |beta| ≤ D + (t ^ 2 / 2) * p) :
    beta ^ 2 ≤ 2 * p * D := by
  by_cases hb : beta = 0
  · simp only [hb, zero_pow, ne_eq, OfNat.ofNat_ne_zero, not_false_eq_true]
    positivity
  have hab : 0 < |beta| := abs_pos.mpr hb
  have h := hvar (|beta| / p) (div_pos hab hp)
  have hm := mul_le_mul_of_nonneg_left h (sq_nonneg p)
  have heq : p ^ 2 * ((|beta| / p) * |beta|) = p * beta ^ 2 := by
    rw [← sq_abs beta]
    field_simp
  have heq2 : p ^ 2 * (D + ((|beta| / p) ^ 2 / 2) * p) = p ^ 2 * D + p * beta ^ 2 / 2 := by
    rw [← sq_abs beta]
    field_simp [hp.ne'] <;> ring
  rw [heq, heq2] at hm
  have hh : p * beta ^ 2 ≤ p * (2 * p * D) := by nlinarith
  exact (mul_le_mul_iff_of_pos_left hp).mp hh

theorem grouped_two_correlation {alpha beta p D : ℝ}
    (hp : 0 < p) (hD : 0 ≤ D) (hb : |beta| ≤ p)
    (hmean : ∀ t : ℝ, 0 < t → t ≤ 1 / 2 →
      t * |alpha| ≤ D + (4 / 3 : ℝ) * t ^ 2 * p)
    (hsign : ∀ t : ℝ, 0 < t → t * |beta| ≤ D + (t ^ 2 / 2) * p) :
    alpha * beta / p ≤ 4 * D := by
  have hsq := unnormalized_sign_pinsker hp hD hsign
  have hbn : |beta / p| ≤ 1 := by
    rw [abs_div, abs_of_pos hp]
    exact (div_le_one hp).mpr hb
  have hbsq : (beta / p) ^ 2 ≤ 2 * (D / p) := by
    rw [div_pow]
    apply (div_le_iff₀ (sq_pos_of_pos hp)).mpr
    convert! hsq using 1
    field_simp [hp.ne'] <;> ring
  have han : ∀ t : ℝ, 0 < t → t ≤ 1 / 2 →
      t * |alpha / p| ≤ D / p + (4 / 3 : ℝ) * t ^ 2 := by
    intro t ht ht1
    have h := (div_le_div_of_nonneg_right (hmean t ht ht1) hp.le)
    rw [abs_div, abs_of_pos hp]
    convert! h using 1 <;> field_simp <;> ring
  have hprod := two_correlation_product (div_nonneg hD hp.le) hbn hbsq han
  have hu := (le_abs_self _).trans hprod
  have hh := mul_le_mul_of_nonneg_left hu hp.le
  have heq : p * ((alpha / p) * (beta / p)) = alpha * beta / p := by field_simp
  have heq2 : p * (4 * (D / p)) = 4 * D := by field_simp
  rwa [heq, heq2] at hh

end PoissonAudit
