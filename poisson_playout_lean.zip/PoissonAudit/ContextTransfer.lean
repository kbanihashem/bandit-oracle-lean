module
public import PoissonAudit.ContextRows
public section
open MeasureTheory Set
namespace PoissonAudit
noncomputable section

variable {X Y : Type*} [MeasurableSpace X] [MeasurableSpace Y] [Fintype Y] [MeasurableSingletonClass Y]

theorem context_table_transfer (D : Measure X) [IsProbabilityMeasure D] (g : X → Y) (hg : Measurable g)
    (T : ℕ) (F : (Fin T → Y × X) → ℝ) (hm : Measurable F) (B C : ℝ) (hb : ∀ z, |F z| ≤ B)
    (hc : ∀ rows : Fin T → Y → X, (∫ ys, F (rowLookup T (rows,ys)) ∂iidPool (D.map g) T) ≤ C) :
    (∫ xs, F (fun t => (g (xs t),xs t)) ∂iidPool D T) ≤ C := by
  let μ := iidPool (Measure.pi (contextFiber D g)) T
  let ν := iidPool (D.map g) T
  haveI : IsProbabilityMeasure (D.map g) := (Measure.isProbabilityMeasure_map_iff hg.aemeasurable).mpr inferInstance
  haveI : IsProbabilityMeasure ν := iidPool_isProbability _ _
  haveI : IsProbabilityMeasure μ := iidPool_isProbability _ _
  have hraw := measurePreserving_pi (fun _ : Fin T => D) (fun _ => D.map (fun x => (g x,x)))
    (fun _ => (show MeasurePreserving (fun x => (g x,x)) D (D.map (fun x => (g x,x))) from ⟨hg.prodMk measurable_id,rfl⟩))
  have hrows := rowLookup_preserves_iid D g hg T
  have h1 := integral_map (μ := Measure.pi (fun _ : Fin T => D)) hraw.measurable.aemeasurable (f := F) hm.aestronglyMeasurable
  have h2 := integral_map (μ := (iidPool (Measure.pi (contextFiber D g)) T).prod (iidPool (D.map g) T)) hrows.measurable.aemeasurable (f := F) hm.aestronglyMeasurable
  rw [hraw.map_eq] at h1
  rw [hrows.map_eq] at h2
  have hi : Integrable (fun z => F (rowLookup T z)) (μ.prod ν) :=
    Integrable.of_bound (hm.comp (measurable_rowLookup T)).aestronglyMeasurable B
      (Filter.Eventually.of_forall fun z => by simpa only [Real.norm_eq_abs] using hb (rowLookup T z))
  change _ = (∫ z, F (rowLookup T z) ∂μ.prod ν) at h2
  rw [integral_prod _ hi] at h2
  calc
    _ = _ := h1.symm
    _ = _ := h2
    _ ≤ ∫ _ : Fin T → Y → X, C ∂μ := integral_mono hi.integral_prod_left (integrable_const _) hc
    _ = C := by simp

end
end PoissonAudit
