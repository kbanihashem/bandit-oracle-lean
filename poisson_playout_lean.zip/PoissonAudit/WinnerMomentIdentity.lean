module

public import PoissonAudit.WinnerMoments

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

theorem sum_winner_observable {Omega P : Type*} [Fintype P] {K : ℕ}
    (W : Omega → P) (pick : P → Fin K) (a : Fin K) (omega : Omega) (y : ℝ) :
    (∑ p, if pick p = a then (outcomeEvent W p).indicator (fun _ => (1 : ℝ)) omega * y else 0) =
      if pick (W omega) = a then y else 0 := by
  classical
  rw [Finset.sum_eq_single (W omega)]
  · by_cases h : pick (W omega) = a <;> simp [outcomeEvent, h]
  · intro p _ hp
    by_cases h : pick p = a <;> simp [outcomeEvent, h, Ne.symm hp]
  · simp

variable {V P : Type*} [MeasurableSpace V] {K : ℕ}
    [Fintype P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem winnerGroupMoment_eq_joint (nu : Measure V) [IsProbabilityMeasure nu]
    (W : (Fin K → ℝ) × V → P) (hW : Measurable W) (pick : P → Fin K) (a : Fin K)
    (g : ℝ → ℝ) (hg : Integrable g realLaplace) :
    winnerGroupMoment nu W pick a g =
      ∫ v, (if pick (W v) = a then g (v.1 a) else 0) ∂(laplaceMeasure K).prod nu := by
  classical
  let F := fun p (v : (Fin K → ℝ) × V) =>
    (outcomeEvent W p).indicator (fun _ => (1 : ℝ)) v * g (v.1 a)
  have hi (p : P) : Integrable (F p) ((laplaceMeasure K).prod nu) :=
    integrable_event_coordinate_observable nu _ (hW (measurableSet_singleton p)) a g hg
  have heq (p : P) :
      (∫ z, eventChannel nu (outcomeEvent W p) z * g (z a) ∂laplaceMeasure K) =
      ∫ v, F p v ∂(laplaceMeasure K).prod nu :=
    eventChannel_moment_eq_joint nu _ (hW (measurableSet_singleton p)) a g hg
  unfold winnerGroupMoment
  simp_rw [heq]
  have hif (p : P) : (if pick p = a then ∫ v, F p v ∂(laplaceMeasure K).prod nu else 0) =
      ∫ v, (if pick p = a then F p v else 0) ∂(laplaceMeasure K).prod nu := by
    by_cases hp : pick p = a <;> simp [hp]
  simp_rw [hif]
  rw [← integral_finsetSum]
  · apply integral_congr_ae
    filter_upwards [] with v
    exact sum_winner_observable W pick a v (g (v.1 a))
  · intro p _
    by_cases hp : pick p = a
    · simpa only [hp, ite_true] using hi p
    · simp only [hp, ite_false]
      exact integrable_const 0

theorem winnerGroupMoment_abs_le (nu : Measure V) [IsProbabilityMeasure nu]
    (W : (Fin K → ℝ) × V → P) (hW : Measurable W) (pick : P → Fin K) (a : Fin K)
    (g : ℝ → ℝ) (hg : Integrable g realLaplace) :
    |winnerGroupMoment nu W pick a g| ≤ winnerGroupMoment nu W pick a (fun z => |g z|) := by
  rw [winnerGroupMoment_eq_joint nu W hW pick a g hg,
    winnerGroupMoment_eq_joint nu W hW pick a _ hg.abs]
  calc
    _ ≤ ∫ v, |if pick (W v) = a then g (v.1 a) else 0| ∂(laplaceMeasure K).prod nu :=
      abs_integral_le_integral_abs
    _ = _ := by
      apply integral_congr_ae
      filter_upwards [] with v
      by_cases h : pick (W v) = a <;> simp [h]

theorem winnerGroupMoment_sign_bound (nu : Measure V) [IsProbabilityMeasure nu]
    (W : (Fin K → ℝ) × V → P) (hW : Measurable W) (pick : P → Fin K) (a : Fin K) :
    |winnerGroupMoment nu W pick a laplaceSign| ≤ winnerGroupMass nu W pick a := by
  have h := winnerGroupMoment_abs_le nu W hW pick a laplaceSign integrable_realLaplace_sign
  have heq : (fun z => |laplaceSign z|) = (fun _ => (1 : ℝ)) := funext abs_laplaceSign
  rw [heq, winnerGroupMoment_one nu W hW pick a] at h
  exact h

end

end PoissonAudit
