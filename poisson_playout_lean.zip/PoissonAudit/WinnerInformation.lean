module

public import PoissonAudit.ConditionalKL
public import PoissonAudit.KLTensorization
public import PoissonAudit.FiniteEntropy
public import Mathlib.MeasureTheory.Integral.Bochner.SumMeasure

public section

open MeasureTheory ProbabilityTheory InformationTheory
open scoped BigOperators ENNReal

namespace PoissonAudit

noncomputable section

@[expose] def eventPosterior {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) (E : Set Omega) : Measure Omega := by
  classical
  exact if mu E = 0 then mu else mu[|E]

instance eventPosterior_isProbability {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) [IsProbabilityMeasure mu] (E : Set Omega) :
    IsProbabilityMeasure (eventPosterior mu E) := by
  classical
  unfold eventPosterior
  split_ifs with hp
  · infer_instance
  · exact cond_isProbabilityMeasure hp

theorem map_eventPosterior {Omega Lambda : Type*}
    [MeasurableSpace Omega] [MeasurableSpace Lambda]
    (mu : Measure Omega) (f : Omega → Lambda) (hf : Measurable f)
    (E : Set Lambda) (hE : MeasurableSet E) :
    (eventPosterior mu (f ⁻¹' E)).map f = eventPosterior (mu.map f) E := by
  classical
  unfold eventPosterior
  rw [Measure.map_apply hf hE]
  split_ifs with hp
  · rfl
  · unfold ProbabilityTheory.cond
    rw [Measure.map_smul _ hf.aemeasurable, ← Measure.restrict_map hf hE,
      Measure.map_apply hf hE]

theorem weighted_eventPosterior_kl {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) [IsProbabilityMeasure mu] (E : Set Omega) (hE : MeasurableSet E) :
    mu E * klDiv (eventPosterior mu E) mu =
      ENNReal.ofReal (-((mu E).toReal * Real.log (mu E).toReal)) := by
  classical
  by_cases hp : mu E = 0
  · simp [hp, eventPosterior]
  · rw [eventPosterior, ite_eq_right hp, klDiv_conditioned_event mu E hE hp]
    calc
      _ = ENNReal.ofReal (mu E).toReal * ENNReal.ofReal (-Real.log (mu E).toReal) := by
        rw [ENNReal.ofReal_toReal (measure_ne_top mu E)]
      _ = ENNReal.ofReal ((mu E).toReal * (-Real.log (mu E).toReal)) :=
        (ENNReal.ofReal_mul ENNReal.toReal_nonneg).symm
      _ = _ := by congr 1; ring

@[expose] def outcomeEvent {Omega P : Type*} (W : Omega → P) (p : P) : Set Omega :=
  {omega | W omega = p}

@[expose] def outcomeMass {Omega P : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) (W : Omega → P) (p : P) : ℝ := (mu (outcomeEvent W p)).toReal

theorem outcomeMass_nonneg {Omega P : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) (W : Omega → P) (p : P) : 0 ≤ outcomeMass mu W p :=
  ENNReal.toReal_nonneg

theorem outcomeMass_le_one {Omega P : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) [IsProbabilityMeasure mu] (W : Omega → P) (p : P) :
    outcomeMass mu W p ≤ 1 := by
  have h := ENNReal.toReal_mono (by norm_num : (1 : ENNReal) ≠ ∞)
    (show mu (outcomeEvent W p) ≤ 1 from prob_le_one)
  simpa only [outcomeMass, ENNReal.toReal_one] using h

theorem sum_outcomeMass {Omega P : Type*} [MeasurableSpace Omega]
    [MeasurableSpace P] [MeasurableSingletonClass P] [Fintype P]
    (mu : Measure Omega) [IsProbabilityMeasure mu] (W : Omega → P) (hW : Measurable W) :
    ∑ p, outcomeMass mu W p = 1 := by
  have h := integral_fintype (μ := mu.map W) (f := fun _ : P => (1 : ℝ)) Integrable.of_finite
  simp only [integral_const, probReal_univ, smul_eq_mul, mul_one] at h
  have heq : ∀ p, outcomeMass mu W p = (mu.map W).real {p} := by
    intro p
    rw [Measure.real, Measure.map_apply hW (measurableSet_singleton p)]
    rfl
  simp_rw [heq]
  exact h.symm

theorem sum_weighted_winnerPosterior_kl {Omega P : Type*} [MeasurableSpace Omega]
    [MeasurableSpace P] [MeasurableSingletonClass P] [Fintype P]
    (mu : Measure Omega) [IsProbabilityMeasure mu] (W : Omega → P) (hW : Measurable W) :
    (∑ p, mu (outcomeEvent W p) * klDiv (eventPosterior mu (outcomeEvent W p)) mu) =
      ENNReal.ofReal (finiteEntropy (outcomeMass mu W)) := by
  have hterm : ∀ p, mu (outcomeEvent W p) * klDiv (eventPosterior mu (outcomeEvent W p)) mu =
      ENNReal.ofReal (-(outcomeMass mu W p * Real.log (outcomeMass mu W p))) := by
    intro p
    exact weighted_eventPosterior_kl mu (outcomeEvent W p) (hW (measurableSet_singleton p))
  simp_rw [hterm]
  rw [← ENNReal.ofReal_sum_of_nonneg]
  · unfold finiteEntropy
    rw [Finset.sum_neg_distrib]
  · intro p _
    have h := mul_nonpos_of_nonneg_of_nonpos (outcomeMass_nonneg mu W p)
      (Real.log_nonpos (outcomeMass_nonneg mu W p) (outcomeMass_le_one mu W p))
    linarith

@[expose] def coordinateInformation {U P : Type*} [MeasurableSpace U] [Fintype P]
    (mu : Measure U) (n : ℕ) (W : (Fin n → U) → P) (i : Fin n) : ENNReal :=
  ∑ p, iidPool mu n (outcomeEvent W p) *
    klDiv ((eventPosterior (iidPool mu n) (outcomeEvent W p)).map (fun u => u i)) mu

theorem sum_coordinateInformation_le_log_card {U P : Type*} [MeasurableSpace U]
    [StandardBorelSpace U] [Nonempty U]
    [MeasurableSpace P] [MeasurableSingletonClass P] [Fintype P] [Nonempty P]
    (mu : Measure U) [IsProbabilityMeasure mu] (n : ℕ)
    (W : (Fin n → U) → P) (hW : Measurable W) :
    (∑ i, coordinateInformation mu n W i) ≤ ENNReal.ofReal (Real.log (Fintype.card P)) := by
  unfold coordinateInformation
  rw [Finset.sum_comm]
  calc
    _ = ∑ p, iidPool mu n (outcomeEvent W p) *
        ∑ i, klDiv ((eventPosterior (iidPool mu n) (outcomeEvent W p)).map (fun u => u i)) mu := by
      apply Finset.sum_congr rfl
      intro p _
      rw [Finset.mul_sum]
    _ ≤ ∑ p, iidPool mu n (outcomeEvent W p) *
        klDiv (eventPosterior (iidPool mu n) (outcomeEvent W p)) (iidPool mu n) := by
      apply Finset.sum_le_sum
      intro p _
      exact mul_le_mul_right (klDiv_sum_coordinates_le mu n
        (eventPosterior (iidPool mu n) (outcomeEvent W p))) _
    _ = ENNReal.ofReal (finiteEntropy (outcomeMass (iidPool mu n) W)) :=
      sum_weighted_winnerPosterior_kl (iidPool mu n) W hW
    _ ≤ _ := ENNReal.ofReal_le_ofReal (finiteEntropy_le_log_card _
      (outcomeMass_nonneg (iidPool mu n) W) (sum_outcomeMass (iidPool mu n) W hW))

end

end PoissonAudit
