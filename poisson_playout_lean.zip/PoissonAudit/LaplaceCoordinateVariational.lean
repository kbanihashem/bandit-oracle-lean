module

public import PoissonAudit.LaplaceEntropy
public import PoissonAudit.LaplaceProductLaw

public section

open MeasureTheory InformationTheory
open scoped ENNReal

namespace PoissonAudit

noncomputable section

theorem laplace_coordinate_integral (K : ℕ) (a : Fin K) (f : ℝ → ℝ) (hf : Measurable f) :
    (∫ z, f (z a) ∂laplaceMeasure K) = ∫ y, f y ∂realLaplace := by
  rw [laplaceMeasure_eq_iid]
  have hmp := measurePreserving_eval (fun _ : Fin K => realLaplace) a
  have h := integral_map hmp.measurable.aemeasurable (f := f)
    (by rw [hmp.map_eq]; exact hf.aestronglyMeasurable)
  rw [hmp.map_eq] at h
  exact h.symm

theorem integrable_laplace_coordinate_comp (K : ℕ) (a : Fin K) (f : ℝ → ℝ)
    (hf : Integrable f realLaplace) : Integrable (fun z => f (z a)) (laplaceMeasure K) := by
  rw [laplaceMeasure_eq_iid]
  exact (measurePreserving_eval (fun _ : Fin K => realLaplace) a).integrable_comp_of_integrable hf

theorem laplace_coordinate_exp_integral (K : ℕ) (a : Fin K) {t : ℝ} (ht : |t| < 1) :
    (∫ z, Real.exp (t * z a) ∂laplaceMeasure K) = 1 / (1 - t ^ 2) := by
  rw [laplace_coordinate_integral K a (fun y => Real.exp (t * y)) (by fun_prop)]
  exact integral_realLaplace_exp ht

theorem laplace_coordinate_sign_exp_integral (K : ℕ) (a : Fin K) (t : ℝ) :
    (∫ z, Real.exp (t * laplaceSign (z a)) ∂laplaceMeasure K) = Real.cosh t := by
  rw [laplace_coordinate_integral K a (fun y => Real.exp (t * laplaceSign y)) (by fun_prop)]
  exact integral_realLaplace_exp_sign t

theorem integrable_laplace_exp_sign (t : ℝ) :
    Integrable (fun y => Real.exp (t * laplaceSign y)) realLaplace := by
  apply Integrable.of_bound (by fun_prop) (Real.exp |t|)
  filter_upwards [] with y
  rw [Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]
  apply Real.exp_le_exp.mpr
  calc
    _ ≤ |t * laplaceSign y| := le_abs_self _
    _ = |t| := by rw [abs_mul, abs_laplaceSign, mul_one]

theorem laplace_coordinate_density_mean_variational (K : ℕ) (a : Fin K) (f : (Fin K → ℝ) → ℝ)
    (hf0 : ∀ z, 0 ≤ f z) (hfi : Integrable f (laplaceMeasure K))
    (hnorm : (∫ z, f z ∂laplaceMeasure K) = 1)
    (hki : Integrable (fun z => klFun (f z)) (laplaceMeasure K))
    (hfzi : Integrable (fun z => f z * z a) (laplaceMeasure K))
    {t : ℝ} (ht : |t| < 1) :
    t * (∫ z, f z * z a ∂laplaceMeasure K) ≤
      (∫ z, klFun (f z) ∂laplaceMeasure K) - Real.log (1 - t ^ 2) := by
  have ht2 : 0 < 1 - t ^ 2 := by nlinarith [(sq_lt_one_iff_abs_lt_one t).mpr ht]
  have h := density_entropy_variational (laplaceMeasure K) f (fun z => t * z a) hf0 hfi hnorm hki
    (by convert! hfzi.const_mul t using 1; funext z; ring)
    (integrable_laplace_coordinate_comp K a _ (integrable_realLaplace_exp ht))
    (by rw [laplace_coordinate_exp_integral K a ht]; exact div_pos (by norm_num) ht2)
  have heq : (∫ z, f z * (t * z a) ∂laplaceMeasure K) =
      t * ∫ z, f z * z a ∂laplaceMeasure K := by
    rw [← integral_const_mul]
    apply integral_congr_ae
    filter_upwards [] with z
    ring
  rw [heq, laplace_coordinate_exp_integral K a ht,
    Real.log_div (by norm_num) ht2.ne', Real.log_one] at h
  linarith

theorem laplace_coordinate_density_sign_variational (K : ℕ) (a : Fin K) (f : (Fin K → ℝ) → ℝ)
    (hf0 : ∀ z, 0 ≤ f z) (hfi : Integrable f (laplaceMeasure K))
    (hnorm : (∫ z, f z ∂laplaceMeasure K) = 1)
    (hki : Integrable (fun z => klFun (f z)) (laplaceMeasure K))
    (hfsi : Integrable (fun z => f z * laplaceSign (z a)) (laplaceMeasure K)) (t : ℝ) :
    t * (∫ z, f z * laplaceSign (z a) ∂laplaceMeasure K) ≤
      (∫ z, klFun (f z) ∂laplaceMeasure K) + t ^ 2 / 2 := by
  have h := density_entropy_variational (laplaceMeasure K) f (fun z => t * laplaceSign (z a)) hf0 hfi hnorm hki
    (by convert! hfsi.const_mul t using 1; funext z; ring)
    (integrable_laplace_coordinate_comp K a _ (integrable_laplace_exp_sign t))
    (by rw [laplace_coordinate_sign_exp_integral K a t]; exact Real.cosh_pos t)
  have heq : (∫ z, f z * (t * laplaceSign (z a)) ∂laplaceMeasure K) =
      t * ∫ z, f z * laplaceSign (z a) ∂laplaceMeasure K := by
    rw [← integral_const_mul]
    apply integral_congr_ae
    filter_upwards [] with z
    ring
  rw [heq, laplace_coordinate_sign_exp_integral] at h
  have hlog : Real.log (Real.cosh t) ≤ t ^ 2 / 2 :=
    (Real.log_le_iff_le_exp (Real.cosh_pos t)).mpr (Real.cosh_le_exp_half_sq t)
  linarith

end

end PoissonAudit
