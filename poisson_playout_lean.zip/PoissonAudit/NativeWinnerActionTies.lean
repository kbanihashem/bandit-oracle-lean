module
public import PoissonAudit.PoolQueryEncoding
public section
open MeasureTheory Set
namespace PoissonAudit
noncomputable section

theorem laplace_coordinate_affine_ne {K : ℕ} (a b : Fin K) (hab : a ≠ b) (u v A B : ℝ) (hu : 0 < u) :
    ∀ᵐ z ∂laplaceMeasure K, A + u * z a ≠ B + v * z b := by
  classical
  let L : (Fin K → ℝ) →ₗ[ℝ] ℝ := u • LinearMap.proj a - v • LinearMap.proj b
  have hval : L (Pi.single a 1) = u := by simp [L, hab, hab.symm]
  have hL : L ≠ 0 := by
    intro h
    have hz := congrArg (fun f : (Fin K → ℝ) →ₗ[ℝ] ℝ => f (Pi.single a 1)) h
    rw [hval] at hz
    exact hu.ne' hz
  have hac : laplaceMeasure K ≪ (volume : Measure (Fin K → ℝ)) := withDensity_absolutelyContinuous _ _
  have hnull := hac (linear_fiber_haar_zero volume L hL (B - A))
  have hne : ∀ᵐ z ∂laplaceMeasure K, L z ≠ B - A := by
    rw [ae_iff]
    simpa only [not_not] using hnull
  filter_upwards [hne] with z hz
  intro htie
  apply hz
  change u * z a - v * z b = B - A
  linarith

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem native_inserted_tie_action (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (hsigma : ∀ j, 0 < sigma j) (x : X) (p q : P) :
    ∀ᵐ v ∂insertedExperimentLaw r D K,
      experimentScore predict sigma S x v p = experimentScore predict sigma S x v q → predict p x = predict q x := by
  by_cases ha : predict p x = predict q x
  · exact Filter.Eventually.of_forall fun _ _ => ha
  have hE : MeasurableSet {v : NativeNoise X K | experimentScore predict sigma S x v p ≠ experimentScore predict sigma S x v q} :=
    (measurableSet_eq_fun (measurable_experimentScore predict sigma S x p) (measurable_experimentScore predict sigma S x q)).compl
  have hrev : ∀ᵐ pool ∂markedPoolLaw r (contextLaplaceLaw D K), ∀ᵐ z ∂laplaceMeasure K,
      experimentScore predict sigma S x (z, pool) p ≠ experimentScore predict sigma S x (z, pool) q := by
    apply Filter.Eventually.of_forall
    intro pool
    have h := laplace_coordinate_affine_ne (predict p x) (predict q x) ha (sigma (x, predict p x)) (sigma (x, predict q x))
      (S p + ∑ j, sigma j * poissonCoefficient predict pool p j)
      (S q + ∑ j, sigma j * poissonCoefficient predict pool q j) (hsigma _)
    filter_upwards [h] with z hz
    intro htie
    apply hz
    unfold experimentScore markValue at htie
    linarith
  have hcur := (Measure.ae_ae_comm hE).mpr hrev
  have hfull := (Measure.ae_prod_iff_ae_ae hE).mpr hcur
  filter_upwards [hfull] with v hv
  exact fun htie => (hv htie).elim

theorem native_inserted_all_context_ties (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (hsigma : ∀ j, 0 < sigma j) :
    ∀ᵐ v ∂insertedExperimentLaw r D K, ∀ x p q,
      experimentScore predict sigma S x v p = experimentScore predict sigma S x v q → predict p x = predict q x :=
  ae_all_iff.mpr fun x => ae_all_iff.mpr fun p => ae_all_iff.mpr fun q => native_inserted_tie_action r D predict sigma S hsigma x p q

theorem native_any_maximizer_action (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (hsigma : ∀ j, 0 < sigma j) :
    ∀ᵐ v ∂insertedExperimentLaw r D K, ∀ x p,
      experimentScore predict sigma S x v p = treeBestScore (experimentScore predict sigma S x v) →
        predict p x = experimentAction predict sigma S x v := by
  filter_upwards [native_inserted_all_context_ties r D predict sigma S hsigma] with v hv
  intro x p hp
  apply hv x p (experimentWinner predict sigma S x v)
  rw [hp]
  exact (winner_score_eq_treeBestScore _).symm
end
end PoissonAudit
