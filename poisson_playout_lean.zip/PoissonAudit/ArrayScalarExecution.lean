module
public import PoissonAudit.ScalarExecution
public section
namespace PoissonAudit
noncomputable section

@[expose] def gradientEnvironment {K : ℕ} (r : NNReal) (lam B eta : ℝ) (state : ArrayReplayState K)
    (z : Fin K → ℝ) (action a : Fin K) : GradientInput → ℝ := by
  classical
  exact fun
    | .sigma => vectorValues state.1 a
    | .mark => z a
    | .indicator => if action = a then 1 else 0
    | .intensity => r
    | .penalty => lam
    | .stepSize => eta
    | .cap => B

@[expose] def averageEnvironment {K : ℕ} (state : ArrayReplayState K) (j : ℕ) (a : Fin K) : AverageInput → ℝ
  | .count => j
  | .current => vectorValues state.1 a
  | .average => vectorValues state.2 a

@[expose] def executeArrayCoordinates {K : ℕ} (r : NNReal) (lam B eta : ℝ) (state : ArrayReplayState K)
    (z : Fin K → ℝ) (action : Fin K) (j : ℕ) : ArrayReplayState K × ℕ :=
  let next := executeScalarVector (fun a => gradientEnvironment r lam B eta state z action a) (fun _ => projectedGradientExpr)
  let avg := executeScalarVector (averageEnvironment state j) (fun _ => averageExpr)
  ((next.1, avg.1), next.2 + avg.2 + K)

theorem executeArrayCoordinates_steps {K : ℕ} (r : NNReal) (lam B eta : ℝ) (state : ArrayReplayState K)
    (z : Fin K → ℝ) (action : Fin K) (j : ℕ) : (executeArrayCoordinates r lam B eta state z action j).2 = 35 * K := by
  dsimp only [executeArrayCoordinates]
  rw [executeScalarVector_steps _ _ 17 (fun _ => projectedGradientExpr_steps),
    executeScalarVector_steps _ _ 15 (fun _ => averageExpr_steps)]
  ring

theorem executeArrayCoordinates_values {K : ℕ} (r : NNReal) (lam B eta : ℝ) (state : ArrayReplayState K)
    (z : Fin K → ℝ) (action : Fin K) (j : ℕ) :
    arrayStateValues (executeArrayCoordinates r lam B eta state z action j).1 =
      (fun a => boxClip B (vectorValues state.1 a - eta *
        ((r : ℝ) * ((if action = a then 1 else 0) * z a) - lam / vectorValues state.1 a)),
       fun a => (j : ℝ) / ((j : ℝ) + 1) * vectorValues state.2 a +
         1 / ((j : ℝ) + 1) * vectorValues state.1 a) := by
  classical
  unfold arrayStateValues executeArrayCoordinates
  simp only [executeScalarVector_values]
  rfl

@[expose] def interpretedArrayLocalStep {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (j : ℕ) (record : ReplayRecord X K) (x : X) (state : ArrayReplayState K) : ArrayReplayState K × ℕ :=
  let designated := Vector.ofFn (fun a => vectorValues state.1 a * record.1 a)
  let action := arrayValueOracleAction oracle fallback (history ++ record.2) x designated
  executeArrayCoordinates r lam B eta state record.1 action j

theorem interpretedArrayLocalStep_values {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (j : ℕ) (record : ReplayRecord X K) (x : X) (state : ArrayReplayState K) :
    arrayStateValues (interpretedArrayLocalStep r lam B eta history oracle fallback j record x state).1 =
      arrayStateValues (arrayReplayLocalStep r lam B eta history oracle fallback j record x state) := by
  unfold interpretedArrayLocalStep
  rw [executeArrayCoordinates_values]
  unfold arrayStateValues arrayReplayLocalStep
  simp only [vectorValues_ofFn]
end
end PoissonAudit
