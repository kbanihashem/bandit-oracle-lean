module
public import PoissonAudit.OracleRegret
public import PoissonAudit.WaitingSampler
public import PoissonAudit.Initialization
public section
open MeasureTheory Set
namespace PoissonAudit
noncomputable section

variable {X P : Type*} [MeasurableSpace X] {K : ℕ}

def waitingOutcome (a : InitializedPlan) (D : Measure X) [IsProbabilityMeasure D]
    (oracle : List (CostExample X K) → ℝ) (fallback : Fin K) (H : List (CostExample X K))
    (x : X) (o : EmpiricalChoice K a.trials × Fin K) : ℝ :=
  let p := a.params
  let val := fun Q => -oracle (negateCostQuery Q)
  let training := waitTrainingLaw a.cap p.r D K a.iterations
  let trials := iidPool (waitNoiseLaw a.cap p.r D K) a.trials
  (((training.prod trials).map (fun v => (executeArraySampler p.r p.lam p.B a.step H val fallback
    a.cap a.iterations a.trials v.1 v.2 x).choice)) {o.1}).toReal *
      vectorValues (executeProbabilityTable K p.gamma a.trials o.1).1 o.2

variable [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

def waitingRegret (a : InitializedPlan) (D : Measure X) [IsProbabilityMeasure D]
    (oracle : List (CostExample X K) → ℝ) (fallback : Fin K) (predict : P → X → Fin K) :
    (n : ℕ) → (Fin n → X × (Fin K → ℝ)) → List (CostExample X K) → (P → ℝ) → ℝ
  | 0, _, _, Q => treeBestScore Q
  | n+1, v, H, Q =>
    let x := (v 0).1
    let c := (v 0).2
    ∑ o, waitingOutcome a D oracle fallback H x o *
      (c o.2 + waitingRegret a D oracle fallback predict n (fun t => v t.succ)
        (manuscriptUpdate a.params.gamma H x o.1 o.2 (c o.2)) (fun i => Q i - c (predict i x)))

theorem waitingRegret_eq (D : Measure X) [IsProbabilityMeasure D] (predict : P → X → Fin K)
    (hp : ∀ i, Measurable (predict i)) (T : ℕ) (hK : 2 ≤ K) (L : ℝ)
    (oracle : List (CostExample X K) → ℝ)
    (ho : ∀ R, (∀ i, oracle R ≤ queryScore predict R i) ∧ ∃ i, oracle R = queryScore predict R i)
    (fallback : Fin K) (n : ℕ) (v : Fin n → X × (Fin K → ℝ)) (H : List (CostExample X K)) (Q : P → ℝ) :
    waitingRegret (specifiedPlan K T L) D oracle fallback predict n v H Q =
    oracleRegret (manuscriptPlan K T L) D oracle fallback predict n v H Q := by
  let a := specifiedPlan K T L
  let p := manuscriptPlan K T L
  let val := fun R => -oracle (negateCostQuery R)
  have hval := maximizing_value_from_minimizing predict oracle ho
  have hk (hist : List (CostExample X K)) (x : X) (o : EmpiricalChoice K a.trials × Fin K) :
      waitingOutcome a D oracle fallback hist x o = oracleOutcome p D oracle fallback hist x o := by
    have hc := (cappedOracleChoice_quotient_certificate (fun x i => predict i x) (Measurable.of_eval hp)
      p.r D predict (fun i y => y i) (fun _ _ => rfl) hist val hval fallback p.lam p.B a.step
      (manuscriptPlan_box K T L hK) a.cap a.iterations a.trials x).1
    have he := waiting_sampler_law p.r D p.lam p.B a.step hist val fallback a.cap a.iterations a.trials x
      (by simp only [(executeArraySampler_correct p.r p.lam p.B a.step hist val fallback a.cap a.iterations a.trials _ _ x).1]; exact hc)
    exact congrArg (fun μ : Measure (EmpiricalChoice K a.trials) =>
      (μ {o.1}).toReal * vectorValues (executeProbabilityTable K p.gamma a.trials o.1).1 o.2) he
  induction n generalizing H Q with
  | zero => rfl
  | succ n ih =>
    dsimp only [waitingRegret,oracleRegret]
    apply Finset.sum_congr rfl
    intro o _
    rw [hk,ih]
    rfl

theorem initialized_upper_bound (D : Measure X) [IsProbabilityMeasure D] (predict : P → X → Fin K)
    (hp : ∀ i, Measurable (predict i)) (T : ℕ) (hT : 0 < T) (hK : 2 ≤ K)
    (oracle : List (CostExample X K) → ℝ)
    (ho : ∀ R, (∀ i, oracle R ≤ queryScore predict R i) ∧ ∃ i, oracle R = queryScore predict R i)
    (fallback : Fin K) (c : Fin T → X → Fin K → ℝ) (hm : ∀ t a, Measurable (fun x => c t x a))
    (hc : ∀ t x a, c t x a ∈ Icc (0 : ℝ) 1) (L : ℝ) (hL : Real.log (2 * Fintype.card P) ≤ L) :
    (∫ xs, waitingRegret ((initializePlan K T L).run 0).1 D oracle fallback predict T
      (fun t => (xs t,c t (xs t))) [] (fun _ => 0) ∂iidPool D T) ≤
      38 * Real.exp 1 * Real.sqrt ((K : ℝ)*T*L) * Real.log (2*(K : ℝ)*T) ∧
    PowerBound (2+(K : ℝ)+T+2*L) 521 (totalWork K T L) := by
  constructor
  · rw [initializePlan_spec]
    simp only [waitingRegret_eq D predict hp T hK L oracle ho fallback]
    exact oracle_upper_bound D predict hp T hT hK oracle ho fallback c hm hc L hL
  · have hN : (1 : ℝ) ≤ Fintype.card P := by exact_mod_cast Fintype.card_pos (α := P)
    have hlog : 1/2 ≤ Real.log 2 := by
      have h := Real.one_sub_inv_le_log_of_pos (by norm_num : (0 : ℝ) < 2)
      norm_num at h ⊢
      exact h
    exact totalWork_polynomial K T hK hT L (hlog.trans ((Real.log_le_log (by norm_num) (by linarith : (2 : ℝ) ≤ 2 * Fintype.card P)).trans hL))

end
end PoissonAudit
