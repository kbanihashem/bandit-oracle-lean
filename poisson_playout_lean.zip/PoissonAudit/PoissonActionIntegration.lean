module

public import PoissonAudit.ActionLineIntegration
public import PoissonAudit.PoissonUpdateControl

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def actionPenaltyScore (predict : P → X → Fin K) (S : P → ℝ)
    (x : X) (a : Fin K) (t : ℝ) : P → ℝ :=
  fun p => S p + t * actionSlope (fun p => predict p x) a p

theorem actionPenaltyScore_zero (predict : P → X → Fin K) (S : P → ℝ) (x : X) (a : Fin K) :
    actionPenaltyScore predict S x a 0 = S := by ext p; simp [actionPenaltyScore]

@[expose] def insertedPotential (r : NNReal) (D : Measure X)
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) : ℝ :=
  ∫ v, Finset.univ.sup' Finset.univ_nonempty (experimentScore predict sigma S x v)
    ∂insertedExperimentLaw r D K

@[expose] def uninsertedActionProbability (r : NNReal) (D : Measure X)
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) : ℝ :=
  outcomeMass (markedPoolLaw r (contextLaplaceLaw D K)) (fun pool => predict (poissonWinner predict sigma S pool) x) a

@[expose] def insertionGap (r : NNReal) (D : Measure X)
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) : ℝ :=
  insertedPotential r D predict sigma S x -
    affinePoolPotential (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict) sigma

theorem integrable_experimentScore (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (p : P) :
    Integrable (fun v => experimentScore predict sigma S x v p) (insertedExperimentLaw r D K) := by
  have hz : Integrable (fun v : (Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ))) => v.1 (predict p x))
      (insertedExperimentLaw r D K) := by
    unfold insertedExperimentLaw
    simpa only [mul_one] using (integrable_laplace_coordinate K (predict p x)).mul_prod
      (integrable_const (1 : ℝ) (μ := markedPoolLaw r (contextLaplaceLaw D K)))
  have hp : Integrable (fun v : (Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ))) =>
      ∑ j, sigma j * poissonCoefficient predict v.2 p j) (insertedExperimentLaw r D K) := by
    unfold insertedExperimentLaw
    simpa only [one_mul] using (integrable_const (1 : ℝ) (μ := laplaceMeasure K)).mul_prod
      (integrable_poisson_linear_score r D predict sigma p)
  exact ((integrable_const (S p)).add (hz.const_mul (sigma (x, predict p x)))).add hp

theorem lineMax_experimentScore (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (a : Fin K) (t : ℝ)
    (v : (Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ)))) :
    lineMax (experimentScore predict sigma S x v) (actionSlope (fun p => predict p x) a) t =
      Finset.univ.sup' Finset.univ_nonempty
        (experimentScore predict sigma (actionPenaltyScore predict S x a t) x v) := by
  unfold lineMax
  apply Finset.sup'_congr Finset.univ_nonempty rfl
  intro p _
  unfold experimentScore actionPenaltyScore
  ring

theorem lineWinner_experimentScore (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (a : Fin K) (t : ℝ)
    (v : (Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ)))) :
    lineWinner (experimentScore predict sigma S x v) (actionSlope (fun p => predict p x) a) t =
      experimentWinner predict sigma (actionPenaltyScore predict S x a t) x v := by
  apply congrArg winner
  funext p
  unfold experimentScore actionPenaltyScore
  ring

theorem lineActionMass_experiment (r : NNReal) (D : Measure X)
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) (t : ℝ) :
    lineActionMass (insertedExperimentLaw r D K) (fun p v => experimentScore predict sigma S x v p)
      (fun p => predict p x) a t =
    experimentProbability r D predict sigma (actionPenaltyScore predict S x a t) x a := by
  unfold lineActionMass experimentProbability outcomeMass outcomeEvent experimentAction
  congr 2
  ext v
  change predict (lineWinner (experimentScore predict sigma S x v) (actionSlope (fun p => predict p x) a) t) x = a ↔ _
  rw [lineWinner_experimentScore]
  rfl

theorem insertedPotential_action_change (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) (b : ℝ) :
    insertedPotential r D predict sigma (actionPenaltyScore predict S x a b) x -
      insertedPotential r D predict sigma S x =
      -(∫ t in (0 : ℝ)..b, experimentProbability r D predict sigma (actionPenaltyScore predict S x a t) x a) := by
  have h := expected_action_line_change (insertedExperimentLaw r D K)
    (fun p v => experimentScore predict sigma S x v p) (measurable_experimentScore predict sigma S x)
    (integrable_experimentScore r D predict sigma S x) (fun p => predict p x) a 0 b
  simp_rw [lineMax_experimentScore, lineActionMass_experiment] at h
  rw [actionPenaltyScore_zero] at h
  exact h

theorem lineWinner_poissonScore (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (a : Fin K) (t : ℝ)
    (v : ℕ × (ℕ → X × (Fin K → ℝ))) :
    lineWinner (poissonScore predict sigma S v) (actionSlope (fun p => predict p x) a) t =
      poissonWinner predict sigma (actionPenaltyScore predict S x a t) v := by
  apply congrArg winner
  funext p
  unfold poissonScore actionPenaltyScore
  ring

theorem lineActionMass_uninserted (r : NNReal) (D : Measure X)
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) (t : ℝ) :
    lineActionMass (markedPoolLaw r (contextLaplaceLaw D K)) (fun p v => poissonScore predict sigma S v p)
      (fun p => predict p x) a t =
    uninsertedActionProbability r D predict sigma (actionPenaltyScore predict S x a t) x a := by
  unfold lineActionMass uninsertedActionProbability outcomeMass outcomeEvent
  congr 2
  ext v
  change predict (lineWinner (poissonScore predict sigma S v) (actionSlope (fun p => predict p x) a) t) x = a ↔ _
  rw [lineWinner_poissonScore]
  rfl

theorem poissonPotential_action_change (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) (b : ℝ) :
    affinePoolPotential (markedPoolLaw r (contextLaplaceLaw D K))
      (actionPenaltyScore predict S x a b) (poissonCoefficient predict) sigma -
    affinePoolPotential (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict) sigma =
      -(∫ t in (0 : ℝ)..b, uninsertedActionProbability r D predict sigma
        (actionPenaltyScore predict S x a t) x a) := by
  have h := expected_action_line_change (markedPoolLaw r (contextLaplaceLaw D K))
    (fun p v => poissonScore predict sigma S v p)
    (fun p => measurable_const.add (measurable_poisson_linear_score predict sigma p))
    (fun p => (integrable_const _).add (integrable_poisson_linear_score r D predict sigma p))
    (fun p => predict p x) a 0 b
  have heq (t : ℝ) (v : ℕ × (ℕ → X × (Fin K → ℝ))) :
      lineMax (poissonScore predict sigma S v) (actionSlope (fun p => predict p x) a) t =
        affinePoolMax (actionPenaltyScore predict S x a t) (poissonCoefficient predict) sigma v := by
    unfold lineMax affinePoolMax
    apply Finset.sup'_congr Finset.univ_nonempty rfl
    intro p _
    unfold poissonScore actionPenaltyScore
    ring
  simp_rw [heq, lineActionMass_uninserted] at h
  rw [actionPenaltyScore_zero] at h
  exact h

theorem intervalIntegrable_inserted_action_probability
    (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) (b : ℝ) :
    IntervalIntegrable (fun t => experimentProbability r D predict sigma
      (actionPenaltyScore predict S x a t) x a) volume 0 b := by
  have h := intervalIntegrable_lineActionMass (insertedExperimentLaw r D K)
    (fun p v => experimentScore predict sigma S x v p) (measurable_experimentScore predict sigma S x)
    (fun p => predict p x) a 0 b
  convert! h using 1
  funext t
  exact (lineActionMass_experiment r D predict sigma S x a t).symm

theorem intervalIntegrable_uninserted_action_probability
    (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) (b : ℝ) :
    IntervalIntegrable (fun t => uninsertedActionProbability r D predict sigma
      (actionPenaltyScore predict S x a t) x a) volume 0 b := by
  have h := intervalIntegrable_lineActionMass (markedPoolLaw r (contextLaplaceLaw D K))
    (fun p v => poissonScore predict sigma S v p)
    (fun p => measurable_const.add (measurable_poisson_linear_score predict sigma p))
    (fun p => predict p x) a 0 b
  convert! h using 1
  funext t
  exact (lineActionMass_uninserted r D predict sigma S x a t).symm

theorem insertionGap_action_change
    (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) (b : ℝ) :
    insertionGap r D predict sigma S x -
      insertionGap r D predict sigma (actionPenaltyScore predict S x a b) x =
      ∫ t in (0 : ℝ)..b,
        experimentProbability r D predict sigma (actionPenaltyScore predict S x a t) x a -
        uninsertedActionProbability r D predict sigma (actionPenaltyScore predict S x a t) x a := by
  rw [intervalIntegral.integral_sub
    (intervalIntegrable_inserted_action_probability r D predict sigma S x a b)
    (intervalIntegrable_uninserted_action_probability r D predict sigma S x a b)]
  have hG := insertedPotential_action_change r D predict sigma S x a b
  have hF := poissonPotential_action_change r D predict sigma S x a b
  unfold insertionGap
  linarith

end

end PoissonAudit
