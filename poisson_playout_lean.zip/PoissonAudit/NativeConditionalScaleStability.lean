module
public import PoissonAudit.NativeFullFlat
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section

theorem outcomeMass_measurePreserving {Omega Lambda A : Type*}
    [MeasurableSpace Omega] [MeasurableSpace Lambda] [MeasurableSpace A] [MeasurableSingletonClass A]
    (mu : Measure Omega) (nu : Measure Lambda) (e : Omega → Lambda) (he : MeasurePreserving e mu nu)
    (W : Lambda → A) (hW : Measurable W) (a : A) :
    outcomeMass mu (fun v => W (e v)) a = outcomeMass nu W a := by
  unfold outcomeMass outcomeEvent
  have hE : MeasurableSet {z | W z = a} := hW (measurableSet_singleton a)
  rw [← he.map_eq, Measure.map_apply he.measurable hE]
  rfl

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K m : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem fullFlatScale_l1 (sigma tau : X × Fin K → ℝ) (x : X) (C : Fin m → X) :
    (∑ j, |fullFlatScale sigma x C j - fullFlatScale tau x C j|) =
      (∑ a, |sigma (x, a) - tau (x, a)|) + ∑ i : Fin m, ∑ a, |sigma (C i, a) - tau (C i, a)| := by
  classical
  calc
    _ = ∑ q : Fin (m + 1) × Fin K, |sigma ((Fin.cons x C : Fin (m + 1) → X) q.1, q.2) -
        tau ((Fin.cons x C : Fin (m + 1) → X) q.1, q.2)| := by
      symm
      apply Fintype.sum_equiv finProdFinEquiv
      intro q
      change _ = |fullFlatScale sigma x C (finProdFinEquiv q) - fullFlatScale tau x C (finProdFinEquiv q)|
      rw [fullFlatScale_apply, fullFlatScale_apply]
    _ = ∑ i : Fin (m + 1), ∑ a, |sigma ((Fin.cons x C : Fin (m + 1) → X) i, a) -
        tau ((Fin.cons x C : Fin (m + 1) → X) i, a)| := Fintype.sum_prod_type _
    _ = _ := by rw [Fin.sum_univ_succ]; simp only [Fin.cons_zero, Fin.cons_succ]

theorem locationActionMoment_one_eq_outcome (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (C : Fin m → X) (a : Fin K) :
    locationActionMoment predict sigma S x a (fun _ => 1) m C =
      outcomeMass ((laplaceMeasure K).prod (iidPool (laplaceMeasure K) m))
        (fun v => predict (insertedLocationWinner predict sigma S x C v) x) a := by
  classical
  unfold locationActionMoment
  rw [winnerGroupMoment_eq_joint _ _ (measurable_insertedLocationWinner predict sigma S x C) _ _ _ (integrable_const 1)]
  exact integral_if_outcome _ _ ((measurable_of_finite (fun p => predict p x)).comp
    (measurable_insertedLocationWinner predict sigma S x C)) a

@[expose] def fullFlatAction (predict : P → X → Fin K) (S : P → ℝ) (x : X) (C : Fin m → X)
    (z : Fin ((m + 1) * K) → ℝ) : Fin K :=
  predict (winner (fun p => fullFlatScore predict S x C p z)) x

theorem measurable_fullFlatAction (predict : P → X → Fin K) (S : P → ℝ) (x : X) (C : Fin m → X) :
    Measurable (fullFlatAction predict S x C) :=
  (measurable_of_finite (fun p => predict p x)).comp (measurable_winner
    (fun (p : P) (z : Fin ((m + 1) * K) → ℝ) => fullFlatScore predict S x C p z)
      (measurable_fullFlatScore predict S x C))

theorem locationActionMoment_one_eq_flat (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (C : Fin m → X) (a : Fin K) :
    locationActionMoment predict sigma S x a (fun _ => 1) m C =
      outcomeMass (iidPool realLaplace ((m + 1) * K))
        (fun z => fullFlatAction predict S x C (scaleVector (fullFlatScale sigma x C) z)) a := by
  rw [locationActionMoment_one_eq_outcome]
  have heq : (fun v => predict (insertedLocationWinner predict sigma S x C v) x) =
      fun v => fullFlatAction predict S x C (scaleVector (fullFlatScale sigma x C) (fullInsertedFlatEquiv m K v)) := by
    funext v
    unfold fullFlatAction
    rw [fullFlatWinner_eq_inserted]
  rw [heq]
  exact outcomeMass_measurePreserving _ _ (fullInsertedFlatEquiv m K)
    (fullInsertedFlatEquiv_measurePreserving m K) _
      ((measurable_fullFlatAction predict S x C).comp (measurable_scaleVector _)) a

theorem native_conditional_scale_stability (predict : P → X → Fin K) (sigma tau : X × Fin K → ℝ)
    (S : P → ℝ) (hsigma : ∀ j, 1 ≤ sigma j) (htau : ∀ j, 1 ≤ tau j) (x : X) (C : Fin m → X) :
    (∑ a, |locationActionMoment predict sigma S x a (fun _ => 1) m C -
      locationActionMoment predict tau S x a (fun _ => 1) m C|) ≤
        2 * ((∑ a, |sigma (x, a) - tau (x, a)|) + ∑ i : Fin m, ∑ a, |sigma (C i, a) - tau (C i, a)|) := by
  have hs (j) : 1 ≤ fullFlatScale sigma x C j := hsigma _
  have ht (j) : 1 ≤ fullFlatScale tau x C j := htau _
  have h := iid_laplace_outcome_l1_stability ((m + 1) * K) (fullFlatScale sigma x C) (fullFlatScale tau x C)
    hs ht (fullFlatAction predict S x C) (measurable_fullFlatAction predict S x C)
  simp_rw [locationActionMoment_one_eq_flat]
  rw [fullFlatScale_l1] at h
  exact h
end
end PoissonAudit
