module
public import PoissonAudit.RoundBound
public import PoissonAudit.FiniteChoiceMixture
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] abbrev paperNativeFiniteOutcome (K : ℕ) (delta : ℝ) := EmpiricalChoice K (paperTrials K delta) × Fin K

@[expose] def paperNativeFiniteChoiceLaw (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta : ℝ) (hB : 1 ≤ B) (S : P → ℝ) (x : X) : PMF (EmpiricalChoice K (paperTrials K delta)) :=
  let J := paperIterations K r lam B eps
  let m := paperTrials K delta
  nativeCappedChoiceLaw r D predict S lam B (paperStep K r lam B eps) hB
    (paperCap r (J + m) delta) J m x

@[expose] def paperNativeFiniteChoiceWeight (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta : ℝ) (hB : 1 ≤ B) (S : P → ℝ) (x : X)
    (choice : EmpiricalChoice K (paperTrials K delta)) : ℝ :=
  let J := paperIterations K r lam B eps
  let m := paperTrials K delta
  nativeCappedChoiceWeight r D predict S lam B (paperStep K r lam B eps) hB
    (paperCap r (J + m) delta) J m x choice

theorem paperNativeFiniteChoiceWeight_nonneg (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta : ℝ) (hB : 1 ≤ B) (S : P → ℝ) (x : X)
    (choice : EmpiricalChoice K (paperTrials K delta)) :
    0 ≤ paperNativeFiniteChoiceWeight r D predict lam B eps delta hB S x choice := outcomeMass_nonneg _ _ _

theorem paperNativeFiniteChoiceWeight_sum (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta : ℝ) (hB : 1 ≤ B) (S : P → ℝ) (x : X) :
    (∑ choice, paperNativeFiniteChoiceWeight r D predict lam B eps delta hB S x choice) = 1 :=
  sum_outcomeMass _ _ (measurable_of_finite _)

theorem integral_paperNativeFiniteChoiceLaw (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta : ℝ) (hB : 1 ≤ B) (S : P → ℝ) (x : X)
    (f : EmpiricalChoice K (paperTrials K delta) → ℝ) :
    (∫ choice, f choice ∂(paperNativeFiniteChoiceLaw r D predict lam B eps delta hB S x).toMeasure) =
      ∑ choice, paperNativeFiniteChoiceWeight r D predict lam B eps delta hB S x choice * f choice := by
  exact integral_actionPMF (paperNativeFiniteChoiceWeight r D predict lam B eps delta hB S x)
    (paperNativeFiniteChoiceWeight_nonneg r D predict lam B eps delta hB S x)
    (paperNativeFiniteChoiceWeight_sum r D predict lam B eps delta hB S x) f

@[expose] def paperNativeFiniteOutcomeWeight (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta gamma : ℝ) (hB : 1 ≤ B) (S : P → ℝ) (x : X)
    (o : paperNativeFiniteOutcome K delta) : ℝ :=
  choiceActionWeight (paperNativeFiniteChoiceWeight r D predict lam B eps delta hB S x)
    (choiceProbability K gamma (paperTrials K delta)) o

@[expose] def paperNativeFiniteOutcomeUpdate (predict : P → X → Fin K) (delta gamma : ℝ)
    (S : P → ℝ) (x : X) (c : Fin K → ℝ) (o : paperNativeFiniteOutcome K delta) : P → ℝ :=
  treeUpdatedScore S (choiceProbability K gamma (paperTrials K delta) o.1) c (fun p => predict p x) o.2

theorem paperNativeFiniteOutcomeWeight_nonneg (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta gamma : ℝ) (hB : 1 ≤ B) (hg0 : 0 ≤ gamma) (hg1 : gamma ≤ 1) (hK : 0 < K) (hd : 0 < delta)
    (S : P → ℝ) (x : X) (o : paperNativeFiniteOutcome K delta) :
    0 ≤ paperNativeFiniteOutcomeWeight r D predict lam B eps delta gamma hB S x o :=
  choiceActionWeight_nonneg _ _ (paperNativeFiniteChoiceWeight_nonneg r D predict lam B eps delta hB S x)
    (choiceProbability_nonneg gamma hg0 hg1 _ (paperTrials_pos K hK delta hd)) o

theorem paperNativeFiniteOutcomeWeight_sum (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta gamma : ℝ) (hB : 1 ≤ B) (hK : 0 < K) (hd : 0 < delta) (S : P → ℝ) (x : X) :
    (∑ o, paperNativeFiniteOutcomeWeight r D predict lam B eps delta gamma hB S x o) = 1 :=
  choiceActionWeight_sum _ _ (paperNativeFiniteChoiceWeight_sum r D predict lam B eps delta hB S x)
    (choiceProbability_sum hK gamma _ (paperTrials_pos K hK delta hd))

theorem paperNativeFiniteOutcome_mean_update (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta gamma : ℝ) (hB : 1 ≤ B) (hK : 0 < K)
    (hg0 : 0 < gamma) (hg1 : gamma ≤ 1) (hd : 0 < delta) (S : P → ℝ) (x : X) (c : Fin K → ℝ) :
    (fun p => ∑ o, paperNativeFiniteOutcomeWeight r D predict lam B eps delta gamma hB S x o *
      paperNativeFiniteOutcomeUpdate predict delta gamma S x c o p) = fun p => S p - c (predict p x) :=
  choiceActionWeight_mean_update _ _ (paperNativeFiniteChoiceWeight_sum r D predict lam B eps delta hB S x)
    (choiceProbability_pos hK gamma hg0 hg1 _ (paperTrials_pos K hK delta hd))
    (choiceProbability_sum hK gamma _ (paperTrials_pos K hK delta hd)) S c (fun p => predict p x)

theorem paperNative_finite_sum_round_bound (r : NNReal) (hr : 0 < (r : ℝ)) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta gamma : ℝ)
    (hlam : 0 < lam) (hB : 1 ≤ B) (heps : 0 < eps) (hd : 0 < delta) (hK : 0 < K)
    (hg : 0 < gamma) (hgsmall : gamma ≤ 1 / 2) (hcap : (K : ℝ) / gamma ≤ B)
    (hlamBudget : 4 * (r : ℝ) * explorationLog K gamma ≤ lam)
    (hepsBudget : eps ≤ lam * delta ^ 2 / (32 * B ^ 2 * ((r : ℝ) + 1)))
    (c : X → Fin K → ℝ) (hc0 : ∀ x a, 0 ≤ c x a) (hc1 : ∀ x a, c x a ≤ 1) (S : P → ℝ) :
    (∑ x, (D {x}).toReal * ∑ o, paperNativeFiniteOutcomeWeight r D predict lam B eps delta gamma hB S x o *
      (c x o.2 + nativeVariationalValue r D predict lam B hB (paperNativeFiniteOutcomeUpdate predict delta gamma S x (c x) o))) ≤
        nativeVariationalValue r D predict lam B hB S + nativeRoundSlack P r K lam B gamma + (1 + K / gamma) * (2 * delta * Real.sqrt (((r : ℝ) + 1) * K)) := by
  let s : NativeScaleBox X K B := ⟨nativeOptimalScale r D predict lam B hB S,
    (optimalScale_spec (markedPoolLaw r (contextLaplaceLaw D K)) (poissonCoefficient predict)
      (integrable_poissonCoefficient r D predict) (fun j => (D {j.1}).toReal) lam B hB S).1⟩
  have hmin := (optimalScale_spec (markedPoolLaw r (contextLaplaceLaw D K)) (poissonCoefficient predict)
    (integrable_poissonCoefficient r D predict) (fun j => (D {j.1}).toReal) lam B hB S).2
  have h := paper_one_round r hr D predict S lam B eps delta gamma hlam hB heps hd hK hg hgsmall hcap hlamBudget s hmin hepsBudget c hc0 hc1
  change (∫ x, ∫ choice, nativeRoundFunctional r D predict lam B hB S x (c x) (choiceProbability K gamma (paperTrials K delta) choice)
    ∂(paperNativeFiniteChoiceLaw r D predict lam B eps delta hB S x).toMeasure ∂D) ≤ _ at h
  simp_rw [integral_paperNativeFiniteChoiceLaw] at h
  rw [integral_fintype Integrable.of_finite] at h
  simp only [Measure.real, smul_eq_mul] at h
  have heq : (∑ x, (D {x}).toReal * ∑ o, paperNativeFiniteOutcomeWeight r D predict lam B eps delta gamma hB S x o *
      (c x o.2 + nativeVariationalValue r D predict lam B hB (paperNativeFiniteOutcomeUpdate predict delta gamma S x (c x) o))) =
    (∑ x, (D {x}).toReal * ∑ choice, paperNativeFiniteChoiceWeight r D predict lam B eps delta hB S x choice *
      nativeRoundFunctional r D predict lam B hB S x (c x) (choiceProbability K gamma (paperTrials K delta) choice)) +
        nativeVariationalValue r D predict lam B hB S := by
    simp only [Fintype.sum_prod_type, paperNativeFiniteOutcomeWeight, choiceActionWeight, paperNativeFiniteOutcomeUpdate,
      mul_assoc, ← Finset.mul_sum]
    simp_rw [nativeRoundFunctional_add_value r D predict lam B hB S _ _ _
      (choiceProbability_sum hK gamma _ (paperTrials_pos K hK delta hd) _)]
    exact finite_weighted_add_const _ (paperNativeFiniteChoiceWeight r D predict lam B eps delta hB S)
      (context_mass_sum D) (paperNativeFiniteChoiceWeight_sum r D predict lam B eps delta hB S) _ _
  rw [heq]
  linarith

theorem paperNative_capped_finite_context_regret (r : NNReal) (hr : 0 < (r : ℝ)) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta gamma : ℝ)
    (hlam : 0 < lam) (hB : 1 ≤ B) (heps : 0 < eps) (hd : 0 < delta) (hK : 0 < K)
    (hg : 0 < gamma) (hgsmall : gamma ≤ 1 / 2) (hcap : (K : ℝ) / gamma ≤ B)
    (hlamBudget : 4 * (r : ℝ) * explorationLog K gamma ≤ lam)
    (hepsBudget : eps ≤ lam * delta ^ 2 / (32 * B ^ 2 * ((r : ℝ) + 1)))
    (costs : List (X → Fin K → ℝ)) (hc0 : ∀ c ∈ costs, ∀ x a, 0 ≤ c x a)
    (hc1 : ∀ c ∈ costs, ∀ x a, c x a ≤ 1) :
    finiteOutcomeLoss (fun x => (D {x}).toReal) Prod.snd
      (paperNativeFiniteOutcomeWeight r D predict lam B eps delta gamma hB) (paperNativeFiniteOutcomeUpdate predict delta gamma) costs (fun _ => 0) +
        contextBestScore (fun x => (D {x}).toReal) predict costs (fun _ => 0) ≤
          6 * (r : ℝ) * K + lam * K * Real.log B + costs.length * (nativeRoundSlack P r K lam B gamma + (1 + K / gamma) * (2 * delta * Real.sqrt (((r : ℝ) + 1) * K))) := by
  have hgm : gamma ≤ 1 := by linarith
  have h := finiteOutcome_regret (fun x => (D {x}).toReal) (fun _ => ENNReal.toReal_nonneg) (context_mass_sum D)
    predict Prod.snd (paperNativeFiniteOutcomeWeight r D predict lam B eps delta gamma hB)
    (paperNativeFiniteOutcomeWeight_nonneg r D predict lam B eps delta gamma hB hg.le hgm hK hd)
    (paperNativeFiniteOutcomeWeight_sum r D predict lam B eps delta gamma hB hK hd)
    (paperNativeFiniteOutcomeUpdate predict delta gamma)
    (paperNativeFiniteOutcome_mean_update r D predict lam B eps delta gamma hB hK hg hgm hd)
    (nativeVariationalValue r D predict lam B hB)
    (fun S p => poisson_variationalValue_ge_score r D predict S lam B hlam.le hB p)
    (nativeRoundSlack P r K lam B gamma + (1 + K / gamma) * (2 * delta * Real.sqrt (((r : ℝ) + 1) * K))) costs
    (fun c hc S => by
      have hrnd := paperNative_finite_sum_round_bound r hr D predict lam B eps delta gamma hlam hB heps hd hK hg hgsmall hcap hlamBudget hepsBudget c (hc0 c hc) (hc1 c hc) S
      linarith) (fun _ => 0)
  have hi := native_initial_value_bound r D predict lam B hB
  linarith
@[expose] def paperNativeCappedLaw (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta gamma : ℝ) (hB : 1 ≤ B) (hK : 0 < K)
    (hg0 : 0 ≤ gamma) (hg1 : gamma ≤ 1) (hd : 0 < delta) (costs : List (X → Fin K → ℝ)) :
    PMF (outcomePaths (paperNativeFiniteOutcome K delta) costs) :=
  outcomePathLaw (fun x => (D {x}).toReal) (fun _ => ENNReal.toReal_nonneg) (context_mass_sum D)
    (paperNativeFiniteOutcomeWeight r D predict lam B eps delta gamma hB)
    (paperNativeFiniteOutcomeUpdate predict delta gamma)
    (paperNativeFiniteOutcomeWeight_nonneg r D predict lam B eps delta gamma hB hg0 hg1 hK hd)
    (paperNativeFiniteOutcomeWeight_sum r D predict lam B eps delta gamma hB hK hd) costs (fun _ => 0)

theorem paperNative_capped_expected_regret (r : NNReal) (hr : 0 < (r : ℝ)) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta gamma : ℝ)
    (hlam : 0 < lam) (hB : 1 ≤ B) (heps : 0 < eps) (hd : 0 < delta) (hK : 0 < K)
    (hg : 0 < gamma) (hgsmall : gamma ≤ 1 / 2) (hcap : (K : ℝ) / gamma ≤ B)
    (hlamBudget : 4 * (r : ℝ) * explorationLog K gamma ≤ lam)
    (hepsBudget : eps ≤ lam * delta ^ 2 / (32 * B ^ 2 * ((r : ℝ) + 1)))
    (costs : List (X → Fin K → ℝ)) (hc0 : ∀ c ∈ costs, ∀ x a, 0 ≤ c x a)
    (hc1 : ∀ c ∈ costs, ∀ x a, c x a ≤ 1) :
    (∫ path, outcomePathLoss Prod.snd costs path + treeBestScore (outcomePathTrueScore predict costs (fun _ => 0) path)
      ∂(paperNativeCappedLaw r D predict lam B eps delta gamma hB hK hg.le (by linarith) hd costs).toMeasure) ≤
        6 * (r : ℝ) * K + lam * K * Real.log B + costs.length * (nativeRoundSlack P r K lam B gamma + (1 + K / gamma) * (2 * delta * Real.sqrt (((r : ℝ) + 1) * K))) := by
  unfold paperNativeCappedLaw
  rw [integral_outcomePath_regret]
  exact paperNative_capped_finite_context_regret r hr D predict lam B eps delta gamma hlam hB heps hd hK hg hgsmall hcap hlamBudget hepsBudget costs hc0 hc1
end
end PoissonAudit
