module

public import PoissonAudit.MarkedPoolMoments
public import PoissonAudit.LaplaceProductLaw
public import PoissonAudit.ScaleStrongConvexity

public section

open MeasureTheory ProbabilityTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] {K : ℕ}

@[expose] def singleMarkCoefficient (predict : P → X → Fin K) (p : P)
    (j : X × Fin K) (u : X × (Fin K → ℝ)) : ℝ := by
  classical
  exact if predict p j.1 = j.2 then ({j.1} : Set X).indicator (fun _ => (1 : ℝ)) u.1 * u.2 j.2 else 0

@[expose] def contextLaplaceLaw (D : Measure X) (K : ℕ) : Measure (X × (Fin K → ℝ)) :=
  D.prod (laplaceMeasure K)

instance contextLaplaceLaw_isProbability (D : Measure X) [IsProbabilityMeasure D] :
    IsProbabilityMeasure (contextLaplaceLaw D K) := by unfold contextLaplaceLaw; infer_instance

theorem measurable_singleMarkCoefficient (predict : P → X → Fin K) (p : P) (j : X × Fin K) :
    Measurable (singleMarkCoefficient predict p j) := by
  classical
  unfold singleMarkCoefficient
  split_ifs
  · exact ((measurable_const.indicator (measurableSet_singleton j.1)).comp measurable_fst).mul
      ((measurable_pi_apply j.2).comp measurable_snd)
  · exact measurable_const

theorem integrable_singleMarkCoefficient (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (p : P) (j : X × Fin K) :
    Integrable (singleMarkCoefficient predict p j) (contextLaplaceLaw D K) := by
  classical
  unfold singleMarkCoefficient
  split_ifs
  · exact ((integrable_const (1 : ℝ)).indicator (measurableSet_singleton j.1)).mul_prod
      (integrable_laplace_coordinate K j.2)
  · exact integrable_const (0 : ℝ)

theorem integral_singleMarkCoefficient (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (p : P) (j : X × Fin K) :
    (∫ u, singleMarkCoefficient predict p j u ∂contextLaplaceLaw D K) = 0 := by
  classical
  unfold singleMarkCoefficient
  split_ifs
  · change (∫ u : X × (Fin K → ℝ), ({j.1} : Set X).indicator (fun _ => (1 : ℝ)) u.1 * u.2 j.2 ∂D.prod (laplaceMeasure K)) = 0
    have h := integral_prod_mul (μ := D) (ν := laplaceMeasure K)
      (({j.1} : Set X).indicator (fun _ => (1 : ℝ))) (fun z : Fin K → ℝ => z j.2)
    simpa only [integral_laplace_coordinate, mul_zero] using h
  · simp

@[expose] def poissonCoefficient (predict : P → X → Fin K)
    (pool : ℕ × (ℕ → X × (Fin K → ℝ))) (p : P) (j : X × Fin K) : ℝ :=
  poolSum (singleMarkCoefficient predict p j) pool

theorem integrable_poissonCoefficient (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (p : P) (j : X × Fin K) :
    Integrable (fun pool => poissonCoefficient predict pool p j)
      (markedPoolLaw r (contextLaplaceLaw D K)) :=
  integrable_poolSum r _ _ (measurable_singleMarkCoefficient predict p j)
    (integrable_singleMarkCoefficient D predict p j)

theorem integral_poissonCoefficient (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (p : P) (j : X × Fin K) :
    (∫ pool, poissonCoefficient predict pool p j ∂markedPoolLaw r (contextLaplaceLaw D K)) = 0 := by
  change (∫ pool, poolSum _ pool ∂_) = _
  rw [integral_poolSum r _ _ (measurable_singleMarkCoefficient predict p j)
    (integrable_singleMarkCoefficient D predict p j), integral_singleMarkCoefficient, mul_zero]

variable [Fintype X]

theorem singleMark_expansion (predict : P → X → Fin K) (p : P)
    (sigma : X × Fin K → ℝ) (u : X × (Fin K → ℝ)) :
    (∑ j, sigma j * singleMarkCoefficient predict p j u) = sigma (u.1, predict p u.1) * u.2 (predict p u.1) := by
  classical
  rw [Finset.sum_eq_single (u.1, predict p u.1)]
  · simp [singleMarkCoefficient]
  · intro j _ hj
    by_cases hp : predict p j.1 = j.2
    · by_cases hx : u.1 = j.1
      · have hj' : j = (u.1, predict p u.1) := by
          apply Prod.ext
          · exact hx.symm
          · rw [← hp, hx]
        exact (hj hj').elim
      · simp [singleMarkCoefficient, hp, hx]
    · simp [singleMarkCoefficient, hp]
  · simp

theorem poissonCoefficient_expansion (predict : P → X → Fin K) (p : P)
    (sigma : X × Fin K → ℝ) (pool : ℕ × (ℕ → X × (Fin K → ℝ))) :
    (∑ j, sigma j * poissonCoefficient predict pool p j) =
      ∑ i : Fin pool.1, sigma ((pool.2 i).1, predict p (pool.2 i).1) * (pool.2 i).2 (predict p (pool.2 i).1) := by
  classical
  unfold poissonCoefficient poolSum
  simp_rw [Finset.mul_sum]
  rw [Finset.sum_comm]
  exact Finset.sum_congr rfl fun i _ => singleMark_expansion predict p sigma (pool.2 i)

theorem poisson_scalePenalty_eq (D : Measure X) [IsProbabilityMeasure D]
    (sigma : X × Fin K → ℝ) (lam B : ℝ) :
    scalePenalty (fun j : X × Fin K => (D {j.1}).toReal) lam B sigma =
      lam * ∫ x, ∑ a : Fin K, Real.log (B / sigma (x, a)) ∂D := by
  classical
  have h := integral_fintype (μ := D) (f := fun x => ∑ a : Fin K, Real.log (B / sigma (x, a)))
    Integrable.of_finite
  rw [h]
  simp only [scalePenalty, Fintype.sum_prod_type, Measure.real, smul_eq_mul, Finset.mul_sum]

variable [Fintype P] [Nonempty P]

theorem exists_poisson_scale_minimizer (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B : ℝ) (hB : 1 ≤ B) :
    ∃ sigma ∈ scaleBox (X × Fin K) B,
      IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
        (fun j => (D {j.1}).toReal) lam B) (scaleBox (X × Fin K) B) sigma :=
  exists_scale_minimizer _ S _ (integrable_poissonCoefficient r D predict) _ lam B hB

theorem poisson_variationalValue_ge_score (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B : ℝ) (hlam : 0 ≤ lam) (hB : 1 ≤ B) (p : P) :
    S p ≤ variationalValue (markedPoolLaw r (contextLaplaceLaw D K)) (poissonCoefficient predict)
      (integrable_poissonCoefficient r D predict) (fun j => (D {j.1}).toReal) lam B hB S :=
  variationalValue_ge_score _ _ (integrable_poissonCoefficient r D predict)
    (integral_poissonCoefficient r D predict) _ (fun _ => ENNReal.toReal_nonneg) lam B hlam hB S p

end

end PoissonAudit
