module

public import PoissonAudit.DegenerateActions

public section

open MeasureTheory Set

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X]
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]
    {K : ℕ}

theorem poisson_inserted_quadratic_remainder
    (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (hsigma : 0 < sigma (x, a))
    (b : ℝ) (hb : 0 ≤ b) (hbs : b ≤ sigma (x, a)) :
    insertedPotential r D predict sigma (actionPenaltyScore predict S x a b) x -
      insertedPotential r D predict sigma S x + b * experimentProbability r D predict sigma S x a ≤
      (Real.exp 1 - 2) * (experimentBeta r D predict sigma S x a / sigma (x, a)) * b ^ 2 := by
  classical
  cases K with
  | zero => exact Fin.elim0 a
  | succ n =>
    by_cases hE : (actionPolicyGroup predict x a).Nonempty
    · by_cases hEc : (actionPolicyGroup predict x a)ᶜ.Nonempty
      · have h := insertedPotential_quadratic_remainder r D predict sigma S x a hsigma hE hEc b hb hbs
        rw [thresholdCurvature_eq_experimentBeta r D predict sigma S x a hsigma hE hEc] at h
        exact h
      · have hall : ∀ p, predict p x = a := by
          intro p
          apply (mem_actionPolicyGroup predict x a p).mp
          by_contra hp
          exact hEc ⟨p, Finset.mem_compl.mpr hp⟩
        rw [insertedPotential_remainder_all r D predict sigma S x a hall b,
          experimentBeta_all r D predict sigma S x a hall]
        simp
    · have hnone : ∀ p, predict p x ≠ a := by
        intro p hp
        exact hE ⟨p, (mem_actionPolicyGroup predict x a p).mpr hp⟩
      rw [insertedPotential_remainder_none r D predict sigma S x a hnone b,
        experimentBeta_none r D predict sigma S x a hnone]
      simp

theorem experimentBeta_nonneg (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (hsigma : 0 < sigma (x, a)) :
    0 ≤ experimentBeta r D predict sigma S x a := by
  classical
  cases K with
  | zero => exact Fin.elim0 a
  | succ n =>
    by_cases hE : (actionPolicyGroup predict x a).Nonempty
    · by_cases hEc : (actionPolicyGroup predict x a)ᶜ.Nonempty
      · have h := experimentBeta_eq_thresholdDensity r D predict sigma S x a hsigma hE hEc 0
        rw [actionPenaltyScore_zero] at h
        rw [h]
        exact integral_nonneg fun _ => (realLaplaceDensity_pos _).le
      · have hall : ∀ p, predict p x = a := by
          intro p
          apply (mem_actionPolicyGroup predict x a p).mp
          by_contra hp
          exact hEc ⟨p, Finset.mem_compl.mpr hp⟩
        rw [experimentBeta_all r D predict sigma S x a hall]
    · have hnone : ∀ p, predict p x ≠ a := by
        intro p hp
        exact hE ⟨p, (mem_actionPolicyGroup predict x a p).mpr hp⟩
      rw [experimentBeta_none r D predict sigma S x a hnone]

theorem experimentBeta_le_probability (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) :
    experimentBeta r D predict sigma S x a ≤ experimentProbability r D predict sigma S x a := by
  classical
  let E := experimentActionEvent predict sigma S x a
  have hE : MeasurableSet E := measurable_experimentActionEvent predict sigma S x a
  have hi : Integrable (fun v => E.indicator (fun _ => (1 : ℝ)) v) (insertedExperimentLaw r D K) :=
    (integrable_const (1 : ℝ)).indicator hE
  have hp : (∫ v, E.indicator (fun _ => (1 : ℝ)) v ∂insertedExperimentLaw r D K) =
      experimentProbability r D predict sigma S x a := by
    have h := integral_indicator_const (1 : ℝ) (μ := insertedExperimentLaw r D K) hE
    convert! h using 1
    change (insertedExperimentLaw r D K).real E = (insertedExperimentLaw r D K).real E * 1
    ring
  rw [← hp]
  apply integral_mono (integrable_experiment_beta r D predict sigma S x a) hi
  intro v
  change E.indicator (fun _ => (1 : ℝ)) v * laplaceSign (v.1 a) ≤ E.indicator (fun _ => (1 : ℝ)) v
  have hsign : laplaceSign (v.1 a) ≤ 1 := (le_abs_self _).trans_eq (abs_laplaceSign _)
  by_cases h : v ∈ E
  · simpa only [Set.indicator_of_mem h, one_mul] using hsign
  · simp only [Set.indicator_of_notMem h, zero_mul, le_refl]

end

end PoissonAudit
