module
public import PoissonAudit.NativeCappedLaw
public import PoissonAudit.FiniteRound
public import PoissonAudit.PoissonCap
public import PoissonAudit.FiniteChoiceMixture
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem paper_action_accuracy (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eps delta gamma : ℝ)
    (hlam : 0 < lam) (hB : 1 ≤ B) (heps : 0 < eps) (hd : 0 < delta) (hK : 0 < K)
    (hg0 : 0 ≤ gamma) (hg1 : gamma ≤ 1) (s : NativeScaleBox X K B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun q => (D {q.1}).toReal) lam B) (scaleBox (X × Fin K) B) s.val)
    (hepsBudget : eps ≤ lam * delta ^ 2 / (32 * B ^ 2 * ((r : ℝ) + 1))) :
    let J := paperIterations K r lam B eps
    let m := paperTrials K delta
    let cap := paperCap r (J + m) delta
    let eta := paperStep K r lam B eps
    (∫ x, ∫ choice, ∑ a, |choiceProbability K gamma m choice a - nativeBanditProbability r D predict s.val S gamma x a|
      ∂(nativeCappedChoiceLaw r D predict S lam B eta hB cap J m x).toMeasure ∂D) ≤ 2 * delta * Real.sqrt (((r : ℝ) + 1) * K) := by
  dsimp only
  let J := paperIterations K r lam B eps
  let m := paperTrials K delta
  let cap := paperCap r (J + m) delta
  let eta := paperStep K r lam B eps
  let z := Real.sqrt (((r : ℝ) + 1) * K)
  have hk : (1 : ℝ) ≤ K := by exact_mod_cast hK
  have hnon : 0 ≤ (r : ℝ) := r.coe_nonneg
  have hz2 : z ^ 2 = ((r : ℝ) + 1) * K := Real.sq_sqrt (by positivity)
  have hz0 : 0 ≤ z := Real.sqrt_nonneg _
  have hz1 : 1 ≤ z := by nlinarith [mul_nonneg hnon (Nat.cast_nonneg K)]
  have hz : 0 < z := by linarith
  have hoptbudget : eps ≤ lam * (delta*z)^2 / (32 * B^2 * ((r : ℝ)+1)^2 * K) := by
    apply hepsBudget.trans
    apply le_of_eq
    rw [mul_pow, hz2]
    field_simp
  have hopt := paper_mean_action_accuracy r D predict S lam B eps (delta*z) hlam hB heps
    (mul_pos hd hz) hK s hmin hoptbudget
  have hm := paperTrials_pos K hK delta hd
  have hmain := paper_native_capped_mean_reference_error r D predict S lam B eta gamma hB hK hg0 hg1 cap J m hm s
  have hcap := paper_count_cap r (J+m) (by omega) delta hd
  change ((J+m : ℕ) : ℝ) * (ProbabilityTheory.poissonMeasure r).real {n : ℕ | cap < n} ≤ delta / 4 at hcap
  have htrials : (K : ℝ) * Real.sqrt (1 / (m : ℝ)) ≤ delta*z/4 := by
    apply cardinal_sqrt_one_div_le (Nat.cast_nonneg K) (by positivity) hm
    apply le_trans _ (Nat.le_ceil (16 * (K : ℝ) / delta^2))
    rw [div_pow, mul_pow, hz2]
    apply (div_le_div_iff₀ (by positivity) (by positivity)).mpr
    nlinarith only [mul_nonneg hnon (show 0 ≤ (K : ℝ)^2 * delta^2 by positivity)]
  change _ ≤ 2 * delta * z
  change (∫ state, nativeMeanActionError r D predict S state.2.val s.val ∂nativeSGDStateLaw r D predict S lam B eta hB J) ≤ delta*z/2 at hopt
  linarith [mul_le_mul_of_nonneg_left hz1 hd.le]

theorem paper_one_round (r : NNReal) (hr : 0 < (r : ℝ)) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eps delta gamma : ℝ)
    (hlam : 0 < lam) (hB : 1 ≤ B) (heps : 0 < eps) (hd : 0 < delta) (hK : 0 < K)
    (hg : 0 < gamma) (hgsmall : gamma ≤ 1 / 2) (hcap : (K : ℝ) / gamma ≤ B)
    (hlamBudget : 4 * (r : ℝ) * explorationLog K gamma ≤ lam)
    (s : NativeScaleBox X K B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun q => (D {q.1}).toReal) lam B) (scaleBox (X × Fin K) B) s.val)
    (hepsBudget : eps ≤ lam * delta ^ 2 / (32 * B ^ 2 * ((r : ℝ) + 1)))
    (c : X → Fin K → ℝ) (hc0 : ∀ x a, 0 ≤ c x a) (hc1 : ∀ x a, c x a ≤ 1) :
    let J := paperIterations K r lam B eps
    let m := paperTrials K delta
    let cap := paperCap r (J + m) delta
    let eta := paperStep K r lam B eps
    (∫ x, ∫ choice, nativeRoundFunctional r D predict lam B hB S x (c x) (choiceProbability K gamma m choice)
      ∂(nativeCappedChoiceLaw r D predict S lam B eta hB cap J m x).toMeasure ∂D) ≤
        nativeRoundSlack P r K lam B gamma + (1 + K / gamma) * (2 * delta * Real.sqrt (((r : ℝ) + 1) * K)) := by
  dsimp only
  let J := paperIterations K r lam B eps
  let m := paperTrials K delta
  let cap := paperCap r (J + m) delta
  let eta := paperStep K r lam B eps
  let nu := fun x => (nativeCappedChoiceLaw r D predict S lam B eta hB cap J m x).toMeasure
  let ideal := nativeBanditProbability r D predict s.val S gamma
  let err := fun x choice => ∑ a, |choiceProbability K gamma m choice a - ideal x a|
  let Phi := fun x q => nativeRoundFunctional r D predict lam B hB S x (c x) q
  let C : ℝ := 1 + K / gamma
  have hC : 0 ≤ C := by dsimp [C]; positivity
  have hgm : gamma ≤ 1 := by linarith
  have hm : 0 < m := paperTrials_pos K hK delta hd
  have hp (x : X) (choice : EmpiricalChoice K m) : Phi x (choiceProbability K gamma m choice) ≤ Phi x (ideal x) + C * err x choice := by
    have h := native_probability_perturbation r D predict lam B gamma hlam.le hB hK hg S x (c x)
      (choiceProbability K gamma m choice) (ideal x) (hc0 x) (hc1 x)
      (choiceProbability_floor gamma hgm m hm choice)
      (fun a => exploration_floor (experimentProbability_nonneg r D predict s.val S x a) hgm)
    have hab := (le_abs_self _).trans h
    change Phi x (choiceProbability K gamma m choice) - Phi x (ideal x) ≤ C * err x choice at hab
    linarith
  have hx (x : X) : (∫ choice, Phi x (choiceProbability K gamma m choice) ∂nu x) ≤
      Phi x (ideal x) + C * (∫ choice, err x choice ∂nu x) := by
    have h := integral_mono (μ := nu x) Integrable.of_finite Integrable.of_finite (hp x)
    rw [integral_add (integrable_const _) Integrable.of_finite, integral_const_mul,
      integral_const, probReal_univ, one_smul] at h
    exact h
  have houter := integral_mono (μ := D) Integrable.of_finite Integrable.of_finite hx
  rw [integral_add Integrable.of_finite Integrable.of_finite, integral_const_mul] at houter
  have hac := paper_action_accuracy r D predict S lam B eps delta gamma hlam hB heps hd hK hg.le hgm s hmin hepsBudget
  change (∫ x, ∫ choice, err x choice ∂nu x ∂D) ≤ 2 * delta * Real.sqrt (((r : ℝ) + 1) * K) at hac
  have hideal := native_one_round_bound r hr D predict s.val S lam B gamma hK hg hgsmall hlam hB hcap hlamBudget s.property hmin c hc0 hc1
  change (∫ x, Phi x (ideal x) ∂D) ≤ nativeRoundSlack P r K lam B gamma at hideal
  have hacc := mul_le_mul_of_nonneg_left hac hC
  change _ ≤ nativeRoundSlack P r K lam B gamma + C * (2 * delta * Real.sqrt (((r : ℝ) + 1) * K))
  linarith
end
end PoissonAudit
