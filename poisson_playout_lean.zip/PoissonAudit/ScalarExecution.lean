module
public import PoissonAudit.ArrayReplay
public section
namespace PoissonAudit
noncomputable section

inductive ScalarExpr (I : Type*) where
  | input : I → ScalarExpr I
  | constant : ℝ → ScalarExpr I
  | add : ScalarExpr I → ScalarExpr I → ScalarExpr I
  | sub : ScalarExpr I → ScalarExpr I → ScalarExpr I
  | mul : ScalarExpr I → ScalarExpr I → ScalarExpr I
  | div : ScalarExpr I → ScalarExpr I → ScalarExpr I
  | min : ScalarExpr I → ScalarExpr I → ScalarExpr I
  | max : ScalarExpr I → ScalarExpr I → ScalarExpr I

@[expose] def ScalarExpr.value {I : Type*} (env : I → ℝ) : ScalarExpr I → ℝ
  | .input i => env i
  | .constant r => r
  | .add a b => a.value env + b.value env
  | .sub a b => a.value env - b.value env
  | .mul a b => a.value env * b.value env
  | .div a b => a.value env / b.value env
  | .min a b => Min.min (a.value env) (b.value env)
  | .max a b => Max.max (a.value env) (b.value env)

@[expose] def ScalarExpr.steps {I : Type*} : ScalarExpr I → ℕ
  | .input _ => 1
  | .constant _ => 1
  | .add a b | .sub a b | .mul a b | .div a b | .min a b | .max a b => a.steps + b.steps + 1

@[expose] def ScalarExpr.execute {I : Type*} (env : I → ℝ) : ScalarExpr I → ℝ × ℕ
  | .input i => (env i, 1)
  | .constant r => (r, 1)
  | .add a b => let x := a.execute env; let y := b.execute env; (x.1 + y.1, x.2 + y.2 + 1)
  | .sub a b => let x := a.execute env; let y := b.execute env; (x.1 - y.1, x.2 + y.2 + 1)
  | .mul a b => let x := a.execute env; let y := b.execute env; (x.1 * y.1, x.2 + y.2 + 1)
  | .div a b => let x := a.execute env; let y := b.execute env; (x.1 / y.1, x.2 + y.2 + 1)
  | .min a b => let x := a.execute env; let y := b.execute env; (Min.min x.1 y.1, x.2 + y.2 + 1)
  | .max a b => let x := a.execute env; let y := b.execute env; (Max.max x.1 y.1, x.2 + y.2 + 1)

theorem ScalarExpr.execute_correct {I : Type*} (env : I → ℝ) (e : ScalarExpr I) : e.execute env = (e.value env, e.steps) := by
  induction e <;> simp_all [ScalarExpr.execute, ScalarExpr.value, ScalarExpr.steps]

inductive GradientInput where
  | sigma | mark | indicator | intensity | penalty | stepSize | cap
  deriving DecidableEq

@[expose] def projectedGradientExpr : ScalarExpr GradientInput :=
  .min (.input .cap) (.max (.constant 1)
    (.sub (.input .sigma) (.mul (.input .stepSize)
      (.sub (.mul (.input .intensity) (.mul (.input .indicator) (.input .mark)))
        (.div (.input .penalty) (.input .sigma))))))

theorem projectedGradientExpr_steps : projectedGradientExpr.steps = 17 := by
  norm_num [projectedGradientExpr, ScalarExpr.steps]

theorem projectedGradientExpr_value (env : GradientInput → ℝ) : projectedGradientExpr.value env =
    boxClip (env .cap) (env .sigma - env .stepSize * (env .intensity * (env .indicator * env .mark) - env .penalty / env .sigma)) := rfl

inductive AverageInput where
  | count | current | average
  deriving DecidableEq

@[expose] def averageExpr : ScalarExpr AverageInput :=
  .add (.mul (.div (.input .count) (.add (.input .count) (.constant 1))) (.input .average))
    (.mul (.div (.constant 1) (.add (.input .count) (.constant 1))) (.input .current))

theorem averageExpr_steps : averageExpr.steps = 15 := by norm_num [averageExpr, ScalarExpr.steps]

theorem averageExpr_value (env : AverageInput → ℝ) : averageExpr.value env =
    env .count / (env .count + 1) * env .average + 1 / (env .count + 1) * env .current := rfl

@[expose] def executeScalarVector {I : Type*} {K : ℕ} (env : Fin K → I → ℝ) (expr : Fin K → ScalarExpr I) : Vector ℝ K × ℕ :=
  let results := Vector.ofFn (fun a => (expr a).execute (env a))
  (results.map Prod.fst, (results.toList.map Prod.snd).sum + K)

theorem executeScalarVector_values {I : Type*} {K : ℕ} (env : Fin K → I → ℝ) (expr : Fin K → ScalarExpr I) :
    vectorValues (executeScalarVector env expr).1 = fun a => (expr a).value (env a) := by
  funext a
  simp [executeScalarVector, vectorValues, Vector.get, Vector.ofFn, ScalarExpr.execute_correct]
  congr 1

theorem executeScalarVector_steps {I : Type*} {K : ℕ} (env : Fin K → I → ℝ) (expr : Fin K → ScalarExpr I)
    (n : ℕ) (hn : ∀ a, (expr a).steps = n) : (executeScalarVector env expr).2 = K * (n + 1) := by
  simp [executeScalarVector, ScalarExpr.execute_correct, hn, Vector.toList_ofFn, List.map_ofFn, List.sum_ofFn]
  ring
end
end PoissonAudit
