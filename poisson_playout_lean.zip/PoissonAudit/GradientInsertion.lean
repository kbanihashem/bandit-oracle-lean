module

public import PoissonAudit.InsertionIntegrability

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def insertedCorrelationMass (r : NNReal) (D : Measure X)
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (j : X × Fin K) : ℝ :=
  ∫ n, (∫ u0, ∫ pool, insertedContribution predict sigma S j n (u0, pool)
    ∂iidPool (contextLaplaceLaw D K) n ∂contextLaplaceLaw D K) ∂ProbabilityTheory.poissonMeasure r

theorem integrable_poisson_winner_coefficient (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (j : X × Fin K) :
    Integrable (fun pool => poissonCoefficient predict pool (poissonWinner predict sigma S pool) j)
      (markedPoolLaw r (contextLaplaceLaw D K)) := by
  classical
  have h := integrable_poisson_selected_slope r D predict sigma (coordinateDirection j) S
  simpa only [coordinateDirection, ite_mul, one_mul, zero_mul, Finset.sum_ite_eq', Finset.mem_univ, if_true] using h

theorem poisson_winner_gradient_insertion (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (j : X × Fin K) :
    (∫ pool, poissonCoefficient predict pool (poissonWinner predict sigma S pool) j
      ∂markedPoolLaw r (contextLaplaceLaw D K)) = (r : ℝ) * insertedCorrelationMass r D predict sigma S j := by
  have hpref (n : ℕ) :
      (∫ u, finitePoolGradient predict sigma S j (poolPrefix n u) ∂markSequence (contextLaplaceLaw D K)) =
        ∫ u : Fin n → X × (Fin K → ℝ), finitePoolGradient predict sigma S j u ∂iidPool (contextLaplaceLaw D K) n := by
    have hmp := poolPrefix_measurePreserving (contextLaplaceLaw D K) n
    have h := integral_map hmp.measurable.aemeasurable
      (f := finitePoolGradient predict sigma S j)
      (by rw [hmp.map_eq]; exact (measurable_finitePoolGradient predict sigma S j n).aestronglyMeasurable)
    rw [hmp.map_eq] at h
    exact h.symm
  change (∫ pool, poissonCoefficient predict pool (poissonWinner predict sigma S pool) j
    ∂(ProbabilityTheory.poissonMeasure r).prod (markSequence (contextLaplaceLaw D K))) = _
  rw [integral_prod _ (integrable_poisson_winner_coefficient r D predict sigma S j)]
  simp_rw [poissonCoefficient_winner_eq_finiteGradient, hpref]
  exact finite_gradient_poisson_insertion r D predict sigma S j

theorem poisson_minimizer_inserted_lower (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (lam B : ℝ) (hB : 1 ≤ B)
    (hsigma : sigma ∈ scaleBox (X × Fin K) B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun j => (D {j.1}).toReal) lam B) (scaleBox (X × Fin K) B) sigma)
    (j : X × Fin K) (hj : sigma j < B) :
    lam * (D {j.1}).toReal ≤ (r : ℝ) * sigma j * insertedCorrelationMass r D predict sigma S j := by
  have h := poisson_minimizer_gradient_nonneg r D predict sigma S lam B hB hsigma hmin j hj
  unfold poissonCoordinateGradient at h
  rw [poisson_winner_gradient_insertion] at h
  have hs : 0 < sigma j := by have hsj : (1 : ℝ) ≤ sigma j := hsigma.1 j; linarith
  have hi : lam * (D {j.1}).toReal / sigma j ≤ (r : ℝ) * insertedCorrelationMass r D predict sigma S j := by linarith
  have hm := (div_le_iff₀ hs).mp hi
  nlinarith

theorem poisson_minimizer_inserted_upper (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (lam B : ℝ) (hB : 1 ≤ B)
    (hsigma : sigma ∈ scaleBox (X × Fin K) B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun j => (D {j.1}).toReal) lam B) (scaleBox (X × Fin K) B) sigma)
    (j : X × Fin K) (hj : 1 < sigma j) :
    (r : ℝ) * sigma j * insertedCorrelationMass r D predict sigma S j ≤ lam * (D {j.1}).toReal := by
  have h := poisson_minimizer_gradient_nonpos r D predict sigma S lam B hB hsigma hmin j hj
  unfold poissonCoordinateGradient at h
  rw [poisson_winner_gradient_insertion] at h
  have hs : 0 < sigma j := by have hsj : (1 : ℝ) ≤ sigma j := hsigma.1 j; linarith
  have hi : (r : ℝ) * insertedCorrelationMass r D predict sigma S j ≤ lam * (D {j.1}).toReal / sigma j := by linarith
  have hm := (le_div_iff₀ hs).mp hi
  nlinarith

end

end PoissonAudit
