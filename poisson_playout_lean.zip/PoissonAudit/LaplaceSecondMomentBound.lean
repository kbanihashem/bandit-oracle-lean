module
public import PoissonAudit.LaplaceCoordinateVariational
public section
open MeasureTheory
namespace PoissonAudit
noncomputable section

theorem laplace_square_exp_bound (z : ℝ) :
    z ^ 2 ≤ 8 * (Real.exp ((1 / 2) * z) + Real.exp (-(1 / 2) * z)) := by
  rcases le_total 0 z with hz | hz
  · have h := Real.pow_div_factorial_le_exp ((1 / 2 : ℝ) * z) (by linarith : 0 ≤ (1 / 2 : ℝ) * z) 2
    norm_num at h
    nlinarith [Real.exp_pos (-(1 / 2) * z)]
  · have h := Real.pow_div_factorial_le_exp (-(1 / 2 : ℝ) * z) (by linarith : 0 ≤ -(1 / 2 : ℝ) * z) 2
    norm_num at h
    rw [show -((1 / 2 : ℝ) * z) = -(1 / 2 : ℝ) * z by ring] at h
    nlinarith [Real.exp_pos ((1 / 2) * z)]

theorem integrable_realLaplace_square : Integrable (fun z : ℝ => z ^ 2) realLaplace := by
  have hp := integrable_realLaplace_exp (t := 1 / 2) (by norm_num)
  have hn := integrable_realLaplace_exp (t := -(1 / 2)) (by norm_num)
  apply ((hp.add hn).const_mul 8).mono' (by fun_prop)
  filter_upwards [] with z
  change |z ^ 2| ≤ 8 * (Real.exp ((1 / 2) * z) + Real.exp (-(1 / 2) * z))
  rw [abs_of_nonneg (sq_nonneg z)]
  exact laplace_square_exp_bound z

theorem integral_realLaplace_square_le : (∫ z : ℝ, z ^ 2 ∂realLaplace) ≤ 32 := by
  have hp := integrable_realLaplace_exp (t := 1 / 2) (by norm_num)
  have hn := integrable_realLaplace_exp (t := -(1 / 2)) (by norm_num)
  have h := integral_mono integrable_realLaplace_square ((hp.add hn).const_mul 8) laplace_square_exp_bound
  change (∫ z : ℝ, z ^ 2 ∂realLaplace) ≤ ∫ z, 8 * (Real.exp ((1 / 2) * z) + Real.exp (-(1 / 2) * z)) ∂realLaplace at h
  rw [integral_const_mul, integral_add hp hn, integral_realLaplace_exp (t := 1 / 2) (by norm_num),
    integral_realLaplace_exp (t := -(1 / 2)) (by norm_num)] at h
  norm_num at h ⊢
  linarith

theorem integrable_laplace_coordinate_square (K : ℕ) (a : Fin K) :
    Integrable (fun z : Fin K → ℝ => (z a) ^ 2) (laplaceMeasure K) :=
  integrable_laplace_coordinate_comp K a _ integrable_realLaplace_square

theorem integral_laplace_coordinate_square_le (K : ℕ) (a : Fin K) :
    (∫ z : Fin K → ℝ, (z a) ^ 2 ∂laplaceMeasure K) ≤ 32 := by
  rw [laplace_coordinate_integral K a (fun y => y ^ 2) (by fun_prop)]
  exact integral_realLaplace_square_le
end
end PoissonAudit
