module
public import PoissonAudit.PoolQueryEncoding
public section
namespace PoissonAudit
noncomputable section

@[expose] def negateCostQuery {X : Type*} {K : ℕ} (Q : List (CostExample X K)) : List (CostExample X K) :=
  Q.map (fun q => (q.1, fun a => -q.2 a))

theorem queryScore_negate {X P : Type*} {K : ℕ} (predict : P → X → Fin K) (Q : List (CostExample X K)) (p : P) :
    queryScore predict (negateCostQuery Q) p = -queryScore predict Q p := by
  induction Q with
  | nil => simp [negateCostQuery, queryScore]
  | cons q qs ih =>
    simp only [negateCostQuery, List.map_cons, queryScore, List.sum_cons] at ih ⊢
    linarith

theorem maximizing_value_from_minimizing {X P : Type*} [Fintype P] [Nonempty P] {K : ℕ}
    (predict : P → X → Fin K) (oracle : List (CostExample X K) → ℝ)
    (horacle : ∀ Q, (∀ p, oracle Q ≤ queryScore predict Q p) ∧ ∃ p, oracle Q = queryScore predict Q p)
    (Q : List (CostExample X K)) :
    -oracle (negateCostQuery Q) = treeBestScore (queryScore predict Q) := by
  obtain ⟨hl, p, hp⟩ := horacle (negateCostQuery Q)
  have he : -oracle (negateCostQuery Q) = queryScore predict Q p := by rw [hp, queryScore_negate]; ring
  apply le_antisymm
  · rw [he]
    exact Finset.le_sup' (f := queryScore predict Q) (Finset.mem_univ p)
  · apply treeBestScore_le
    intro a
    have h := hl a
    rw [queryScore_negate] at h
    linarith

theorem negateCostQuery_length {X : Type*} {K : ℕ} (Q : List (CostExample X K)) : (negateCostQuery Q).length = Q.length := List.length_map _
end
end PoissonAudit
