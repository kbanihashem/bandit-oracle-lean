module

public import PoissonAudit.LaplaceTailDerivative
public import Mathlib.Analysis.Calculus.ParametricIntegral

public section

open MeasureTheory Set Filter
open scoped Topology

namespace PoissonAudit

noncomputable section

instance realLaplace_nullSingletonClass : NullSingletonClass realLaplace := by
  unfold realLaplace
  infer_instance

theorem realLaplaceDensity_le_half (t : ℝ) : realLaplaceDensity t ≤ 1 / 2 := by
  unfold realLaplaceDensity
  have he : Real.exp (-|t|) ≤ 1 := Real.exp_le_one_iff.mpr (neg_nonpos.mpr (abs_nonneg _))
  linarith

theorem laplaceSurvival_nonneg (t : ℝ) : 0 ≤ laplaceSurvival t := by
  rw [laplaceSurvival_eq_probability]
  exact ENNReal.toReal_nonneg

theorem laplaceSurvival_le_one (t : ℝ) : laplaceSurvival t ≤ 1 := by
  rw [laplaceSurvival_eq_probability]
  exact ENNReal.toReal_le_of_le_ofReal (by norm_num) (by simpa using (prob_le_one : realLaplace (Ioi t) ≤ 1))

theorem continuous_laplaceSurvival : Continuous laplaceSurvival :=
  continuous_iff_continuousAt.mpr fun t => (hasDerivAt_laplaceSurvival t).continuousAt

@[expose] def thresholdProbability {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) (theta : Omega → ℝ) (sigma s : ℝ) : ℝ :=
  ∫ omega, laplaceSurvival (theta omega + s / sigma) ∂mu

@[expose] def thresholdCurvature {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) (theta : Omega → ℝ) (sigma s : ℝ) : ℝ :=
  (∫ omega, realLaplaceDensity (theta omega + s / sigma) ∂mu) / sigma

theorem integrable_threshold_survival {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) [IsProbabilityMeasure mu] (theta : Omega → ℝ) (htheta : Measurable theta)
    (sigma s : ℝ) : Integrable (fun omega => laplaceSurvival (theta omega + s / sigma)) mu := by
  apply Integrable.of_bound (continuous_laplaceSurvival.measurable.comp (htheta.add_const _)).aestronglyMeasurable 1
  filter_upwards [] with omega
  change |laplaceSurvival (theta omega + s / sigma)| ≤ 1
  rw [abs_of_nonneg (laplaceSurvival_nonneg _)]
  exact laplaceSurvival_le_one _

theorem integrable_threshold_density {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) [IsProbabilityMeasure mu] (theta : Omega → ℝ) (htheta : Measurable theta)
    (sigma s : ℝ) : Integrable (fun omega => realLaplaceDensity (theta omega + s / sigma)) mu := by
  apply Integrable.of_bound (continuous_realLaplaceDensity.measurable.comp (htheta.add_const _)).aestronglyMeasurable (1 / 2)
  filter_upwards [] with omega
  change |realLaplaceDensity (theta omega + s / sigma)| ≤ 1 / 2
  rw [abs_of_pos (realLaplaceDensity_pos _)]
  exact realLaplaceDensity_le_half _

theorem hasDerivAt_threshold_survival (theta sigma s : ℝ) :
    HasDerivAt (fun u => laplaceSurvival (theta + u / sigma))
      (-realLaplaceDensity (theta + s / sigma) / sigma) s := by
  have hi : HasDerivAt (fun u : ℝ => theta + u / sigma) (1 / sigma) s := by
    convert! ((hasDerivAt_id s).div_const sigma).const_add theta using 1
  have h := (hasDerivAt_laplaceSurvival (theta + s / sigma)).comp s hi
  convert! h using 1
  ring

theorem hasDerivAt_thresholdProbability {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) [IsProbabilityMeasure mu] (theta : Omega → ℝ) (htheta : Measurable theta)
    (sigma s : ℝ) (hsigma : 0 < sigma) :
    HasDerivAt (thresholdProbability mu theta sigma) (-thresholdCurvature mu theta sigma s) s := by
  have h := hasDerivAt_integral_of_dominated_loc_of_deriv_le
    (μ := mu) (x₀ := s) (s := Set.univ)
    (F := fun u omega => laplaceSurvival (theta omega + u / sigma))
    (F' := fun u omega => -realLaplaceDensity (theta omega + u / sigma) / sigma)
    (bound := fun _ => (1 / 2) / sigma) Filter.univ_mem
    (Filter.Eventually.of_forall fun u => (integrable_threshold_survival mu theta htheta sigma u).aestronglyMeasurable)
    (integrable_threshold_survival mu theta htheta sigma s)
    ((continuous_realLaplaceDensity.measurable.comp (htheta.add_const _)).neg.div_const sigma).aestronglyMeasurable
    (Filter.Eventually.of_forall fun omega u _ => by
      rw [Real.norm_eq_abs, abs_div, abs_neg, abs_of_pos (realLaplaceDensity_pos _), abs_of_pos hsigma]
      exact div_le_div_of_nonneg_right (realLaplaceDensity_le_half _) hsigma.le)
    (integrable_const _)
    (Filter.Eventually.of_forall fun omega u _ => hasDerivAt_threshold_survival (theta omega) sigma u)
  convert! h.2 using 1
  unfold thresholdCurvature
  rw [integral_div, integral_neg]
  ring

theorem thresholdCurvature_shift_le {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) [IsProbabilityMeasure mu] (theta : Omega → ℝ) (htheta : Measurable theta)
    (sigma s : ℝ) (hsigma : 0 < sigma) (hs : 0 ≤ s) :
    thresholdCurvature mu theta sigma s ≤ Real.exp (s / sigma) * thresholdCurvature mu theta sigma 0 := by
  have he : (∫ omega, realLaplaceDensity (theta omega + s / sigma) ∂mu) ≤
      Real.exp (s / sigma) * ∫ omega, realLaplaceDensity (theta omega) ∂mu := by
    rw [← integral_const_mul]
    apply integral_mono (integrable_threshold_density mu theta htheta sigma s)
      (by simpa only [zero_div, add_zero] using
        (integrable_threshold_density mu theta htheta sigma 0).const_mul (Real.exp (s / sigma)))
    intro omega
    have h := realLaplaceDensity_shift_le (theta omega) (s / sigma)
    rwa [abs_of_nonneg (div_nonneg hs hsigma.le)] at h
  unfold thresholdCurvature
  simp only [zero_div, add_zero]
  have hdiv := div_le_div_of_nonneg_right he hsigma.le
  convert! hdiv using 1 <;> ring

end

end PoissonAudit
