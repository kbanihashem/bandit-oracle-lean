module

public import PoissonAudit.FiniteUpperBound
public import PoissonAudit.SchedulePayoff
public import PoissonAudit.ContextTransfer
public import PoissonAudit.ArithmeticBanditPlan

public section
open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit
noncomputable section

@[expose] def manuscriptPlan (K T : ℕ) (L : ℝ) : BanditParameters :=
  let k : ℝ := K
  let t : ℝ := T
  let γ := 1 / (t+1)
  let B := k * (t+1)
  let A := Real.sqrt (k*t*L)
  let r := Real.toNNReal (A/(k*(1+Real.log B)))
  let lam := 4*A/k
  let δ := 1/(t*(1+k/γ))
  ⟨r,lam,B,γ,lam*δ^2/(32*B^2*((r : ℝ)+1)),δ⟩

theorem manuscriptPlan_box (K T : ℕ) (L : ℝ) (hK : 2 ≤ K) :
    1 ≤ (manuscriptPlan K T L).B := by
  change 1 ≤ (K : ℝ) * (T+1)
  exact one_le_mul_of_one_le_of_one_le (by exact_mod_cast (show 1 ≤ K by omega)) (by linarith [Nat.cast_nonneg (α := ℝ) T])

variable {X Y P : Type*} [MeasurableSpace X] [MeasurableSpace Y] [MeasurableSingletonClass Y] [Fintype Y]
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P] {K : ℕ}

@[expose] def manuscriptPayoff (D : Measure Y) [IsProbabilityMeasure D] (predict : P → Y → Fin K)
    (T : ℕ) (L : ℝ) (hK : 2 ≤ K) (v : Fin T → Y × (Fin K → ℝ)) : ℝ :=
  let p := manuscriptPlan K T L
  schedulePayoff (paperNativeFiniteOutcomeWeight p.r D predict p.lam p.B p.eps p.delta p.gamma (manuscriptPlan_box K T L hK))
    (paperNativeFiniteOutcomeUpdate predict p.delta p.gamma) Prod.snd predict T v (fun _ => 0) (fun _ => 0)

theorem manuscript_finite_schedule (D : Measure Y) [IsProbabilityMeasure D] (predict : P → Y → Fin K)
    (T : ℕ) (hT : 0 < T) (hK : 2 ≤ K) (c : Fin T → Y → Fin K → ℝ)
    (hc : ∀ t y a, c t y a ∈ Icc (0 : ℝ) 1) (L : ℝ) (hL : Real.log (2 * Fintype.card P) ≤ L) :
    (∫ ys, manuscriptPayoff D predict T L hK (fun t => (ys t,c t (ys t))) ∂iidPool D T) ≤
      38 * Real.exp 1 * Real.sqrt ((K : ℝ)*T*L) * Real.log (2*(K : ℝ)*T) := by
  suffices aux : ∀ (cs : List (Y → Fin K → ℝ)) (hlen : cs.length = T),
      (∀ i : Fin cs.length, cs.get i = c (i.cast hlen)) → _ by
    apply aux (List.ofFn c) List.length_ofFn
    intro i
    simp
    rfl
  intro cs hlen hget
  subst T
  have hcost (f) (hf : f ∈ cs) (y a) : f y a ∈ Icc (0 : ℝ) 1 := by
    obtain ⟨i, hi⟩ := List.mem_iff_get.mp hf
    rw [← hi,hget]
    exact hc _ _ _
  have h := finite_context_upper_bound D predict hK cs hT (fun f hf y a => (hcost f hf y a).1)
    (fun f hf y a => (hcost f hf y a).2) L hL
  obtain ⟨hB,hk,hg,hg1,hd,hr⟩ := h
  let p := manuscriptPlan K cs.length L
  let w := paperNativeFiniteOutcomeWeight p.r D predict p.lam p.B p.eps p.delta p.gamma hB
  let U := paperNativeFiniteOutcomeUpdate predict p.delta p.gamma
  have hws := paperNativeFiniteOutcomeWeight_sum p.r D predict p.lam p.B p.eps p.delta p.gamma hB hk hd
  have hseq := integral_schedulePayoff_finite D w hws U Prod.snd predict cs (fun _ => 0) (fun _ => 0)
  have heq := integral_outcomePath_regret predict Prod.snd (fun y => (D {y}).toReal)
    (fun _ => ENNReal.toReal_nonneg) (context_mass_sum D) w U
    (paperNativeFiniteOutcomeWeight_nonneg p.r D predict p.lam p.B p.eps p.delta p.gamma hB hg hg1 hk hd)
    hws cs (fun _ => 0)
  have hfin := hseq.trans heq.symm
  simp only [hget,Fin.cast_refl] at hfin
  exact hfin.le.trans hr

theorem manuscript_upper_bound (D : Measure X) [IsProbabilityMeasure D] (predict : P → X → Fin K)
    (hp : ∀ p, Measurable (predict p)) (T : ℕ) (hT : 0 < T) (hK : 2 ≤ K)
    (c : Fin T → X → Fin K → ℝ) (hm : ∀ t a, Measurable (fun x => c t x a))
    (hc : ∀ t x a, c t x a ∈ Icc (0 : ℝ) 1) (L : ℝ) (hL : Real.log (2 * Fintype.card P) ≤ L) :
    let g := fun x p => predict p x
    letI : IsProbabilityMeasure (D.map g) :=
      (Measure.isProbabilityMeasure_map_iff (Measurable.of_eval hp).aemeasurable).mpr inferInstance
    (∫ xs, manuscriptPayoff (D.map g) (fun p y => y p) T L hK
      (fun t => (g (xs t),c t (xs t))) ∂iidPool D T) ≤
      38 * Real.exp 1 * Real.sqrt ((K : ℝ)*T*L) * Real.log (2*(K : ℝ)*T) := by
  let g := fun x p => predict p x
  have hg : Measurable g := Measurable.of_eval hp
  haveI : IsProbabilityMeasure (D.map g) := (Measure.isProbabilityMeasure_map_iff hg.aemeasurable).mpr inferInstance
  let p := manuscriptPlan K T L
  let hB := manuscriptPlan_box K T L hK
  let pred := fun (p : P) (y : P → Fin K) => y p
  let F := fun z : Fin T → (P → Fin K) × X =>
    manuscriptPayoff (D.map g) pred T L hK (fun t => ((z t).1,c t (z t).2))
  refine context_table_transfer D g hg T F ?_ (2*T) _ ?_ ?_
  · refine measurable_schedulePayoff _ (fun y o => measurable_paper_weight p.r (D.map g) pred p.lam p.B p.eps p.delta p.gamma hB y o) (paperNativeFiniteOutcomeUpdate pred p.delta p.gamma) ?_ Prod.snd pred T _ ?_ _ _ measurable_const measurable_const
    · intro y o
      apply Measurable.of_eval
      intro j
      unfold paperNativeFiniteOutcomeUpdate treeUpdatedScore treeEstimatedPolicyLoss
      split_ifs <;> fun_prop
    · apply Measurable.of_eval
      intro t
      exact (measurable_fst.comp (measurable_pi_apply t)).prodMk
        (Measurable.of_eval fun a => (hm t a).comp (measurable_snd.comp (measurable_pi_apply t)))
  · intro z
    have hk : 0 < K := by omega
    have hg1 : p.gamma ≤ 1 := by change 1 / ((T : ℝ)+1) ≤ 1; apply div_le_one_of_le₀ <;> linarith [Nat.cast_nonneg (α := ℝ) T]
    have hg0 : 0 < p.gamma := by change 0 < 1 / ((T : ℝ)+1); positivity
    have hd : 0 < p.delta := by change 0 < 1 / ((T : ℝ)*(1+(K : ℝ)/p.gamma)); positivity
    have h := schedulePayoff_bound _
      (paperNativeFiniteOutcomeWeight_nonneg p.r (D.map g) pred p.lam p.B p.eps p.delta p.gamma hB hg0.le hg1 hk hd)
      (paperNativeFiniteOutcomeWeight_sum p.r (D.map g) pred p.lam p.B p.eps p.delta p.gamma hB hk hd)
      (paperNativeFiniteOutcomeUpdate pred p.delta p.gamma) Prod.snd pred T
      (fun t => ((z t).1,c t (z t).2)) (fun t a => hc _ _ _) (fun _ => 0) (fun _ => 0) 0 (by simp)
    simpa only [F, manuscriptPayoff, p, hB, zero_add] using h

  · intro rows
    exact manuscript_finite_schedule (D.map g) pred T hT hK (fun t y => c t (rows t y)) (fun t y a => hc t (rows t y) a) L hL

end
end PoissonAudit
