module

public import Mathlib.Analysis.SpecialFunctions.Gamma.Basic
public import PoissonAudit.NativeGradientMoments

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

theorem integral_realLaplace_square : (∫ z : ℝ, z ^ 2 ∂realLaplace) = 2 := by
  have h := Real.integral_rpow_mul_exp_neg_mul_Ioi (a := 3) (r := 1) (by norm_num) (by norm_num)
  have hg : Real.Gamma 3 = 2 := by
    simpa using Real.Gamma_nat_eq_factorial 2
  rw [hg] at h
  norm_num at h
  rw [integral_realLaplace]
  have ha := integral_comp_abs (f := fun z : ℝ => z ^ 2 * Real.exp (-z))
  simp only [sq_abs] at ha
  rw [ha, h]
  norm_num

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem paper_gradient_coordinate (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (lam : ℝ)
    (j : X × Fin K) (hs : 1 ≤ sigma j) :
    (∫ v, (nativeSampledGradient r predict sigma S lam v j) ^ 2 ∂insertedExperimentLaw r D K) ≤
      4 * (r : ℝ) ^ 2 + 2 * lam ^ 2 := by
  have hz : Integrable (fun v : (Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ))) => (v.1 j.2) ^ 2) (insertedExperimentLaw r D K) :=
    (integrable_laplace_coordinate_square K j.2).comp_fst (markedPoolLaw r (contextLaplaceLaw D K))
  have h := integral_mono (integrable_nativeSampledGradient_square r D predict sigma S lam j hs)
    ((hz.const_mul (2 * (r : ℝ) ^ 2)).add (integrable_const (2 * lam ^ 2)))
    (fun v => nativeSampledGradient_square_bound r predict sigma S lam v j hs)
  change _ ≤ ∫ v, 2 * (r : ℝ) ^ 2 * (v.1 j.2) ^ 2 + 2 * lam ^ 2 ∂insertedExperimentLaw r D K at h
  rw [integral_add (hz.const_mul (2 * (r : ℝ) ^ 2)) (integrable_const _), integral_const_mul,
    integral_const, probReal_univ, one_smul] at h
  have heq : (∫ v, (v.1 j.2) ^ 2 ∂insertedExperimentLaw r D K) = ∫ z, (z j.2) ^ 2 ∂laplaceMeasure K := by
    change (∫ v, (v.1 j.2) ^ 2 ∂(laplaceMeasure K).prod (markedPoolLaw r (contextLaplaceLaw D K))) = _
    rw [integral_prod _ hz]
    simp only [integral_const, probReal_univ, one_smul]
  rw [heq] at h
  rw [laplace_coordinate_integral K j.2 (fun z => z ^ 2) (by fun_prop), integral_realLaplace_square] at h
  linarith

theorem paper_gradient_bound (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (lam : ℝ)
    (hs : ∀ j, 1 ≤ sigma j) :
    (∫ v, nativeGradientSquaredNorm D (nativeSampledGradient r predict sigma S lam v)
      ∂insertedExperimentLaw r D K) ≤ K * (4 * (r : ℝ) ^ 2 + 2 * lam ^ 2) := by
  unfold nativeGradientSquaredNorm
  rw [integral_finsetSum _ (fun j _ =>
    (integrable_nativeSampledGradient_square r D predict sigma S lam j (hs j)).const_mul _)]
  simp only [integral_const_mul]
  have h := Finset.sum_le_sum (s := Finset.univ) fun j _ => mul_le_mul_of_nonneg_left
    (paper_gradient_coordinate r D predict sigma S lam j (hs j)) (show 0 ≤ (D {j.1}).toReal from ENNReal.toReal_nonneg)
  rw [← Finset.sum_mul, context_action_mass_sum D] at h
  exact h

end
end PoissonAudit
