module
public import PoissonAudit.NativeProbabilityMeasurable
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem integrable_nativeMeanActionError_state (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (B : ℝ) (s : NativeScaleBox X K B)
    (mu : Measure (NativeSGDState X K B)) [IsFiniteMeasure mu] :
    Integrable (fun state : NativeSGDState X K B => nativeMeanActionError r D predict S state.2.val s.val) mu := by
  have hm : Measurable (fun state : NativeSGDState X K B => nativeMeanActionError r D predict S state.2.val s.val) :=
    (measurable_nativeMeanActionError_scale r D predict S s.val).comp
    (measurable_subtype_coe.comp measurable_snd)
  apply Integrable.of_bound hm.aestronglyMeasurable K
  filter_upwards [] with state
  have hb := nativeMeanActionError_bounds r D predict S state.2.val s.val
  rw [Real.norm_eq_abs, abs_of_nonneg hb.1]
  exact hb.2

theorem native_SGD_mean_action_accuracy (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eps delta : ℝ)
    (hlam : 0 < lam) (hB : 1 ≤ B) (heps : 0 < eps) (hd : 0 < delta) (hK : 0 < K)
    (s : NativeScaleBox X K B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun q => (D {q.1}).toReal) lam B) (scaleBox (X × Fin K) B) s.val)
    (hepsBudget : eps ≤ lam * delta ^ 2 / (32 * B ^ 2 * ((r : ℝ) + 1) ^ 2 * K))
    (J : ℕ) (hJ : 0 < J)
    (hbudget : B ^ 2 * K * (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2)) / eps ^ 2 ≤ J) :
    (∫ state, nativeMeanActionError r D predict S state.2.val s.val
      ∂nativeSGDStateLaw r D predict S lam B (eps / (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2))) hB J) ≤ delta / 2 := by
  let mu := nativeSGDStateLaw r D predict S lam B (eps / (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2))) hB J
  let dist := fun state : NativeSGDState X K B => weightedSquareDistance (fun q => (D {q.1}).toReal) state.2.val s.val
  let C : ℝ := 4 * ((r : ℝ) + 1) ^ 2 * K / delta
  have hC : 0 ≤ C := by dsimp [C]; positivity
  have hdcont : Continuous dist := by
    apply continuous_finsetSum
    intro q _
    exact continuous_const.mul ((((continuous_apply q).comp (continuous_subtype_val.comp continuous_snd)).sub continuous_const).pow 2)
  have hdi : Integrable dist mu := integrable_continuous_nativeSGDState B mu _ hdcont
  have hp (state : NativeSGDState X K B) : nativeMeanActionError r D predict S state.2.val s.val ≤ delta / 4 + C * dist state :=
    native_action_error_young r D predict S state.2.val s.val state.2.property.1 s.property.1 delta hd
  have hi := integral_mono (integrable_nativeMeanActionError_state r D predict S B s mu)
    ((integrable_const (delta / 4)).add (hdi.const_mul C)) hp
  change _ ≤ ∫ state, delta / 4 + C * dist state ∂mu at hi
  rw [integral_add (integrable_const _) (hdi.const_mul C), integral_const, probReal_univ, one_smul, integral_const_mul] at hi
  have hs := native_SGD_scale_accuracy r D predict S lam B eps hlam hB heps hK s hmin J hJ hbudget
  change (∫ state, dist state ∂mu) ≤ 2 * B ^ 2 * eps / lam at hs
  have hm := mul_le_mul_of_nonneg_left hs hC
  have hscalar : C * (2 * B ^ 2 * eps / lam) ≤ delta / 4 := by
    have hB0 : 0 < B := by linarith
    have hc0 : 0 < (r : ℝ) + 1 := by positivity
    have hden : 0 < 32 * B ^ 2 * ((r : ℝ) + 1) ^ 2 * (K : ℝ) := by positivity
    have he := (le_div_iff₀ hden).mp hepsBudget
    apply (le_div_iff₀ (by norm_num : (0 : ℝ) < 4)).mpr
    have heq : (C * (2 * B ^ 2 * eps / lam) * 4) * (delta * lam) =
        32 * B ^ 2 * ((r : ℝ) + 1) ^ 2 * K * eps := by dsimp [C]; field_simp <;> ring
    have hscaled : (C * (2 * B ^ 2 * eps / lam) * 4) * (delta * lam) ≤ delta * (delta * lam) := by
      rw [heq]
      nlinarith only [he]
    exact (mul_le_mul_iff_of_pos_right (mul_pos hd hlam)).mp hscaled
  linarith
end
end PoissonAudit
