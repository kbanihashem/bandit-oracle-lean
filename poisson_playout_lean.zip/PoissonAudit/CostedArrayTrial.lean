module
public import PoissonAudit.CostedConstructionBound
public section
open scoped BigOperators
namespace PoissonAudit
noncomputable section

structure ArrayTrialRun (X : Type*) (K : ℕ) where
  action : Fin K
  queries : List (List (CostExample X K))
  internalWork : ℕ
  allocatedWords : ℕ

@[expose] def executeArrayTrial {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (records : List (ReplayRecord X K)) (x : X) (v : NativeNoise X K) : ArrayTrialRun X K :=
  let atX := executeArrayReplay r lam B eta history oracle fallback records x
  let runs := Vector.ofFn (fun i : Fin v.2.1 =>
    executeArrayReplay r lam B eta history oracle fallback records (v.2.2 i).1)
  let examples := List.ofFn (fun i : Fin v.2.1 =>
    let coeff := Vector.ofFn (fun a => vectorValues (runs.get i).state.2 a * (v.2.2 i).2 a)
    ((v.2.2 i).1, vectorValues coeff))
  let designated := Vector.ofFn (fun a => vectorValues atX.state.2 a * v.1 a)
  let call := executeValueCall oracle fallback (history ++ examples) x designated
  let poolRequests := (runs.toList.map ArrayReplayRun.queries).flatten
  ⟨call.action, atX.queries ++ poolRequests ++ call.queries,
    atX.internalWork + (∑ i : Fin v.2.1, ((runs.get i).internalWork + 4 * K + 1)) +
      call.scalarWork + 4 * K + 2 * atX.queries.length + poolRequests.length,
    atX.allocatedWords + (∑ i : Fin v.2.1, ((runs.get i).allocatedWords + K + 1)) +
      call.allocatedWords + K + 2 * atX.queries.length + poolRequests.length⟩

theorem executeArrayTrial_correct {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (records : List (ReplayRecord X K)) (x : X) (v : NativeNoise X K) :
    (executeArrayTrial r lam B eta history oracle fallback records x v).action =
      replayTrialAction r lam B eta history oracle fallback records x v ∧
    (executeArrayTrial r lam B eta history oracle fallback records x v).queries =
      replayTrialQueries r lam B eta history oracle fallback records x v := by
  have hs (y : X) : vectorValues (executeArrayReplay r lam B eta history oracle fallback records y).state.2 =
      (replayAt r lam B eta history oracle fallback records y).2 :=
    congrArg Prod.snd (executeArrayReplay_correct r lam B eta history oracle fallback records y).1
  have he : (List.ofFn (fun i : Fin v.2.1 =>
      ((v.2.2 i).1, vectorValues (Vector.ofFn (fun a => vectorValues
        (executeArrayReplay r lam B eta history oracle fallback records (v.2.2 i).1).state.2 a * (v.2.2 i).2 a))))) =
      (makeReplayRecord (fun y => (replayAt r lam B eta history oracle fallback records y).2) v).2 := by
    unfold makeReplayRecord scaledPoolExamples
    simp only [vectorValues_ofFn, hs, poolPrefix]
  constructor
  · dsimp only [executeArrayTrial]
    rw [executeValueCall_action, arrayValueOracleAction_eq]
    simp only [vectorGet_ofFn]
    rw [he, vectorValues_ofFn, hs]
    rfl
  · dsimp only [executeArrayTrial]
    rw [executeValueCall_queries]
    simp only [vectorGet_ofFn]
    rw [he, vectorValues_ofFn, hs]
    simp only [Vector.toList_ofFn, List.map_ofFn, Function.comp_apply]
    simp only [(executeArrayReplay_correct r lam B eta history oracle fallback records x).2]
    have hq : (List.ofFn (fun i : Fin v.2.1 =>
        (executeArrayReplay r lam B eta history oracle fallback records (v.2.2 i).1).queries)).flatten =
        (List.ofFn (fun i : Fin v.2.1 => replayQueries r lam B eta history oracle fallback records (v.2.2 i).1)).flatten := by
      congr 1
      apply congrArg List.ofFn
      funext i
      exact (executeArrayReplay_correct r lam B eta history oracle fallback records (v.2.2 i).1).2
    change _ ++ (List.ofFn (fun i : Fin v.2.1 =>
      (executeArrayReplay r lam B eta history oracle fallback records (v.2.2 i).1).queries)).flatten ++ _ = _
    rw [hq]
    rfl

@[expose] def trialInternalBudget (K cap J : ℕ) : ℕ :=
  replayInternalBudget K J + cap * (replayInternalBudget K J + 4 * K + 1) +
    (4 * K ^ 2 + 12 * K + 1) + 4 * K + (cap + 2) * J * (K + 1)

theorem executeArrayTrial_work {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (records : List (ReplayRecord X K)) (x : X) (v : NativeNoise X K) (cap : ℕ) (hc : v.2.1 ≤ cap) :
    (executeArrayTrial r lam B eta history oracle fallback records x v).internalWork ≤
      trialInternalBudget K cap records.length := by
  let atX := executeArrayReplay r lam B eta history oracle fallback records x
  let runs := Vector.ofFn (fun i : Fin v.2.1 =>
    executeArrayReplay r lam B eta history oracle fallback records (v.2.2 i).1)
  let poolRequests := (runs.toList.map ArrayReplayRun.queries).flatten
  have hx : atX.internalWork ≤ replayInternalBudget K records.length :=
    executeArrayReplay_work r lam B eta history oracle fallback records x
  have hrun (i : Fin v.2.1) : (runs.get i).internalWork ≤ replayInternalBudget K records.length := by
    dsimp only [runs]
    rw [vectorGet_ofFn]
    exact executeArrayReplay_work r lam B eta history oracle fallback records (v.2.2 i).1
  have hs : (∑ i : Fin v.2.1, ((runs.get i).internalWork + 4 * K + 1)) ≤
      cap * (replayInternalBudget K records.length + 4 * K + 1) := by
    have h := Finset.sum_le_sum (s := Finset.univ) (fun i _ => Nat.add_le_add_right (Nat.add_le_add_right (hrun i) (4 * K)) 1)
    simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, Nat.cast_id] at h
    exact h.trans (Nat.mul_le_mul_right _ hc)
  have hxQ : atX.queries.length = records.length * (K + 1) := by
    rw [(executeArrayReplay_correct r lam B eta history oracle fallback records x).2, replayQueries_count]
  have hreq : poolRequests.length ≤ cap * (records.length * (K + 1)) := by
    dsimp only [poolRequests, runs]
    simp only [List.length_flatten, Vector.toList_ofFn, List.map_ofFn, List.sum_ofFn, Function.comp_apply]
    simp only [(executeArrayReplay_correct r lam B eta history oracle fallback records _).2,
      replayQueries_count, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, Nat.cast_id]
    exact Nat.mul_le_mul_right _ hc
  have hcall := executeValueCall_scalar_work oracle fallback
    (history ++ List.ofFn (fun i : Fin v.2.1 => ((v.2.2 i).1, vectorValues (Vector.ofFn (fun a =>
      vectorValues (runs.get i).state.2 a * (v.2.2 i).2 a))))) x
    (Vector.ofFn (fun a => vectorValues atX.state.2 a * v.1 a))
  change atX.internalWork + (∑ i : Fin v.2.1, ((runs.get i).internalWork + 4 * K + 1)) + _ +
    4 * K + 2 * atX.queries.length + poolRequests.length ≤ _
  rw [hxQ]
  unfold trialInternalBudget
  nlinarith only [hx, hs, hreq, hcall]
end
end PoissonAudit
