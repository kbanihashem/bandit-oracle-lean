module
public import PoissonAudit.FiniteBanditTree
public section
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X A P : Type*} [Fintype X] [Fintype A] [Fintype P] [Nonempty P]

theorem finite_weighted_add_const (d : X → ℝ) (q : X → A → ℝ)
    (hd : ∑ x, d x = 1) (hq : ∀ x, ∑ a, q x a = 1) (f : X → A → ℝ) (C : ℝ) :
    (∑ x, d x * ∑ a, q x a * (f x a + C)) = (∑ x, d x * ∑ a, q x a * f x a) + C := by
  simp_rw [mul_add, Finset.sum_add_distrib, ← Finset.sum_mul, hq, one_mul]
  simp_rw [mul_add, Finset.sum_add_distrib]
  rw [← Finset.sum_mul, hd, one_mul]

theorem finiteBanditTerminal_mono (d : X → ℝ) (hd : ∀ x, 0 ≤ d x)
    (predict : P → X → A) (q : (P → ℝ) → X → A → ℝ)
    (hq : ∀ S x a, 0 ≤ q S x a) (f g : (P → ℝ) → ℝ) (hfg : ∀ S, f S ≤ g S)
    (costs : List (X → A → ℝ)) (S : P → ℝ) :
    finiteBanditTerminal d predict q f costs S ≤ finiteBanditTerminal d predict q g costs S := by
  classical
  induction costs generalizing S with
  | nil => exact hfg S
  | cons c cs ih =>
    apply Finset.sum_le_sum
    intro x _
    apply mul_le_mul_of_nonneg_left _ (hd x)
    exact Finset.sum_le_sum fun a _ => mul_le_mul_of_nonneg_left (ih _) (hq S x a)

theorem finiteBandit_potential_bound (d : X → ℝ) (hd : ∀ x, 0 ≤ d x) (hdsum : ∑ x, d x = 1)
    (predict : P → X → A) (q : (P → ℝ) → X → A → ℝ)
    (hq : ∀ S x a, 0 ≤ q S x a) (hqsum : ∀ S x, ∑ a, q S x a = 1)
    (R : (P → ℝ) → ℝ) (u : ℝ) (costs : List (X → A → ℝ))
    (hround : ∀ c ∈ costs, ∀ S, (∑ x, d x * ∑ a, q S x a *
      (c x a + R (treeUpdatedScore S (q S x) (c x) (fun p => predict p x) a))) ≤ R S + u)
    (S : P → ℝ) :
    finiteBanditLoss d predict q costs S + finiteBanditTerminal d predict q R costs S ≤
      R S + costs.length * u := by
  classical
  induction costs generalizing S with
  | nil => simp [finiteBanditLoss, finiteBanditTerminal]
  | cons c cs ih =>
    have hi (S : P → ℝ) := ih (fun c hc => hround c (List.mem_cons_of_mem _ hc)) S
    have hpoint (x : X) (a : A) := add_le_add (le_refl (c x a))
      (hi (treeUpdatedScore S (q S x) (c x) (fun p => predict p x) a))
    have h := Finset.sum_le_sum (s := Finset.univ) (fun x _ =>
      mul_le_mul_of_nonneg_left (Finset.sum_le_sum (s := Finset.univ) (fun a _ =>
        mul_le_mul_of_nonneg_left (hpoint x a) (hq S x a))) (hd x))
    have hr := hround c (List.mem_cons_self) S
    calc
      _ = ∑ x, d x * ∑ a, q S x a * (c x a + (finiteBanditLoss d predict q cs
          (treeUpdatedScore S (q S x) (c x) (fun p => predict p x) a) +
          finiteBanditTerminal d predict q R cs (treeUpdatedScore S (q S x) (c x) (fun p => predict p x) a))) := by
        simp only [finiteBanditLoss, finiteBanditTerminal, ← Finset.sum_add_distrib, ← mul_add]
        apply Finset.sum_congr rfl
        intro x _
        congr 1
        apply Finset.sum_congr rfl
        intro a _
        ring
      _ ≤ ∑ x, d x * ∑ a, q S x a * (c x a + (R (treeUpdatedScore S (q S x) (c x) (fun p => predict p x) a) + cs.length * u)) := h
      _ = (∑ x, d x * ∑ a, q S x a * (c x a + R (treeUpdatedScore S (q S x) (c x) (fun p => predict p x) a))) + cs.length * u := by
        simp_rw [← add_assoc]
        exact finite_weighted_add_const d (q S) hdsum (hqsum S) _ _
      _ ≤ R S + (c :: cs).length * u := by simp only [List.length_cons, Nat.cast_add, Nat.cast_one]; linarith

theorem finiteBandit_regret (d : X → ℝ) (hd : ∀ x, 0 ≤ d x) (hdsum : ∑ x, d x = 1)
    (predict : P → X → A) (q : (P → ℝ) → X → A → ℝ)
    (hq : ∀ S x a, 0 < q S x a) (hqsum : ∀ S x, ∑ a, q S x a = 1)
    (R : (P → ℝ) → ℝ) (hterminal : ∀ S p, S p ≤ R S) (u : ℝ)
    (costs : List (X → A → ℝ))
    (hround : ∀ c ∈ costs, ∀ S, (∑ x, d x * ∑ a, q S x a *
      (c x a + R (treeUpdatedScore S (q S x) (c x) (fun p => predict p x) a))) ≤ R S + u)
    (S : P → ℝ) :
    finiteBanditLoss d predict q costs S + contextBestScore d predict costs S ≤ R S + costs.length * u := by
  have hc := finiteBandit_comparator d hd predict q hq hqsum costs S
  have ht := finiteBanditTerminal_mono d hd predict q (fun S x a => (hq S x a).le)
    treeBestScore R (fun S => treeBestScore_le (hterminal S)) costs S
  have hp := finiteBandit_potential_bound d hd hdsum predict q (fun S x a => (hq S x a).le)
    hqsum R u costs hround S
  linarith
end
end PoissonAudit
