module
public import PoissonAudit.FiniteOutcomeRegret
public section
open MeasureTheory
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X A P O : Type*} [Fintype O] [Fintype X] [Fintype A] [Fintype P] [Nonempty P]

@[expose] def outcomePaths (O : Type*) : List (X → A → ℝ) → Type _
  | [] => (Fin 0 → X × O)
  | _ :: cs => X × O × outcomePaths O cs

instance outcomePaths_fintype (costs : List (X → A → ℝ)) : Fintype (outcomePaths O costs) := by
  induction costs with
  | nil => exact inferInstanceAs (Fintype (Fin 0 → X × O))
  | cons c cs ih => letI := ih; exact inferInstanceAs (Fintype (X × O × outcomePaths O cs))

instance outcomePaths_measurableSpace (costs : List (X → A → ℝ)) : MeasurableSpace (outcomePaths O costs) := ⊤
instance outcomePaths_measurableSingletonClass (costs : List (X → A → ℝ)) : MeasurableSingletonClass (outcomePaths O costs) := ⟨fun _ => trivial⟩

@[expose] def outcomePathWeight (d : X → ℝ) (q : (P → ℝ) → X → O → ℝ)
    (U : (P → ℝ) → X → (A → ℝ) → O → P → ℝ) :
    (costs : List (X → A → ℝ)) → (P → ℝ) → outcomePaths O costs → ℝ
  | [], _, _ => 1
  | c :: cs, S, path => d path.1 * q S path.1 path.2.1 * outcomePathWeight d q U cs
      (U S path.1 (c path.1) path.2.1) path.2.2

@[expose] def outcomePathLoss (action : O → A) : (costs : List (X → A → ℝ)) → outcomePaths O costs → ℝ
  | [], _ => 0
  | c :: cs, path => c path.1 (action path.2.1) + outcomePathLoss action cs path.2.2

@[expose] def outcomePathEstimate (U : (P → ℝ) → X → (A → ℝ) → O → P → ℝ) :
    (costs : List (X → A → ℝ)) → (P → ℝ) → outcomePaths O costs → (P → ℝ)
  | [], S, _ => S
  | c :: cs, S, path => outcomePathEstimate U cs
      (U S path.1 (c path.1) path.2.1) path.2.2

@[expose] def outcomePathTrueScore (predict : P → X → A) :
    (costs : List (X → A → ℝ)) → (P → ℝ) → outcomePaths O costs → (P → ℝ)
  | [], S, _ => S
  | c :: cs, S, path => outcomePathTrueScore predict cs (trueScoreStep predict S c path.1) path.2.2

theorem outcomePathWeight_nonneg (d : X → ℝ) (hd : ∀ x, 0 ≤ d x) (q : (P → ℝ) → X → O → ℝ)
    (U : (P → ℝ) → X → (A → ℝ) → O → P → ℝ) (hq : ∀ S x o, 0 ≤ q S x o)
    (costs : List (X → A → ℝ)) (S : P → ℝ) (path : outcomePaths O costs) :
    0 ≤ outcomePathWeight d q U costs S path := by
  induction costs generalizing S with
  | nil => exact zero_le_one
  | cons c cs ih => exact mul_nonneg (mul_nonneg (hd _) (hq _ _ _)) (ih _ _)

theorem outcomePathWeight_sum (d : X → ℝ) (hdsum : ∑ x, d x = 1) (q : (P → ℝ) → X → O → ℝ)
    (U : (P → ℝ) → X → (A → ℝ) → O → P → ℝ) (hqsum : ∀ S x, ∑ o, q S x o = 1)
    (costs : List (X → A → ℝ)) (S : P → ℝ) :
    (∑ path, outcomePathWeight d q U costs S path) = 1 := by
  classical
  induction costs generalizing S with
  | nil =>
    change (∑ _path : Fin 0 → X × O, (1 : ℝ)) = 1
    simp
  | cons c cs ih =>
    change (∑ path : X × O × outcomePaths O cs, _) = 1
    simp only [Fintype.sum_prod_type, outcomePathWeight, ← Finset.mul_sum, ih, mul_one, hqsum, hdsum]

@[expose] def outcomePathLaw (d : X → ℝ) (hd : ∀ x, 0 ≤ d x) (hdsum : ∑ x, d x = 1)
    (q : (P → ℝ) → X → O → ℝ)
    (U : (P → ℝ) → X → (A → ℝ) → O → P → ℝ)
    (hq : ∀ S x o, 0 ≤ q S x o) (hqsum : ∀ S x, ∑ o, q S x o = 1)
    (costs : List (X → A → ℝ)) (S : P → ℝ) : PMF (outcomePaths O costs) :=
  actionPMF (outcomePathWeight d q U costs S) (outcomePathWeight_nonneg d hd q U hq costs S)
    (outcomePathWeight_sum d hdsum q U hqsum costs S)

theorem outcomePath_terminal_sum (d : X → ℝ) (q : (P → ℝ) → X → O → ℝ)
    (U : (P → ℝ) → X → (A → ℝ) → O → P → ℝ)
    (f : (P → ℝ) → ℝ) (costs : List (X → A → ℝ)) (S : P → ℝ) :
    (∑ path, outcomePathWeight d q U costs S path * f (outcomePathEstimate U costs S path)) =
      finiteOutcomeTerminal d q U f costs S := by
  classical
  induction costs generalizing S with
  | nil =>
    change (∑ _path : Fin 0 → X × O, (1 : ℝ) * f S) = f S
    simp
  | cons c cs ih =>
    change (∑ path : X × O × outcomePaths O cs, _) = _
    simp only [Fintype.sum_prod_type, outcomePathWeight, outcomePathEstimate, finiteOutcomeTerminal]
    simp_rw [mul_assoc, ← Finset.mul_sum, ih]

theorem outcomePath_comparator_sum (d : X → ℝ) (predict : P → X → A) (q : (P → ℝ) → X → O → ℝ)
    (U : (P → ℝ) → X → (A → ℝ) → O → P → ℝ)
    (hqsum : ∀ S x, ∑ o, q S x o = 1) (costs : List (X → A → ℝ)) (S V : P → ℝ) :
    (∑ path, outcomePathWeight d q U costs S path * treeBestScore (outcomePathTrueScore predict costs V path)) =
      contextBestScore d predict costs V := by
  classical
  induction costs generalizing S V with
  | nil =>
    change (∑ _path : Fin 0 → X × O, (1 : ℝ) * treeBestScore V) = treeBestScore V
    simp
  | cons c cs ih =>
    change (∑ path : X × O × outcomePaths O cs, _) = _
    simp only [Fintype.sum_prod_type, outcomePathWeight, outcomePathTrueScore, contextBestScore]
    simp_rw [mul_assoc, ← Finset.mul_sum, ih, ← Finset.sum_mul, hqsum, one_mul]

theorem outcomePath_loss_sum (action : O → A) (d : X → ℝ) (hdsum : ∑ x, d x = 1) (q : (P → ℝ) → X → O → ℝ)
    (U : (P → ℝ) → X → (A → ℝ) → O → P → ℝ) (hqsum : ∀ S x, ∑ o, q S x o = 1)
    (costs : List (X → A → ℝ)) (S : P → ℝ) :
    (∑ path, outcomePathWeight d q U costs S path * outcomePathLoss action costs path) =
      finiteOutcomeLoss d action q U costs S := by
  classical
  induction costs generalizing S with
  | nil => simp [outcomePathWeight, outcomePathLoss, finiteOutcomeLoss, outcomePaths]
  | cons c cs ih =>
    change (∑ path : X × O × outcomePaths O cs, _) = _
    simp only [Fintype.sum_prod_type, outcomePathWeight, outcomePathLoss, finiteOutcomeLoss]
    apply Finset.sum_congr rfl
    intro x _
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro a _
    simp_rw [mul_assoc, ← Finset.mul_sum]
    simp_rw [mul_add, Finset.sum_add_distrib, ← Finset.sum_mul]
    rw [outcomePathWeight_sum d hdsum q U hqsum, one_mul, ih]
    ring

theorem integral_outcomePath_regret (predict : P → X → A) (action : O → A) (d : X → ℝ) (hd : ∀ x, 0 ≤ d x) (hdsum : ∑ x, d x = 1)
    (q : (P → ℝ) → X → O → ℝ)
    (U : (P → ℝ) → X → (A → ℝ) → O → P → ℝ)
    (hq : ∀ S x o, 0 ≤ q S x o) (hqsum : ∀ S x, ∑ o, q S x o = 1)
    (costs : List (X → A → ℝ)) (S : P → ℝ) :
    (∫ path, outcomePathLoss action costs path + treeBestScore (outcomePathTrueScore predict costs S path)
      ∂(outcomePathLaw d hd hdsum q U hq hqsum costs S).toMeasure) =
      finiteOutcomeLoss d action q U costs S + contextBestScore d predict costs S := by
  unfold outcomePathLaw
  rw [integral_actionPMF]
  simp only [mul_add, Finset.sum_add_distrib]
  rw [outcomePath_loss_sum action d hdsum q U hqsum, outcomePath_comparator_sum d predict q U hqsum]
end
end PoissonAudit
