module

public import PoissonAudit.ThresholdPotential
public import PoissonAudit.ExponentialRemainder
public import Mathlib.Analysis.Calculus.MeanValue

public section

open MeasureTheory Set

namespace PoissonAudit

noncomputable section

variable {Omega : Type*} [MeasurableSpace Omega]

theorem thresholdCurvature_nonneg (mu : Measure Omega) (theta : Omega → ℝ)
    (sigma s : ℝ) (hsigma : 0 ≤ sigma) : 0 ≤ thresholdCurvature mu theta sigma s := by
  unfold thresholdCurvature
  exact div_nonneg (integral_nonneg fun _ => (realLaplaceDensity_pos _).le) hsigma

theorem thresholdPotential_zero (mu : Measure Omega) (theta : Omega → ℝ) (sigma : ℝ) :
    thresholdPotential mu theta sigma 0 = 0 := by simp [thresholdPotential, thresholdIncrement]

theorem thresholdProbability_drop_le (mu : Measure Omega) [IsProbabilityMeasure mu]
    (theta : Omega → ℝ) (htheta : Measurable theta) (sigma b : ℝ)
    (hsigma : 0 < sigma) (hb : 0 ≤ b) :
    thresholdProbability mu theta sigma 0 - thresholdProbability mu theta sigma b ≤
      sigma * thresholdCurvature mu theta sigma 0 * (Real.exp (b / sigma) - 1) := by
  let p := thresholdProbability mu theta sigma
  let h := thresholdCurvature mu theta sigma
  have hdp (u : ℝ) : HasDerivAt (fun v => p 0 - p v) (h u) u := by
    convert! (hasDerivAt_thresholdProbability mu theta htheta sigma u hsigma).const_sub (p 0) using 1
    ring
  have hdB (u : ℝ) : HasDerivAt (fun v => sigma * h 0 * (Real.exp (v / sigma) - 1))
      (Real.exp (u / sigma) * h 0) u := by
    have hd := (((hasDerivAt_id u).div_const sigma).exp.sub_const 1).const_mul (sigma * h 0)
    convert! hd using 1
    simp only [id_eq]
    field_simp [hsigma.ne'] <;> ring
  have hle := image_le_of_deriv_right_le_deriv_boundary
    (f := fun u => p 0 - p u) (f' := h)
    (B := fun u => sigma * h 0 * (Real.exp (u / sigma) - 1))
    (B' := fun u => Real.exp (u / sigma) * h 0) (a := 0) (b := b)
    (fun u _ => (hdp u).continuousAt.continuousWithinAt)
    (fun u _ => (hdp u).hasDerivWithinAt)
    (by simp)
    (fun u _ => (hdB u).continuousAt.continuousWithinAt)
    (fun u _ => (hdB u).hasDerivWithinAt)
    (fun u hu => thresholdCurvature_shift_le mu theta htheta sigma u hsigma hu.1)
  exact hle ⟨hb, le_rfl⟩

theorem thresholdPotential_exponential_remainder (mu : Measure Omega) [IsProbabilityMeasure mu]
    (theta : Omega → ℝ) (htheta : Measurable theta) (sigma b : ℝ)
    (hsigma : 0 < sigma) (hb : 0 ≤ b) :
    thresholdPotential mu theta sigma b + b * thresholdProbability mu theta sigma 0 ≤
      thresholdCurvature mu theta sigma 0 * sigma ^ 2 * (Real.exp (b / sigma) - 1 - b / sigma) := by
  let p := thresholdProbability mu theta sigma
  let h := thresholdCurvature mu theta sigma
  let H := thresholdPotential mu theta sigma
  have hdH (u : ℝ) : HasDerivAt (fun v => H v + v * p 0) (p 0 - p u) u := by
    have hd := (hasDerivAt_thresholdPotential mu theta htheta sigma u hsigma).add
      ((hasDerivAt_id u).mul_const (p 0))
    convert! hd using 1
    ring
  have hdB (u : ℝ) : HasDerivAt
      (fun v => h 0 * sigma ^ 2 * (Real.exp (v / sigma) - 1 - v / sigma))
      (sigma * h 0 * (Real.exp (u / sigma) - 1)) u := by
    have hd := ((((hasDerivAt_id u).div_const sigma).exp.sub_const 1).sub
      ((hasDerivAt_id u).div_const sigma)).const_mul (h 0 * sigma ^ 2)
    convert! hd using 1
    simp only [id_eq]
    field_simp [hsigma.ne'] <;> ring
  have hle := image_le_of_deriv_right_le_deriv_boundary
    (f := fun u => H u + u * p 0) (f' := fun u => p 0 - p u)
    (B := fun u => h 0 * sigma ^ 2 * (Real.exp (u / sigma) - 1 - u / sigma))
    (B' := fun u => sigma * h 0 * (Real.exp (u / sigma) - 1)) (a := 0) (b := b)
    (fun u _ => (hdH u).continuousAt.continuousWithinAt)
    (fun u _ => (hdH u).hasDerivWithinAt)
    (by simp [H, thresholdPotential_zero])
    (fun u _ => (hdB u).continuousAt.continuousWithinAt)
    (fun u _ => (hdB u).hasDerivWithinAt)
    (fun u hu => thresholdProbability_drop_le mu theta htheta sigma u hsigma hu.1)
  exact hle ⟨hb, le_rfl⟩

theorem thresholdPotential_quadratic_remainder (mu : Measure Omega) [IsProbabilityMeasure mu]
    (theta : Omega → ℝ) (htheta : Measurable theta) (sigma b : ℝ)
    (hsigma : 0 < sigma) (hb : 0 ≤ b) (hbs : b ≤ sigma) :
    thresholdPotential mu theta sigma b + b * thresholdProbability mu theta sigma 0 ≤
      (Real.exp 1 - 2) * thresholdCurvature mu theta sigma 0 * b ^ 2 := by
  have he := exp_quadratic_remainder (div_nonneg hb hsigma.le) ((div_le_one hsigma).mpr hbs)
  have hm := mul_le_mul_of_nonneg_left he
    (mul_nonneg (thresholdCurvature_nonneg mu theta sigma 0 hsigma.le) (sq_nonneg sigma))
  have h := thresholdPotential_exponential_remainder mu theta htheta sigma b hsigma hb
  have heq : thresholdCurvature mu theta sigma 0 * sigma ^ 2 *
      ((Real.exp 1 - 2) * (b / sigma) ^ 2) =
      (Real.exp 1 - 2) * thresholdCurvature mu theta sigma 0 * b ^ 2 := by
    field_simp [hsigma.ne'] <;> ring
  rw [heq] at hm
  exact h.trans hm

end

end PoissonAudit
