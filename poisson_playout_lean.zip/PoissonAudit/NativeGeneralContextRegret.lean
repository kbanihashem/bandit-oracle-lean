module
public import PoissonAudit.FeedbackLossList
public import PoissonAudit.NativeCappedRate
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [Fintype P] [Nonempty P] [LinearOrder P]
    [MeasurableSpace P] [MeasurableSingletonClass P] {K : ℕ}

@[expose] def nativeLiftedCappedLaw (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (hp : ∀ p, Measurable (predict p)) (costs : List (X → Fin K → ℝ))
    (hc : ∀ c ∈ costs, ∀ a, Measurable (fun x => c x a))
    (r : NNReal) (lam B eps delta gamma : ℝ) (hB : 1 ≤ B) :
    Measure (ContextTranscript X (NativeFiniteOutcome K delta)
      (feedbackLossList P K costs.length (costs.length ^ 2)).length) := by
  let L := costs.length ^ 2
  let f := feedbackContextList predict costs L
  have hf : Measurable f := measurable_feedbackContextList predict hp costs hc L
  haveI : IsProbabilityMeasure (D.map f) := (Measure.isProbabilityMeasure_map_iff hf.aemeasurable).mpr inferInstance
  exact liftedContextLaw D f (nativeFiniteOutcomeWeight r (D.map f) feedbackPrediction lam B eps delta gamma hB)
    (nativeFiniteOutcomeUpdate feedbackPrediction delta gamma) (feedbackLossList P K costs.length L) (fun _ => 0)

@[expose] def nativeLiftedOriginalRegret (predict : P → X → Fin K) (costs : List (X → Fin K → ℝ)) (delta : ℝ) :
    ContextTranscript X (NativeFiniteOutcome K delta) (feedbackLossList P K costs.length (costs.length ^ 2)).length → ℝ :=
  transcriptOriginalRegret predict (feedbackOriginalCost (P := P) costs (costs.length ^ 2)) Prod.snd

theorem native_general_context_capped_regret (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (hp : ∀ p, Measurable (predict p)) (hK : 0 < K)
    (costs : List (X → Fin K → ℝ)) (hT : 0 < costs.length)
    (hc : ∀ c ∈ costs, ∀ a, Measurable (fun x => c x a))
    (hc0 : ∀ c ∈ costs, ∀ x a, 0 ≤ c x a) (hc1 : ∀ c ∈ costs, ∀ x a, c x a ≤ 1) :
    ∃ (r : NNReal) (lam B gamma eps delta : ℝ) (hB : 1 ≤ B) (hg : 0 < gamma) (hgs : gamma ≤ 1 / 2)
        (heps : 0 < eps) (hd : 0 < delta),
      (∫ path, nativeLiftedOriginalRegret predict costs delta path
        ∂nativeLiftedCappedLaw D predict hp costs hc r lam B eps delta gamma hB) ≤
          60 * Real.exp 1 * Real.sqrt ((K : ℝ) * costs.length * Real.log (2 * Fintype.card P)) *
            Real.log (2 * (K : ℝ) * costs.length) + 2 := by
  let L := costs.length ^ 2
  let Y := FiniteFeedbackContext P K costs.length L
  let f := feedbackContextList predict costs L
  let cs := feedbackLossList P K costs.length L
  let cOrig := feedbackOriginalCost (P := P) costs L
  have hL : 0 < L := pow_pos hT 2
  have hf : Measurable f := measurable_feedbackContextList predict hp costs hc L
  haveI : IsProbabilityMeasure (D.map f) := (Measure.isProbabilityMeasure_map_iff hf.aemeasurable).mpr inferInstance
  have hlen : cs.length = costs.length := feedbackLossList_length P K costs.length L
  have hcs : 0 < cs.length := by rw [hlen]; exact hT
  have hcostMeas (t : Fin cs.length) (a : Fin K) : Measurable (fun x => cOrig t x a) :=
    hc _ (feedbackOriginalCost_mem costs L t) a
  have hcost0 (t : Fin cs.length) (x : X) (a : Fin K) : 0 ≤ cOrig t x a := hc0 _ (feedbackOriginalCost_mem costs L t) x a
  have hcost1 (t : Fin cs.length) (x : X) (a : Fin K) : cOrig t x a ≤ 1 := hc1 _ (feedbackOriginalCost_mem costs L t) x a
  have hround : (cs.length : ℝ) / L ≤ 1 := by
    have ht : (1 : ℝ) ≤ costs.length := by exact_mod_cast hT
    have ht0 : (0 : ℝ) < costs.length := by exact_mod_cast hT
    rw [hlen]
    change (costs.length : ℝ) / ((costs.length ^ 2 : ℕ) : ℝ) ≤ 1
    rw [Nat.cast_pow]
    exact (div_le_one (sq_pos_of_pos ht0)).mpr (by nlinarith)
  obtain ⟨r, lam, B, gamma, eps, delta, hB, hg, hgs, heps, hd, hrate⟩ :=
    native_capped_square_root_regret (D.map f) (feedbackPrediction : P → Y → Fin K) hK cs hcs
      (feedbackLossList_nonneg P K costs.length L hL) (feedbackLossList_le_one P K costs.length L hL)
  let w := nativeFiniteOutcomeWeight r (D.map f) (feedbackPrediction : P → Y → Fin K) lam B eps delta gamma hB
  let U := nativeFiniteOutcomeUpdate (feedbackPrediction : P → Y → Fin K) delta gamma
  have hgm : gamma ≤ 1 := by linarith
  have hw := nativeFiniteOutcomeWeight_nonneg r (D.map f) (feedbackPrediction : P → Y → Fin K) lam B eps delta gamma hB hg.le hgm
  have hws := nativeFiniteOutcomeWeight_sum r (D.map f) (feedbackPrediction : P → Y → Fin K) lam B eps delta gamma hB hK
  have htransfer := integral_original_regret_le_quotient D f hf predict hp (feedbackPrediction : P → Y → Fin K)
    (fun _ _ => rfl) w hw hws U cs cOrig hcostMeas L hL hcost0 hcost1
    (feedbackLossList_factor predict costs L) Prod.snd
  have hid := integral_outcomePath_regret (feedbackPrediction : P → Y → Fin K) Prod.snd
    (fun y => ((D.map f) {y}).toReal) (fun _ => ENNReal.toReal_nonneg) (context_mass_sum (D.map f))
    w U hw hws cs (fun _ => 0)
  change (∫ path, outcomePathLoss Prod.snd cs path + treeBestScore (outcomePathTrueScore feedbackPrediction cs (fun _ => 0) path)
    ∂(nativeCappedLaw r (D.map f) feedbackPrediction lam B eps delta gamma hB hK hg.le hgm cs).toMeasure) = _ at hid
  rw [hid] at hrate
  have hlenReal : (cs.length : ℝ) = costs.length := by exact_mod_cast hlen
  rw [hlenReal] at hrate
  refine ⟨r, lam, B, gamma, eps, delta, hB, hg, hgs, heps, hd, ?_⟩
  change (∫ path, transcriptOriginalRegret predict cOrig Prod.snd path ∂liftedContextLaw D f w U cs (fun _ => 0)) ≤ _
  linarith
end
end PoissonAudit
