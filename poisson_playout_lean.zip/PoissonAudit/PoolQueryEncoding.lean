module
public import PoissonAudit.CostSensitiveQueries
public section
open Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} {K m : ℕ}

@[expose] def scaledPoolExamples (sigma : X × Fin K → ℝ) (pool : Fin m → X × (Fin K → ℝ)) : List (CostExample X K) :=
  List.ofFn fun i => ((pool i).1, fun a => sigma ((pool i).1, a) * (pool i).2 a)

theorem queryScore_scaledPoolExamples (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (pool : Fin m → X × (Fin K → ℝ)) (p : P) :
    queryScore predict (scaledPoolExamples sigma pool) p =
      ∑ i, sigma ((pool i).1, predict p (pool i).1) * (pool i).2 (predict p (pool i).1) := by
  simp [queryScore, scaledPoolExamples, List.map_ofFn, List.sum_ofFn]

@[expose] def insertedQuery (Q : List (CostExample X K)) (sigma : X × Fin K → ℝ)
    (x : X) (z0 : Fin K → ℝ) (pool : Fin m → X × (Fin K → ℝ)) : List (CostExample X K) :=
  (Q ++ scaledPoolExamples sigma pool) ++ [(x, fun a => sigma (x, a) * z0 a)]

theorem insertedQuery_length (Q : List (CostExample X K)) (sigma : X × Fin K → ℝ)
    (x : X) (z0 : Fin K → ℝ) (pool : Fin m → X × (Fin K → ℝ)) :
    (insertedQuery Q sigma x z0 pool).length = Q.length + m + 1 := by simp [insertedQuery, scaledPoolExamples, Nat.add_assoc]

theorem queryScore_insertedQuery (predict : P → X → Fin K) (Q : List (CostExample X K))
    (sigma : X × Fin K → ℝ) (x : X) (z0 : Fin K → ℝ) (pool : Fin m → X × (Fin K → ℝ)) (p : P) :
    queryScore predict (insertedQuery Q sigma x z0 pool) p =
      insertedPoolScore predict sigma (queryScore predict Q) ((x, z0), pool) p := by
  unfold insertedQuery insertedPoolScore markValue
  rw [queryScore_designated, queryScore_append, queryScore_scaledPoolExamples]
  ring

@[expose] def appendBanditObservation (Q : List (CostExample X K)) (x : X) (a : Fin K) (b : ℝ) : List (CostExample X K) := by
  classical
  exact Q ++ [(x, fun k => if k = a then -b else 0)]

theorem appendBanditObservation_length (Q : List (CostExample X K)) (x : X) (a : Fin K) (b : ℝ) :
    (appendBanditObservation Q x a b).length = Q.length + 1 := by simp [appendBanditObservation]

theorem queryScore_appendBanditObservation (predict : P → X → Fin K) (Q : List (CostExample X K))
    (x : X) (a : Fin K) (b : ℝ) :
    queryScore predict (appendBanditObservation Q x a b) = actionPenaltyScore predict (queryScore predict Q) x a b := by
  classical
  funext p
  unfold appendBanditObservation actionPenaltyScore actionSlope
  rw [queryScore_designated]
  split_ifs <;> ring

variable [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X]

@[expose] def nativeNoiseQuery (Q : List (CostExample X K)) (sigma : X × Fin K → ℝ) (x : X) (v : NativeNoise X K) : List (CostExample X K) :=
  insertedQuery Q sigma x v.1 (poolPrefix v.2.1 v.2.2)

theorem nativeNoiseQuery_length (Q : List (CostExample X K)) (sigma : X × Fin K → ℝ) (x : X) (v : NativeNoise X K) :
    (nativeNoiseQuery Q sigma x v).length = Q.length + v.2.1 + 1 := insertedQuery_length Q sigma x v.1 _

theorem nativeNoiseQuery_cap_length (Q : List (CostExample X K)) (sigma : X × Fin K → ℝ)
    (x : X) (v : NativeNoise X K) (cap : ℕ) (hcap : v.2.1 ≤ cap) :
    (nativeNoiseQuery Q sigma x v).length ≤ Q.length + cap + 1 := by rw [nativeNoiseQuery_length]; omega

theorem queryScore_nativeNoiseQuery (predict : P → X → Fin K) (Q : List (CostExample X K))
    (sigma : X × Fin K → ℝ) (x : X) (v : NativeNoise X K) (p : P) :
    queryScore predict (nativeNoiseQuery Q sigma x v) p = experimentScore predict sigma (queryScore predict Q) x v p := by
  unfold nativeNoiseQuery
  rw [queryScore_insertedQuery]
  unfold experimentScore insertedPoolScore markValue
  rw [poissonCoefficient_expansion]
  rfl
end
end PoissonAudit
