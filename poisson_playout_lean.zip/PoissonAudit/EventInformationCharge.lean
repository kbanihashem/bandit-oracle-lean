module

public import PoissonAudit.WeightedLaplaceVariational
public import PoissonAudit.FirstBlockInformation
public import PoissonAudit.ConditionalChannel

public section

open MeasureTheory InformationTheory ProbabilityTheory
open scoped ENNReal BigOperators

namespace PoissonAudit

noncomputable section

@[expose] def eventInformationCharge {U V : Type*} [MeasurableSpace U] [MeasurableSpace V]
    (mu : Measure U) (nu : Measure V) (E : Set (U × V)) : ℝ :=
  (mu.prod nu E).toReal * (klDiv (eventPosterior (mu.prod nu) E).fst mu).toReal

theorem eventInformationCharge_nonneg {U V : Type*} [MeasurableSpace U] [MeasurableSpace V]
    (mu : Measure U) (nu : Measure V) (E : Set (U × V)) : 0 ≤ eventInformationCharge mu nu E :=
  mul_nonneg ENNReal.toReal_nonneg ENNReal.toReal_nonneg

theorem channelEntropyCharge_event (K : ℕ) {V : Type*} [MeasurableSpace V]
    (nu : Measure V) [IsProbabilityMeasure nu] (E : Set ((Fin K → ℝ) × V)) (hE : MeasurableSet E) :
    channelEntropyCharge K (eventChannel nu E) ((laplaceMeasure K).prod nu E).toReal =
      eventInformationCharge (laplaceMeasure K) nu E := by
  classical
  by_cases hz : (laplaceMeasure K).prod nu E = 0
  · simp [channelEntropyCharge, eventInformationCharge, hz]
  · unfold channelEntropyCharge eventInformationCharge
    rw [eventPosterior, if_neg hz, fst_conditioned_product_channel_density _ _ E hE hz]

theorem laplace_event_weighted_variational (K : ℕ) (a : Fin K) {V : Type*} [MeasurableSpace V]
    (nu : Measure V) [IsProbabilityMeasure nu] (E : Set ((Fin K → ℝ) × V)) (hE : MeasurableSet E) :
    (∀ t : ℝ, 0 < t → t ≤ 1 / 2 →
      t * |∫ z, eventChannel nu E z * z a ∂laplaceMeasure K| ≤
        eventInformationCharge (laplaceMeasure K) nu E + (4 / 3 : ℝ) * t ^ 2 * ((laplaceMeasure K).prod nu E).toReal) ∧
    (∀ t : ℝ, 0 < t →
      t * |∫ z, eventChannel nu E z * laplaceSign (z a) ∂laplaceMeasure K| ≤
        eventInformationCharge (laplaceMeasure K) nu E + (t ^ 2 / 2) * ((laplaceMeasure K).prod nu E).toReal) := by
  have h := weighted_laplace_channel_variational K a (eventChannel nu E)
    (measurable_eventSectionMass nu E hE).ennreal_toReal
    (fun z => (eventChannel_mem_Icc nu E z).1) (fun z => (eventChannel_mem_Icc nu E z).2)
  dsimp only at h
  rw [integral_eventChannel (laplaceMeasure K) nu E hE,
    channelEntropyCharge_event K nu E hE] at h
  exact h

theorem firstBlockInformation_toReal {U V P : Type*} [MeasurableSpace U] [MeasurableSpace V]
    [MeasurableSpace P] [MeasurableSingletonClass P] [Fintype P] [Nonempty P]
    (mu : Measure U) (nu : Measure V) [IsProbabilityMeasure mu] [IsProbabilityMeasure nu]
    (W : U × V → P) (hW : Measurable W) :
    (firstBlockInformation mu nu W).toReal = ∑ p, eventInformationCharge mu nu (outcomeEvent W p) := by
  have hb := firstBlockInformation_le_log_card mu nu W hW
  have hfinite (p : P) : mu.prod nu (outcomeEvent W p) *
      klDiv (eventPosterior (mu.prod nu) (outcomeEvent W p)).fst mu ≠ ∞ := by
    apply ne_top_of_le_ne_top ENNReal.ofReal_ne_top
    exact (Finset.single_le_sum (f := fun q => mu.prod nu (outcomeEvent W q) *
      klDiv (eventPosterior (mu.prod nu) (outcomeEvent W q)).fst mu)
      (fun _ _ => zero_le) (Finset.mem_univ p)).trans hb
  unfold firstBlockInformation eventInformationCharge
  rw [ENNReal.toReal_sum (fun p _ => hfinite p)]
  simp only [ENNReal.toReal_mul]

end

end PoissonAudit
