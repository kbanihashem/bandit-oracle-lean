module

public import PoissonAudit.VariationalConvexity
public import PoissonAudit.PotentialPerturbation

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {Omega P Q : Type*} [MeasurableSpace Omega]
    [Fintype P] [Nonempty P] [Fintype Q]

omit [MeasurableSpace Omega] in
theorem affinePoolMax_translation (S : P → ℝ) (V : Omega → P → Q → ℝ)
    (sigma : Q → ℝ) (d : ℝ) (omega : Omega) :
    affinePoolMax (fun p => S p + d) V sigma omega = affinePoolMax S V sigma omega + d := by
  classical
  obtain ⟨p, _, hp⟩ := Finset.exists_mem_eq_sup' (s := Finset.univ) Finset.univ_nonempty
    (fun p => S p + d + ∑ j, sigma j * V omega p j)
  obtain ⟨q, _, hq⟩ := Finset.exists_mem_eq_sup' (s := Finset.univ) Finset.univ_nonempty
    (fun p => S p + ∑ j, sigma j * V omega p j)
  have hple := Finset.le_sup' (s := Finset.univ)
    (f := fun p => S p + ∑ j, sigma j * V omega p j) (Finset.mem_univ p)
  have hqle := Finset.le_sup' (s := Finset.univ)
    (f := fun p => S p + d + ∑ j, sigma j * V omega p j) (Finset.mem_univ q)
  unfold affinePoolMax
  rw [hp, hq]
  rw [hp] at hqle
  rw [hq] at hple
  linarith

theorem affinePoolPotential_translation (mu : Measure Omega) [IsProbabilityMeasure mu]
    (V : Omega → P → Q → ℝ) (hV : ∀ p j, Integrable (fun omega => V omega p j) mu)
    (S : P → ℝ) (sigma : Q → ℝ) (d : ℝ) :
    affinePoolPotential mu (fun p => S p + d) V sigma = affinePoolPotential mu S V sigma + d := by
  unfold affinePoolPotential
  simp_rw [affinePoolMax_translation]
  rw [integral_add (integrable_affinePoolMax mu S V hV sigma) (integrable_const d)]
  simp

theorem variationalValue_translation (mu : Measure Omega) [IsProbabilityMeasure mu]
    (V : Omega → P → Q → ℝ) (hV : ∀ p j, Integrable (fun omega => V omega p j) mu)
    (w : Q → ℝ) (lam B : ℝ) (hB : 1 ≤ B) (S : P → ℝ) (d : ℝ) :
    variationalValue mu V hV w lam B hB (fun p => S p + d) =
      variationalValue mu V hV w lam B hB S + d := by
  let s := optimalScale mu V hV w lam B hB S
  let t := optimalScale mu V hV w lam B hB (fun p => S p + d)
  have hs := variationalValue_le mu V hV w lam B hB (fun p => S p + d) s
    (optimalScale_spec mu V hV w lam B hB S).1
  have ht := variationalValue_le mu V hV w lam B hB S t
    (optimalScale_spec mu V hV w lam B hB (fun p => S p + d)).1
  have heq (sigma : Q → ℝ) : scaleObjective mu (fun p => S p + d) V w lam B sigma =
      scaleObjective mu S V w lam B sigma + d := by
    unfold scaleObjective
    rw [affinePoolPotential_translation mu V hV]
    ring
  rw [heq] at hs
  have hsval : scaleObjective mu S V w lam B s = variationalValue mu V hV w lam B hB S := rfl
  have htval : scaleObjective mu (fun p => S p + d) V w lam B t =
      variationalValue mu V hV w lam B hB (fun p => S p + d) := rfl
  rw [hsval] at hs
  rw [heq] at htval
  linarith

theorem variational_one_step_probability_lipschitz {A : Type*} [Fintype A]
    (mu : Measure Omega) [IsProbabilityMeasure mu]
    (V : Omega → P → Q → ℝ) (hV : ∀ p j, Integrable (fun omega => V omega p j) mu)
    (w : Q → ℝ) (hw : ∀ j, 0 ≤ w j) (lam B : ℝ) (hlam : 0 ≤ lam) (hB : 1 ≤ B)
    (S : P → ℝ) (f : A → P → ℝ) (q r c : A → ℝ) (floor : ℝ)
    (hfloor : 0 < floor) (hq : ∀ a, floor ≤ q a) (hr : ∀ a, floor ≤ r a)
    (hc0 : ∀ a, 0 ≤ c a) (hc1 : ∀ a, c a ≤ 1)
    (hf0 : ∀ a p, 0 ≤ f a p) (hf1 : ∀ a p, f a p ≤ 1) :
    let R := variationalValue mu V hV w lam B hB
    |((∑ a, q a * c a) - ∑ a, q a * lossDrop R S (f a) (c a / q a)) -
      ((∑ a, r a * c a) - ∑ a, r a * lossDrop R S (f a) (c a / r a))| ≤
      (1 + 1 / floor) * ∑ a, |q a - r a| := by
  exact one_step_probability_lipschitz _ S f q r c floor hfloor hq hr hc0 hc1 hf0 hf1
    (variationalValue_mono mu V hV w lam B hB)
    (convex_variationalValue mu V hV w hw lam B hlam hB)
    (variationalValue_translation mu V hV w lam B hB)

end

end PoissonAudit
