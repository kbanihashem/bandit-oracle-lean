module

public import PoissonAudit.ExperimentBeta
public import PoissonAudit.LaplaceCoordinateVariational

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def experimentMoment (r : NNReal) (D : Measure X)
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (g : ℝ → ℝ) : ℝ :=
  ∫ v, (experimentActionEvent predict sigma S x a).indicator (fun _ => (1 : ℝ)) v * g (v.1 a)
    ∂insertedExperimentLaw r D K

@[expose] def finiteInsertedMoment (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (a : Fin K) (g : ℝ → ℝ) (n : ℕ)
    (v : (Fin K → ℝ) × (Fin n → X × (Fin K → ℝ))) : ℝ := by
  classical
  exact if predict (insertedMarkWinner predict sigma S ((x, v.1), v.2)) x = a then g (v.1 a) else 0

theorem measurable_finiteInsertedMoment (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (a : Fin K) (g : ℝ → ℝ) (hg : Measurable g) (n : ℕ) :
    Measurable (finiteInsertedMoment predict sigma S x a g n) := by
  classical
  have hm : Measurable (fun v : (Fin K → ℝ) × (Fin n → X × (Fin K → ℝ)) => ((x, v.1), v.2)) :=
    (measurable_const.prodMk measurable_fst).prodMk measurable_snd
  have hW := (measurable_insertedMarkWinner predict sigma S n).comp hm
  have hA := (measurable_of_finite (fun p => predict p x)).comp hW
  have hE : MeasurableSet {v : (Fin K → ℝ) × (Fin n → X × (Fin K → ℝ)) | predict (insertedMarkWinner predict sigma S ((x, v.1), v.2)) x = a} :=
    hA (measurableSet_singleton a)
  have h := (hg.comp ((measurable_pi_apply a).comp measurable_fst)).indicator hE
  convert! h using 1
  funext v
  by_cases hv : predict (insertedMarkWinner predict sigma S ((x, v.1), v.2)) x = a <;>
    simp [finiteInsertedMoment, hv]

theorem integrable_experimentMoment_integrand (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (g : ℝ → ℝ) (hg : Integrable g realLaplace) :
    Integrable (fun v => (experimentActionEvent predict sigma S x a).indicator (fun _ => (1 : ℝ)) v * g (v.1 a))
      (insertedExperimentLaw r D K) := by
  classical
  have hgi : Integrable (fun v : (Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ))) => g (v.1 a))
      (insertedExperimentLaw r D K) := by
    unfold insertedExperimentLaw
    simpa only [mul_one] using (integrable_laplace_coordinate_comp K a g hg).mul_prod
      (integrable_const (1 : ℝ) (μ := markedPoolLaw r (contextLaplaceLaw D K)))
  convert! hgi.indicator (measurable_experimentActionEvent predict sigma S x a) using 1
  funext v
  by_cases hv : v ∈ experimentActionEvent predict sigma S x a <;> simp [hv]

theorem experimentMoment_eq_finite (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (g : ℝ → ℝ) (hgm : Measurable g) (hgi : Integrable g realLaplace) :
    experimentMoment r D predict sigma S x a g =
      ∫ n, (∫ z0, ∫ pool, finiteInsertedMoment predict sigma S x a g n (z0, pool)
        ∂iidPool (contextLaplaceLaw D K) n ∂laplaceMeasure K) ∂ProbabilityTheory.poissonMeasure r := by
  classical
  let F := fun v : (Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ))) =>
    (experimentActionEvent predict sigma S x a).indicator (fun _ => (1 : ℝ)) v * g (v.1 a)
  have hf : Integrable F ((laplaceMeasure K).prod
      ((ProbabilityTheory.poissonMeasure r).prod (markSequence (contextLaplaceLaw D K)))) :=
    integrable_experimentMoment_integrand r D predict sigma S x a g hgi
  change (∫ v, F v ∂(laplaceMeasure K).prod
    ((ProbabilityTheory.poissonMeasure r).prod (markSequence (contextLaplaceLaw D K)))) = _
  rw [integral_fresh_count_marks _ _ _ F hf]
  apply integral_congr_ae
  filter_upwards [] with n
  apply integral_congr_ae
  filter_upwards [] with z0
  have heq (u : ℕ → X × (Fin K → ℝ)) :
      F (z0, (n, u)) = finiteInsertedMoment predict sigma S x a g n (z0, poolPrefix n u) := by
    simp only [F, Set.indicator_apply, experimentActionEvent, outcomeEvent, Set.mem_ofPred_eq, experimentAction]
    simp only [experimentWinner_eq_insertedMarkWinner]
    by_cases h : predict (insertedMarkWinner predict sigma S ((x, z0), poolPrefix n u)) x = a <;>
      simp [finiteInsertedMoment, h]
  simp_rw [heq]
  have hmp := poolPrefix_measurePreserving (contextLaplaceLaw D K) n
  have hmeas : Measurable (fun pool => finiteInsertedMoment predict sigma S x a g n (z0, pool)) :=
    (measurable_finiteInsertedMoment predict sigma S x a g hgm n).comp
      (measurable_const.prodMk measurable_id)
  have h := integral_map hmp.measurable.aemeasurable
    (f := fun pool => finiteInsertedMoment predict sigma S x a g n (z0, pool))
    (by rw [hmp.map_eq]; exact hmeas.aestronglyMeasurable)
  rw [hmp.map_eq] at h
  exact h.symm

theorem experimentMoment_id (r : NNReal) (D : Measure X) (predict : P → X → Fin K)
    (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) :
    experimentMoment r D predict sigma S x a (fun z => z) = experimentAlpha r D predict sigma S x a := rfl

theorem experimentMoment_sign (r : NNReal) (D : Measure X) (predict : P → X → Fin K)
    (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) :
    experimentMoment r D predict sigma S x a laplaceSign = experimentBeta r D predict sigma S x a := rfl

theorem experimentMoment_one (r : NNReal) (D : Measure X) (predict : P → X → Fin K)
    (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) :
    experimentMoment r D predict sigma S x a (fun _ => 1) = experimentProbability r D predict sigma S x a := by
  unfold experimentMoment
  simp only [mul_one]
  have h := integral_indicator_const (1 : ℝ) (μ := insertedExperimentLaw r D K)
    (measurable_experimentActionEvent predict sigma S x a)
  convert! h using 1
  change (insertedExperimentLaw r D K).real (experimentActionEvent predict sigma S x a) =
    (insertedExperimentLaw r D K).real (experimentActionEvent predict sigma S x a) * 1
  ring

end

end PoissonAudit
