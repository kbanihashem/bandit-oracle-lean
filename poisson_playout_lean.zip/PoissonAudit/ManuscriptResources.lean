module
public import PoissonAudit.Manuscript
public import PoissonAudit.CountedProgramCertificate
public import Mathlib.Analysis.Complex.ExponentialBounds
public section

namespace PoissonAudit
noncomputable section

theorem manuscript_online_budget (K T : ℕ) (hK : 2 ≤ K) (hT : 0 < T) (L : ℝ) (hL : 1/2 ≤ L) :
    let p := manuscriptPlan K T L
    let J := paperIterations K p.r p.lam p.B p.eps
    let m := paperTrials K p.delta
    let M := paperCap p.r (J+m) p.delta
    PowerBound (2 + (K : ℝ) + T + 2*L) 512 (T * onlineWorkBudget T K M J m) := by
  intro p J m M
  let k : ℝ := K
  let t : ℝ := T
  let H := 2+k+t+2*L
  let A := Real.sqrt (k*t*L)
  let B := k*(t+1)
  let ell := 1+Real.log B
  let γ := 1/(t+1)
  let δ := γ/(t*(γ+k))
  let r := A/(k*ell)
  let lam := 4*A/k
  let eps := lam*δ^2/(32*B^2*(r+1)^2*k)
  have hk : 2 ≤ k := by dsimp [k]; exact_mod_cast hK
  have ht : 1 ≤ t := by dsimp [t]; exact_mod_cast hT
  have hk0 : 0 < k := by linarith
  have ht0 : 0 < t := by linarith
  have hkt : 2 ≤ k*t := by nlinarith only [hk, mul_nonneg hk0.le (sub_nonneg.mpr ht)]
  have hprod : 1 ≤ k*t*L := by nlinarith only [hL,mul_nonneg (sub_nonneg.mpr hkt) (by linarith : 0 ≤ L)]
  have hA2 : A^2 = k*t*L := Real.sq_sqrt (by linarith)
  have hA : 1 ≤ A := by nlinarith only [Real.sqrt_nonneg (k*t*L),hA2,hprod]
  have hB : 1 ≤ B := by dsimp [B]; nlinarith only [hk,hkt]
  have hell : 1 ≤ ell := by dsimp [ell]; linarith [Real.log_nonneg hB]
  have hb := arithmetic_tuning_power_bounds k t (2*L) A ell (by linarith) ht (by linarith) hA (by nlinarith only [hA2,hprod]) hell
  change 2 ≤ H ∧ 0 < r ∧ 0 < lam ∧ 0 < δ ∧ 0 < eps ∧
    PowerBound H 3 r ∧ PowerBound H 1 k ∧ PowerBound H 4 lam ∧ PowerBound H 3 B ∧
    PowerBound H 30 (1/eps) ∧ PowerBound H 4 (1/δ) at hb
  obtain ⟨hH,hr,hl,hd,he,hrP,hkP,hlP,hBP,heP,hdP⟩ := hb
  have hH0 : 0 ≤ H := by linarith
  have hγ : 0 < γ := by dsimp [γ]; positivity
  have hrval : (p.r : ℝ) = r := Real.coe_toNNReal _ hr.le
  have hdval : p.delta = δ := by
    change 1/(t*(1+k/γ)) = γ/(t*(γ+k))
    field_simp
  have hecmp : eps ≤ p.eps := by
    change lam*δ^2/(32*B^2*(r+1)^2*k) ≤ lam*p.delta^2/(32*B^2*((p.r : ℝ)+1))
    rw [hdval,hrval]
    apply div_le_div_of_nonneg_left (by positivity) (by positivity)
    have h1 : 1 ≤ (r+1)*k := by nlinarith only [hk, mul_nonneg hr.le hk0.le]
    nlinarith only [mul_nonneg (show 0 ≤ 32*B^2*(r+1) by positivity) (sub_nonneg.mpr h1)]
  have heP' : PowerBound H 30 (1/p.eps) :=
    powerBound_le heP (by have := he.trans_le hecmp; positivity) (one_div_le_one_div_of_le he hecmp)
  have hnative := native_finite_budgets_power_bound H hH p.r K p.lam p.B p.eps p.delta
    (hrval ▸ hrP) hkP hlP hBP heP' (hdval ▸ hdP)
  have hJle : J ≤ nativeSGDIterations p.r K p.lam p.B p.eps := by
    apply max_le_max_left
    apply Nat.ceil_mono
    unfold paperDiameter paperGradientSize
    rw [mul_pow, Real.sq_sqrt (Nat.cast_nonneg K), Real.sq_sqrt (by positivity)]
    gcongr
    norm_num
  have hJ := powerBound_le hnative.1 (Nat.cast_nonneg _) (Nat.cast_le.mpr hJle)
  have hmle : m ≤ nativeEmpiricalTrials K p.delta := by
    apply le_trans _ (le_max_right ..)
    apply Nat.ceil_mono
    gcongr
    change k ≤ k^2
    nlinarith only [hk,sq_nonneg (k-1)]
  have hm := powerBound_le hnative.2.1 (Nat.cast_nonneg _) (Nat.cast_le.mpr hmle)
  have hcount : PowerBound H 83 ((J+m : ℕ) : ℝ) := by
    simp only [Nat.cast_add]
    exact powerBound_add hH hJ hm
  have hcountpos : 0 < J+m := by
    have hJpos : 0 < J := lt_of_lt_of_le Nat.zero_lt_one (le_max_left ..)
    omega
  have hdp : 0 < p.delta := hdval ▸ hd
  have hbase : PowerBound H 89 (4*((J+m : ℕ) : ℝ)/p.delta) := by
    have h := powerBound_mul hH0 (powerBound_scale hH hcount 2) (hdval ▸ hdP : PowerBound H 4 (1/p.delta))
    convert! h using 1 <;> ring
  have htwo : PowerBound H 4 (2*(p.r : ℝ)) := by
    simpa using powerBound_scale hH (hrval ▸ hrP : PowerBound H 3 (p.r : ℝ)) 1
  have hsum := powerBound_add hH htwo hbase
  have hcaple : M ≤ max 1 ⌈2*(p.r : ℝ)+4*((J+m : ℕ) : ℝ)/p.delta⌉₊ := by
    apply le_trans _ (le_max_right ..)
    apply Nat.ceil_mono
    apply add_le_add
    · exact mul_le_mul_of_nonneg_right (by linarith [Real.exp_one_lt_three]) p.r.coe_nonneg
    · linarith [Real.log_le_sub_one_of_pos (by positivity : 0 < 4*((J+m : ℕ) : ℝ)/p.delta)]
  have hM := powerBound_le (powerBound_ceil_max hH hsum) (Nat.cast_nonneg _) (Nat.cast_le.mpr hcaple)
  have htP : PowerBound H 1 t := ⟨ht0.le, by dsimp [H]; linarith⟩
  exact onlineWorkBudget_power_bound H hH T K M J m htP hkP (powerBound_mono (by linarith) hM (by decide)) hJ hm

end
end PoissonAudit
