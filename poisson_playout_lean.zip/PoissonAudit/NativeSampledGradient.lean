module
public import PoissonAudit.NativeStochasticGradient
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def nativeSampledGradient (r : NNReal) (predict : P → X → Fin K)
    (sigma : X × Fin K → ℝ) (S : P → ℝ) (lam : ℝ)
    (v : (Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ)))) (j : X × Fin K) : ℝ :=
  (r : ℝ) * ((experimentActionEvent predict sigma S j.1 j.2).indicator (fun _ => (1 : ℝ)) v * v.1 j.2) - lam / sigma j

theorem measurable_nativeSampledGradient (r : NNReal) (predict : P → X → Fin K)
    (sigma : X × Fin K → ℝ) (S : P → ℝ) (lam : ℝ) (j : X × Fin K) :
    Measurable (fun v => nativeSampledGradient r predict sigma S lam v j) := by
  unfold nativeSampledGradient
  exact (measurable_const.mul (((measurable_const.indicator
    (measurable_experimentActionEvent predict sigma S j.1 j.2))).mul
      ((measurable_pi_apply j.2).comp measurable_fst))).sub measurable_const

theorem integrable_nativeSampledGradient (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (lam : ℝ) (j : X × Fin K) :
    Integrable (fun v => nativeSampledGradient r predict sigma S lam v j) (insertedExperimentLaw r D K) :=
  ((integrable_experiment_correlation r D predict sigma S j.1 j.2).const_mul r).sub (integrable_const _)

theorem integral_nativeSampledGradient (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (lam : ℝ) (j : X × Fin K) :
    (∫ v, nativeSampledGradient r predict sigma S lam v j ∂insertedExperimentLaw r D K) =
      (r : ℝ) * experimentAlpha r D predict sigma S j.1 j.2 - lam / sigma j := by
  unfold nativeSampledGradient
  rw [integral_sub ((integrable_experiment_correlation r D predict sigma S j.1 j.2).const_mul r) (integrable_const _),
    integral_const_mul, integral_const, probReal_univ, one_smul]
  rfl

theorem nativeSampledGradient_mean (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (lam : ℝ) (j : X × Fin K) :
    (D {j.1}).toReal * (∫ v, nativeSampledGradient r predict sigma S lam v j ∂insertedExperimentLaw r D K) =
      poissonCoordinateGradient r D predict sigma S lam j := by
  rw [integral_nativeSampledGradient]
  unfold poissonCoordinateGradient
  rw [poisson_winner_gradient_insertion, insertedCorrelationMass_eq,
    ← experimentAlpha_eq_insertedAlpha]
  ring

theorem nativeSampledGradient_square_bound (r : NNReal) (predict : P → X → Fin K)
    (sigma : X × Fin K → ℝ) (S : P → ℝ) (lam : ℝ)
    (v : (Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ)))) (j : X × Fin K) (hs : 1 ≤ sigma j) :
    (nativeSampledGradient r predict sigma S lam v j) ^ 2 ≤ 2 * (r : ℝ) ^ 2 * (v.1 j.2) ^ 2 + 2 * lam ^ 2 := by
  have hs0 : 0 < sigma j := by linarith
  have hdiv : (lam / sigma j) ^ 2 ≤ lam ^ 2 := by
    rw [div_pow]
    exact div_le_self (sq_nonneg lam) (by nlinarith)
  unfold nativeSampledGradient
  by_cases h : v ∈ experimentActionEvent predict sigma S j.1 j.2
  · simp only [Set.indicator_of_mem h, one_mul]
    nlinarith only [hdiv, sq_nonneg ((r : ℝ) * v.1 j.2 + lam / sigma j)]
  · simp only [Set.indicator_of_notMem h, zero_mul, mul_zero, zero_sub, neg_sq]
    nlinarith [sq_nonneg ((r : ℝ) * v.1 j.2)]

theorem integrable_nativeSampledGradient_square (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (lam : ℝ)
    (j : X × Fin K) (hs : 1 ≤ sigma j) :
    Integrable (fun v => (nativeSampledGradient r predict sigma S lam v j) ^ 2) (insertedExperimentLaw r D K) := by
  have hz : Integrable (fun v : (Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ))) => (v.1 j.2) ^ 2) (insertedExperimentLaw r D K) :=
    (integrable_laplace_coordinate_square K j.2).comp_fst (markedPoolLaw r (contextLaplaceLaw D K))
  apply ((hz.const_mul (2 * (r : ℝ) ^ 2)).add (integrable_const (2 * lam ^ 2))).mono'
    ((measurable_nativeSampledGradient r predict sigma S lam j).pow_const 2).aestronglyMeasurable
  filter_upwards [] with v
  change |(nativeSampledGradient r predict sigma S lam v j) ^ 2| ≤ 2 * (r : ℝ) ^ 2 * (v.1 j.2) ^ 2 + 2 * lam ^ 2
  rw [abs_of_nonneg (sq_nonneg _)]
  exact nativeSampledGradient_square_bound r predict sigma S lam v j hs

theorem integral_nativeSampledGradient_square_le (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (lam : ℝ)
    (j : X × Fin K) (hs : 1 ≤ sigma j) :
    (∫ v, (nativeSampledGradient r predict sigma S lam v j) ^ 2 ∂insertedExperimentLaw r D K) ≤
      64 * (r : ℝ) ^ 2 + 2 * lam ^ 2 := by
  have hz : Integrable (fun v : (Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ))) => (v.1 j.2) ^ 2) (insertedExperimentLaw r D K) :=
    (integrable_laplace_coordinate_square K j.2).comp_fst (markedPoolLaw r (contextLaplaceLaw D K))
  have h := integral_mono (integrable_nativeSampledGradient_square r D predict sigma S lam j hs)
    ((hz.const_mul (2 * (r : ℝ) ^ 2)).add (integrable_const (2 * lam ^ 2)))
    (fun v => nativeSampledGradient_square_bound r predict sigma S lam v j hs)
  change _ ≤ ∫ v, 2 * (r : ℝ) ^ 2 * (v.1 j.2) ^ 2 + 2 * lam ^ 2 ∂insertedExperimentLaw r D K at h
  rw [integral_add (hz.const_mul (2 * (r : ℝ) ^ 2)) (integrable_const _), integral_const_mul,
    integral_const, probReal_univ, one_smul] at h
  have heq : (∫ v, (v.1 j.2) ^ 2 ∂insertedExperimentLaw r D K) = ∫ z, (z j.2) ^ 2 ∂laplaceMeasure K := by
    change (∫ v, (v.1 j.2) ^ 2 ∂(laplaceMeasure K).prod (markedPoolLaw r (contextLaplaceLaw D K))) = _
    rw [integral_prod _ hz]
    simp only [integral_const, probReal_univ, one_smul]
  rw [heq] at h
  have hm := mul_le_mul_of_nonneg_left (integral_laplace_coordinate_square_le K j.2) (by positivity : 0 ≤ 2 * (r : ℝ) ^ 2)
  nlinarith
end
end PoissonAudit
