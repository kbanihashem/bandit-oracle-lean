module
public import PoissonAudit.NativeCappedChoiceLaw
public import PoissonAudit.FiniteKernelRealization
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def nativeRawCappedOutcome (predict : P → X → Fin K) (S : P → ℝ) (B : ℝ) (x : X) (cap m : ℕ)
    (v : NativeFlaggedState X K B × (Fin m → NativeNoise X K)) : CappedRawOutcome K m :=
  (v.1.2, fun i => nativeEnrichedTrial predict v.1.1.2.val S x cap (v.2 i))

theorem measurable_nativeRawCappedOutcome (predict : P → X → Fin K) (S : P → ℝ) (B : ℝ) (x : X) (cap m : ℕ) :
    Measurable (nativeRawCappedOutcome predict S B x cap m) := by
  apply Measurable.prodMk
  · exact measurable_snd.comp measurable_fst
  · apply Measurable.of_eval
    intro i
    exact (measurable_joint_nativeEnrichedTrial predict S x cap).comp
      ((measurable_subtype_coe.comp (measurable_snd.comp (measurable_fst.comp measurable_fst))).prodMk
        ((measurable_pi_apply i).comp measurable_snd))

theorem nativeEnrichedPool_measurePreserving (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (cap m : ℕ) :
    MeasurePreserving (fun u : Fin m → NativeNoise X K => fun i => nativeEnrichedTrial predict sigma S x cap (u i))
      (iidPool (insertedExperimentLaw r D K) m) (iidPool (nativeEnrichedLaw r D predict sigma S x cap).toMeasure m) :=
  measurePreserving_pi (fun _ : Fin m => insertedExperimentLaw r D K) (fun _ => _)
    (fun _ => nativeEnrichedLaw_measurePreserving r D predict sigma S x cap)

theorem integral_nativeRawCappedOutcome_fixed (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (B : ℝ) (x : X) (cap m : ℕ)
    (state : NativeFlaggedState X K B) (f : CappedRawOutcome K m → ℝ) :
    (∫ u, f (nativeRawCappedOutcome predict S B x cap m (state, u)) ∂iidPool (insertedExperimentLaw r D K) m) =
      ∑ o, nativeCappedKernel r D predict S B x cap m state o * f o := by
  have hmp := nativeEnrichedPool_measurePreserving r D predict state.1.2.val S x cap m
  have h := integral_map hmp.measurable.aemeasurable (f := fun u => f (state.2, u))
    (by rw [hmp.map_eq]; exact (measurable_of_finite _).aestronglyMeasurable)
  rw [hmp.map_eq] at h
  change (∫ u, f (state.2, u) ∂iidPool (nativeEnrichedLaw r D predict state.1.2.val S x cap).toMeasure m) = _ at h
  unfold nativeRawCappedOutcome
  rw [← h]
  rw [nativeCappedKernel_test_sum]
  exact integral_iid_actionPMF (nativeEnrichedProbability r D predict state.1.2.val S x cap)
    (nativeEnrichedProbability_nonneg r D predict state.1.2.val S x cap)
    (nativeEnrichedProbability_sum r D predict state.1.2.val S x cap) m (fun u => f (state.2, u))

theorem nativeRawCappedOutcome_measurePreserving (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ) (hB : 1 ≤ B) (cap J m : ℕ) (x : X) :
    MeasurePreserving (nativeRawCappedOutcome predict S B x cap m)
      ((nativeFlaggedStateLaw r D predict S lam B eta hB cap J).prod (iidPool (insertedExperimentLaw r D K) m))
      (nativeCappedRawLaw r D predict S lam B eta hB cap J m x).toMeasure :=
  finiteKernelMixture_realization _ _ _ (measurable_nativeRawCappedOutcome predict S B x cap m) _
    (nativeCappedKernel_nonneg r D predict S B x cap m) (nativeCappedKernel_sum r D predict S B x cap m)
    (measurable_nativeCappedKernel r D predict S B x cap m) (integral_nativeRawCappedOutcome_fixed r D predict S B x cap m)

theorem nativeChoiceCappedOutcome_measurePreserving (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ) (hB : 1 ≤ B) (cap J m : ℕ) (x : X) :
    MeasurePreserving (fun v => cappedOutcomeChoice (nativeRawCappedOutcome predict S B x cap m v))
      ((nativeFlaggedStateLaw r D predict S lam B eta hB cap J).prod (iidPool (insertedExperimentLaw r D K) m))
      (nativeCappedChoiceLaw r D predict S lam B eta hB cap J m x).toMeasure := by
  have hc := outcome_measurePreserving (nativeCappedRawLaw r D predict S lam B eta hB cap J m x).toMeasure
    cappedOutcomeChoice (measurable_of_finite _)
  exact hc.comp (nativeRawCappedOutcome_measurePreserving r D predict S lam B eta hB cap J m x)
end
end PoissonAudit
