module

public import PoissonAudit.ContextPrefixAverage
public import PoissonAudit.PoissonInformationBudget
public import PoissonAudit.GroupedCorrelationAlgebra
public import PoissonAudit.PoissonQuadraticRemainder

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def actionEntropyCharge (r : NNReal) (D : Measure X)
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) : ℝ :=
  ∫ pool, contextPrefixField (locationActionEntropy predict sigma S x a) pool ∂markedPoolLaw r D

theorem integrable_locationActionEntropy_field (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) :
    Integrable (contextPrefixField (locationActionEntropy predict sigma S x a)) (markedPoolLaw r D) := by
  apply integrable_contextPrefixField r D _ (Real.log (Fintype.card P))
  intro n C
  rw [abs_of_nonneg (locationActionEntropy_bounds predict sigma S x a n C).1]
  exact (locationActionEntropy_bounds predict sigma S x a n C).2

theorem actionEntropyCharge_nonneg (r : NNReal) (D : Measure X)
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) :
    0 ≤ actionEntropyCharge r D predict sigma S x a :=
  integral_nonneg fun pool => (locationActionEntropy_bounds predict sigma S x a pool.1 (poolPrefix pool.1 pool.2)).1

theorem integrable_locationActionMoment_field (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K)
    (g : ℝ → ℝ) (hgm : Measurable g) (hgi : Integrable g realLaplace) :
    Integrable (contextPrefixField (locationActionMoment predict sigma S x a g)) (markedPoolLaw r D) :=
  integrable_contextPrefixField r D _ (∫ z, |g z| ∂realLaplace)
    (locationActionMoment_abs_bound predict sigma S x a g hgm hgi)

theorem integral_locationActionMoment_field (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K)
    (g : ℝ → ℝ) (hgm : Measurable g) (hgi : Integrable g realLaplace) :
    (∫ pool, contextPrefixField (locationActionMoment predict sigma S x a g) pool ∂markedPoolLaw r D) =
      experimentMoment r D predict sigma S x a g := by
  rw [integral_contextPrefixField r D _ (∫ z, |g z| ∂realLaplace)
    (locationActionMoment_abs_bound predict sigma S x a g hgm hgi)]
  exact (experimentMoment_eq_contexts r D predict sigma S x a g hgm hgi).symm

theorem sum_actionEntropyCharge (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) :
    (∑ a, actionEntropyCharge r D predict sigma S x a) = insertedConditionalInformation r D predict sigma S x := by
  unfold actionEntropyCharge
  rw [← integral_finsetSum _ (fun a _ => integrable_locationActionEntropy_field r D predict sigma S x a)]
  calc
    _ = ∫ pool, contextPrefixField
        (fun n C => insertedLocationInformationReal predict sigma S n (x, C)) pool ∂markedPoolLaw r D := by
      apply integral_congr_ae
      filter_upwards [] with pool
      exact sum_locationActionEntropy predict sigma S x pool.1 (poolPrefix pool.1 pool.2)
    _ = _ := by
      apply integral_contextPrefixField r D _ (Real.log (Fintype.card P))
      intro n C
      rw [abs_of_nonneg (insertedLocationInformationReal_bounds predict sigma S n (x, C)).1]
      exact (insertedLocationInformationReal_bounds predict sigma S n (x, C)).2

theorem poisson_actionEntropyCharge_budget (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) :
    (r : ℝ) * (∫ x, ∑ a, actionEntropyCharge r D predict sigma S x a ∂D) ≤ Real.log (Fintype.card P) := by
  simp_rw [sum_actionEntropyCharge]
  exact poisson_inserted_information_budget r D predict sigma S

theorem native_grouped_variational (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) :
    (∀ t : ℝ, 0 < t → t ≤ 1 / 2 →
      t * |experimentAlpha r D predict sigma S x a| ≤
        actionEntropyCharge r D predict sigma S x a +
          (4 / 3 : ℝ) * t ^ 2 * experimentProbability r D predict sigma S x a) ∧
    (∀ t : ℝ, 0 < t →
      t * |experimentBeta r D predict sigma S x a| ≤
        actionEntropyCharge r D predict sigma S x a +
          (t ^ 2 / 2) * experimentProbability r D predict sigma S x a) := by
  have hp := integrable_locationActionMoment_field r D predict sigma S x a (fun _ => (1 : ℝ)) measurable_const
    (integrable_const 1)
  have hD := integrable_locationActionEntropy_field r D predict sigma S x a
  constructor
  · intro t ht ht1
    have h := integral_variational_bound (markedPoolLaw r D)
      (contextPrefixField (locationActionMoment predict sigma S x a (fun z => z)))
      (contextPrefixField (locationActionMoment predict sigma S x a (fun _ => 1)))
      (contextPrefixField (locationActionEntropy predict sigma S x a))
      (integrable_locationActionMoment_field r D predict sigma S x a _ measurable_id integrable_realLaplace_id)
      hp hD t ((4 / 3 : ℝ) * t ^ 2) ht.le
      (fun pool => (locationActionMoment_variational predict sigma S x a pool.1 (poolPrefix pool.1 pool.2)).1 t ht ht1)
    rw [integral_locationActionMoment_field r D predict sigma S x a (fun z : ℝ => z) measurable_id integrable_realLaplace_id,
      integral_locationActionMoment_field r D predict sigma S x a _ measurable_const (integrable_const 1),
      experimentMoment_id, experimentMoment_one] at h
    exact h
  · intro t ht
    have h := integral_variational_bound (markedPoolLaw r D)
      (contextPrefixField (locationActionMoment predict sigma S x a laplaceSign))
      (contextPrefixField (locationActionMoment predict sigma S x a (fun _ => 1)))
      (contextPrefixField (locationActionEntropy predict sigma S x a))
      (integrable_locationActionMoment_field r D predict sigma S x a _ measurable_laplaceSign integrable_realLaplace_sign)
      hp hD t (t ^ 2 / 2) ht.le
      (fun pool => (locationActionMoment_variational predict sigma S x a pool.1 (poolPrefix pool.1 pool.2)).2 t ht)
    rw [integral_locationActionMoment_field r D predict sigma S x a _ measurable_laplaceSign integrable_realLaplace_sign,
      integral_locationActionMoment_field r D predict sigma S x a _ measurable_const (integrable_const 1),
      experimentMoment_sign, experimentMoment_one] at h
    exact h

theorem native_alpha_beta_entropy_bound (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K)
    (hsigma : 0 < sigma (x, a)) (hp : 0 < experimentProbability r D predict sigma S x a) :
    experimentAlpha r D predict sigma S x a * experimentBeta r D predict sigma S x a /
      experimentProbability r D predict sigma S x a ≤ 4 * actionEntropyCharge r D predict sigma S x a := by
  have hv := native_grouped_variational r D predict sigma S x a
  apply grouped_two_correlation hp (actionEntropyCharge_nonneg r D predict sigma S x a) _ hv.1 hv.2
  rw [abs_of_nonneg (experimentBeta_nonneg r D predict sigma S x a hsigma)]
  exact experimentBeta_le_probability r D predict sigma S x a

end

end PoissonAudit
