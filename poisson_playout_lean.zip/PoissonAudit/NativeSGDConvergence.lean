module
public import PoissonAudit.NativeSGDDrift
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem native_SGD_expected_lyapunov (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ)
    (hlam : 0 ≤ lam) (hB : 1 ≤ B) (heta : 0 ≤ eta) (s : NativeScaleBox X K B) (J : ℕ) :
    (∫ state, nativeSGDLyapunov r D predict S lam B eta s J state
      ∂nativeSGDStateLaw r D predict S lam B eta hB J) ≤
        B ^ 2 * K + J * eta ^ 2 * (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2)) := by
  induction J with
  | zero =>
    change (∫ state, nativeSGDLyapunov r D predict S lam B eta s 0 state
      ∂Measure.dirac (nativeUnitScale B hB, nativeUnitScale B hB)) ≤ _
    rw [integral_dirac]
    simp only [nativeSGDLyapunov, Nat.cast_zero, mul_zero, zero_mul, zero_add]
    have hb := weightedSquareDistance_box_bound (fun q : X × Fin K => (D {q.1}).toReal)
      (nativeUnitScale (X := X) (K := K) B hB).val s.val (fun _ => ENNReal.toReal_nonneg) B
      (nativeUnitScale B hB).property s.property
    rw [context_action_mass_sum D] at hb
    simpa only [add_zero] using hb
  | succ j ih =>
    let mu := nativeSGDStateLaw r D predict S lam B eta hB j
    let noise := insertedExperimentLaw r D K
    let next := fun v : NativeSGDState X K B × NativeNoise X K => nativeSGDTransition r predict S lam B eta hB j v.1 v.2
    let Lnext := nativeSGDLyapunov r D predict S lam B eta s (j + 1)
    let Lold := nativeSGDLyapunov r D predict S lam B eta s j
    have hm : Measurable next := measurable_nativeSGDTransition r predict S lam B eta hB j
    have hc : Continuous Lnext := continuous_nativeSGDLyapunov r D predict S lam B eta hB s (j + 1)
    have ho : Integrable Lold mu := integrable_continuous_nativeSGDState B mu _
      (continuous_nativeSGDLyapunov r D predict S lam B eta hB s j)
    have hmap : Integrable Lnext ((mu.prod noise).map next) := integrable_continuous_nativeSGDState B _ _ hc
    have hi : Integrable (fun v => Lnext (next v)) (mu.prod noise) := hmap.comp_measurable hm
    change (∫ state, Lnext state ∂(mu.prod noise).map next) ≤ _
    rw [integral_map hm.aemeasurable hc.measurable.aestronglyMeasurable, integral_prod _ hi]
    have h := integral_mono hi.integral_prod_left
      (ho.add (integrable_const (eta ^ 2 * (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2)))))
      (fun state => native_SGD_lyapunov_drift r D predict S lam B eta hlam hB heta s j state)
    change (∫ state, ∫ v, Lnext (next (state, v)) ∂noise ∂mu) ≤
      ∫ state, Lold state + eta ^ 2 * (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2)) ∂mu at h
    rw [integral_add ho (integrable_const _), integral_const, probReal_univ, one_smul] at h
    change (∫ state, Lold state ∂mu) ≤ _ at ih
    simp only [Nat.cast_add, Nat.cast_one]
    nlinarith

theorem native_SGD_expected_objective_error (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ)
    (hlam : 0 ≤ lam) (hB : 1 ≤ B) (heta : 0 < eta) (s : NativeScaleBox X K B) (J : ℕ) (hJ : 0 < J) :
    (∫ state, nativeBoxObjective r D predict S lam B state.2 - nativeBoxObjective r D predict S lam B s
      ∂nativeSGDStateLaw r D predict S lam B eta hB J) ≤
        B ^ 2 * K / (2 * eta * J) + eta * (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2)) / 2 := by
  let mu := nativeSGDStateLaw r D predict S lam B eta hB J
  let gap := fun state : NativeSGDState X K B => nativeBoxObjective r D predict S lam B state.2 - nativeBoxObjective r D predict S lam B s
  let L := nativeSGDLyapunov r D predict S lam B eta s J
  have hg : Continuous gap := ((continuous_nativeBoxObjective r D predict S lam B hB).comp continuous_snd).sub continuous_const
  have hi : Integrable gap mu := integrable_continuous_nativeSGDState B mu _ hg
  have hLi : Integrable L mu := integrable_continuous_nativeSGDState B mu _ (continuous_nativeSGDLyapunov r D predict S lam B eta hB s J)
  have hp (state : NativeSGDState X K B) : 2 * eta * J * gap state ≤ L state := by
    have hn := weightedSquareDistance_nonneg (fun q : X × Fin K => (D {q.1}).toReal) state.1.val s.val
      (fun _ => ENNReal.toReal_nonneg)
    change _ ≤ 2 * eta * J * gap state + _
    linarith
  have h := integral_mono (hi.const_mul (2 * eta * J)) hLi hp
  change (∫ state, 2 * eta * J * gap state ∂mu) ≤ _ at h
  rw [integral_const_mul] at h
  have hL := native_SGD_expected_lyapunov r D predict S lam B eta hlam hB heta.le s J
  change (∫ state, L state ∂mu) ≤ _ at hL
  have hpos : 0 < 2 * eta * (J : ℝ) := by positivity
  have hh := h.trans hL
  have hdiv : (∫ state, gap state ∂mu) ≤ (B ^ 2 * K + (J : ℝ) * eta ^ 2 * (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2))) / (2 * eta * J) :=
    (le_div_iff₀ hpos).mpr (by nlinarith only [hh])
  have heq : (B ^ 2 * K + (J : ℝ) * eta ^ 2 * (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2))) /
      (2 * eta * J) = B ^ 2 * K / (2 * eta * J) + eta * (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2)) / 2 := by
    field_simp <;> ring
  rw [heq] at hdiv
  exact hdiv
end
end PoissonAudit
