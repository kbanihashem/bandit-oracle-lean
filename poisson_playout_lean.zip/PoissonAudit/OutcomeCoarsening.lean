module

public import PoissonAudit.WinnerMomentIdentity

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

theorem integral_outcomeIndicator {Omega P : Type*} [MeasurableSpace Omega]
    [MeasurableSpace P] [MeasurableSingletonClass P]
    (mu : Measure Omega) (W : Omega → P) (hW : Measurable W) (p : P) :
    (∫ omega, (outcomeEvent W p).indicator (fun _ => (1 : ℝ)) omega ∂mu) = outcomeMass mu W p := by
  have hE : MeasurableSet (outcomeEvent W p) := hW (measurableSet_singleton p)
  calc
    _ = mu.real (outcomeEvent W p) • (1 : ℝ) := integral_indicator_const _ hE
    _ = _ := by change mu.real (outcomeEvent W p) * 1 = mu.real (outcomeEvent W p); ring

theorem eventChannel_outcome_eq_mass {U V P : Type*} [MeasurableSpace U] [MeasurableSpace V]
    [MeasurableSpace P] [MeasurableSingletonClass P]
    (nu : Measure V) [IsProbabilityMeasure nu] (W : U × V → P) (hW : Measurable W) (p : P) (z : U) :
    eventChannel nu (outcomeEvent W p) z = outcomeMass nu (fun v => W (z, v)) p := by
  have hE : MeasurableSet (outcomeEvent W p) := hW (measurableSet_singleton p)
  rw [eventChannel_eq_integral_indicator nu _ hE]
  exact integral_outcomeIndicator nu (fun v => W (z, v))
    (hW.comp (measurable_const.prodMk measurable_id)) p

theorem outcomeMass_comp_finite {Omega P : Type*} [MeasurableSpace Omega]
    [MeasurableSpace P] [MeasurableSingletonClass P] [Fintype P] {K : ℕ}
    (mu : Measure Omega) [IsProbabilityMeasure mu] (W : Omega → P) (hW : Measurable W)
    (pick : P → Fin K) (a : Fin K) :
    outcomeMass mu (fun omega => pick (W omega)) a =
      ∑ p, if pick p = a then outcomeMass mu W p else 0 := by
  classical
  have hcomp : Measurable (fun omega => pick (W omega)) := (measurable_of_finite pick).comp hW
  rw [← integral_outcomeIndicator mu _ hcomp a]
  let F := fun p omega => if pick p = a then (outcomeEvent W p).indicator (fun _ => (1 : ℝ)) omega else 0
  have hi (p : P) : Integrable (F p) mu := by
    have hE : MeasurableSet (outcomeEvent W p) := hW (measurableSet_singleton p)
    by_cases hp : pick p = a
    · simpa only [F, hp, ite_true] using (integrable_const (1 : ℝ) (μ := mu)).indicator hE
    · simp only [F, hp, ite_false]
      exact integrable_const 0
  calc
    _ = ∫ omega, ∑ p, F p omega ∂mu := by
      apply integral_congr_ae
      filter_upwards [] with omega
      have h := sum_winner_observable W pick a omega (1 : ℝ)
      simpa only [F, mul_one, Set.indicator_apply, outcomeEvent, Set.mem_ofPred_eq] using h.symm
    _ = ∑ p, ∫ omega, F p omega ∂mu := integral_finsetSum _ (fun p _ => hi p)
    _ = _ := by
      apply Finset.sum_congr rfl
      intro p _
      by_cases hp : pick p = a
      · simp only [F, hp, ite_true]
        exact integral_outcomeIndicator mu W hW p
      · simp [F, hp]

end

end PoissonAudit
