module
public import PoissonAudit.CostedArrayConstruction
public section
open scoped BigOperators
namespace PoissonAudit
noncomputable section

@[expose] def replayInternalBudget (K n : ℕ) : ℕ := 2 * K + n * (60 * (K + 1) ^ 2 + n * (K + 2))
@[expose] def constructionStepBudget (K cap N : ℕ) : ℕ :=
  cap * (replayInternalBudget K N + 4 * K + 1) + cap * N ^ 2 * (K + 1) + cap * (N * (K + 1)) + 1

theorem replayInternalBudget_mono (K : ℕ) {j N : ℕ} (hj : j ≤ N) : replayInternalBudget K j ≤ replayInternalBudget K N := by
  unfold replayInternalBudget
  gcongr

theorem executeArrayConstruction_work {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (cap N J : ℕ) (tape : NativeNoiseTape X K J) (hc : nativeTapeCountsBounded cap J tape) (hJN : J ≤ N) :
    (executeArrayConstruction r lam B eta history oracle fallback J tape).internalWork ≤ J * constructionStepBudget K cap N := by
  induction J with
  | zero => simp [executeArrayConstruction]
  | succ j ih =>
    let prior : NativeNoiseTape X K j := tape.1
    let noise : NativeNoise X K := tape.2
    let old := executeArrayConstruction r lam B eta history oracle fallback j prior
    let runs := Vector.ofFn (fun i : Fin noise.2.1 =>
      executeArrayReplay r lam B eta history oracle fallback old.records (noise.2.2 i).1)
    let requests := (runs.toList.map ArrayReplayRun.queries).flatten
    have hjN : j ≤ N := by omega
    have hprev : old.internalWork ≤ j * constructionStepBudget K cap N := ih prior hc.1 hjN
    have hold := executeArrayConstruction_correct r lam B eta history oracle fallback j prior
    have hlen : old.records.length = j := by
      change (executeArrayConstruction r lam B eta history oracle fallback j prior).records.length = _
      rw [hold.1, buildReplayRecords_length]
    have hreval (i : Fin noise.2.1) : runs.get i = executeArrayReplay r lam B eta history oracle fallback old.records (noise.2.2 i).1 := vectorGet_ofFn _ i
    have hrun (i : Fin noise.2.1) : (runs.get i).internalWork ≤ replayInternalBudget K N := by
      have h := executeArrayReplay_work r lam B eta history oracle fallback old.records (noise.2.2 i).1
      change _ ≤ replayInternalBudget K old.records.length at h
      rw [hlen] at h
      rw [hreval]
      exact h.trans (replayInternalBudget_mono K hjN)
    have hrunQ (i : Fin noise.2.1) : (runs.get i).queries.length = j * (K + 1) := by
      rw [hreval]
      rw [(executeArrayReplay_correct r lam B eta history oracle fallback old.records (noise.2.2 i).1).2,
        replayQueries_count, hlen]
    have hs : (∑ i : Fin noise.2.1, ((runs.get i).internalWork + 4 * K + 1)) ≤
        cap * (replayInternalBudget K N + 4 * K + 1) := by
      have h := Finset.sum_le_sum (s := Finset.univ) (fun i _ => Nat.add_le_add_right (Nat.add_le_add_right (hrun i) (4 * K)) 1)
      simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, Nat.cast_id] at h
      exact h.trans (Nat.mul_le_mul_right _ hc.2)
    have hreq : requests.length = noise.2.1 * (j * (K + 1)) := by
      dsimp only [requests, runs]
      simp only [List.length_flatten, List.map_map, Vector.toList_ofFn, List.map_ofFn, List.sum_ofFn,
        Function.comp_apply, vectorGet_ofFn]
      have he (i : Fin noise.2.1) :
          (executeArrayReplay r lam B eta history oracle fallback old.records (noise.2.2 i).1).queries.length = j * (K + 1) := by rw [← hreval]; exact hrunQ i
      simp only [he, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, Nat.cast_id]
    have hreqB : requests.length ≤ cap * (N * (K + 1)) := by rw [hreq]; exact Nat.mul_le_mul hc.2 (Nat.mul_le_mul_right _ hjN)
    have hq : old.queries.length ≤ cap * N ^ 2 * (K + 1) := by
      have h := buildReplayQueries_count r lam B eta history oracle fallback cap j prior hc.1
      change (executeArrayConstruction r lam B eta history oracle fallback j prior).queries.length ≤ _
      rw [hold.2]
      exact h.trans (by gcongr)
    change old.internalWork + (∑ i : Fin noise.2.1, ((runs.get i).internalWork + 4 * K + 1)) +
      old.queries.length + requests.length + 1 ≤ _
    calc
      _ ≤ j * constructionStepBudget K cap N + cap * (replayInternalBudget K N + 4 * K + 1) +
          cap * N ^ 2 * (K + 1) + cap * (N * (K + 1)) + 1 := by omega
      _ = (j + 1) * constructionStepBudget K cap N := by unfold constructionStepBudget; ring
end
end PoissonAudit
