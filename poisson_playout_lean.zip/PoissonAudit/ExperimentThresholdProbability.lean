module

public import PoissonAudit.ExperimentThresholdIdentity

public section

open MeasureTheory Set Filter
open scoped BigOperators

namespace PoissonAudit

noncomputable section

theorem ae_random_threshold_ne {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) [IsProbabilityMeasure mu] (theta : Omega → ℝ) (htheta : Measurable theta)
    (sigma s : ℝ) :
    ∀ᵐ v : Omega × ℝ ∂mu.prod realLaplace, v.2 ≠ theta v.1 + s / sigma := by
  apply (Measure.ae_prod_iff_ae_ae
    (measurableSet_eq_fun measurable_snd ((htheta.comp measurable_fst).add_const (s / sigma))).compl).mpr
  exact Filter.Eventually.of_forall fun omega => realLaplace.ae_ne (theta omega + s / sigma)

theorem integral_random_thresholdSlope {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) [IsProbabilityMeasure mu] (theta : Omega → ℝ) (htheta : Measurable theta)
    (sigma s : ℝ) (hsigma : 0 < sigma) :
    (∫ v : Omega × ℝ, thresholdSlope (theta v.1) sigma v.2 s ∂mu.prod realLaplace) =
      -thresholdProbability mu theta sigma s := by
  rw [integral_prod _ (integrable_random_thresholdSlope mu theta htheta sigma s)]
  simp_rw [thresholdSlope, threshold_positive_iff _ _ _ _ hsigma, integral_negative_laplace_tail]
  exact integral_neg _

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X]
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]
    {n : ℕ}

theorem ae_restored_experimentIndicator (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin (n + 1)) (sigma : X × Fin (n + 1) → ℝ) (S : P → ℝ)
    (x : X) (a : Fin (n + 1)) (hsigma : 0 < sigma (x, a))
    (hE : (actionPolicyGroup predict x a).Nonempty) (hEc : (actionPolicyGroup predict x a)ᶜ.Nonempty)
    (s : ℝ) :
    ∀ᵐ v ∂(experimentRemainderLaw r D n).prod realLaplace,
      (experimentActionEvent predict sigma (actionPenaltyScore predict S x a s) x a).indicator
        (fun _ => (1 : ℝ)) (restoreExperimentEquiv a v) =
      -thresholdSlope (experimentThreshold predict sigma S x a hE hEc v.1) (sigma (x, a)) v.2 s := by
  classical
  have htheta := measurable_experimentThreshold predict sigma S x a hE hEc
  filter_upwards [ae_random_threshold_ne (experimentRemainderLaw r D n)
    (experimentThreshold predict sigma S x a hE hEc) htheta (sigma (x, a)) s] with v hv
  have hiff := restored_experimentAction_iff predict sigma S x a s hsigma hE hEc v hv
  have hmem : restoreExperimentEquiv a v ∈
      experimentActionEvent predict sigma (actionPenaltyScore predict S x a s) x a ↔
      experimentThreshold predict sigma S x a hE hEc v.1 + s / sigma (x, a) < v.2 := hiff
  unfold thresholdSlope
  simp only [threshold_positive_iff _ _ _ _ hsigma]
  by_cases h : experimentThreshold predict sigma S x a hE hEc v.1 + s / sigma (x, a) < v.2
  · simp [hmem.mpr h, h]
  · have hn := mt hmem.mp h
    simp [hn, h]

theorem experimentProbability_eq_thresholdProbability (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin (n + 1)) (sigma : X × Fin (n + 1) → ℝ) (S : P → ℝ)
    (x : X) (a : Fin (n + 1)) (hsigma : 0 < sigma (x, a))
    (hE : (actionPolicyGroup predict x a).Nonempty) (hEc : (actionPolicyGroup predict x a)ᶜ.Nonempty)
    (s : ℝ) :
    experimentProbability r D predict sigma (actionPenaltyScore predict S x a s) x a =
      thresholdProbability (experimentRemainderLaw r D n)
        (experimentThreshold predict sigma S x a hE hEc) (sigma (x, a)) s := by
  let E := experimentActionEvent predict sigma (actionPenaltyScore predict S x a s) x a
  have hEmeas : MeasurableSet E := measurable_experimentActionEvent predict sigma _ x a
  have hprob : experimentProbability r D predict sigma (actionPenaltyScore predict S x a s) x a =
      ∫ v, E.indicator (fun _ => (1 : ℝ)) v ∂insertedExperimentLaw r D (n + 1) := by
    symm
    have h := integral_indicator_const (1 : ℝ) (μ := insertedExperimentLaw r D (n + 1)) hEmeas
    convert! h using 1
    change (insertedExperimentLaw r D (n + 1)).real E = (insertedExperimentLaw r D (n + 1)).real E * 1
    ring
  rw [hprob, ← (restoreExperimentEquiv_measurePreserving r D a).integral_comp'
    (fun v => E.indicator (fun _ => (1 : ℝ)) v)]
  have hi := integral_congr_ae (ae_restored_experimentIndicator r D predict sigma S x a hsigma hE hEc s)
  change (∫ v, E.indicator (fun _ => (1 : ℝ)) (restoreExperimentEquiv a v)
    ∂(experimentRemainderLaw r D n).prod realLaplace) = _
  rw [hi, integral_neg, integral_random_thresholdSlope _ _
    (measurable_experimentThreshold predict sigma S x a hE hEc) _ _ hsigma, neg_neg]

end

end PoissonAudit
