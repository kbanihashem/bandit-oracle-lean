module
public import PoissonAudit.ArrayScalarExecution
public import PoissonAudit.OperationalValueOracle
public section
namespace PoissonAudit
noncomputable section

structure ArrayReplayRun (X : Type*) (K : ℕ) where
  state : ArrayReplayState K
  queries : List (List (CostExample X K))
  internalWork : ℕ
  allocatedWords : ℕ

@[expose] def executeArrayLocalStep {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (j : ℕ) (record : ReplayRecord X K) (x : X) (state : ArrayReplayState K) : ArrayReplayRun X K :=
  let designated := Vector.ofFn (fun a => vectorValues state.1 a * record.1 a)
  let call := executeValueCall oracle fallback (history ++ record.2) x designated
  let next := executeArrayCoordinates r lam B eta state record.1 call.action j
  ⟨next.1, call.queries, call.scalarWork + next.2 + 4 * K, call.allocatedWords + 3 * K⟩

theorem executeArrayLocalStep_values {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (j : ℕ) (record : ReplayRecord X K) (x : X) (state : ArrayReplayState K) :
    arrayStateValues (executeArrayLocalStep r lam B eta history oracle fallback j record x state).state =
      replayLocalStep r lam B eta history oracle fallback j record x (arrayStateValues state) := by
  unfold executeArrayLocalStep
  rw [executeArrayCoordinates_values, executeValueCall_action, arrayValueOracleAction_eq]
  simp only [vectorValues_ofFn]
  rfl

theorem executeArrayLocalStep_queries {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (j : ℕ) (record : ReplayRecord X K) (x : X) (state : ArrayReplayState K) :
    (executeArrayLocalStep r lam B eta history oracle fallback j record x state).queries =
      actionValueQueries (history ++ record.2) x (fun a => vectorValues state.1 a * record.1 a) := by
  dsimp only [executeArrayLocalStep]
  rw [executeValueCall_queries, vectorValues_ofFn]

theorem executeArrayLocalStep_work {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (j : ℕ) (record : ReplayRecord X K) (x : X) (state : ArrayReplayState K) :
    (executeArrayLocalStep r lam B eta history oracle fallback j record x state).internalWork ≤ 60 * (K + 1) ^ 2 := by
  have h := executeValueCall_scalar_work oracle fallback (history ++ record.2) x
    (Vector.ofFn (fun a => vectorValues state.1 a * record.1 a))
  dsimp only [executeArrayLocalStep]
  rw [executeArrayCoordinates_steps]
  nlinarith

@[expose] def executeArrayReplay {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K) :
    List (ReplayRecord X K) → X → ArrayReplayRun X K
  | [], _ => ⟨(Vector.ofFn (fun _ => 1), Vector.ofFn (fun _ => 1)), [], 2 * K, 2 * K⟩
  | record :: records, x =>
    let old := executeArrayReplay r lam B eta history oracle fallback records x
    let next := executeArrayLocalStep r lam B eta history oracle fallback records.length record x old.state
    ⟨next.state, old.queries ++ next.queries,
      old.internalWork + next.internalWork + records.length + old.queries.length,
      old.allocatedWords + next.allocatedWords + records.length + old.queries.length⟩

theorem executeArrayReplay_correct {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (records : List (ReplayRecord X K)) (x : X) :
    arrayStateValues (executeArrayReplay r lam B eta history oracle fallback records x).state =
      replayAt r lam B eta history oracle fallback records x ∧
    (executeArrayReplay r lam B eta history oracle fallback records x).queries =
      replayQueries r lam B eta history oracle fallback records x := by
  induction records with
  | nil => simp only [executeArrayReplay, arrayStateValues, vectorValues_ofFn, replayAt, replayQueries, and_self]
  | cons record records ih =>
    constructor
    · change arrayStateValues (executeArrayLocalStep r lam B eta history oracle fallback records.length record x _).state = _
      rw [executeArrayLocalStep_values, ih.1]
      rfl
    · change (executeArrayReplay r lam B eta history oracle fallback records x).queries ++
        (executeArrayLocalStep r lam B eta history oracle fallback records.length record x _).queries = _
      rw [executeArrayLocalStep_queries, ih.2]
      have hs := congrArg Prod.fst ih.1
      change vectorValues (executeArrayReplay r lam B eta history oracle fallback records x).state.1 = _ at hs
      rw [hs]
      rfl

theorem executeArrayReplay_work {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (records : List (ReplayRecord X K)) (x : X) :
    (executeArrayReplay r lam B eta history oracle fallback records x).internalWork ≤
      2 * K + records.length * (60 * (K + 1) ^ 2 + records.length * (K + 2)) := by
  induction records with
  | nil => simp [executeArrayReplay]
  | cons record records ih =>
    have hlocal := executeArrayLocalStep_work r lam B eta history oracle fallback records.length record x
      (executeArrayReplay r lam B eta history oracle fallback records x).state
    have hq := (executeArrayReplay_correct r lam B eta history oracle fallback records x).2
    have hcount : (executeArrayReplay r lam B eta history oracle fallback records x).queries.length = records.length * (K + 1) := by
      rw [hq, replayQueries_count]
    change _ ≤ _ at ih
    dsimp only [executeArrayReplay]
    rw [hcount, List.length_cons]
    have hmono : records.length * (60 * (K + 1) ^ 2 + records.length * (K + 2)) ≤
        records.length * (60 * (K + 1) ^ 2 + (records.length + 1) * (K + 2)) := by gcongr <;> omega
    have hadd : 60 * (K + 1) ^ 2 + records.length + records.length * (K + 1) ≤
        60 * (K + 1) ^ 2 + (records.length + 1) * (K + 2) := by nlinarith
    nlinarith only [ih, hlocal, hmono, hadd]
end
end PoissonAudit
