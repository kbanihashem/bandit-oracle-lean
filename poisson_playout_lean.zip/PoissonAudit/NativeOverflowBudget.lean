module
public import PoissonAudit.NativeOverflowProcess
public section
open MeasureTheory Set
namespace PoissonAudit
noncomputable section

@[expose] def boolStatistic (b : Bool) : ℝ := if b then 1 else 0

theorem boolStatistic_mem (b : Bool) : boolStatistic b ∈ Set.Icc (0 : ℝ) 1 := by cases b <;> norm_num [boolStatistic]

theorem probability_integral_fst {Omega Lambda : Type*} [MeasurableSpace Omega] [MeasurableSpace Lambda]
    (mu : Measure Omega) (nu : Measure Lambda) [SFinite mu] [IsProbabilityMeasure nu]
    (f : Omega → ℝ) (hf : Integrable f mu) : (∫ v, f v.1 ∂mu.prod nu) = ∫ z, f z ∂mu := by
  rw [integral_prod _ (hf.comp_fst nu)]
  simp only [integral_const, probReal_univ, one_smul]

theorem probability_integral_snd {Omega Lambda : Type*} [MeasurableSpace Omega] [MeasurableSpace Lambda]
    (mu : Measure Omega) (nu : Measure Lambda) [IsProbabilityMeasure mu] [SFinite nu]
    (f : Lambda → ℝ) (hf : Integrable f nu) : (∫ v, f v.2 ∂mu.prod nu) = ∫ z, f z ∂nu := by
  rw [integral_prod _ (hf.comp_snd mu)]
  simp only [integral_const, probReal_univ, one_smul]

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem integrable_nativeOverflowStatistic (r : NNReal) (D : Measure X) [IsProbabilityMeasure D] (cap : ℕ) :
    Integrable (fun v : NativeNoise X K => boolStatistic (nativeOverflowBool cap v)) (insertedExperimentLaw r D K) := by
  apply Integrable.of_bound ((measurable_of_finite boolStatistic).comp (measurable_nativeOverflowBool cap)).aestronglyMeasurable 1
  filter_upwards [] with v
  change ‖boolStatistic (nativeOverflowBool cap v)‖ ≤ 1
  rw [Real.norm_eq_abs, abs_of_nonneg (boolStatistic_mem _).1]
  exact (boolStatistic_mem _).2

theorem integral_nativeOverflowStatistic (r : NNReal) (D : Measure X) [IsProbabilityMeasure D] (cap : ℕ) :
    (∫ v : NativeNoise X K, boolStatistic (nativeOverflowBool cap v) ∂insertedExperimentLaw r D K) =
      (insertedExperimentLaw r D K).real (nativeOverflowEvent cap) := by
  have hE : MeasurableSet (nativeOverflowEvent (X := X) (K := K) cap) :=
    measurableSet_lt measurable_const (measurable_fst.comp measurable_snd)
  have heq : (fun v : NativeNoise X K => boolStatistic (nativeOverflowBool cap v)) =
      (nativeOverflowEvent cap).indicator (fun _ => (1 : ℝ)) := by
    funext v
    by_cases h : cap < v.2.1 <;> simp [boolStatistic, nativeOverflowBool, nativeOverflowEvent, h]
  rw [heq, integral_indicator_const 1 hE, smul_eq_mul, mul_one]

theorem integrable_flagStatistic (B : ℝ) (mu : Measure (NativeFlaggedState X K B)) [IsFiniteMeasure mu] :
    Integrable (fun state : NativeFlaggedState X K B => boolStatistic state.2) mu := by
  apply Integrable.of_bound ((measurable_of_finite boolStatistic).comp measurable_snd).aestronglyMeasurable 1
  filter_upwards [] with state
  change ‖boolStatistic state.2‖ ≤ 1
  rw [Real.norm_eq_abs, abs_of_nonneg (boolStatistic_mem _).1]
  exact (boolStatistic_mem _).2

theorem native_construction_overflow_budget (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ) (hB : 1 ≤ B) (cap : ℕ) (hc : 0 < cap) (J : ℕ) :
    (∫ state : NativeFlaggedState X K B, boolStatistic state.2
      ∂nativeFlaggedStateLaw r D predict S lam B eta hB cap J) ≤ J * ((r : ℝ) / cap) := by
  induction J with
  | zero => simp [nativeFlaggedStateLaw, boolStatistic]
  | succ j ih =>
    let mu := nativeFlaggedStateLaw r D predict S lam B eta hB cap j
    let noise := insertedExperimentLaw r D K
    let F := fun v : NativeFlaggedState X K B × NativeNoise X K => nativeFlaggedTransition r predict S lam B eta hB cap j v.1 v.2
    have hF : Measurable F := measurable_nativeFlaggedTransition r predict S lam B eta hB cap j
    have hiOld : Integrable (fun state : NativeFlaggedState X K B => boolStatistic state.2) mu := integrable_flagStatistic B mu
    have hiTail : Integrable (fun v : NativeNoise X K => boolStatistic (nativeOverflowBool cap v)) noise := integrable_nativeOverflowStatistic r D cap
    have hiNew : Integrable (fun v => boolStatistic (F v).2) (mu.prod noise) := by
      apply Integrable.of_bound ((measurable_of_finite boolStatistic).comp (measurable_snd.comp hF)).aestronglyMeasurable 1
      filter_upwards [] with v
      change ‖boolStatistic (F v).2‖ ≤ 1
      rw [Real.norm_eq_abs, abs_of_nonneg (boolStatistic_mem _).1]
      exact (boolStatistic_mem _).2
    have hp (v : NativeFlaggedState X K B × NativeNoise X K) : boolStatistic (F v).2 ≤
        boolStatistic v.1.2 + boolStatistic (nativeOverflowBool cap v.2) := by
      change boolStatistic (v.1.2 || nativeOverflowBool cap v.2) ≤ _
      cases h1 : v.1.2 <;> cases h2 : nativeOverflowBool cap v.2 <;> norm_num [boolStatistic]
    have h := integral_mono hiNew ((hiOld.comp_fst noise).add (hiTail.comp_snd mu)) hp
    change (∫ v, boolStatistic (F v).2 ∂mu.prod noise) ≤
      ∫ v, boolStatistic v.1.2 + boolStatistic (nativeOverflowBool cap v.2) ∂mu.prod noise at h
    rw [integral_add (hiOld.comp_fst noise) (hiTail.comp_snd mu),
      probability_integral_fst mu noise _ hiOld, probability_integral_snd mu noise _ hiTail,
      integral_nativeOverflowStatistic r D cap] at h
    have ht := native_noise_overflow_bound (K := K) r D cap hc
    change (∫ state, boolStatistic state.2 ∂mu) ≤ _ at ih
    change (∫ state, boolStatistic state.2 ∂(mu.prod noise).map F) ≤ _
    rw [integral_map (f := fun state : NativeFlaggedState X K B => boolStatistic state.2) hF.aemeasurable ((measurable_of_finite boolStatistic).comp measurable_snd).aestronglyMeasurable]
    simp only [Nat.cast_add, Nat.cast_one]
    nlinarith
end
end PoissonAudit
