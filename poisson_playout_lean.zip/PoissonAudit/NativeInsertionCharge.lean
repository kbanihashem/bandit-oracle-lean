module

public import PoissonAudit.UninsertedAveraging
public import PoissonAudit.NativeExpectedRemainder

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem native_action_probability_difference (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (s : ℝ) (hsigma : 0 < sigma (x, a)) (hs : 0 ≤ s) (hss : s ≤ sigma (x, a)) :
    experimentProbability r D predict sigma (actionPenaltyScore predict S x a s) x a -
      uninsertedActionProbability r D predict sigma (actionPenaltyScore predict S x a s) x a ≤
      2 * Real.exp 1 * actionEntropyCharge r D predict sigma S x a := by
  let Ss := actionPenaltyScore predict S x a s
  let fi := contextPrefixField (locationActionMoment predict sigma Ss x a (fun _ => (1 : ℝ)))
  let fu := contextPrefixField (locationUninsertedProbability predict sigma Ss x a)
  let fD := contextPrefixField (locationActionEntropy predict sigma S x a)
  have hi : Integrable fi (markedPoolLaw r D) :=
    integrable_locationActionMoment_field r D predict sigma Ss x a _ measurable_const (integrable_const 1)
  have hu : Integrable fu (markedPoolLaw r D) := integrable_locationUninserted_field r D predict sigma Ss x a
  have hD : Integrable fD (markedPoolLaw r D) := integrable_locationActionEntropy_field r D predict sigma S x a
  have h := integral_mono (hi.sub hu) (hD.const_mul (2 * Real.exp 1))
    (fun pool => location_action_difference_bound predict sigma S x a s hsigma hs hss (poolPrefix pool.1 pool.2))
  change (∫ pool, fi pool - fu pool ∂markedPoolLaw r D) ≤
    ∫ pool, 2 * Real.exp 1 * fD pool ∂markedPoolLaw r D at h
  rw [integral_sub hi hu, integral_const_mul] at h
  change (∫ pool, contextPrefixField (locationActionMoment predict sigma Ss x a (fun _ => 1)) pool ∂markedPoolLaw r D) -
    (∫ pool, contextPrefixField (locationUninsertedProbability predict sigma Ss x a) pool ∂markedPoolLaw r D) ≤
    2 * Real.exp 1 * actionEntropyCharge r D predict sigma S x a at h
  rw [integral_locationActionMoment_field r D predict sigma Ss x a (fun _ => 1) measurable_const (integrable_const 1),
    integral_locationUninserted_field r D predict sigma Ss x a, experimentMoment_one] at h
  exact h

theorem native_insertionGap_action_bound (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (b : ℝ) (hsigma : 0 < sigma (x, a)) (hb : 0 ≤ b) (hbs : b ≤ sigma (x, a)) :
    insertionGap r D predict sigma S x - insertionGap r D predict sigma (actionPenaltyScore predict S x a b) x ≤
      2 * Real.exp 1 * b * actionEntropyCharge r D predict sigma S x a := by
  rw [insertionGap_action_change]
  have hi := (intervalIntegrable_inserted_action_probability r D predict sigma S x a b).sub
    (intervalIntegrable_uninserted_action_probability r D predict sigma S x a b)
  calc
    _ ≤ ∫ _s in (0 : ℝ)..b, 2 * Real.exp 1 * actionEntropyCharge r D predict sigma S x a :=
      intervalIntegral.integral_mono_on hb hi intervalIntegrable_const
        (fun s hs => native_action_probability_difference r D predict sigma S x a s hsigma hs.1 (hs.2.trans hbs))
    _ = _ := by
      rw [intervalIntegral.integral_const]
      simp only [sub_zero, smul_eq_mul]
      ring

@[expose] def nativeBanditInsertion (r : NNReal) (D : Measure X)
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (gamma : ℝ) (x : X) (a : Fin K) (c : ℝ) : ℝ :=
  insertionGap r D predict sigma S x - insertionGap r D predict sigma
    (actionPenaltyScore predict S x a (nativeBanditUpdate r D predict sigma S gamma x a c)) x

theorem native_weighted_insertion_bound
    (r : NNReal) (hr : 0 < (r : ℝ)) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (lam B gamma : ℝ) (hK : 0 < K) (hg : 0 < gamma) (hgsmall : gamma ≤ 1 / 2)
    (hB : 1 ≤ B) (hcap : (K : ℝ) / gamma ≤ B)
    (hlam : 4 * (r : ℝ) * explorationLog K gamma ≤ lam)
    (hsigma : sigma ∈ scaleBox (X × Fin K) B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun j => (D {j.1}).toReal) lam B) (scaleBox (X × Fin K) B) sigma)
    (x : X) (a : Fin K) (hx : 0 < (D {x}).toReal) (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c ≤ 1) :
    nativeBanditProbability r D predict sigma S gamma x a * nativeBanditInsertion r D predict sigma S gamma x a c ≤
      2 * Real.exp 1 * actionEntropyCharge r D predict sigma S x a := by
  let q := nativeBanditProbability r D predict sigma S gamma x a
  have hq : 0 < q := exploration_positive hK hg (experimentProbability_nonneg r D predict sigma S x a) (by linarith)
  have hs : 0 < sigma (x, a) := by have h : (1 : ℝ) ≤ sigma (x, a) := hsigma.1 (x, a); linarith
  have hb0 : 0 ≤ nativeBanditUpdate r D predict sigma S gamma x a c := div_nonneg hc0 hq.le
  have hbs : nativeBanditUpdate r D predict sigma S gamma x a c ≤ sigma (x, a) :=
    poisson_minimizer_controls_importance_update r hr D predict sigma S lam B gamma hK hg hgsmall hB hcap hlam hsigma hmin x a hx c hc1
  have h := mul_le_mul_of_nonneg_left
    (native_insertionGap_action_bound r D predict sigma S x a (nativeBanditUpdate r D predict sigma S gamma x a c) hs hb0 hbs) hq.le
  have hcancel : q * nativeBanditUpdate r D predict sigma S gamma x a c = c := by
    change q * (c / q) = c
    field_simp
  have hbound : q * (2 * Real.exp 1 * nativeBanditUpdate r D predict sigma S gamma x a c *
      actionEntropyCharge r D predict sigma S x a) ≤ 2 * Real.exp 1 * actionEntropyCharge r D predict sigma S x a := by
    have heq : q * (2 * Real.exp 1 * nativeBanditUpdate r D predict sigma S gamma x a c *
        actionEntropyCharge r D predict sigma S x a) = 2 * Real.exp 1 * c * actionEntropyCharge r D predict sigma S x a := by
      calc
        _ = 2 * Real.exp 1 * (q * nativeBanditUpdate r D predict sigma S gamma x a c) *
            actionEntropyCharge r D predict sigma S x a := by ring
        _ = _ := by rw [hcancel]
    rw [heq]
    have hD := actionEntropyCharge_nonneg r D predict sigma S x a
    have hm := mul_le_mul_of_nonneg_right hc1
      (mul_nonneg (by positivity : 0 ≤ 2 * Real.exp 1) hD)
    convert! hm using 1 <;> ring
  exact h.trans hbound

theorem native_expected_insertion_charge
    (r : NNReal) (hr : 0 < (r : ℝ)) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (lam B gamma : ℝ) (hK : 0 < K) (hg : 0 < gamma) (hgsmall : gamma ≤ 1 / 2)
    (hB : 1 ≤ B) (hcap : (K : ℝ) / gamma ≤ B)
    (hlam : 4 * (r : ℝ) * explorationLog K gamma ≤ lam)
    (hsigma : sigma ∈ scaleBox (X × Fin K) B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun j => (D {j.1}).toReal) lam B) (scaleBox (X × Fin K) B) sigma)
    (c : X → Fin K → ℝ) (hc0 : ∀ x a, 0 ≤ c x a) (hc1 : ∀ x a, c x a ≤ 1) :
    (∫ x, ∑ a, nativeBanditProbability r D predict sigma S gamma x a *
      nativeBanditInsertion r D predict sigma S gamma x a (c x a) ∂D) ≤
      2 * Real.exp 1 * Real.log (Fintype.card P) / r := by
  have hpoint : ∀ᵐ x ∂D, (∑ a, nativeBanditProbability r D predict sigma S gamma x a *
      nativeBanditInsertion r D predict sigma S gamma x a (c x a)) ≤
      2 * Real.exp 1 * ∑ a, actionEntropyCharge r D predict sigma S x a := by
    filter_upwards [ae_positive_context_mass D] with x hx
    have h := Finset.sum_le_sum (s := Finset.univ) fun a _ =>
      native_weighted_insertion_bound r hr D predict sigma S lam B gamma hK hg hgsmall hB hcap hlam
        hsigma hmin x a hx (c x a) (hc0 x a) (hc1 x a)
    simpa only [Finset.mul_sum] using h
  have h := integral_mono_ae (μ := D)
    (f := fun x => ∑ a, nativeBanditProbability r D predict sigma S gamma x a *
      nativeBanditInsertion r D predict sigma S gamma x a (c x a))
    (g := fun x => 2 * Real.exp 1 * ∑ a, actionEntropyCharge r D predict sigma S x a)
    Integrable.of_finite Integrable.of_finite hpoint
  rw [integral_const_mul] at h
  have hb : (∫ x, ∑ a, actionEntropyCharge r D predict sigma S x a ∂D) ≤ Real.log (Fintype.card P) / r := by
    apply (le_div_iff₀ hr).mpr
    simpa only [mul_comm] using poisson_actionEntropyCharge_budget r D predict sigma S
  have hc := mul_le_mul_of_nonneg_left hb (by positivity : 0 ≤ 2 * Real.exp 1)
  have heq : 2 * Real.exp 1 * (Real.log (Fintype.card P) / r) = 2 * Real.exp 1 * Real.log (Fintype.card P) / r := by ring
  rw [heq] at hc
  exact h.trans hc

end

end PoissonAudit
