module

public import PoissonAudit.EntropyVariational

public section

namespace PoissonAudit

theorem neg_log_one_sub_sq_le {t : ℝ} (ht0 : 0 ≤ t) (ht : t ≤ 1 / 2) :
    -Real.log (1 - t ^ 2) ≤ (4 / 3 : ℝ) * t ^ 2 := by
  have ht2 : t ^ 2 ≤ 1 / 4 := by nlinarith
  have hpos : 0 < 1 - t ^ 2 := by linarith
  have h := Real.one_sub_inv_le_log_of_pos hpos
  have hr : (1 - t ^ 2)⁻¹ - 1 ≤ (4 / 3 : ℝ) * t ^ 2 := by
    apply (mul_le_mul_iff_of_pos_left hpos).mp
    rw [mul_sub, mul_inv_cancel₀ hpos.ne']
    nlinarith [sq_nonneg (t ^ 2)]
  linarith

theorem two_correlation_product {a b d : ℝ} (hd : 0 ≤ d)
    (hb : |b| ≤ 1) (hbsq : b ^ 2 ≤ 2 * d)
    (ha : ∀ t : ℝ, 0 < t → t ≤ 1 / 2 →
      t * |a| ≤ d + (4 / 3 : ℝ) * t ^ 2) :
    |a * b| ≤ 4 * d := by
  by_cases hd0 : d = 0
  · have hb0 : b = 0 := by nlinarith [sq_nonneg b]
    simp [hb0, hd0]
  have hdp : 0 < d := lt_of_le_of_ne hd (Ne.symm hd0)
  by_cases hsmall : d ≤ 1
  · let s := Real.sqrt d
    have hs : 0 < s := Real.sqrt_pos.mpr hdp
    have hss : s ^ 2 = d := Real.sq_sqrt hd
    have hs1 : s ≤ 1 := Real.sqrt_le_one.mpr hsmall
    have hmean := ha (s / 2) (by positivity) (by linarith)
    have hab : |a| ≤ (8 / 3 : ℝ) * s := by nlinarith
    have hsign : |b| ≤ (3 / 2 : ℝ) * s := by
      have hsq : |b| ^ 2 ≤ 2 * d := by simpa only [sq_abs] using hbsq
      nlinarith [abs_nonneg b, sq_nonneg (|b| - (3 / 2 : ℝ) * s)]
    rw [abs_mul]
    calc
      _ ≤ ((8 / 3 : ℝ) * s) * ((3 / 2 : ℝ) * s) :=
        mul_le_mul hab hsign (abs_nonneg b) (by positivity)
      _ = 4 * d := by nlinarith
  · have hbig : 1 ≤ d := le_of_lt (lt_of_not_ge hsmall)
    have hmean := ha (1 / 2) (by norm_num) (by norm_num)
    have hab : |a| ≤ (8 / 3 : ℝ) * d := by nlinarith
    rw [abs_mul]
    calc
      _ ≤ |a| * 1 := mul_le_mul_of_nonneg_left hb (abs_nonneg a)
      _ ≤ 4 * d := by nlinarith

theorem binary_two_correlation {p alpha beta d1 d0 : ℝ}
    (hp : 0 < p) (hp1 : p < 1)
    (h1 : |(alpha / p) * (beta / p)| ≤ 4 * d1)
    (h0 : |(-alpha / (1 - p)) * (-beta / (1 - p))| ≤ 4 * d0) :
    alpha * beta / (p * (1 - p)) ≤ 4 * (p * d1 + (1 - p) * d0) := by
  have hp0 : 0 < 1 - p := by linarith
  have h1' := mul_le_mul_of_nonneg_left ((le_abs_self _).trans h1) hp.le
  have h0' := mul_le_mul_of_nonneg_left ((le_abs_self _).trans h0) hp0.le
  have heq : alpha * beta / (p * (1 - p)) =
      p * ((alpha / p) * (beta / p)) +
      (1 - p) * ((-alpha / (1 - p)) * (-beta / (1 - p))) := by
    field_simp
    ring
  rw [heq]
  nlinarith

end PoissonAudit
