module
public import PoissonAudit.CachedActionSelection
public section
open scoped BigOperators
namespace PoissonAudit
noncomputable section

@[simp] theorem vectorGet_ofFn {A : Type*} {n : ℕ} (f : Fin n → A) (i : Fin n) : (Vector.ofFn f).get i = f i := by
  simp [Vector.get, Vector.ofFn]
  congr 1

@[expose] def materializedBoostQuery {X : Type*} {K : ℕ} (Q : List (CostExample X K)) (x : X)
    (v : Vector ℝ K) (a : Fin K) : List (CostExample X K) := by
  classical
  exact Q ++ [(x, vectorValues (Vector.ofFn (fun b => vectorValues v b + if b = a then 1 else 0)))]

theorem materializedBoostQuery_eq {X : Type*} {K : ℕ} (Q : List (CostExample X K)) (x : X)
    (v : Vector ℝ K) (a : Fin K) : materializedBoostQuery Q x v a = boostedDesignatedQuery Q x (vectorValues v) a := by
  simp only [materializedBoostQuery, vectorValues_ofFn, boostedDesignatedQuery]

@[expose] def materializedValueQueries {X : Type*} {K : ℕ} (Q : List (CostExample X K)) (x : X)
    (v : Vector ℝ K) : Vector (List (CostExample X K)) (K + 1) :=
  Vector.ofFn (Fin.cases (Q ++ [(x, vectorValues v)]) (materializedBoostQuery Q x v))

theorem materializedValueQueries_list {X : Type*} {K : ℕ} (Q : List (CostExample X K)) (x : X)
    (v : Vector ℝ K) : (materializedValueQueries Q x v).toList = actionValueQueries Q x (vectorValues v) := by
  simp [materializedValueQueries, Vector.toList_ofFn, List.ofFn_succ, materializedBoostQuery_eq, actionValueQueries]

structure ExecutedValueCall (X : Type*) (K : ℕ) where
  action : Fin K
  queries : List (List (CostExample X K))
  scalarWork : ℕ
  allocatedWords : ℕ

@[expose] def executeValueCall {X : Type*} {K : ℕ} (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (Q : List (CostExample X K)) (x : X) (v : Vector ℝ K) : ExecutedValueCall X K :=
  let requests := materializedValueQueries Q x v
  let answers := Vector.ofFn (fun i => oracle (requests.get i))
  let base := answers.get 0
  let table := Vector.ofFn (fun a : Fin K => answers.get a.succ)
  let selected := executeCachedSelection base table fallback
  ⟨selected.1, requests.toList, selected.2 + 4 * K ^ 2 + 4 * K + 1, 4 * K ^ 2 + 4 * K + 1⟩

theorem executeValueCall_action {X : Type*} {K : ℕ} (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (Q : List (CostExample X K)) (x : X) (v : Vector ℝ K) :
    (executeValueCall oracle fallback Q x v).action = arrayValueOracleAction oracle fallback Q x v := by
  classical
  dsimp only [executeValueCall]
  rw [executeCachedSelection_value]
  simp only [vectorGet_ofFn, materializedValueQueries, vectorValues_ofFn, Fin.cases_zero, Fin.cases_succ,
    materializedBoostQuery_eq, arrayValueOracleAction]

theorem executeValueCall_queries {X : Type*} {K : ℕ} (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (Q : List (CostExample X K)) (x : X) (v : Vector ℝ K) :
    (executeValueCall oracle fallback Q x v).queries = actionValueQueries Q x (vectorValues v) :=
  materializedValueQueries_list Q x v

theorem executeValueCall_query_count {X : Type*} {K : ℕ} (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (Q : List (CostExample X K)) (x : X) (v : Vector ℝ K) :
    (executeValueCall oracle fallback Q x v).queries.length = K + 1 := by
  rw [executeValueCall_queries, actionValueQueries_count]

theorem executeValueCall_scalar_work {X : Type*} {K : ℕ} (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (Q : List (CostExample X K)) (x : X) (v : Vector ℝ K) :
    (executeValueCall oracle fallback Q x v).scalarWork ≤ 4 * K ^ 2 + 12 * K + 1 := by
  have h := executeCachedSelection_steps
    (oracle (Q ++ [(x, vectorValues v)]))
    (Vector.ofFn (fun a => oracle (materializedBoostQuery Q x v a))) fallback
  dsimp only [executeValueCall]
  simp only [vectorGet_ofFn, materializedValueQueries, Fin.cases_zero, Fin.cases_succ]
  omega
end
end PoissonAudit
