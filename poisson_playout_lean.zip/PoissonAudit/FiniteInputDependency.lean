module
public import PoissonAudit.CostedArraySampler
public section
namespace PoissonAudit
noncomputable section

@[expose] def NoiseAgrees {X : Type*} {K : ℕ} (cap : ℕ) (v w : NativeNoise X K) : Prop :=
  v.1 = w.1 ∧ v.2.1 = w.2.1 ∧ ∀ i : Fin cap, v.2.2 i = w.2.2 i

@[expose] def TapeAgrees {X : Type*} {K : ℕ} (cap : ℕ) :
    (J : ℕ) → NativeNoiseTape X K J → NativeNoiseTape X K J → Prop
  | 0, _, _ => True
  | J + 1, v, w => TapeAgrees cap J v.1 w.1 ∧ NoiseAgrees cap v.2 w.2

theorem TapeAgrees_counts {X : Type*} {K : ℕ} (cap J : ℕ) (v w : NativeNoiseTape X K J)
    (h : TapeAgrees cap J v w) : nativeTapeCountsBounded cap J v ↔ nativeTapeCountsBounded cap J w := by
  induction J with
  | zero => rfl
  | succ J ih =>
    change (_ ∧ v.2.2.1 ≤ cap) ↔ (_ ∧ w.2.2.1 ≤ cap)
    rw [ih v.1 w.1 h.1, h.2.2.1]

theorem makeReplayRecord_finite_input {X : Type*} {K : ℕ} (cap : ℕ) (current : X → Fin K → ℝ)
    (v w : NativeNoise X K) (h : NoiseAgrees cap v w) (hc : v.2.1 ≤ cap) :
    makeReplayRecord current v = makeReplayRecord current w := by
  rcases v with ⟨z, M, u⟩
  rcases w with ⟨z', M', u'⟩
  rcases h with ⟨rfl, rfl, hp⟩
  have he : poolPrefix M u = poolPrefix M u' := by
    funext i
    exact hp ⟨i.val, lt_of_lt_of_le i.isLt hc⟩
  simp only [makeReplayRecord, he]

theorem buildReplayRecords_finite_input {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (cap J : ℕ) (v w : NativeNoiseTape X K J) (h : TapeAgrees cap J v w) (hc : nativeTapeCountsBounded cap J v) :
    buildReplayRecords r lam B eta history oracle fallback J v = buildReplayRecords r lam B eta history oracle fallback J w := by
  induction J with
  | zero => rfl
  | succ J ih =>
    dsimp only [buildReplayRecords]
    rw [ih v.1 w.1 h.1 hc.1]
    congr 1
    exact makeReplayRecord_finite_input cap _ v.2 w.2 h.2 hc.2

theorem replayTrialAction_finite_input {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (records : List (ReplayRecord X K)) (x : X) (cap : ℕ) (v w : NativeNoise X K)
    (h : NoiseAgrees cap v w) (hc : v.2.1 ≤ cap) :
    replayTrialAction r lam B eta history oracle fallback records x v = replayTrialAction r lam B eta history oracle fallback records x w := by
  dsimp only [replayTrialAction]
  rw [makeReplayRecord_finite_input cap _ v w h hc, h.1]

theorem cappedOracleChoice_finite_input {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (cap J m : ℕ) (v w : NativeNoiseTape X K J) (trials trials' : Fin m → NativeNoise X K) (x : X)
    (h : TapeAgrees cap J v w) (ht : ∀ i, NoiseAgrees cap (trials i) (trials' i)) :
    cappedOracleChoice r lam B eta history oracle fallback cap J m v trials x =
      cappedOracleChoice r lam B eta history oracle fallback cap J m w trials' x := by
  classical
  have hc : (nativeTapeCountsBounded cap J v ∧ ∀ i, (trials i).2.1 ≤ cap) ↔
      (nativeTapeCountsBounded cap J w ∧ ∀ i, (trials' i).2.1 ≤ cap) := by
    rw [TapeAgrees_counts cap J v w h]
    simp only [(ht _).2.1]
  unfold cappedOracleChoice
  by_cases hv : nativeTapeCountsBounded cap J v ∧ ∀ i, (trials i).2.1 ≤ cap
  · rw [if_pos hv, if_pos (hc.mp hv), buildReplayRecords_finite_input r lam B eta history oracle fallback cap J v w h hv.1]
    congr 1
    funext i
    exact replayTrialAction_finite_input r lam B eta history oracle fallback _ x cap _ _ (ht i) (hv.2 i)
  · rw [if_neg hv, if_neg (fun hw => hv (hc.mpr hw))]
end
end PoissonAudit
