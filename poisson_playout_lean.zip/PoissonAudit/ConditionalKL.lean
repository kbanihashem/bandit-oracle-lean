module

public import Mathlib.InformationTheory.KullbackLeibler.Basic
public import Mathlib.Probability.ConditionalProbability
public import Mathlib.Tactic

public section

open MeasureTheory ProbabilityTheory InformationTheory
open MeasureTheory.Measure
open scoped ENNReal

namespace PoissonAudit

theorem klDiv_conditioned_event {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) [IsProbabilityMeasure mu]
    (E : Set Omega) (hE : MeasurableSet E) (hp : mu E ≠ 0) :
    klDiv (mu[|E]) mu = ENNReal.ofReal (-Real.log (mu E).toReal) := by
  let rho := mu[|E]
  let _ : IsProbabilityMeasure rho := cond_isProbabilityMeasure hp
  have hac : rho ≪ mu := cond_absolutelyContinuous
  have hrest : rho ≪ mu.restrict E := smul_absolutelyContinuous
  have hmem : ∀ᵐ omega ∂rho, omega ∈ E := hrest.ae_le (ae_restrict_mem hE)
  have hscale := Measure.rnDeriv_smul_left_of_ne_top (mu.restrict E) mu
    (r := (mu E)⁻¹) (ENNReal.inv_ne_top.mpr hp)
  have hderiv : rho.rnDeriv mu =ᵐ[rho] fun _ => (mu E)⁻¹ := by
    have hs := hac.ae_le hscale
    have hr := hac.ae_le (Measure.rnDeriv_restrict_self mu hE)
    filter_upwards [hs, hr, hmem] with omega hs hr hmem
    change rho.rnDeriv mu omega = (mu E)⁻¹ • (mu.restrict E).rnDeriv mu omega at hs
    rw [hs, hr]
    simp [hmem]
  have hllr : llr rho mu =ᵐ[rho] fun _ => -Real.log (mu E).toReal := by
    filter_upwards [hderiv] with omega h
    rw [llr_def]
    simp only [h, ENNReal.toReal_inv, Real.log_inv]
  have hint : Integrable (llr rho mu) rho := (integrable_const _).congr hllr.symm
  change klDiv rho mu = _
  rw [klDiv_of_ac_of_integrable hac hint, integral_congr_ae hllr]
  simp

end PoissonAudit
