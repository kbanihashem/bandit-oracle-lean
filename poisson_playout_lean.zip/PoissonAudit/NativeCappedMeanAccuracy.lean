module
public import PoissonAudit.NativeCappedAccuracy
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section

theorem finite_integral_swap {X Y : Type*} [Fintype X] [MeasurableSpace X] [MeasurableSingletonClass X]
    [MeasurableSpace Y] (D : Measure X) [IsFiniteMeasure D] (mu : Measure Y) (f : X → Y → ℝ)
    (hf : ∀ x, Integrable (f x) mu) :
    (∫ x, ∫ y, f x y ∂mu ∂D) = ∫ y, ∫ x, f x y ∂D ∂mu := by
  have he (y : Y) : (∫ x, f x y ∂D) = ∑ x, (D {x}).toReal * f x y := by
    rw [integral_fintype Integrable.of_finite]
    rfl
  simp_rw [he]
  rw [integral_fintype Integrable.of_finite, integral_finsetSum _ (fun x _ => (hf x).const_mul _)]
  apply Finset.sum_congr rfl
  intro x _
  exact (integral_const_mul (D {x}).toReal (f x)).symm

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem native_mean_mixture_contract (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (sigma tau : X × Fin K → ℝ) (gamma : ℝ)
    (hg0 : 0 ≤ gamma) (hg1 : gamma ≤ 1) :
    (∫ x, ∑ a, |nativeBanditProbability r D predict sigma S gamma x a -
      nativeBanditProbability r D predict tau S gamma x a| ∂D) ≤ nativeMeanActionError r D predict S sigma tau := by
  apply integral_mono Integrable.of_finite Integrable.of_finite
  intro x
  apply Finset.sum_le_sum
  intro a _
  have he : nativeBanditProbability r D predict sigma S gamma x a - nativeBanditProbability r D predict tau S gamma x a =
      (1 - gamma) * (experimentProbability r D predict sigma S x a - experimentProbability r D predict tau S x a) := by
    unfold nativeBanditProbability explorationProbability
    ring
  rw [he, abs_mul, abs_of_nonneg (sub_nonneg.mpr hg1)]
  exact mul_le_of_le_one_left (abs_nonneg _) (by linarith)

theorem native_capped_mean_reference_error (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta gamma : ℝ) (hB : 1 ≤ B)
    (hK : 0 < K) (hg0 : 0 ≤ gamma) (hg1 : gamma ≤ 1) (cap J m : ℕ) (hc : 0 < cap) (hm : 0 < m)
    (s : NativeScaleBox X K B) :
    (∫ x, ∫ choice, ∑ a, |choiceProbability K gamma m choice a - nativeBanditProbability r D predict s.val S gamma x a|
      ∂(nativeCappedChoiceLaw r D predict S lam B eta hB cap J m x).toMeasure ∂D) ≤
        K * Real.sqrt (1 / m) +
          (∫ state : NativeSGDState X K B, nativeMeanActionError r D predict S state.2.val s.val
            ∂nativeSGDStateLaw r D predict S lam B eta hB J) +
              2 * ((J + m : ℕ) * ((r : ℝ) / cap)) := by
  let mu := nativeFlaggedStateLaw r D predict S lam B eta hB cap J
  let err := fun x (state : NativeFlaggedState X K B) => ∑ a,
    |nativeBanditProbability r D predict state.1.2.val S gamma x a - nativeBanditProbability r D predict s.val S gamma x a|
  have hei (x : X) : Integrable (err x) mu := integrable_nativeMixtureError_flagged r D predict S B gamma x _ mu
  have hp (x : X) := native_capped_reference_error r D predict S lam B eta gamma hB hK hg0 hg1 cap J m hc hm x
    (nativeBanditProbability r D predict s.val S gamma x)
    (nativeBanditProbability_nonneg r D predict s.val S gamma hg0 hg1 x)
    (nativeBanditProbability_sum r D predict s.val S gamma hK x)
  have hi := integral_mono (μ := D) Integrable.of_finite Integrable.of_finite hp
  change _ ≤ ∫ x, K * Real.sqrt (1 / m) + (∫ state, err x state ∂mu) + 2 * ((J + m : ℕ) * ((r : ℝ) / cap)) ∂D at hi
  rw [integral_add Integrable.of_finite (integrable_const _),
    integral_add (integrable_const _) Integrable.of_finite] at hi
  simp only [integral_const, probReal_univ, one_smul] at hi
  rw [finite_integral_swap D mu err hei] at hi
  have hproj := nativeFlaggedStateLaw_projection r D predict S lam B eta hB cap J
  have hmean := integrable_nativeMeanActionError_state r D predict S B s
    (nativeSGDStateLaw r D predict S lam B eta hB J)
  have hmeanFlag := hproj.integrable_comp_of_integrable hmean
  have herrInt : Integrable (fun state : NativeFlaggedState X K B => ∫ x, err x state ∂D) mu := by
    have he (state : NativeFlaggedState X K B) : (∫ x, err x state ∂D) = ∑ x, (D {x}).toReal * err x state := by
      rw [integral_fintype Integrable.of_finite]; rfl
    simp_rw [he]
    exact integrable_finsetSum _ (fun x _ => (hei x).const_mul _)
  have herr := integral_mono herrInt hmeanFlag (fun state => native_mean_mixture_contract r D predict S state.1.2.val s.val gamma hg0 hg1)
  have hmap := integral_map hproj.measurable.aemeasurable
    (f := fun state : NativeSGDState X K B => nativeMeanActionError r D predict S state.2.val s.val)
    (by rw [hproj.map_eq]; exact hmean.aestronglyMeasurable)
  rw [hproj.map_eq] at hmap
  change (∫ state, nativeMeanActionError r D predict S state.2.val s.val ∂nativeSGDStateLaw r D predict S lam B eta hB J) =
    ∫ state : NativeFlaggedState X K B, nativeMeanActionError r D predict S state.1.2.val s.val ∂mu at hmap
  change (∫ state, ∫ x, err x state ∂D ∂mu) ≤
    (∫ state : NativeFlaggedState X K B, nativeMeanActionError r D predict S state.1.2.val s.val ∂mu) at herr
  rw [← hmap] at herr
  linarith

theorem native_capped_mean_action_accuracy (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eps delta gamma : ℝ)
    (hlam : 0 < lam) (hB : 1 ≤ B) (heps : 0 < eps) (hd : 0 < delta) (hK : 0 < K)
    (hg0 : 0 ≤ gamma) (hg1 : gamma ≤ 1) (s : NativeScaleBox X K B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun q => (D {q.1}).toReal) lam B) (scaleBox (X × Fin K) B) s.val)
    (hepsBudget : eps ≤ lam * delta ^ 2 / (32 * B ^ 2 * ((r : ℝ) + 1) ^ 2 * K)) :
    let J := nativeSGDIterations r K lam B eps
    let m := nativeEmpiricalTrials K delta
    let cap := nativeCountCap r (J + m) delta
    let eta := eps / (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2))
    (∫ x, ∫ choice, ∑ a, |choiceProbability K gamma m choice a - nativeBanditProbability r D predict s.val S gamma x a|
      ∂(nativeCappedChoiceLaw r D predict S lam B eta hB cap J m x).toMeasure ∂D) ≤ delta := by
  dsimp only
  let J := nativeSGDIterations r K lam B eps
  let m := nativeEmpiricalTrials K delta
  let cap := nativeCountCap r (J + m) delta
  let eta := eps / (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2))
  have hmain := native_capped_mean_reference_error r D predict S lam B eta gamma hB hK hg0 hg1 cap J m
    (nativeCountCap_pos r (J + m) delta) (nativeEmpiricalTrials_pos K delta) s
  have hopt := native_SGD_mean_action_accuracy r D predict S lam B eps delta hlam hB heps hd hK s hmin hepsBudget J
    (nativeSGDIterations_pos r K lam B eps) (nativeSGDIterations_budget r K lam B eps)
  have hcap := nativeCountCap_total_tail_budget r (J + m) delta hd
  have htrials : (K : ℝ) * Real.sqrt (1 / (m : ℝ)) ≤ delta / 4 := by
    apply cardinal_sqrt_one_div_le (Nat.cast_nonneg K) (by linarith) (nativeEmpiricalTrials_pos K delta)
    convert! nativeEmpiricalTrials_budget K delta using 1 <;> ring
  change _ ≤ delta
  change _ ≤ (K : ℝ) * Real.sqrt (1 / (m : ℝ)) + _ + _ at hmain
  change (∫ state, nativeMeanActionError r D predict S state.2.val s.val ∂nativeSGDStateLaw r D predict S lam B eta hB J) ≤ delta / 2 at hopt
  change ((J + m : ℕ) : ℝ) * ((r : ℝ) / cap) ≤ delta / 8 at hcap
  linarith
end
end PoissonAudit
