module

public import PoissonAudit.ActionMarkShift
public import PoissonAudit.OutcomeCoarsening

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K m : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def locationUninsertedProbability (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (a : Fin K) (m : ℕ) (C : Fin m → X) : ℝ :=
  outcomeMass (iidPool (laplaceMeasure K) m) (fun Z => predict (locationWinner predict sigma S C Z) x) a

theorem location_channel_action_clamp (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (a : Fin K) (s : ℝ) (hsigma : sigma (x, a) ≠ 0)
    (C : Fin m → X) (p : P) :
    eventChannel (iidPool (laplaceMeasure K) m) (outcomeEvent (insertedLocationWinner predict sigma S x C) p)
      (-actionMarkShift (sigma (x, a)) a s) =
    outcomeMass (iidPool (laplaceMeasure K) m) (locationWinner predict sigma (actionPenaltyScore predict S x a s) C) p := by
  rw [eventChannel_outcome_eq_mass _ _ (measurable_insertedLocationWinner predict sigma S x C)]
  have heq : (fun Z => insertedLocationWinner predict sigma S x C (-actionMarkShift (sigma (x, a)) a s, Z)) =
      locationWinner predict sigma (actionPenaltyScore predict S x a s) C := by
    funext Z
    exact (locationWinner_action_clamp predict sigma S x a s hsigma C Z).symm
  rw [heq]

theorem locationUninsertedProbability_action_clamp (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (a : Fin K) (s : ℝ) (hsigma : sigma (x, a) ≠ 0) (C : Fin m → X) :
    locationUninsertedProbability predict sigma (actionPenaltyScore predict S x a s) x a m C =
      ∑ p, if predict p x = a then
        eventChannel (iidPool (laplaceMeasure K) m) (outcomeEvent (insertedLocationWinner predict sigma S x C) p)
          (-actionMarkShift (sigma (x, a)) a s) else 0 := by
  unfold locationUninsertedProbability
  rw [outcomeMass_comp_finite _ _ (measurable_locationWinner predict sigma (actionPenaltyScore predict S x a s) C)
    (fun p => predict p x) a]
  simp_rw [location_channel_action_clamp predict sigma S x a s hsigma C]

theorem location_action_difference_eq_shift (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (a : Fin K) (s : ℝ) (hsigma : sigma (x, a) ≠ 0) (C : Fin m → X) :
    locationActionMoment predict sigma (actionPenaltyScore predict S x a s) x a (fun _ => 1) m C -
      locationUninsertedProbability predict sigma (actionPenaltyScore predict S x a s) x a m C =
    conditionalShiftDifference predict sigma S x a C (actionMarkShift (sigma (x, a)) a s) := by
  classical
  rw [locationUninsertedProbability_action_clamp predict sigma S x a s hsigma C]
  unfold locationActionMoment winnerGroupMoment conditionalShiftDifference
  simp only [mul_one]
  simp_rw [location_channel_action_shift predict sigma S x a s hsigma C]
  rw [← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro p _
  by_cases hp : predict p x = a
  · simp only [hp, ite_true]
    let E := outcomeEvent (insertedLocationWinner predict sigma S x C) p
    let nu := iidPool (laplaceMeasure K) m
    let v := actionMarkShift (sigma (x, a)) a s
    have hE : MeasurableSet E := measurable_insertedLocationWinner predict sigma S x C (measurableSet_singleton p)
    have hr : Integrable (fun z : Fin K → ℝ => eventChannel nu E (z - v)) (laplaceMeasure K) :=
      Integrable.of_mem_Icc 0 1
        (((measurable_eventSectionMass nu E hE).ennreal_toReal.comp (measurable_id.sub_const v)).aemeasurable)
        (Filter.Eventually.of_forall fun z => eventChannel_mem_Icc nu E (z - v))
    rw [integral_sub hr (integrable_const _)]
    simp only [integral_const, probReal_univ, one_smul]
    rfl
  · simp [hp]

theorem location_action_difference_bound (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (a : Fin K) (s : ℝ) (hsigma : 0 < sigma (x, a))
    (hs : 0 ≤ s) (hss : s ≤ sigma (x, a)) (C : Fin m → X) :
    locationActionMoment predict sigma (actionPenaltyScore predict S x a s) x a (fun _ => 1) m C -
      locationUninsertedProbability predict sigma (actionPenaltyScore predict S x a s) x a m C ≤
      2 * Real.exp 1 * locationActionEntropy predict sigma S x a m C := by
  rw [location_action_difference_eq_shift predict sigma S x a s hsigma.ne' C]
  have h := conditional_action_shift_charge predict sigma S x a C (actionMarkShift (sigma (x, a)) a s)
  have hl : l1 (actionMarkShift (sigma (x, a)) a s) ≤ 1 := by
    rw [l1_actionMarkShift, abs_of_nonneg (div_nonneg hs hsigma.le)]
    exact (div_le_one hsigma).mpr hss
  have he := Real.exp_le_exp.mpr hl
  have hD := (locationActionEntropy_bounds predict sigma S x a m C).1
  exact h.trans (mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left he (by norm_num)) hD)

theorem locationUninsertedProbability_bounds (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (a : Fin K) (m : ℕ) (C : Fin m → X) :
    0 ≤ locationUninsertedProbability predict sigma S x a m C ∧
      locationUninsertedProbability predict sigma S x a m C ≤ 1 :=
  ⟨outcomeMass_nonneg _ _ _, outcomeMass_le_one _ _ _⟩

end

end PoissonAudit
