module
public import PoissonAudit.FiniteBanditRegret
public section
open MeasureTheory
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X A P : Type*} [Fintype X] [Fintype A] [Fintype P] [Nonempty P]

@[expose] def banditPaths : List (X → A → ℝ) → Type _
  | [] => (Fin 0 → X × A)
  | _ :: cs => X × A × banditPaths cs

instance banditPaths_fintype (costs : List (X → A → ℝ)) : Fintype (banditPaths costs) := by
  induction costs with
  | nil => exact inferInstanceAs (Fintype (Fin 0 → X × A))
  | cons c cs ih => letI := ih; exact inferInstanceAs (Fintype (X × A × banditPaths cs))

instance banditPaths_measurableSpace (costs : List (X → A → ℝ)) : MeasurableSpace (banditPaths costs) := ⊤
instance banditPaths_measurableSingletonClass (costs : List (X → A → ℝ)) : MeasurableSingletonClass (banditPaths costs) := ⟨fun _ => trivial⟩

@[expose] def banditPathWeight (d : X → ℝ) (predict : P → X → A) (q : (P → ℝ) → X → A → ℝ) :
    (costs : List (X → A → ℝ)) → (P → ℝ) → banditPaths costs → ℝ
  | [], _, _ => 1
  | c :: cs, S, path => d path.1 * q S path.1 path.2.1 * banditPathWeight d predict q cs
      (treeUpdatedScore S (q S path.1) (c path.1) (fun p => predict p path.1) path.2.1) path.2.2

@[expose] def banditPathLoss : (costs : List (X → A → ℝ)) → banditPaths costs → ℝ
  | [], _ => 0
  | c :: cs, path => c path.1 path.2.1 + banditPathLoss cs path.2.2

@[expose] def banditPathEstimate (predict : P → X → A) (q : (P → ℝ) → X → A → ℝ) :
    (costs : List (X → A → ℝ)) → (P → ℝ) → banditPaths costs → (P → ℝ)
  | [], S, _ => S
  | c :: cs, S, path => banditPathEstimate predict q cs
      (treeUpdatedScore S (q S path.1) (c path.1) (fun p => predict p path.1) path.2.1) path.2.2

@[expose] def banditPathTrueScore (predict : P → X → A) :
    (costs : List (X → A → ℝ)) → (P → ℝ) → banditPaths costs → (P → ℝ)
  | [], S, _ => S
  | c :: cs, S, path => banditPathTrueScore predict cs (trueScoreStep predict S c path.1) path.2.2

theorem banditPathWeight_nonneg (d : X → ℝ) (hd : ∀ x, 0 ≤ d x) (predict : P → X → A)
    (q : (P → ℝ) → X → A → ℝ) (hq : ∀ S x a, 0 ≤ q S x a)
    (costs : List (X → A → ℝ)) (S : P → ℝ) (path : banditPaths costs) :
    0 ≤ banditPathWeight d predict q costs S path := by
  induction costs generalizing S with
  | nil => exact zero_le_one
  | cons c cs ih => exact mul_nonneg (mul_nonneg (hd _) (hq _ _ _)) (ih _ _)

theorem banditPathWeight_sum (d : X → ℝ) (hdsum : ∑ x, d x = 1) (predict : P → X → A)
    (q : (P → ℝ) → X → A → ℝ) (hqsum : ∀ S x, ∑ a, q S x a = 1)
    (costs : List (X → A → ℝ)) (S : P → ℝ) :
    (∑ path, banditPathWeight d predict q costs S path) = 1 := by
  classical
  induction costs generalizing S with
  | nil =>
    change (∑ _path : Fin 0 → X × A, (1 : ℝ)) = 1
    simp
  | cons c cs ih =>
    change (∑ path : X × A × banditPaths cs, _) = 1
    simp only [Fintype.sum_prod_type, banditPathWeight, ← Finset.mul_sum, ih, mul_one, hqsum, hdsum]

@[expose] def banditPathLaw (d : X → ℝ) (hd : ∀ x, 0 ≤ d x) (hdsum : ∑ x, d x = 1)
    (predict : P → X → A) (q : (P → ℝ) → X → A → ℝ)
    (hq : ∀ S x a, 0 ≤ q S x a) (hqsum : ∀ S x, ∑ a, q S x a = 1)
    (costs : List (X → A → ℝ)) (S : P → ℝ) : PMF (banditPaths costs) :=
  actionPMF (banditPathWeight d predict q costs S) (banditPathWeight_nonneg d hd predict q hq costs S)
    (banditPathWeight_sum d hdsum predict q hqsum costs S)

theorem banditPath_terminal_sum (d : X → ℝ) (predict : P → X → A) (q : (P → ℝ) → X → A → ℝ)
    (f : (P → ℝ) → ℝ) (costs : List (X → A → ℝ)) (S : P → ℝ) :
    (∑ path, banditPathWeight d predict q costs S path * f (banditPathEstimate predict q costs S path)) =
      finiteBanditTerminal d predict q f costs S := by
  classical
  induction costs generalizing S with
  | nil =>
    change (∑ _path : Fin 0 → X × A, (1 : ℝ) * f S) = f S
    simp
  | cons c cs ih =>
    change (∑ path : X × A × banditPaths cs, _) = _
    simp only [Fintype.sum_prod_type, banditPathWeight, banditPathEstimate, finiteBanditTerminal]
    simp_rw [mul_assoc, ← Finset.mul_sum, ih]

theorem banditPath_comparator_sum (d : X → ℝ) (predict : P → X → A) (q : (P → ℝ) → X → A → ℝ)
    (hqsum : ∀ S x, ∑ a, q S x a = 1) (costs : List (X → A → ℝ)) (S U : P → ℝ) :
    (∑ path, banditPathWeight d predict q costs S path * treeBestScore (banditPathTrueScore predict costs U path)) =
      contextBestScore d predict costs U := by
  classical
  induction costs generalizing S U with
  | nil =>
    change (∑ _path : Fin 0 → X × A, (1 : ℝ) * treeBestScore U) = treeBestScore U
    simp
  | cons c cs ih =>
    change (∑ path : X × A × banditPaths cs, _) = _
    simp only [Fintype.sum_prod_type, banditPathWeight, banditPathTrueScore, contextBestScore]
    simp_rw [mul_assoc, ← Finset.mul_sum, ih, ← Finset.sum_mul, hqsum, one_mul]

theorem banditPath_loss_sum (d : X → ℝ) (hdsum : ∑ x, d x = 1) (predict : P → X → A)
    (q : (P → ℝ) → X → A → ℝ) (hqsum : ∀ S x, ∑ a, q S x a = 1)
    (costs : List (X → A → ℝ)) (S : P → ℝ) :
    (∑ path, banditPathWeight d predict q costs S path * banditPathLoss costs path) =
      finiteBanditLoss d predict q costs S := by
  classical
  induction costs generalizing S with
  | nil => simp [banditPathWeight, banditPathLoss, finiteBanditLoss, banditPaths]
  | cons c cs ih =>
    change (∑ path : X × A × banditPaths cs, _) = _
    simp only [Fintype.sum_prod_type, banditPathWeight, banditPathLoss, finiteBanditLoss]
    apply Finset.sum_congr rfl
    intro x _
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro a _
    simp_rw [mul_assoc, ← Finset.mul_sum]
    simp_rw [mul_add, Finset.sum_add_distrib, ← Finset.sum_mul]
    rw [banditPathWeight_sum d hdsum predict q hqsum, one_mul, ih]
    ring

theorem integral_banditPath_regret (d : X → ℝ) (hd : ∀ x, 0 ≤ d x) (hdsum : ∑ x, d x = 1)
    (predict : P → X → A) (q : (P → ℝ) → X → A → ℝ)
    (hq : ∀ S x a, 0 ≤ q S x a) (hqsum : ∀ S x, ∑ a, q S x a = 1)
    (costs : List (X → A → ℝ)) (S : P → ℝ) :
    (∫ path, banditPathLoss costs path + treeBestScore (banditPathTrueScore predict costs S path)
      ∂(banditPathLaw d hd hdsum predict q hq hqsum costs S).toMeasure) =
      finiteBanditLoss d predict q costs S + contextBestScore d predict costs S := by
  unfold banditPathLaw
  rw [integral_actionPMF]
  simp only [mul_add, Finset.sum_add_distrib]
  rw [banditPath_loss_sum d hdsum predict q hqsum, banditPath_comparator_sum d predict q hqsum]
end
end PoissonAudit
