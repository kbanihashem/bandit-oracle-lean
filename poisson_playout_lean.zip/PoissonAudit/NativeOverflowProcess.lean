module
public import PoissonAudit.PoissonOverflow
public section
open MeasureTheory Set
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] abbrev NativeFlaggedState (X : Type*) (K : ℕ) (B : ℝ) := NativeSGDState X K B × Bool

@[expose] def nativeOverflowBool (cap : ℕ) (v : NativeNoise X K) : Bool := if cap < v.2.1 then true else false

theorem measurable_nativeOverflowBool (cap : ℕ) : Measurable (nativeOverflowBool (X := X) (K := K) cap) :=
  measurable_const.ite (measurableSet_lt measurable_const (measurable_fst.comp measurable_snd)) measurable_const

@[expose] def nativeFlaggedTransition (r : NNReal) (predict : P → X → Fin K) (S : P → ℝ)
    (lam B eta : ℝ) (hB : 1 ≤ B) (cap j : ℕ) (state : NativeFlaggedState X K B) (v : NativeNoise X K) : NativeFlaggedState X K B :=
  (nativeSGDTransition r predict S lam B eta hB j state.1 v, state.2 || nativeOverflowBool cap v)

theorem measurable_nativeFlaggedTransition (r : NNReal) (predict : P → X → Fin K) (S : P → ℝ)
    (lam B eta : ℝ) (hB : 1 ≤ B) (cap j : ℕ) :
    Measurable (fun v : NativeFlaggedState X K B × NativeNoise X K => nativeFlaggedTransition r predict S lam B eta hB cap j v.1 v.2) := by
  apply Measurable.prodMk
  · exact (measurable_nativeSGDTransition r predict S lam B eta hB j).comp
      ((measurable_fst.comp measurable_fst).prodMk measurable_snd)
  · exact (measurable_of_finite (fun b : Bool × Bool => b.1 || b.2)).comp
      ((measurable_snd.comp measurable_fst).prodMk ((measurable_nativeOverflowBool cap).comp measurable_snd))

@[expose] def nativeFlaggedStateLaw (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ) (hB : 1 ≤ B) (cap : ℕ) : ℕ → Measure (NativeFlaggedState X K B)
  | 0 => Measure.dirac ((nativeUnitScale B hB, nativeUnitScale B hB), false)
  | j + 1 => ((nativeFlaggedStateLaw r D predict S lam B eta hB cap j).prod (insertedExperimentLaw r D K)).map
      (fun v => nativeFlaggedTransition r predict S lam B eta hB cap j v.1 v.2)

instance nativeFlaggedStateLaw_isProbability (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ) (hB : 1 ≤ B) (cap J : ℕ) :
    IsProbabilityMeasure (nativeFlaggedStateLaw r D predict S lam B eta hB cap J) := by
  induction J with
  | zero => exact inferInstanceAs (IsProbabilityMeasure (Measure.dirac ((nativeUnitScale B hB, nativeUnitScale B hB), false)))
  | succ j ih =>
    letI := ih
    exact (Measure.isProbabilityMeasure_map_iff (measurable_nativeFlaggedTransition r predict S lam B eta hB cap j).aemeasurable).mpr inferInstance

theorem nativeFlaggedStateLaw_projection (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ) (hB : 1 ≤ B) (cap J : ℕ) :
    MeasurePreserving Prod.fst (nativeFlaggedStateLaw r D predict S lam B eta hB cap J)
      (nativeSGDStateLaw r D predict S lam B eta hB J) := by
  induction J with
  | zero =>
    refine ⟨measurable_fst, ?_⟩
    simp only [nativeFlaggedStateLaw, nativeSGDStateLaw, Measure.map_dirac, measurable_fst]
  | succ j ih =>
    let mu := nativeFlaggedStateLaw r D predict S lam B eta hB cap j
    let nu := nativeSGDStateLaw r D predict S lam B eta hB j
    let noise := insertedExperimentLaw r D K
    let F := fun v : NativeFlaggedState X K B × NativeNoise X K => nativeFlaggedTransition r predict S lam B eta hB cap j v.1 v.2
    let G := fun v : NativeSGDState X K B × NativeNoise X K => nativeSGDTransition r predict S lam B eta hB j v.1 v.2
    let proj : NativeFlaggedState X K B × NativeNoise X K → NativeSGDState X K B × NativeNoise X K := Prod.map Prod.fst id
    have hproj : MeasurePreserving proj (mu.prod noise) (nu.prod noise) := ih.prod (MeasurePreserving.id noise)
    have hF : Measurable F := measurable_nativeFlaggedTransition r predict S lam B eta hB cap j
    have hG : Measurable G := measurable_nativeSGDTransition r predict S lam B eta hB j
    refine ⟨measurable_fst, ?_⟩
    change ((mu.prod noise).map F).map Prod.fst = (nu.prod noise).map G
    calc
      _ = (mu.prod noise).map (Prod.fst ∘ F) := Measure.map_map measurable_fst hF
      _ = (mu.prod noise).map (G ∘ proj) := rfl
      _ = ((mu.prod noise).map proj).map G := (Measure.map_map hG hproj.measurable).symm
      _ = _ := by rw [hproj.map_eq]
end
end PoissonAudit
