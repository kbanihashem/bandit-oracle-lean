module

public import Mathlib.Probability.Distributions.Poisson.Basic
public import Mathlib.Tactic

public section

open MeasureTheory ProbabilityTheory
open scoped BigOperators

namespace PoissonAudit

noncomputable section

def poissonWeight (r : ℝ) (m : ℕ) : ℝ := Real.exp (-r) * r ^ m / m.factorial

theorem poisson_reweight (r : ℝ) (m : ℕ) :
    ((m + 1 : ℕ) : ℝ) * poissonWeight r (m + 1) = r * poissonWeight r m := by
  have hf : (m.factorial : ℝ) ≠ 0 := by exact_mod_cast Nat.factorial_ne_zero m
  have hm : (m : ℝ) + 1 ≠ 0 := by positivity
  simp only [poissonWeight, Nat.factorial_succ, Nat.cast_mul, Nat.cast_add,
    Nat.cast_one, pow_succ]
  field_simp

set_option maxHeartbeats 2000000 in

theorem poisson_series_insertion (r : ℝ) (f : ℕ → ℝ)
    (hs : Summable (fun m => poissonWeight r m * f m)) :
    (∑' m, poissonWeight r m * ((m : ℝ) * f (m - 1))) =
      r * ∑' m, poissonWeight r m * f m := by
  have hterm : ∀ m : ℕ,
      poissonWeight r (m + 1) * (((m + 1 : ℕ) : ℝ) * f ((m + 1) - 1)) =
        r * (poissonWeight r m * f m) := by
    intro m
    simp only [Nat.add_sub_cancel]
    calc
      _ = (((m + 1 : ℕ) : ℝ) * poissonWeight r (m + 1)) * f m := by ring
      _ = (r * poissonWeight r m) * f m := by rw [poisson_reweight]
      _ = _ := by ring
  have hsucc : Summable (fun m =>
      poissonWeight r (m + 1) * (((m + 1 : ℕ) : ℝ) * f ((m + 1) - 1))) := by
    simp_rw [hterm]
    exact hs.mul_left r
  rw [tsum_eq_zero_add' hsucc]
  simp only [Nat.cast_zero, zero_mul, mul_zero, zero_add]
  simp_rw [hterm]
  exact tsum_mul_left

theorem poisson_integral_insertion (r : NNReal) (f : ℕ → ℝ)
    (hf : Integrable f (poissonMeasure r)) :
    (∫ m, (m : ℝ) * f (m - 1) ∂poissonMeasure r) =
      (r : ℝ) * ∫ m, f m ∂poissonMeasure r := by
  have hs : Summable (fun m => poissonWeight (r : ℝ) m * f m) := by
    simpa [poissonWeight, smul_eq_mul] using
      (hasSum_integral_poissonMeasure hf).summable
  simp only [integral_poissonMeasure, smul_eq_mul]
  exact poisson_series_insertion (r : ℝ) f hs

end

end PoissonAudit
