module

public import PoissonAudit.NativeOldCurvature
public import PoissonAudit.WeightedCurvatureCharge

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def nativeBanditProbability (r : NNReal) (D : Measure X)
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (gamma : ℝ) (x : X) (a : Fin K) : ℝ :=
  explorationProbability K gamma (experimentProbability r D predict sigma S x a)

@[expose] def nativeBanditUpdate (r : NNReal) (D : Measure X)
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (gamma : ℝ) (x : X) (a : Fin K) (c : ℝ) : ℝ :=
  c / nativeBanditProbability r D predict sigma S gamma x a

@[expose] def nativeBanditRemainder (r : NNReal) (D : Measure X)
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (gamma : ℝ) (x : X) (a : Fin K) (c : ℝ) : ℝ :=
  insertedPotential r D predict sigma (actionPenaltyScore predict S x a (nativeBanditUpdate r D predict sigma S gamma x a c)) x -
    insertedPotential r D predict sigma S x + nativeBanditUpdate r D predict sigma S gamma x a c *
      experimentProbability r D predict sigma S x a

theorem exp_one_sub_two_nonneg : 0 ≤ Real.exp 1 - 2 := by
  have h := Real.add_one_le_exp (1 : ℝ)
  linarith

theorem native_weighted_remainder_bound
    (r : NNReal) (hr : 0 < (r : ℝ)) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (lam B gamma : ℝ) (hK : 0 < K) (hg : 0 < gamma) (hgsmall : gamma ≤ 1 / 2)
    (hB : 1 ≤ B) (hcap : (K : ℝ) / gamma ≤ B)
    (hlam : 4 * (r : ℝ) * explorationLog K gamma ≤ lam)
    (hsigma : sigma ∈ scaleBox (X × Fin K) B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun j => (D {j.1}).toReal) lam B) (scaleBox (X × Fin K) B) sigma)
    (x : X) (a : Fin K) (hx : 0 < (D {x}).toReal) (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c ≤ 1) :
    nativeBanditProbability r D predict sigma S gamma x a * nativeBanditRemainder r D predict sigma S gamma x a c ≤
      (Real.exp 1 - 2) / (1 - gamma) * oldCurvatureRatio r D predict sigma S x a := by
  let p := experimentProbability r D predict sigma S x a
  let q := nativeBanditProbability r D predict sigma S gamma x a
  have hs : 0 < sigma (x, a) := by have h : (1 : ℝ) ≤ sigma (x, a) := hsigma.1 (x, a); linarith
  have hg1 : gamma ≤ 1 := by linarith
  have hq : 0 < q := exploration_positive hK hg (experimentProbability_nonneg r D predict sigma S x a) hg1
  have hb0 : 0 ≤ nativeBanditUpdate r D predict sigma S gamma x a c := div_nonneg hc0 hq.le
  have hbs : nativeBanditUpdate r D predict sigma S gamma x a c ≤ sigma (x, a) :=
    poisson_minimizer_controls_importance_update r hr D predict sigma S lam B gamma hK hg hgsmall hB hcap hlam
      hsigma hmin x a hx c hc1
  have hquad := poisson_inserted_quadratic_remainder r D predict sigma S x a hs
    (nativeBanditUpdate r D predict sigma S gamma x a c) hb0 hbs
  have hmix : (1 - gamma) * p ≤ q := by
    have hfloor : 0 ≤ gamma / (K : ℝ) := div_nonneg hg.le (Nat.cast_nonneg _)
    change (1 - gamma) * p ≤ (1 - gamma) * p + gamma / K
    linarith
  exact importance_quadratic_charge exp_one_sub_two_nonneg hs
    (experimentBeta_nonneg r D predict sigma S x a hs) (experimentBeta_le_probability r D predict sigma S x a)
    (experimentProbability_nonneg r D predict sigma S x a) hq (by linarith) hmix hc0 hc1 hquad

theorem native_expected_quadratic_remainder
    (r : NNReal) (hr : 0 < (r : ℝ)) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (lam B gamma : ℝ) (hK : 0 < K) (hg : 0 < gamma) (hgsmall : gamma ≤ 1 / 2)
    (hlamp : 0 < lam) (hB : 1 ≤ B) (hcap : (K : ℝ) / gamma ≤ B)
    (hlam : 4 * (r : ℝ) * explorationLog K gamma ≤ lam)
    (hsigma : sigma ∈ scaleBox (X × Fin K) B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun j => (D {j.1}).toReal) lam B) (scaleBox (X × Fin K) B) sigma)
    (c : X → Fin K → ℝ) (hc0 : ∀ x a, 0 ≤ c x a) (hc1 : ∀ x a, c x a ≤ 1) :
    (∫ x, ∑ a, nativeBanditProbability r D predict sigma S gamma x a *
      nativeBanditRemainder r D predict sigma S gamma x a (c x a) ∂D) ≤
      (Real.exp 1 - 2) / (1 - gamma) * (4 * Real.log (Fintype.card P) / lam + K / B) := by
  have hC : 0 ≤ (Real.exp 1 - 2) / (1 - gamma) := div_nonneg exp_one_sub_two_nonneg (by linarith)
  have hpoint : ∀ᵐ x ∂D, (∑ a, nativeBanditProbability r D predict sigma S gamma x a *
      nativeBanditRemainder r D predict sigma S gamma x a (c x a)) ≤
      (Real.exp 1 - 2) / (1 - gamma) * ∑ a, oldCurvatureRatio r D predict sigma S x a := by
    filter_upwards [ae_positive_context_mass D] with x hx
    have h := Finset.sum_le_sum (s := Finset.univ) fun a _ =>
      native_weighted_remainder_bound r hr D predict sigma S lam B gamma hK hg hgsmall hB hcap hlam
        hsigma hmin x a hx (c x a) (hc0 x a) (hc1 x a)
    simpa only [Finset.mul_sum] using h
  have h := integral_mono_ae (μ := D)
    (f := fun x => ∑ a, nativeBanditProbability r D predict sigma S gamma x a *
      nativeBanditRemainder r D predict sigma S gamma x a (c x a))
    (g := fun x => (Real.exp 1 - 2) / (1 - gamma) * ∑ a, oldCurvatureRatio r D predict sigma S x a)
    Integrable.of_finite Integrable.of_finite hpoint
  rw [integral_const_mul] at h
  exact h.trans (mul_le_mul_of_nonneg_left
    (native_expected_old_curvature r D predict sigma S lam B hlamp hB hsigma hmin) hC)

end

end PoissonAudit
