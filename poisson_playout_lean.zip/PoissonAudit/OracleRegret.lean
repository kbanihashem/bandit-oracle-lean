module
public import PoissonAudit.ManuscriptOracle
public section
open MeasureTheory Set
namespace PoissonAudit
noncomputable section

variable {X P : Type*} [MeasurableSpace X] {K : ℕ}

@[expose] def oracleOutcome (p : BanditParameters) (D : Measure X) [IsProbabilityMeasure D]
    (oracle : List (CostExample X K) → ℝ) (fallback : Fin K) (H : List (CostExample X K))
    (x : X) (o : paperNativeFiniteOutcome K p.delta) : ℝ :=
  let J := paperIterations K p.r p.lam p.B p.eps
  let m := paperTrials K p.delta
  let M := paperCap p.r (J+m) p.delta
  let eta := paperStep K p.r p.lam p.B p.eps
  let val := fun Q => -oracle (negateCostQuery Q)
  ((((nativeNoiseTapeLaw (K := K) p.r D J).prod (iidPool (insertedExperimentLaw p.r D K) m)).map
    (fun v => (executeArraySampler p.r p.lam p.B eta H val fallback M J m v.1 v.2 x).choice)) {o.1}).toReal *
    vectorValues (executeProbabilityTable K p.gamma m o.1).1 o.2

variable [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def oracleRegret (p : BanditParameters) (D : Measure X) [IsProbabilityMeasure D]
    (oracle : List (CostExample X K) → ℝ) (fallback : Fin K) (predict : P → X → Fin K) :
    (n : ℕ) → (Fin n → X × (Fin K → ℝ)) → List (CostExample X K) → (P → ℝ) → ℝ
  | 0, _, _, Q => treeBestScore Q
  | n+1, v, H, Q =>
    let x := (v 0).1
    let c := (v 0).2
    ∑ o, oracleOutcome p D oracle fallback H x o *
      (c o.2 + oracleRegret p D oracle fallback predict n (fun t => v t.succ)
        (manuscriptUpdate p.gamma H x o.1 o.2 (c o.2)) (fun i => Q i - c (predict i x)))

theorem oracleRegret_eq (p : BanditParameters) (hB : 1 ≤ p.B) (D : Measure X) [IsProbabilityMeasure D]
    (oracle : List (CostExample X K) → ℝ) (fallback : Fin K) (predict : P → X → Fin K)
    (hp : ∀ i, Measurable (predict i))
    (ho : ∀ R, (∀ i, oracle R ≤ queryScore predict R i) ∧ ∃ i, oracle R = queryScore predict R i)
    (n : ℕ) (v : Fin n → X × (Fin K → ℝ)) (H : List (CostExample X K)) (Q : P → ℝ) :
    let g := fun x i => predict i x
    let pred := fun (i : P) (y : P → Fin K) => y i
    oracleRegret p D oracle fallback predict n v H Q =
      schedulePayoff (paperNativeFiniteOutcomeWeight p.r (D.map g) pred p.lam p.B p.eps p.delta p.gamma hB)
        (paperNativeFiniteOutcomeUpdate pred p.delta p.gamma) Prod.snd pred n
        (fun t => (g (v t).1,(v t).2)) (queryScore predict H) Q := by
  let g := fun x i => predict i x
  let pred := fun (i : P) (y : P → Fin K) => y i
  have hg : Measurable g := Measurable.of_eval hp
  induction n generalizing H Q with
  | zero => rfl
  | succ n ih =>
    dsimp only [oracleRegret,schedulePayoff]
    apply Finset.sum_congr rfl
    intro o _
    rw [show oracleOutcome p D oracle fallback H (v 0).1 o = _ from
      manuscript_oracle_round p hB g hg D predict pred (fun _ _ => rfl) H oracle ho fallback (v 0).1 o]
    congr 2
    rw [ih,manuscript_scalar_feedback]
    rfl

theorem oracle_upper_bound (D : Measure X) [IsProbabilityMeasure D] (predict : P → X → Fin K)
    (hp : ∀ i, Measurable (predict i)) (T : ℕ) (hT : 0 < T) (hK : 2 ≤ K)
    (oracle : List (CostExample X K) → ℝ)
    (ho : ∀ R, (∀ i, oracle R ≤ queryScore predict R i) ∧ ∃ i, oracle R = queryScore predict R i)
    (fallback : Fin K) (c : Fin T → X → Fin K → ℝ) (hm : ∀ t a, Measurable (fun x => c t x a))
    (hc : ∀ t x a, c t x a ∈ Icc (0 : ℝ) 1) (L : ℝ) (hL : Real.log (2 * Fintype.card P) ≤ L) :
    (∫ xs, oracleRegret (manuscriptPlan K T L) D oracle fallback predict T
      (fun t => (xs t,c t (xs t))) [] (fun _ => 0) ∂iidPool D T) ≤
      38 * Real.exp 1 * Real.sqrt ((K : ℝ)*T*L) * Real.log (2*(K : ℝ)*T) := by
  have he (xs : Fin T → X) := oracleRegret_eq (manuscriptPlan K T L) (manuscriptPlan_box K T L hK)
    D oracle fallback predict hp ho T (fun t => (xs t,c t (xs t))) [] (fun _ => 0)
  simp_rw [he]
  rw [show queryScore predict [] = (fun _ => 0) from by funext i; simp [queryScore]]
  simpa only [manuscriptPayoff,queryScore,List.map_nil,List.sum_nil] using
    manuscript_upper_bound D predict hp T hT hK c hm hc L hL

end
end PoissonAudit
