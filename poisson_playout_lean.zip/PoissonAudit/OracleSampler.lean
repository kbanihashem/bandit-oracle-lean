module
public import PoissonAudit.NativeTapeFlags
public import PoissonAudit.NativeCappedChoiceBound
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section

@[expose] def replayTrialAction {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (records : List (ReplayRecord X K)) (x : X) (v : NativeNoise X K) : Fin K :=
  let current := fun y => (replayAt r lam B eta history oracle fallback records y).2
  valueOracleAction oracle fallback (history ++ (makeReplayRecord current v).2) x (fun a => current x a * v.1 a)

@[expose] def cappedOracleChoice {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (cap J m : ℕ) (tape : NativeNoiseTape X K J) (trials : Fin m → NativeNoise X K) (x : X) : EmpiricalChoice K m := by
  classical
  exact if nativeTapeCountsBounded cap J tape ∧ ∀ i, (trials i).2.1 ≤ cap then
    some (fun i => replayTrialAction r lam B eta history oracle fallback
      (buildReplayRecords r lam B eta history oracle fallback J tape) x (trials i)) else none

@[expose] def replayTrialQueries {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (records : List (ReplayRecord X K)) (x : X) (v : NativeNoise X K) : List (List (CostExample X K)) :=
  let current := fun y => (replayAt r lam B eta history oracle fallback records y).2
  replayQueries r lam B eta history oracle fallback records x ++
    (List.ofFn (fun i : Fin v.2.1 => replayQueries r lam B eta history oracle fallback records (v.2.2 i).1)).flatten ++
      actionValueQueries (history ++ (makeReplayRecord current v).2) x (fun a => current x a * v.1 a)

theorem replayTrialQueries_count {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (records : List (ReplayRecord X K)) (x : X) (v : NativeNoise X K) :
    (replayTrialQueries r lam B eta history oracle fallback records x v).length =
      ((v.2.1 + 1) * records.length + 1) * (K + 1) := by
  simp only [replayTrialQueries, List.length_append, List.length_flatten, List.map_ofFn, List.sum_ofFn,
    Function.comp_apply, replayQueries_count, actionValueQueries_count, Finset.sum_const,
    Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, Nat.cast_id]
  ring

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem replayTrialAction_native_ae (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ)
    (horacle : ∀ Q, oracle Q = treeBestScore (queryScore predict Q)) (fallback : Fin K)
    (lam B eta : ℝ) (hB : 1 ≤ B) (J : ℕ) (tape : NativeNoiseTape X K J)
    (hgood : nativeTapeGood r predict (queryScore predict history) lam B eta hB J tape) (x : X) :
    ∀ᵐ v ∂insertedExperimentLaw r D K,
      replayTrialAction r lam B eta history oracle fallback (buildReplayRecords r lam B eta history oracle fallback J tape) x v =
        experimentAction predict (nativeTapeState r predict (queryScore predict history) lam B eta hB J tape).2.val
          (queryScore predict history) x v := by
  let state := nativeTapeState r predict (queryScore predict history) lam B eta hB J tape
  have hscale : (fun y => (replayAt r lam B eta history oracle fallback
      (buildReplayRecords r lam B eta history oracle fallback J tape) y).2) = fun y a => state.2.val (y, a) := by
    funext y
    exact congrArg Prod.snd (replayAt_build_native r predict history oracle horacle fallback lam B eta hB J tape hgood y)
  have hpos (q : X × Fin K) : 0 < state.2.val q := lt_of_lt_of_le zero_lt_one (state.2.property.1 q)
  filter_upwards [native_any_maximizer_action r D predict state.2.val (queryScore predict history) hpos] with v hv
  unfold replayTrialAction
  rw [hscale]
  exact native_valueOracleAction_eq predict history oracle horacle fallback state.2.val v hv x
end
end PoissonAudit
