module
public import PoissonAudit.NativeSGDActionAccuracy
public import PoissonAudit.EmpiricalOutcomeLaw
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section

theorem sum_empiricalFrequency {A : Type*} [Fintype A] (m : ℕ) (hm : 0 < m) (u : Fin m → A) :
    (∑ a, empiricalFrequency m a u) = 1 := by
  classical
  unfold empiricalFrequency
  rw [← Finset.sum_div, Finset.sum_comm]
  have h (i : Fin m) : (∑ a, actionIndicator a (u i)) = 1 := by simp [actionIndicator]
  simp only [h, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, mul_one]
  exact div_self (Nat.cast_ne_zero.mpr (Nat.ne_of_gt hm))

@[expose] def empiricalMixture (K : ℕ) (gamma : ℝ) (m : ℕ) (u : Fin m → Fin K) (a : Fin K) : ℝ :=
  explorationProbability K gamma (empiricalFrequency m a u)

theorem empiricalMixture_sum {K : ℕ} (hK : 0 < K) (gamma : ℝ) (m : ℕ) (hm : 0 < m) (u : Fin m → Fin K) :
    (∑ a, empiricalMixture K gamma m u a) = 1 := by
  simp only [empiricalMixture, explorationProbability, Finset.sum_add_distrib, ← Finset.mul_sum,
    sum_empiricalFrequency m hm u, mul_one, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
  have hk : (K : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (Nat.ne_of_gt hK)
  field_simp
  ring

theorem empiricalMixture_floor {K : ℕ} (gamma : ℝ) (hg : gamma ≤ 1) (m : ℕ) (hm : 0 < m)
    (u : Fin m → Fin K) (a : Fin K) : gamma / K ≤ empiricalMixture K gamma m u a :=
  exploration_floor (empiricalFrequency_mem m hm a u).1 hg

theorem empiricalMixture_l1_contract {K : ℕ} (gamma : ℝ) (hg0 : 0 ≤ gamma) (hg1 : gamma ≤ 1)
    (m : ℕ) (u : Fin m → Fin K) (p : Fin K → ℝ) :
    (∑ a, |empiricalMixture K gamma m u a - explorationProbability K gamma (p a)|) ≤
      ∑ a, |empiricalFrequency m a u - p a| := by
  apply Finset.sum_le_sum
  intro a _
  have heq : empiricalMixture K gamma m u a - explorationProbability K gamma (p a) =
      (1 - gamma) * (empiricalFrequency m a u - p a) := by unfold empiricalMixture explorationProbability; ring
  rw [heq, abs_mul, abs_of_nonneg (sub_nonneg.mpr hg1)]
  exact mul_le_of_le_one_left (abs_nonneg _) (by linarith)

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def nativeEmpiricalRule (r : NNReal) (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (gamma : ℝ) (x : X) (m : ℕ) (u : Fin m → NativeNoise X K) (a : Fin K) : ℝ :=
  empiricalMixture K gamma m (fun i => experimentAction predict sigma S x (u i)) a

theorem native_empirical_rule_l1_error (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (gamma : ℝ)
    (hg0 : 0 ≤ gamma) (hg1 : gamma ≤ 1) (x : X) (m : ℕ) (hm : 0 < m) :
    (∫ u, ∑ a, |nativeEmpiricalRule r predict sigma S gamma x m u a -
      nativeBanditProbability r D predict sigma S gamma x a| ∂iidPool (insertedExperimentLaw r D K) m) ≤
        K * Real.sqrt (1 / m) := by
  let noise := insertedExperimentLaw r D K
  let W := experimentAction predict sigma S x
  let p := outcomeMass noise W
  let cat := (actionPMF p (outcomeMass_nonneg noise W) (sum_outcomeMass noise W (measurable_experimentAction predict sigma S x))).toMeasure
  let f := fun u : Fin m → Fin K => ∑ a, |empiricalMixture K gamma m u a - explorationProbability K gamma (p a)|
  have hmp := iid_outcome_measurePreserving noise W (measurable_experimentAction predict sigma S x) m
  have h := integral_map hmp.measurable.aemeasurable (f := f)
    (by rw [hmp.map_eq]; exact (measurable_of_finite f).aestronglyMeasurable)
  rw [hmp.map_eq] at h
  change (∫ u, f u ∂iidPool cat m) = ∫ u, f (fun i => W (u i)) ∂iidPool noise m at h
  change (∫ u, f (fun i => W (u i)) ∂iidPool noise m) ≤ _
  rw [← h]
  have hi := integral_mono (μ := iidPool cat m) (f := f)
    (g := fun u => ∑ a, |empiricalFrequency m a u - p a|) Integrable.of_finite Integrable.of_finite
    (fun u => empiricalMixture_l1_contract gamma hg0 hg1 m u p)
  have he := empiricalFrequency_l1_error p (outcomeMass_nonneg noise W)
    (sum_outcomeMass noise W (measurable_experimentAction predict sigma S x)) m hm
  exact hi.trans (by simpa only [Fintype.card_fin] using he)

theorem cardinal_sqrt_one_div_le {k delta : ℝ} {m : ℕ} (hk : 0 ≤ k) (hd : 0 < delta) (hm : 0 < m)
    (hbudget : k ^ 2 / delta ^ 2 ≤ m) : k * Real.sqrt (1 / m) ≤ delta := by
  have hm0 : (0 : ℝ) < m := by exact_mod_cast hm
  have hb := (div_le_iff₀ (sq_pos_of_pos hd)).mp hbudget
  have hsq : (k * Real.sqrt (1 / (m : ℝ))) ^ 2 ≤ delta ^ 2 := by
    rw [mul_pow, Real.sq_sqrt (div_nonneg (by norm_num) hm0.le), mul_one_div]
    exact (div_le_iff₀ hm0).mpr (by nlinarith only [hb])
  have hn : 0 ≤ k * Real.sqrt (1 / (m : ℝ)) := by positivity
  nlinarith
@[expose] def nativeEmpiricalTrials (K : ℕ) (delta : ℝ) : ℕ := max 1 ⌈16 * (K : ℝ) ^ 2 / delta ^ 2⌉₊

theorem nativeEmpiricalTrials_pos (K : ℕ) (delta : ℝ) : 0 < nativeEmpiricalTrials K delta :=
  lt_of_lt_of_le Nat.zero_lt_one (le_max_left _ _)

theorem nativeEmpiricalTrials_budget (K : ℕ) (delta : ℝ) :
    16 * (K : ℝ) ^ 2 / delta ^ 2 ≤ nativeEmpiricalTrials K delta :=
  (Nat.le_ceil _).trans (Nat.cast_le.mpr (le_max_right _ _))

theorem native_empirical_rule_accuracy (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (gamma delta : ℝ)
    (hg0 : 0 ≤ gamma) (hg1 : gamma ≤ 1) (hd : 0 < delta) (x : X) :
    (∫ u, ∑ a, |nativeEmpiricalRule r predict sigma S gamma x (nativeEmpiricalTrials K delta) u a -
      nativeBanditProbability r D predict sigma S gamma x a| ∂iidPool (insertedExperimentLaw r D K) (nativeEmpiricalTrials K delta)) ≤ delta / 4 := by
  have h := native_empirical_rule_l1_error r D predict sigma S gamma hg0 hg1 x _ (nativeEmpiricalTrials_pos K delta)
  have hb : (K : ℝ) ^ 2 / (delta / 4) ^ 2 ≤ nativeEmpiricalTrials K delta := by
    convert! nativeEmpiricalTrials_budget K delta using 1 <;> ring
  exact h.trans (cardinal_sqrt_one_div_le (Nat.cast_nonneg K) (by linarith) (nativeEmpiricalTrials_pos K delta) hb)

end
end PoissonAudit
