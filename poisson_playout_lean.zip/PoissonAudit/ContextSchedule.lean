module
public import PoissonAudit.ContextLawLift
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section

@[expose] def contextVectorCons {X : Type*} {n : ℕ} (v : X × (Fin n → X)) : Fin (n + 1) → X := Fin.cons v.1 v.2

theorem measurable_contextVectorCons {X : Type*} [MeasurableSpace X] (n : ℕ) : Measurable (@contextVectorCons X n) := by
  apply Measurable.of_eval
  intro i
  refine Fin.cases ?_ (fun j => ?_) i
  · exact measurable_fst
  · exact (measurable_pi_apply j).comp measurable_snd

theorem contextVectorCons_split_zero {X : Type*} {n : ℕ} (z : Fin (n + 1) → X) :
    contextVectorCons (splitMark 0 z) = z := by
  funext i
  refine Fin.cases ?_ (fun j => ?_) i <;> simp [contextVectorCons, splitMark]

theorem contextVectorCons_measurePreserving {X : Type*} [MeasurableSpace X]
    (D : Measure X) [SigmaFinite D] (n : ℕ) :
    MeasurePreserving (@contextVectorCons X n) (D.prod (iidPool D n)) (iidPool D (n + 1)) := by
  have hs := splitMark_measurePreserving D (0 : Fin (n + 1))
  refine ⟨measurable_contextVectorCons n, ?_⟩
  rw [← hs.map_eq, Measure.map_map (measurable_contextVectorCons n) hs.measurable]
  have he : (@contextVectorCons X n) ∘ splitMark 0 = id := funext contextVectorCons_split_zero
  rw [he, Measure.map_id]

@[expose] def transcriptContexts {X O : Type*} : (n : ℕ) → ContextTranscript X O n → (Fin n → X)
  | 0, _ => fun i => Fin.elim0 i
  | n + 1, path => Fin.cons path.1 (transcriptContexts n path.2.2)

@[expose] def transcriptOutcomes {X O : Type*} : (n : ℕ) → ContextTranscript X O n → (Fin n → O)
  | 0, _ => fun i => Fin.elim0 i
  | n + 1, path => Fin.cons path.2.1 (transcriptOutcomes n path.2.2)

theorem measurable_transcriptContexts {X O : Type*} [MeasurableSpace X] [MeasurableSpace O] (n : ℕ) :
    Measurable (@transcriptContexts X O n) := by
  induction n with
  | zero => exact measurable_const
  | succ n ih =>
    exact (measurable_contextVectorCons n).comp
      (measurable_fst.prodMk (ih.comp (measurable_snd.comp measurable_snd)))

theorem measurable_transcriptOutcomes {X O : Type*} [MeasurableSpace X] [MeasurableSpace O] (n : ℕ) :
    Measurable (@transcriptOutcomes X O n) := by
  induction n with
  | zero => exact measurable_const
  | succ n ih =>
    exact (measurable_contextVectorCons n).comp
      ((measurable_fst.comp measurable_snd).prodMk (ih.comp (measurable_snd.comp measurable_snd)))

theorem sum_restrict_fibers {X Y : Type*} [MeasurableSpace X] [MeasurableSpace Y]
    [MeasurableSingletonClass Y] [Fintype Y] (D : Measure X) (f : X → Y) (hf : Measurable f) :
    (∑ y, D.restrict (f ⁻¹' {y})) = D := by
  classical
  apply Measure.ext
  intro s hs
  simp only [Measure.finsetSum_apply, Measure.restrict_apply hs]
  have hdis : (↑(Finset.univ : Finset Y) : Set Y).PairwiseDisjoint (fun y => s ∩ (f ⁻¹' {y})) := by
    intro y _ z _ hyz
    apply Set.disjoint_left.mpr
    intro x hy hz
    exact hyz ((hy.2).symm.trans hz.2)
  have hmeas (y : Y) (_ : y ∈ (Finset.univ : Finset Y)) : MeasurableSet (s ∩ (f ⁻¹' {y})) := hs.inter (hf (measurableSet_singleton y))
  rw [← measure_biUnion_finset hdis hmeas]
  congr 1
  ext x
  simp
end
end PoissonAudit
