module
public import PoissonAudit.NativeSGDAccuracy
public import PoissonAudit.PoissonOverflow
public import PoissonAudit.NativeEmpiricalRule
public section
open scoped BigOperators
namespace PoissonAudit
noncomputable section

@[expose] def PowerBound (H : ℝ) (e : ℕ) (x : ℝ) : Prop := 0 ≤ x ∧ x ≤ H ^ e

theorem powerBound_mono {H x : ℝ} {a b : ℕ} (hH : 1 ≤ H) (hx : PowerBound H a x) (hab : a ≤ b) : PowerBound H b x :=
  ⟨hx.1, hx.2.trans (pow_le_pow_right₀ hH hab)⟩

theorem powerBound_one (H : ℝ) : PowerBound H 0 1 := ⟨zero_le_one, by simp⟩

theorem powerBound_mul {H x y : ℝ} {a b : ℕ} (hH : 0 ≤ H) (hx : PowerBound H a x) (hy : PowerBound H b y) :
    PowerBound H (a + b) (x * y) := by
  refine ⟨mul_nonneg hx.1 hy.1, ?_⟩
  rw [pow_add]
  exact mul_le_mul hx.2 hy.2 hy.1 (pow_nonneg hH _)

theorem powerBound_sq {H x : ℝ} {a : ℕ} (hH : 0 ≤ H) (hx : PowerBound H a x) : PowerBound H (2 * a) (x ^ 2) := by
  convert! powerBound_mul hH hx hx using 1 <;> ring

theorem powerBound_add {H x y : ℝ} {a b : ℕ} (hH : 2 ≤ H) (hx : PowerBound H a x) (hy : PowerBound H b y) :
    PowerBound H (max a b + 1) (x + y) := by
  have hxa := powerBound_mono (by linarith : 1 ≤ H) hx (le_max_left a b)
  have hya := powerBound_mono (by linarith : 1 ≤ H) hy (le_max_right a b)
  refine ⟨add_nonneg hx.1 hy.1, ?_⟩
  rw [pow_succ]
  have hm := mul_le_mul_of_nonneg_right hH (pow_nonneg (by linarith : 0 ≤ H) (max a b))
  nlinarith only [hm, hxa.2, hya.2]

theorem powerBound_const {H : ℝ} (hH : 2 ≤ H) (e : ℕ) : PowerBound H e ((2 : ℝ) ^ e) :=
  ⟨by positivity, pow_le_pow_left₀ (by norm_num) hH _⟩

theorem powerBound_scale {H x : ℝ} {a : ℕ} (hH : 2 ≤ H) (hx : PowerBound H a x) (b : ℕ) :
    PowerBound H (b + a) ((2 : ℝ) ^ b * x) :=
  powerBound_mul (by linarith) (powerBound_const hH b) hx

theorem powerBound_ceil_max {H x : ℝ} {a : ℕ} (hH : 2 ≤ H) (hx : PowerBound H a x) :
    PowerBound H (a + 1) ((max 1 ⌈x⌉₊ : ℕ) : ℝ) := by
  have hc := Nat.ceil_lt_add_one hx.1
  have hu : ((max 1 ⌈x⌉₊ : ℕ) : ℝ) ≤ 1 + x := by
    rw [Nat.cast_max, Nat.cast_one]
    exact max_le (by linarith [hx.1]) (by linarith)
  have hb := powerBound_add hH (powerBound_one H) hx
  simp only [Nat.zero_max] at hb
  exact ⟨Nat.cast_nonneg _, hu.trans hb.2⟩

theorem native_finite_budgets_power_bound (H : ℝ) (hH : 2 ≤ H) (r : NNReal) (K : ℕ) (lam B eps delta : ℝ)
    (hr : PowerBound H 3 (r : ℝ)) (hK : PowerBound H 1 K) (hlam : PowerBound H 4 lam)
    (hB : PowerBound H 3 B) (heps : PowerBound H 30 (1 / eps)) (hdelta : PowerBound H 4 (1 / delta)) :
    PowerBound H 82 (nativeSGDIterations r K lam B eps) ∧
    PowerBound H 15 (nativeEmpiricalTrials K delta) ∧
    PowerBound H 94 (nativeCountCap r (nativeSGDIterations r K lam B eps + nativeEmpiricalTrials K delta) delta) := by
  have hH0 : 0 ≤ H := by linarith
  have hr2 := powerBound_sq hH0 hr
  have hl2 := powerBound_sq hH0 hlam
  have hterm1 : PowerBound H 12 (64 * (r : ℝ) ^ 2) := by convert! powerBound_scale hH hr2 6 using 1 <;> norm_num
  have hterm2 : PowerBound H 9 (2 * lam ^ 2) := by convert! powerBound_scale hH hl2 1 using 1 <;> norm_num
  have hG : PowerBound H 14 (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2)) :=
    powerBound_mul hH0 hK (powerBound_add hH hterm1 hterm2)
  have hbaseJ : PowerBound H 81 (B ^ 2 * K * (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2)) / eps ^ 2) := by
    have h := powerBound_mul hH0 (powerBound_mul hH0 (powerBound_mul hH0 (powerBound_sq hH0 hB) hK) hG) (powerBound_sq hH0 heps)
    convert! h using 1 <;> ring
  have hJ : PowerBound H 82 (nativeSGDIterations r K lam B eps) := powerBound_ceil_max hH hbaseJ
  have hbaseM : PowerBound H 14 (16 * (K : ℝ) ^ 2 / delta ^ 2) := by
    have h := powerBound_mul hH0 (powerBound_scale hH (powerBound_sq hH0 hK) 4) (powerBound_sq hH0 hdelta)
    convert! h using 1 <;> ring
  have hm : PowerBound H 15 (nativeEmpiricalTrials K delta) := powerBound_ceil_max hH hbaseM
  have hcount : PowerBound H 83 ((nativeSGDIterations r K lam B eps + nativeEmpiricalTrials K delta : ℕ) : ℝ) := by
    have h := powerBound_add hH hJ hm
    change PowerBound H 83 ((nativeSGDIterations r K lam B eps : ℝ) + (nativeEmpiricalTrials K delta : ℝ)) at h
    simpa only [Nat.cast_add] using h
  have hbaseCap : PowerBound H 93 (8 * (r : ℝ) * ((nativeSGDIterations r K lam B eps + nativeEmpiricalTrials K delta : ℕ) : ℝ) / delta) := by
    have h := powerBound_mul hH0 (powerBound_mul hH0 (powerBound_scale hH hr 3) hcount) hdelta
    convert! h using 1 <;> ring
  exact ⟨hJ, hm, powerBound_ceil_max hH hbaseCap⟩
end
end PoissonAudit
