module

public import PoissonAudit.RealLaplace

public section

open MeasureTheory Set
open scoped ENNReal

namespace PoissonAudit

noncomputable section

@[expose] def laplaceSign (z : ℝ) : ℝ := if 0 < z then 1 else -1

@[fun_prop] theorem measurable_laplaceSign : Measurable laplaceSign := by
  unfold laplaceSign
  exact measurable_const.ite measurableSet_Ioi measurable_const

theorem abs_laplaceSign (z : ℝ) : |laplaceSign z| = 1 := by
  unfold laplaceSign
  split <;> norm_num

theorem integrable_realLaplace_exp {t : ℝ} (ht : |t| < 1) :
    Integrable (fun z => Real.exp (t * z)) realLaplace := by
  change Integrable _ (volume.withDensity (fun z => ENNReal.ofReal (realLaplaceDensity z)))
  rw [integrable_withDensity_iff_integrable_smul' measurable_realLaplaceDensity.ennreal_ofReal
    (Filter.Eventually.of_forall fun _ => ENNReal.ofReal_lt_top)]
  convert (integrable_tilted_laplace ht).div_const 2 using 1
  funext z
  change (ENNReal.ofReal (realLaplaceDensity z)).toReal * Real.exp (t * z) = _
  rw [ENNReal.toReal_ofReal (realLaplaceDensity_pos z).le]
  unfold realLaplaceDensity
  ring

theorem integrable_realLaplace_id : Integrable (fun z : ℝ => z) realLaplace := by
  have hp := integrable_realLaplace_exp (t := 1 / 2) (by norm_num)
  have hn := integrable_realLaplace_exp (t := -(1 / 2)) (by norm_num)
  apply ((hp.add hn).const_mul 2).mono' measurable_id.aestronglyMeasurable
  filter_upwards [] with z
  change |z| ≤ 2 * (Real.exp ((1 / 2) * z) + Real.exp (-(1 / 2) * z))
  rcases le_total 0 z with hz | hz
  · rw [abs_of_nonneg hz]
    nlinarith [Real.add_one_le_exp ((1 / 2) * z), Real.exp_pos (-(1 / 2) * z)]
  · rw [abs_of_nonpos hz]
    nlinarith [Real.add_one_le_exp (-(1 / 2) * z), Real.exp_pos ((1 / 2) * z)]

theorem integrable_realLaplace_sign : Integrable laplaceSign realLaplace := by
  exact Integrable.of_bound measurable_laplaceSign.aestronglyMeasurable 1
    (Filter.Eventually.of_forall fun z => by simp [Real.norm_eq_abs, abs_laplaceSign])

theorem integral_realLaplace_sign : (∫ z, laplaceSign z ∂realLaplace) = 0 := by
  rw [integral_realLaplace]
  have hl : (∫ z : ℝ in Iic 0, laplaceSign z * Real.exp (-|z|)) = -1 := by
    calc
      _ = ∫ z : ℝ in Iic 0, -Real.exp z := by
        apply setIntegral_congr_fun measurableSet_Iic
        intro z hz
        change laplaceSign z * Real.exp (-|z|) = -Real.exp z
        simp [laplaceSign, not_lt.mpr hz, abs_of_nonpos hz]
      _ = _ := by rw [integral_neg, integral_exp_Iic_zero]
  have hr : (∫ z : ℝ in Ioi 0, laplaceSign z * Real.exp (-|z|)) = 1 := by
    calc
      _ = ∫ z : ℝ in Ioi 0, Real.exp (-z) := by
        apply setIntegral_congr_fun measurableSet_Ioi
        intro z hz
        change laplaceSign z * Real.exp (-|z|) = Real.exp (-z)
        simp [laplaceSign, (show 0 < z from hz), abs_of_pos hz]
      _ = _ := integral_exp_neg_Ioi_zero
  have hi : Integrable (fun z => laplaceSign z * Real.exp (-|z|)) := by
    exact integrable_exp_neg_abs.bdd_mul (c := 1) measurable_laplaceSign.aestronglyMeasurable
      (Filter.Eventually.of_forall fun z => by simp [Real.norm_eq_abs, abs_laplaceSign])
  have hh := integral_add_compl (s := Iic (0 : ℝ)) measurableSet_Iic hi
  rw [compl_Iic, hl, hr] at hh
  rw [← hh]
  norm_num

theorem integral_realLaplace_exp_sign (t : ℝ) :
    (∫ z, Real.exp (t * laplaceSign z) ∂realLaplace) = Real.cosh t := by
  rw [integral_realLaplace]
  have hl : (∫ z : ℝ in Iic 0, Real.exp (t * laplaceSign z) * Real.exp (-|z|)) = Real.exp (-t) := by
    calc
      _ = ∫ z : ℝ in Iic 0, Real.exp (-t) * Real.exp z := by
        apply setIntegral_congr_fun measurableSet_Iic
        intro z hz
        change Real.exp (t * laplaceSign z) * Real.exp (-|z|) = Real.exp (-t) * Real.exp z
        simp [laplaceSign, not_lt.mpr hz, abs_of_nonpos hz]
      _ = _ := by rw [integral_const_mul, integral_exp_Iic_zero, mul_one]
  have hr : (∫ z : ℝ in Ioi 0, Real.exp (t * laplaceSign z) * Real.exp (-|z|)) = Real.exp t := by
    calc
      _ = ∫ z : ℝ in Ioi 0, Real.exp t * Real.exp (-z) := by
        apply setIntegral_congr_fun measurableSet_Ioi
        intro z hz
        change Real.exp (t * laplaceSign z) * Real.exp (-|z|) = Real.exp t * Real.exp (-z)
        simp [laplaceSign, (show 0 < z from hz), abs_of_pos hz]
      _ = _ := by rw [integral_const_mul, integral_exp_neg_Ioi_zero, mul_one]
  have hbound : ∀ z, ‖Real.exp (t * laplaceSign z)‖ ≤ Real.exp |t| := by
    intro z
    rw [Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]
    apply Real.exp_le_exp.mpr
    calc
      _ ≤ |t * laplaceSign z| := le_abs_self _
      _ = |t| := by rw [abs_mul, abs_laplaceSign, mul_one]
  have hi : Integrable (fun z => Real.exp (t * laplaceSign z) * Real.exp (-|z|)) :=
    integrable_exp_neg_abs.bdd_mul (by fun_prop)
      (Filter.Eventually.of_forall hbound)
  have hh := integral_add_compl (s := Iic (0 : ℝ)) measurableSet_Iic hi
  rw [compl_Iic, hl, hr] at hh
  rw [← hh, Real.cosh_eq]
  ring

theorem integral_realLaplace_id : (∫ z : ℝ, z ∂realLaplace) = 0 := by
  rw [integral_realLaplace]
  have hh := integral_neg_eq_self (fun z : ℝ => z * Real.exp (-|z|)) volume
  have heq : (∫ z : ℝ, -z * Real.exp (-|-z|)) = -(∫ z : ℝ, z * Real.exp (-|z|)) := by
    simp only [abs_neg, neg_mul, integral_neg]
  change (∫ z : ℝ, -z * Real.exp (-|-z|)) = _ at hh
  rw [heq] at hh
  linarith

end

end PoissonAudit
