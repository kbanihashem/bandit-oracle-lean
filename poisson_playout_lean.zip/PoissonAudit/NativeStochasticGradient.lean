module
public import PoissonAudit.NativeIdealRate
public import PoissonAudit.LaplaceSecondMomentBound
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem poisson_potential_supporting (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (sigma s : X × Fin K → ℝ) :
    affinePoolPotential (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict) sigma -
      affinePoolPotential (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict) s ≤
      ∑ j, (sigma j - s j) * (∫ pool, poissonCoefficient predict pool (poissonWinner predict sigma S pool) j
        ∂markedPoolLaw r (contextLaplaceLaw D K)) := by
  classical
  let mu := markedPoolLaw r (contextLaplaceLaw D K)
  have hpoint (pool) : affinePoolMax S (poissonCoefficient predict) sigma pool -
      affinePoolMax S (poissonCoefficient predict) s pool ≤
        ∑ j, (sigma j - s j) * poissonCoefficient predict pool (poissonWinner predict sigma S pool) j := by
    let w := poissonWinner predict sigma S pool
    have hw : affinePoolMax S (poissonCoefficient predict) sigma pool =
        S w + ∑ j, sigma j * poissonCoefficient predict pool w j := by
      apply le_antisymm
      · exact Finset.sup'_le _ _ (fun p _ => winner_maximizes (poissonScore predict sigma S pool) p)
      · exact Finset.le_sup' (s := Finset.univ) (f := fun p => S p + ∑ j, sigma j * poissonCoefficient predict pool p j) (Finset.mem_univ w)
    have hs := Finset.le_sup' (s := Finset.univ) (f := fun p => S p + ∑ j, s j * poissonCoefficient predict pool p j) (Finset.mem_univ w)
    rw [hw]
    change _ ≤ ∑ j, (sigma j - s j) * poissonCoefficient predict pool w j
    simp only [sub_mul, Finset.sum_sub_distrib]
    change S w + _ ≤ affinePoolMax S (poissonCoefficient predict) s pool at hs
    linarith
  have hi := integral_mono
    ((integrable_affinePoolMax mu S _ (integrable_poissonCoefficient r D predict) sigma).sub
      (integrable_affinePoolMax mu S _ (integrable_poissonCoefficient r D predict) s))
    (integrable_finsetSum _ (fun j _ => (integrable_poisson_winner_coefficient r D predict sigma S j).const_mul (sigma j - s j))) hpoint
  change (∫ pool, affinePoolMax S (poissonCoefficient predict) sigma pool - affinePoolMax S (poissonCoefficient predict) s pool ∂mu) ≤ _ at hi
  rw [integral_sub (integrable_affinePoolMax mu S _ (integrable_poissonCoefficient r D predict) sigma)
      (integrable_affinePoolMax mu S _ (integrable_poissonCoefficient r D predict) s),
    integral_finsetSum _ (fun j _ => (integrable_poisson_winner_coefficient r D predict sigma S j).const_mul (sigma j - s j))] at hi
  simp only [integral_const_mul] at hi
  exact hi

theorem log_penalty_supporting {Q : Type*} [Fintype Q] (w : Q → ℝ) (hw : ∀ j, 0 ≤ w j)
    (lam B : ℝ) (hlam : 0 ≤ lam) (hB : 0 < B) (sigma s : Q → ℝ)
    (hsigma : ∀ j, 0 < sigma j) (hs : ∀ j, 0 < s j) :
    scalePenalty w lam B sigma - scalePenalty w lam B s ≤
      lam * ∑ j, w j * ((s j - sigma j) / sigma j) := by
  classical
  have hlog (j : Q) : Real.log (B / sigma j) - Real.log (B / s j) ≤ (s j - sigma j) / sigma j := by
    have h := Real.log_le_sub_one_of_pos (div_pos (hs j) (hsigma j))
    rw [Real.log_div hB.ne' (hsigma j).ne', Real.log_div hB.ne' (hs j).ne']
    rw [Real.log_div (hs j).ne' (hsigma j).ne'] at h
    have heq : (s j - sigma j) / sigma j = s j / sigma j - 1 := by field_simp [(hsigma j).ne']
    rw [heq]
    linarith
  have hsum := Finset.sum_le_sum (s := Finset.univ) (fun j _ => mul_le_mul_of_nonneg_left (hlog j) (hw j))
  have h := mul_le_mul_of_nonneg_left hsum hlam
  simpa only [scalePenalty, mul_sub, Finset.sum_sub_distrib] using h

theorem poisson_objective_supporting (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (sigma s : X × Fin K → ℝ)
    (lam B : ℝ) (hlam : 0 ≤ lam) (hB : 0 < B)
    (hsigma : ∀ j, 0 < sigma j) (hs : ∀ j, 0 < s j) :
    scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun j => (D {j.1}).toReal) lam B sigma -
      scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
        (fun j => (D {j.1}).toReal) lam B s ≤
      ∑ j, (sigma j - s j) * poissonCoordinateGradient r D predict sigma S lam j := by
  have hF := poisson_potential_supporting r D predict S sigma s
  have hC := log_penalty_supporting (fun j : X × Fin K => (D {j.1}).toReal)
    (fun _ => ENNReal.toReal_nonneg) lam B hlam hB sigma s hsigma hs
  have heq : (∑ j, (sigma j - s j) * poissonCoordinateGradient r D predict sigma S lam j) =
      (∑ j, (sigma j - s j) * (∫ pool, poissonCoefficient predict pool (poissonWinner predict sigma S pool) j
        ∂markedPoolLaw r (contextLaplaceLaw D K))) +
        lam * ∑ j, (D {j.1}).toReal * ((s j - sigma j) / sigma j) := by
    simp only [poissonCoordinateGradient, mul_sub, Finset.sum_sub_distrib, Finset.mul_sum]
    rw [sub_eq_add_neg]
    congr 1
    rw [← Finset.sum_neg_distrib]
    apply Finset.sum_congr rfl
    intro j _
    ring
  rw [heq]
  unfold scaleObjective
  linarith
end
end PoissonAudit
