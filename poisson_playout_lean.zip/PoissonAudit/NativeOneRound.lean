module

public import PoissonAudit.NativeInsertionCharge
public import PoissonAudit.Algebra

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit
noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def nativeVariationalValue (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B : ℝ) (hB : 1 ≤ B) (S : P → ℝ) : ℝ :=
  variationalValue (markedPoolLaw r (contextLaplaceLaw D K)) (poissonCoefficient predict)
    (integrable_poissonCoefficient r D predict) (fun j => (D {j.1}).toReal) lam B hB S

theorem nativeVariationalValue_eq_minimum (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B : ℝ) (hB : 1 ≤ B) (S : P → ℝ) (sigma : X × Fin K → ℝ)
    (hsigma : sigma ∈ scaleBox (X × Fin K) B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun j => (D {j.1}).toReal) lam B) (scaleBox (X × Fin K) B) sigma) :
    nativeVariationalValue r D predict lam B hB S =
      scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
        (fun j => (D {j.1}).toReal) lam B sigma := by
  apply le_antisymm
  · exact variationalValue_le _ _ (integrable_poissonCoefficient r D predict) _ lam B hB S sigma hsigma
  · exact hmin (optimalScale_spec _ _ (integrable_poissonCoefficient r D predict) _ lam B hB S).1

theorem nativeVariationalValue_envelope (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B : ℝ) (hB : 1 ≤ B) (S T : P → ℝ) (sigma : X × Fin K → ℝ)
    (hsigma : sigma ∈ scaleBox (X × Fin K) B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun j => (D {j.1}).toReal) lam B) (scaleBox (X × Fin K) B) sigma) :
    nativeVariationalValue r D predict lam B hB T - nativeVariationalValue r D predict lam B hB S ≤
      affinePoolPotential (markedPoolLaw r (contextLaplaceLaw D K)) T (poissonCoefficient predict) sigma -
      affinePoolPotential (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict) sigma := by
  rw [nativeVariationalValue_eq_minimum r D predict lam B hB S sigma hsigma hmin]
  have h := variationalValue_le _ _ (integrable_poissonCoefficient r D predict) (fun j => (D {j.1}).toReal) lam B hB T sigma hsigma
  unfold scaleObjective at h ⊢
  change nativeVariationalValue r D predict lam B hB T ≤ _ at h
  linarith

theorem nativeBandit_decomposition (r : NNReal) (D : Measure X) (predict : P → X → Fin K)
    (sigma : X × Fin K → ℝ) (S : P → ℝ) (gamma : ℝ) (x : X) (a : Fin K) (c : ℝ) :
    affinePoolPotential (markedPoolLaw r (contextLaplaceLaw D K))
      (actionPenaltyScore predict S x a (nativeBanditUpdate r D predict sigma S gamma x a c))
        (poissonCoefficient predict) sigma -
      affinePoolPotential (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict) sigma =
      -nativeBanditUpdate r D predict sigma S gamma x a c * experimentProbability r D predict sigma S x a +
        nativeBanditRemainder r D predict sigma S gamma x a c + nativeBanditInsertion r D predict sigma S gamma x a c := by
  unfold nativeBanditRemainder nativeBanditInsertion insertionGap
  ring

theorem native_exploration_charge (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (gamma : ℝ)
    (hK : 0 < K) (hg : 0 ≤ gamma) (x : X) (c : Fin K → ℝ)
    (hc0 : ∀ a, 0 ≤ c a) (hc1 : ∀ a, c a ≤ 1) :
    (∑ a, (nativeBanditProbability r D predict sigma S gamma x a -
      experimentProbability r D predict sigma S x a) * c a) ≤ gamma := by
  have hk : (K : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (Nat.ne_of_gt hK)
  have hu : (∑ _a : Fin K, (1 : ℝ) / K) = 1 := by simp [hk]
  have h := exploration_charge (experimentProbability r D predict sigma S x) (fun _ : Fin K => (1 : ℝ) / K)
    c gamma hg (fun a => experimentProbability_nonneg r D predict sigma S x a)
    (fun _ => div_nonneg zero_le_one (Nat.cast_nonneg K)) hu hc0 hc1
  simpa only [nativeBanditProbability, explorationProbability, mul_one_div] using h

theorem native_one_round_bound
    (r : NNReal) (hr : 0 < (r : ℝ)) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (lam B gamma : ℝ) (hK : 0 < K) (hg : 0 < gamma) (hgsmall : gamma ≤ 1 / 2)
    (hlamp : 0 < lam) (hB : 1 ≤ B) (hcap : (K : ℝ) / gamma ≤ B)
    (hlam : 4 * (r : ℝ) * explorationLog K gamma ≤ lam)
    (hsigma : sigma ∈ scaleBox (X × Fin K) B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun j => (D {j.1}).toReal) lam B) (scaleBox (X × Fin K) B) sigma)
    (c : X → Fin K → ℝ) (hc0 : ∀ x a, 0 ≤ c x a) (hc1 : ∀ x a, c x a ≤ 1) :
    (∫ x, (∑ a, nativeBanditProbability r D predict sigma S gamma x a * c x a) +
      ∑ a, nativeBanditProbability r D predict sigma S gamma x a *
        (nativeVariationalValue r D predict lam B hB
          (actionPenaltyScore predict S x a (nativeBanditUpdate r D predict sigma S gamma x a (c x a))) -
            nativeVariationalValue r D predict lam B hB S) ∂D) ≤
      gamma + (Real.exp 1 - 2) / (1 - gamma) * (4 * Real.log (Fintype.card P) / lam + K / B) +
        2 * Real.exp 1 * Real.log (Fintype.card P) / r := by
  have hpoint (x : X) := one_round_bound
    (nativeBanditProbability r D predict sigma S gamma x)
    (experimentProbability r D predict sigma S x)
    (fun a => nativeBanditUpdate r D predict sigma S gamma x a (c x a)) (c x)
    (fun a => affinePoolPotential (markedPoolLaw r (contextLaplaceLaw D K))
      (actionPenaltyScore predict S x a (nativeBanditUpdate r D predict sigma S gamma x a (c x a)))
        (poissonCoefficient predict) sigma -
        affinePoolPotential (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict) sigma)
    (fun a => nativeVariationalValue r D predict lam B hB
      (actionPenaltyScore predict S x a (nativeBanditUpdate r D predict sigma S gamma x a (c x a))) -
        nativeVariationalValue r D predict lam B hB S)
    (fun a => nativeBanditRemainder r D predict sigma S gamma x a (c x a))
    (fun a => nativeBanditInsertion r D predict sigma S gamma x a (c x a)) gamma
    (∑ a, nativeBanditProbability r D predict sigma S gamma x a * nativeBanditRemainder r D predict sigma S gamma x a (c x a))
    (∑ a, nativeBanditProbability r D predict sigma S gamma x a * nativeBanditInsertion r D predict sigma S gamma x a (c x a))
    (fun a => (exploration_positive hK hg (experimentProbability_nonneg r D predict sigma S x a) (by linarith)).le)
    (fun a => by
      have hq := exploration_positive hK hg (experimentProbability_nonneg r D predict sigma S x a) (by linarith)
      change nativeBanditProbability r D predict sigma S gamma x a *
        (c x a / nativeBanditProbability r D predict sigma S gamma x a) = c x a
      exact mul_div_cancel₀ _ hq.ne')
    (fun a => nativeBandit_decomposition r D predict sigma S gamma x a (c x a))
    (fun a => nativeVariationalValue_envelope r D predict lam B hB S _ sigma hsigma hmin)
    (native_exploration_charge r D predict sigma S gamma hK hg.le x (c x) (hc0 x) (hc1 x)) le_rfl le_rfl
  have hi := integral_mono (μ := D) (f := _) (g := _)
    Integrable.of_finite Integrable.of_finite hpoint
  let rem := fun x => ∑ a, nativeBanditProbability r D predict sigma S gamma x a * nativeBanditRemainder r D predict sigma S gamma x a (c x a)
  let ins := fun x => ∑ a, nativeBanditProbability r D predict sigma S gamma x a * nativeBanditInsertion r D predict sigma S gamma x a (c x a)
  have hsum : (∫ x, gamma + rem x + ins x ∂D) = gamma + (∫ x, rem x ∂D) + (∫ x, ins x ∂D) := by
    rw [integral_add (f := fun x => gamma + rem x) (g := ins) Integrable.of_finite Integrable.of_finite,
      integral_add (f := fun _ => gamma) (g := rem) (integrable_const _) Integrable.of_finite,
      integral_const, probReal_univ, one_smul]
  change _ ≤ ∫ x, gamma + rem x + ins x ∂D at hi
  rw [hsum] at hi
  have hc := native_expected_quadratic_remainder r hr D predict sigma S lam B gamma hK hg hgsmall hlamp hB hcap hlam hsigma hmin c hc0 hc1
  have he := native_expected_insertion_charge r hr D predict sigma S lam B gamma hK hg hgsmall hB hcap hlam hsigma hmin c hc0 hc1
  change _ ≤ _ + (∫ x, rem x ∂D) + (∫ x, ins x ∂D) at hi
  change (∫ x, rem x ∂D) ≤ _ at hc
  change (∫ x, ins x ∂D) ≤ _ at he
  linarith

end
end PoissonAudit
