module
public import PoissonAudit.NativeSGDMeasurable
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] abbrev NativeSGDState (X : Type*) (K : ℕ) (B : ℝ) :=
  NativeScaleBox X K B × NativeScaleBox X K B

@[expose] def nativeBoxAverage (B : ℝ) (j : ℕ) (avg curr : NativeScaleBox X K B) : NativeScaleBox X K B := by
  let a : ℝ := j / ((j : ℝ) + 1)
  let b : ℝ := 1 / ((j : ℝ) + 1)
  have hd : 0 < (j : ℝ) + 1 := by positivity
  have hab : a + b = 1 := by dsimp [a, b]; field_simp
  exact ⟨a • avg.val + b • curr.val,
    (convex_Icc (1 : X × Fin K → ℝ) (fun _ => B)) avg.property curr.property
      (div_nonneg (Nat.cast_nonneg _) hd.le) (one_div_nonneg.mpr hd.le) hab⟩

@[expose] def nativeSGDTransition (r : NNReal) (predict : P → X → Fin K) (S : P → ℝ)
    (lam B eta : ℝ) (hB : 1 ≤ B) (j : ℕ) (state : NativeSGDState X K B) (v : NativeNoise X K) : NativeSGDState X K B :=
  (⟨nativeSGDNext r predict S lam B eta state.1.val v,
      boxGradientStep_feasible state.1.val (nativeSampledGradient r predict state.1.val S lam v) B eta hB⟩,
    nativeBoxAverage B j state.2 state.1)

theorem measurable_nativeSGDTransition (r : NNReal) (predict : P → X → Fin K) (S : P → ℝ)
    (lam B eta : ℝ) (hB : 1 ≤ B) (j : ℕ) :
    Measurable (fun v : NativeSGDState X K B × NativeNoise X K => nativeSGDTransition r predict S lam B eta hB j v.1 v.2) := by
  apply Measurable.prodMk
  · apply Measurable.subtype_mk
    exact (measurable_joint_nativeSGDNext r predict S lam B eta).comp
      ((measurable_subtype_coe.comp (measurable_fst.comp measurable_fst)).prodMk measurable_snd)
  · apply Measurable.subtype_mk
    apply Measurable.of_eval
    intro a
    exact (measurable_const.mul ((measurable_pi_apply a).comp
      (measurable_subtype_coe.comp (measurable_snd.comp measurable_fst)))).add
      (measurable_const.mul ((measurable_pi_apply a).comp
        (measurable_subtype_coe.comp (measurable_fst.comp measurable_fst))))

@[expose] def nativeSGDStateLaw (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ) (hB : 1 ≤ B) : ℕ → Measure (NativeSGDState X K B)
  | 0 => Measure.dirac (nativeUnitScale B hB, nativeUnitScale B hB)
  | j + 1 => ((nativeSGDStateLaw r D predict S lam B eta hB j).prod (insertedExperimentLaw r D K)).map
      (fun v => nativeSGDTransition r predict S lam B eta hB j v.1 v.2)

instance nativeSGDStateLaw_isProbability (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ) (hB : 1 ≤ B) (j : ℕ) :
    IsProbabilityMeasure (nativeSGDStateLaw r D predict S lam B eta hB j) := by
  induction j with
  | zero => exact inferInstanceAs (IsProbabilityMeasure (Measure.dirac (nativeUnitScale B hB, nativeUnitScale B hB)))
  | succ j ih =>
    letI := ih
    exact (Measure.isProbabilityMeasure_map_iff (measurable_nativeSGDTransition r predict S lam B eta hB j).aemeasurable).mpr inferInstance

theorem integrable_continuous_nativeSGDState (B : ℝ) (mu : Measure (NativeSGDState X K B)) [IsFiniteMeasure mu]
    (f : NativeSGDState X K B → ℝ) (hf : Continuous f) : Integrable f mu := by
  obtain ⟨C, hC⟩ := isCompact_univ.exists_bound_of_continuousOn hf.continuousOn
  exact Integrable.of_bound hf.measurable.aestronglyMeasurable C
    (Filter.Eventually.of_forall fun x => hC x (Set.mem_univ x))

@[expose] def nativeSGDLyapunov (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ) (s : NativeScaleBox X K B)
    (j : ℕ) (state : NativeSGDState X K B) : ℝ :=
  2 * eta * j * (nativeBoxObjective r D predict S lam B state.2 - nativeBoxObjective r D predict S lam B s) +
    weightedSquareDistance (fun a => (D {a.1}).toReal) state.1.val s.val

theorem continuous_nativeSGDLyapunov (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ) (hB : 1 ≤ B) (s : NativeScaleBox X K B) (j : ℕ) :
    Continuous (nativeSGDLyapunov r D predict S lam B eta s j) := by
  apply Continuous.add
  · exact continuous_const.mul (((continuous_nativeBoxObjective r D predict S lam B hB).comp continuous_snd).sub continuous_const)
  · apply continuous_finsetSum
    intro a _
    exact continuous_const.mul ((((continuous_apply a).comp (continuous_subtype_val.comp continuous_fst)).sub continuous_const).pow 2)
end
end PoissonAudit
