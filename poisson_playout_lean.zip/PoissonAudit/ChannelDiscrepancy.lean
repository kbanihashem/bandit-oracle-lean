module

public import PoissonAudit.DensityHellinger

public section

open MeasureTheory InformationTheory
open scoped ENNReal

namespace PoissonAudit

theorem sqrt_normalization_identity {r p : ℝ} (hr : 0 ≤ r) (hp : 0 < p) :
    (Real.sqrt r - Real.sqrt p) ^ 2 = p * (Real.sqrt (r / p) - 1) ^ 2 := by
  have hpS : 0 < Real.sqrt p := Real.sqrt_pos.mpr hp
  have hs : Real.sqrt (r / p) * Real.sqrt p = Real.sqrt r := by
    rw [Real.sqrt_div hr p, div_mul_cancel₀ _ hpS.ne']
  calc
    _ = (Real.sqrt (r / p) * Real.sqrt p - Real.sqrt p) ^ 2 := by rw [hs]
    _ = (Real.sqrt p) ^ 2 * (Real.sqrt (r / p) - 1) ^ 2 := by ring
    _ = _ := by rw [Real.sq_sqrt hp.le]

theorem channel_discrepancy_le_posterior_kl {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) [IsProbabilityMeasure mu]
    (r : Omega → ℝ) (hr : Measurable r) (hr0 : ∀ x, 0 ≤ r x)
    (hri : Integrable r mu) (p : ℝ) (hp : 0 < p)
    (hpmean : (∫ x, r x ∂mu) = p) :
    ENNReal.ofReal (∫ x, (Real.sqrt (r x) - Real.sqrt p) ^ 2 ∂mu) ≤
      ENNReal.ofReal p * klDiv (mu.withDensity (fun x => ENNReal.ofReal (r x / p))) mu := by
  have hnorm : (∫ x, r x / p ∂mu) = 1 := by rw [integral_div, hpmean]; exact div_self hp.ne'
  have h := density_hellinger_le_kl mu (fun x => r x / p) (hr.div_const p)
    (fun x => div_nonneg (hr0 x) hp.le) (hri.div_const p) hnorm
  have heq : (∫ x, (Real.sqrt (r x) - Real.sqrt p) ^ 2 ∂mu) =
      p * ∫ x, (Real.sqrt (r x / p) - 1) ^ 2 ∂mu := by
    simp_rw [sqrt_normalization_identity (hr0 _) hp]
    exact integral_const_mul _ _
  rw [heq, ENNReal.ofReal_mul hp.le]
  exact mul_le_mul_right h (ENNReal.ofReal p)

end PoissonAudit
