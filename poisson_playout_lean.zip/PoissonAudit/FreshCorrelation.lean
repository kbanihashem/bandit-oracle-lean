module

public import PoissonAudit.VectorEventTail

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

theorem integral_fresh_count_marks {A B C : Type*}
    [MeasurableSpace A] [MeasurableSpace B] [MeasurableSpace C]
    (mu : Measure A) (nu : Measure B) (rho : Measure C)
    [IsProbabilityMeasure mu] [IsProbabilityMeasure nu] [IsProbabilityMeasure rho]
    (f : A × (B × C) → ℝ) (hf : Integrable f (mu.prod (nu.prod rho))) :
    (∫ v, f v ∂mu.prod (nu.prod rho)) = ∫ b, ∫ a, ∫ c, f (a, (b, c)) ∂rho ∂mu ∂nu := by
  have hmp := measurePreserving_prodAssoc mu nu rho
  have hi := hmp.integrable_comp_of_integrable hf
  calc
    _ = ∫ v : (A × B) × C, f (MeasurableEquiv.prodAssoc v) ∂(mu.prod nu).prod rho :=
      (hmp.integral_comp' f).symm
    _ = ∫ v : A × B, ∫ c, f (v.1, (v.2, c)) ∂rho ∂mu.prod nu := integral_prod _ hi
    _ = _ := integral_prod_symm _ hi.integral_prod_left

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem measurable_insertedActionCoefficient (predict : P → X → Fin K)
    (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) (n : ℕ) :
    Measurable (insertedActionCoefficient predict sigma S x a n) := by
  classical
  have hm : Measurable (fun v : (Fin K → ℝ) × (Fin n → X × (Fin K → ℝ)) => ((x, v.1), v.2)) :=
    (measurable_const.prodMk measurable_fst).prodMk measurable_snd
  have h := (measurable_insertedContribution predict sigma S (x, a) n).comp hm
  convert! h using 1
  funext v
  simp [Function.comp_def, insertedContribution, singleMarkCoefficient, insertedActionCoefficient]

theorem experimentAlpha_eq_insertedAlpha (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) :
    experimentAlpha r D predict sigma S x a = insertedAlpha r D predict sigma S x a := by
  classical
  let g := fun v : (Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ))) =>
    (experimentActionEvent predict sigma S x a).indicator (fun _ => (1 : ℝ)) v * v.1 a
  have hf : Integrable g ((laplaceMeasure K).prod
      ((ProbabilityTheory.poissonMeasure r).prod (markSequence (contextLaplaceLaw D K)))) :=
    integrable_experiment_correlation r D predict sigma S x a
  change (∫ v, g v ∂(laplaceMeasure K).prod
    ((ProbabilityTheory.poissonMeasure r).prod (markSequence (contextLaplaceLaw D K)))) = _
  rw [integral_fresh_count_marks _ _ _ g hf]
  unfold insertedAlpha
  apply integral_congr_ae
  filter_upwards [] with n
  apply integral_congr_ae
  filter_upwards [] with z0
  have heq (u : ℕ → X × (Fin K → ℝ)) :
      g (z0, (n, u)) = insertedActionCoefficient predict sigma S x a n (z0, poolPrefix n u) := by
    simp only [g, Set.indicator_apply, experimentActionEvent, outcomeEvent,
      Set.mem_setOf_eq, experimentAction]
    rw [experimentWinner_eq_insertedMarkWinner]
    by_cases h : predict (insertedMarkWinner predict sigma S ((x, z0), poolPrefix n u)) x = a
    · simp [insertedActionCoefficient, h]
    · simp [insertedActionCoefficient, h]
  simp_rw [heq]
  have hmp := poolPrefix_measurePreserving (contextLaplaceLaw D K) n
  have hmeas : Measurable (fun pool => insertedActionCoefficient predict sigma S x a n (z0, pool)) :=
    (measurable_insertedActionCoefficient predict sigma S x a n).comp
      (measurable_const.prodMk measurable_id)
  have h := integral_map hmp.measurable.aemeasurable
    (f := fun pool => insertedActionCoefficient predict sigma S x a n (z0, pool))
    (by rw [hmp.map_eq]; exact hmeas.aestronglyMeasurable)
  rw [hmp.map_eq] at h
  exact h.symm

end

end PoissonAudit
