module

public import PoissonAudit.FreshCorrelation
public import PoissonAudit.ExplorationProbability

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem poisson_minimizer_controls_inverse_probability
    (r : NNReal) (hr : 0 < (r : ℝ)) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (lam B gamma : ℝ) (hK : 0 < K) (hg : 0 < gamma) (hgsmall : gamma ≤ 1 / 2)
    (hB : 1 ≤ B) (hcap : (K : ℝ) / gamma ≤ B)
    (hlam : 4 * (r : ℝ) * explorationLog K gamma ≤ lam)
    (hsigma : sigma ∈ scaleBox (X × Fin K) B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun j => (D {j.1}).toReal) lam B) (scaleBox (X × Fin K) B) sigma)
    (x : X) (a : Fin K) (hx : 0 < (D {x}).toReal) :
    1 / explorationProbability K gamma (experimentProbability r D predict sigma S x a) ≤ sigma (x, a) := by
  let p := experimentProbability r D predict sigma S x a
  let q := explorationProbability K gamma p
  let ell := explorationLog K gamma
  have hp0 : 0 ≤ p := experimentProbability_nonneg r D predict sigma S x a
  have hg1 : gamma ≤ 1 := by linarith
  have hq : 0 < q := exploration_positive hK hg hp0 hg1
  have hell1 : 1 ≤ ell := exploration_log_ge_one hK hg hg1
  have hellq : 1 - Real.log q ≤ ell := exploration_log_controls hK hg hp0 hg1
  apply scale_controls_update_weak hr (by linarith : 0 < ell) hq
    (le_trans (by norm_num : (0 : ℝ) ≤ 1) (hsigma.1 (x, a))) (hsigma.2 (x, a)) hlam
  · intro hinterior
    refine ⟨experimentAlpha r D predict sigma S x a, ?_, ?_⟩
    · exact experimentAlpha_probability_charge r D predict sigma S x a q ell hq
        (exploration_dominates_half hg.le hp0 hgsmall) hell1 hellq
    · rw [experimentAlpha_eq_insertedAlpha]
      exact poisson_minimizer_first_order_lower r D predict sigma S lam B hB hsigma hmin
        (x, a) hinterior hx
  · exact exploration_cap hK hg hp0 hg1 hcap

theorem poisson_minimizer_controls_importance_update
    (r : NNReal) (hr : 0 < (r : ℝ)) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (lam B gamma : ℝ) (hK : 0 < K) (hg : 0 < gamma) (hgsmall : gamma ≤ 1 / 2)
    (hB : 1 ≤ B) (hcap : (K : ℝ) / gamma ≤ B)
    (hlam : 4 * (r : ℝ) * explorationLog K gamma ≤ lam)
    (hsigma : sigma ∈ scaleBox (X × Fin K) B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun j => (D {j.1}).toReal) lam B) (scaleBox (X × Fin K) B) sigma)
    (x : X) (a : Fin K) (hx : 0 < (D {x}).toReal) (c : ℝ) (hc : c ≤ 1) :
    c / explorationProbability K gamma (experimentProbability r D predict sigma S x a) ≤ sigma (x, a) := by
  have hq : 0 < explorationProbability K gamma (experimentProbability r D predict sigma S x a) :=
    exploration_positive hK hg (experimentProbability_nonneg r D predict sigma S x a) (by linarith)
  exact (div_le_div_of_nonneg_right hc hq.le).trans
    (poisson_minimizer_controls_inverse_probability r hr D predict sigma S lam B gamma hK hg hgsmall
      hB hcap hlam hsigma hmin x a hx)

end

end PoissonAudit
