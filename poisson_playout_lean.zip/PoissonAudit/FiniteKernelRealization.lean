module
public import PoissonAudit.FiniteKernelMixture
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {A Omega Lambda : Type*} [Fintype A] [MeasurableSpace A] [MeasurableSingletonClass A]
    [MeasurableSpace Omega] [MeasurableSpace Lambda]

theorem finite_measure_eq_of_integrals (mu nu : Measure A) [IsProbabilityMeasure mu] [IsProbabilityMeasure nu]
    (h : ∀ f : A → ℝ, (∫ a, f a ∂mu) = ∫ a, f a ∂nu) : mu = nu := by
  classical
  apply Measure.ext_of_singleton
  intro a
  apply (ENNReal.toReal_eq_toReal_iff' (measure_ne_top mu _) (measure_ne_top nu _)).mp
  have he := h (fun b => if b = a then 1 else 0)
  have hmu := integral_if_outcome mu id (measurable_of_finite _) a
  have hnu := integral_if_outcome nu id (measurable_of_finite _) a
  simp only [id_eq] at hmu hnu
  rw [hmu, hnu] at he
  simpa [outcomeMass, outcomeEvent, id_eq, Measure.real] using he

theorem finiteKernelMixture_realization (mu : Measure Omega) (noise : Measure Lambda)
    [IsProbabilityMeasure mu] [IsProbabilityMeasure noise] (W : Omega × Lambda → A) (hW : Measurable W)
    (q : Omega → A → ℝ) (hq : ∀ z a, 0 ≤ q z a) (hsum : ∀ z, ∑ a, q z a = 1)
    (hqm : ∀ a, Measurable (fun z => q z a))
    (htest : ∀ z (f : A → ℝ), (∫ v, f (W (z, v)) ∂noise) = ∑ a, q z a * f a) :
    MeasurePreserving W (mu.prod noise) (finiteKernelMixtureLaw mu q hq hsum hqm).toMeasure := by
  refine ⟨hW, ?_⟩
  haveI : IsProbabilityMeasure ((mu.prod noise).map W) := (Measure.isProbabilityMeasure_map_iff hW.aemeasurable).mpr inferInstance
  apply finite_measure_eq_of_integrals
  intro f
  rw [integral_map hW.aemeasurable (measurable_of_finite f).aestronglyMeasurable,
    integral_finiteKernelMixtureLaw]
  have hi : Integrable (fun z => f (W z)) (mu.prod noise) :=
    (outcome_measurePreserving (mu.prod noise) W hW).integrable_comp_of_integrable Integrable.of_finite
  rw [integral_prod _ hi]
  apply integral_congr_ae
  filter_upwards [] with z
  exact htest z f
end
end PoissonAudit
