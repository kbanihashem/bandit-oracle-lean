module

public import PoissonAudit.Hellinger
public import Mathlib.InformationTheory.KullbackLeibler.Basic
public import Mathlib.MeasureTheory.Integral.Bochner.Basic

public section

open MeasureTheory InformationTheory
open scoped ENNReal

namespace PoissonAudit

theorem density_hellinger_le_kl {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) [IsProbabilityMeasure mu]
    (f : Omega → ℝ) (hf : Measurable f) (hf0 : ∀ x, 0 ≤ f x)
    (hfi : Integrable f mu) (hnorm : (∫ x, f x ∂mu) = 1) :
    ENNReal.ofReal (∫ x, (Real.sqrt (f x) - 1) ^ 2 ∂mu) ≤
      klDiv (mu.withDensity (fun x => ENNReal.ofReal (f x))) mu := by
  let Q := mu.withDensity (fun x => ENNReal.ofReal (f x))
  have hprob : IsProbabilityMeasure Q := by
    refine ⟨?_⟩
    change (mu.withDensity (fun x => ENNReal.ofReal (f x))) Set.univ = 1
    rw [withDensity_apply _ MeasurableSet.univ, Measure.restrict_univ,
      ← ofReal_integral_eq_lintegral_ofReal hfi (Filter.Eventually.of_forall hf0), hnorm]
    simp
  let _ := hprob
  have hH : Integrable (fun x => (Real.sqrt (f x) - 1) ^ 2) mu := by
    apply (hfi.add (integrable_const (1 : ℝ))).mono' (by fun_prop)
    filter_upwards [] with x
    rw [Real.norm_eq_abs, abs_of_nonneg (sq_nonneg _)]
    change (Real.sqrt (f x) - 1) ^ 2 ≤ f x + 1
    nlinarith [Real.sq_sqrt (hf0 x), Real.sqrt_nonneg (f x)]
  have hac : Q ≪ mu := withDensity_absolutelyContinuous _ _
  have hrn := Measure.rnDeriv_withDensity mu hf.ennreal_ofReal
  change ENNReal.ofReal _ ≤ klDiv Q mu
  rw [klDiv_eq_lintegral_klFun_of_ac hac,
    ofReal_integral_eq_lintegral_ofReal hH (Filter.Eventually.of_forall fun x => sq_nonneg _)]
  calc
    _ ≤ ∫⁻ x, ENNReal.ofReal (klFun (f x)) ∂mu := by
      apply lintegral_mono
      intro x
      apply ENNReal.ofReal_le_ofReal
      have h := sqrt_discrepancy_le_kl_term (hf0 x) (by norm_num : (0 : ℝ) < 1)
      simp only [Real.sqrt_one, div_one] at h
      rw [klFun_apply]
      linarith
    _ = _ := by
      apply lintegral_congr_ae
      filter_upwards [hrn] with x hx
      rw [hx, ENNReal.toReal_ofReal (hf0 x)]

end PoissonAudit
