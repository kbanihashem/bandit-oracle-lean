module

public import PoissonAudit.ScaleMinimizer
public import Mathlib.Analysis.Calculus.LocalExtr.Basic

public section

open Set
open scoped Topology

namespace PoissonAudit

noncomputable section

@[expose] def coordinateDirection {Q : Type*} (j k : Q) : ℝ := by
  classical
  exact if k = j then 1 else 0

@[expose] def coordinateLine {Q : Type*} (sigma : Q → ℝ) (j : Q) (t : ℝ) : Q → ℝ :=
  fun k => sigma k + t * coordinateDirection j k

theorem box_minimizer_derivative_nonneg {Q : Type*} (J : (Q → ℝ) → ℝ)
    (sigma : Q → ℝ) (B : ℝ) (hsigma : sigma ∈ scaleBox Q B)
    (hmin : IsMinOn J (scaleBox Q B) sigma) (j : Q) (hj : sigma j < B)
    (d : ℝ) (hd : HasDerivAt (fun t : ℝ => J (coordinateLine sigma j t)) d 0) : 0 ≤ d := by
  classical
  let delta := B - sigma j
  have hdelta : 0 < delta := sub_pos.mpr hj
  have hfeas (t : ℝ) (ht : t ∈ Icc 0 delta) : coordinateLine sigma j t ∈ scaleBox Q B := by
    constructor
    · intro k
      change (1 : ℝ) ≤ coordinateLine sigma j t k
      by_cases hk : k = j
      · subst k
        have hs : (1 : ℝ) ≤ sigma j := hsigma.1 j
        simp [coordinateLine, coordinateDirection]
        linarith [ht.1]
      · simpa [coordinateLine, coordinateDirection, hk] using hsigma.1 k
    · intro k
      by_cases hk : k = j
      · subst k
        change sigma j + t * coordinateDirection j j ≤ B
        simp [coordinateDirection]
        have htd : t ≤ B - sigma j := ht.2
        linarith
      · simpa [coordinateLine, coordinateDirection, hk] using hsigma.2 k
  have hmf : IsMinOn (fun t => J (coordinateLine sigma j t)) (Icc 0 delta) 0 := by
    intro t ht
    have h := hmin (hfeas t ht)
    change J sigma ≤ J (coordinateLine sigma j t) at h
    change J (coordinateLine sigma j 0) ≤ J (coordinateLine sigma j t)
    have hzero : coordinateLine sigma j 0 = sigma := by funext k; simp [coordinateLine]
    rw [hzero]
    exact h
  have hcone : delta - 0 ∈ posTangentConeAt (Icc (0 : ℝ) delta) 0 :=
    sub_mem_posTangentConeAt_of_segment_subset (by rw [segment_eq_Icc hdelta.le])
  have h := hmf.isLocalMinOn.hasFDerivWithinAt_nonneg hd.hasFDerivAt.hasFDerivWithinAt hcone
  have hm : 0 ≤ delta * d := by
    simpa only [ContinuousLinearMap.toSpanSingleton_apply, sub_zero, smul_eq_mul] using h
  exact nonneg_of_mul_nonneg_right hm hdelta

theorem box_minimizer_derivative_nonpos {Q : Type*} (J : (Q → ℝ) → ℝ)
    (sigma : Q → ℝ) (B : ℝ) (hsigma : sigma ∈ scaleBox Q B)
    (hmin : IsMinOn J (scaleBox Q B) sigma) (j : Q) (hj : 1 < sigma j)
    (d : ℝ) (hd : HasDerivAt (fun t : ℝ => J (coordinateLine sigma j t)) d 0) : d ≤ 0 := by
  classical
  let delta := sigma j - 1
  have hdelta : 0 < delta := sub_pos.mpr hj
  have hfeas (t : ℝ) (ht : t ∈ Icc (-delta) 0) : coordinateLine sigma j t ∈ scaleBox Q B := by
    constructor
    · intro k
      change (1 : ℝ) ≤ coordinateLine sigma j t k
      by_cases hk : k = j
      · subst k
        simp [coordinateLine, coordinateDirection]
        have htd : -(sigma j - 1) ≤ t := ht.1
        linarith
      · simpa [coordinateLine, coordinateDirection, hk] using hsigma.1 k
    · intro k
      by_cases hk : k = j
      · subst k
        change sigma j + t * coordinateDirection j j ≤ B
        simp [coordinateDirection]
        have hs : sigma j ≤ B := hsigma.2 j
        linarith [ht.2]
      · simpa [coordinateLine, coordinateDirection, hk] using hsigma.2 k
  have hmf : IsMinOn (fun t => J (coordinateLine sigma j t)) (Icc (-delta) 0) 0 := by
    intro t ht
    have h := hmin (hfeas t ht)
    change J sigma ≤ J (coordinateLine sigma j t) at h
    change J (coordinateLine sigma j 0) ≤ J (coordinateLine sigma j t)
    have hzero : coordinateLine sigma j 0 = sigma := by funext k; simp [coordinateLine]
    rw [hzero]
    exact h
  have hcone : -delta - 0 ∈ posTangentConeAt (Icc (-delta) (0 : ℝ)) 0 :=
    sub_mem_posTangentConeAt_of_segment_subset (by rw [segment_symm, segment_eq_Icc (by linarith : -delta ≤ 0)])
  have h := hmf.isLocalMinOn.hasFDerivWithinAt_nonneg hd.hasFDerivAt.hasFDerivWithinAt hcone
  have hm : delta * d ≤ 0 := by
    simp only [ContinuousLinearMap.toSpanSingleton_apply, sub_zero, smul_eq_mul, neg_mul] at h
    linarith
  exact nonpos_of_mul_nonpos_right hm hdelta

end

end PoissonAudit
