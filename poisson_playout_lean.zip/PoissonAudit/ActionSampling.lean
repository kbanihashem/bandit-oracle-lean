module

public import Mathlib.Probability.ProbabilityMassFunction.Integrals
public import Mathlib.Tactic

public section

open MeasureTheory
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {A P : Type*} [Fintype A] [MeasurableSpace A] [MeasurableSingletonClass A]

def actionPMF (q : A → ℝ) (hq : ∀ a, 0 ≤ q a) (hsum : ∑ a, q a = 1) : PMF A :=
  PMF.ofFintype (fun a => ENNReal.ofReal (q a)) (by
    rw [← ENNReal.ofReal_sum_of_nonneg (fun a _ => hq a), hsum]
    simp)

omit [MeasurableSpace A] [MeasurableSingletonClass A] in
@[simp] theorem actionPMF_toReal (q : A → ℝ) (hq : ∀ a, 0 ≤ q a)
    (hsum : ∑ a, q a = 1) (a : A) :
    ((actionPMF q hq hsum) a).toReal = q a := by
  simp [actionPMF, ENNReal.toReal_ofReal (hq a)]

theorem integral_actionPMF (q : A → ℝ) (hq : ∀ a, 0 ≤ q a)
    (hsum : ∑ a, q a = 1) (f : A → ℝ) :
    (∫ a, f a ∂(actionPMF q hq hsum).toMeasure) = ∑ a, q a * f a := by
  rw [PMF.integral_eq_sum]
  simp only [actionPMF_toReal, smul_eq_mul]

def estimatedPolicyLoss (q c : A → ℝ) (predict : P → A) (a : A) (p : P) : ℝ := by
  classical
  exact if predict p = a then c a / q a else 0

def updatedScore (S : P → ℝ) (q c : A → ℝ) (predict : P → A) (a : A) : P → ℝ :=
  fun p => S p - estimatedPolicyLoss q c predict a p

theorem importance_weight_unbiased (q c : A → ℝ) (predict : P → A)
    (hq : ∀ a, 0 < q a) (hsum : ∑ a, q a = 1) (p : P) :
    (∫ a, estimatedPolicyLoss q c predict a p
      ∂(actionPMF q (fun a => (hq a).le) hsum).toMeasure) = c (predict p) := by
  classical
  rw [integral_actionPMF]
  simp only [estimatedPolicyLoss, mul_ite, mul_zero]
  rw [Finset.sum_eq_single (predict p)]
  · simp only [ite_true]
    exact mul_div_cancel₀ _ (hq (predict p)).ne'
  · intro b _ hb
    simp [Ne.symm hb]
  · simp

theorem expected_updatedScore (S : P → ℝ) (q c : A → ℝ) (predict : P → A)
    (hq : ∀ a, 0 < q a) (hsum : ∑ a, q a = 1) (p : P) :
    (∫ a, updatedScore S q c predict a p
      ∂(actionPMF q (fun a => (hq a).le) hsum).toMeasure) = S p - c (predict p) := by
  unfold updatedScore
  rw [integral_sub Integrable.of_finite Integrable.of_finite,
    importance_weight_unbiased q c predict hq hsum p]
  simp

theorem expected_round_increment (R : (P → ℝ) → ℝ) (S : P → ℝ)
    (q c : A → ℝ) (predict : P → A)
    (hq : ∀ a, 0 ≤ q a) (hsum : ∑ a, q a = 1) :
    (∫ a, c a + R (updatedScore S q c predict a) - R S
      ∂(actionPMF q hq hsum).toMeasure) =
      (∑ a, q a * c a) + ∑ a, q a * (R (updatedScore S q c predict a) - R S) := by
  rw [integral_actionPMF, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro a _
  ring

end

end PoissonAudit
