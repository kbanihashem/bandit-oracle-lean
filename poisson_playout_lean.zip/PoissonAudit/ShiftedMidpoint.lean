module

public import Mathlib.MeasureTheory.Group.Integral
public import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
public import Mathlib.MeasureTheory.Measure.Haar.Unique
public import Mathlib.Tactic
public import PoissonAudit.Algebra

public section

open MeasureTheory
open scoped BigOperators

namespace PoissonAudit

noncomputable section

@[expose] def l1 {K : ℕ} (z : Fin K → ℝ) : ℝ := ∑ a, |z a|

@[expose] def laplaceKernel {K : ℕ} (z : Fin K → ℝ) : ℝ := Real.exp (-l1 z)

theorem l1_nonneg {K : ℕ} (z : Fin K → ℝ) : 0 ≤ l1 z :=
  Finset.sum_nonneg fun _ _ => abs_nonneg _

@[simp] theorem l1_neg {K : ℕ} (z : Fin K → ℝ) : l1 (-z) = l1 z := by
  simp [l1]

@[simp] theorem laplaceKernel_neg {K : ℕ} (z : Fin K → ℝ) :
    laplaceKernel (-z) = laplaceKernel z := by simp [laplaceKernel]

theorem laplaceKernel_pos {K : ℕ} (z : Fin K → ℝ) : 0 < laplaceKernel z :=
  Real.exp_pos _

theorem laplaceKernel_shift {K : ℕ} (y v : Fin K → ℝ) :
    laplaceKernel (y + v) ≤ Real.exp (l1 v) * laplaceKernel y := by
  have htriangle : l1 y ≤ l1 (y + v) + l1 v := by
    unfold l1
    rw [← Finset.sum_add_distrib]
    apply Finset.sum_le_sum
    intro a _
    have h := abs_add_le ((y + v) a) (-v a)
    simpa using h
  unfold laplaceKernel
  rw [← Real.exp_add]
  exact Real.exp_le_exp.mpr (by linarith)

theorem shifted_square_integral {K : ℕ}
    (r : (Fin K → ℝ) → ℝ) (v : Fin K → ℝ) (w : ℝ)
    (hshift : Integrable (fun z =>
      (Real.sqrt (r (z - v)) - Real.sqrt w) ^ 2 * laplaceKernel z))
    (hbase : Integrable (fun z =>
      (Real.sqrt (r z) - Real.sqrt w) ^ 2 * laplaceKernel z)) :
    (∫ z, (Real.sqrt (r (z - v)) - Real.sqrt w) ^ 2 * laplaceKernel z) ≤
      Real.exp (l1 v) *
        (∫ z, (Real.sqrt (r z) - Real.sqrt w) ^ 2 * laplaceKernel z) := by
  have htrans : (∫ z, (Real.sqrt (r (z - v)) - Real.sqrt w) ^ 2 * laplaceKernel z) =
      ∫ y, (Real.sqrt (r y) - Real.sqrt w) ^ 2 * laplaceKernel (y + v) := by
    simpa using (integral_add_right_eq_self
      (fun z => (Real.sqrt (r (z - v)) - Real.sqrt w) ^ 2 * laplaceKernel z) v).symm
  have htransInt : Integrable (fun y =>
      (Real.sqrt (r y) - Real.sqrt w) ^ 2 * laplaceKernel (y + v)) := by
    simpa using hshift.comp_add_right v
  rw [htrans, ← integral_const_mul]
  apply integral_mono htransInt (hbase.const_mul _)
  intro y
  calc
    _ ≤ (Real.sqrt (r y) - Real.sqrt w) ^ 2 *
        (Real.exp (l1 v) * laplaceKernel y) :=
      mul_le_mul_of_nonneg_left (laplaceKernel_shift y v) (sq_nonneg _)
    _ = _ := by ring

theorem shifted_midpoint_comparison {K : ℕ}
    (r : (Fin K → ℝ) → ℝ) (v : Fin K → ℝ) (w : ℝ)
    (hr : ∀ z, 0 ≤ r z) (hw : 0 ≤ w)
    (hmid : ∀ z,
      Real.sqrt (r (z - v)) * Real.sqrt (r (-z - v)) ≤ r (-v))
    (hleft : Integrable (fun z => (r (z - v) - r (-v)) * laplaceKernel z))
    (hshift : Integrable (fun z =>
      (Real.sqrt (r (z - v)) - Real.sqrt w) ^ 2 * laplaceKernel z))
    (hbase : Integrable (fun z =>
      (Real.sqrt (r z) - Real.sqrt w) ^ 2 * laplaceKernel z)) :
    (∫ z, (r (z - v) - r (-v)) * laplaceKernel z) ≤
      2 * Real.exp (l1 v) *
        (∫ z, (Real.sqrt (r z) - Real.sqrt w) ^ 2 * laplaceKernel z) := by
  let A := fun z => (r (z - v) - r (-v)) * laplaceKernel z
  let D := fun z => (Real.sqrt (r (z - v)) - Real.sqrt w) ^ 2 * laplaceKernel z
  have hA : Integrable A := hleft
  have hD : Integrable D := hshift
  have hsymA : (∫ z, A (-z)) = ∫ z, A z := integral_neg_eq_self A volume
  have hsymD : (∫ z, D (-z)) = ∫ z, D z := integral_neg_eq_self D volume
  have hpoint : ∀ z, (A z + A (-z)) / 2 ≤ D z + D (-z) := by
    intro z
    have h := mul_le_mul_of_nonneg_right
      (midpoint_discrepancy (hr (z - v)) (hr (-z - v)) hw (hmid z))
      (laplaceKernel_pos z).le
    dsimp [A, D]
    rw [laplaceKernel_neg]
    nlinarith
  have hint := integral_mono ((hA.add hA.comp_neg).div_const 2)
    (hD.add hD.comp_neg) hpoint
  simp only [Pi.add_apply, integral_div, integral_add hA hA.comp_neg,
    integral_add hD hD.comp_neg, hsymA, hsymD] at hint
  have hdom := shifted_square_integral r v w hshift hbase
  change (∫ z, A z) ≤ _
  change (∫ z, D z) ≤ _ at hdom
  nlinarith

end

end PoissonAudit
