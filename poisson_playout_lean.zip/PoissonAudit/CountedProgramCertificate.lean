module
public import PoissonAudit.ArithmeticBanditPlan
public import PoissonAudit.OriginalProgramSimulation
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section

@[expose] def queryCoefficientCount {X : Type*} (K : ℕ) (qs : List (List (CostExample X K))) : ℕ :=
  K * (qs.map List.length).sum

theorem queryCoefficientCount_bound {X : Type*} (K n : ℕ) (qs : List (List (CostExample X K)))
    (hn : ∀ Q ∈ qs, Q.length ≤ n) : queryCoefficientCount K qs ≤ K * (qs.length * n) := by
  unfold queryCoefficientCount
  apply Nat.mul_le_mul_left
  induction qs with
  | nil => simp
  | cons Q qs ih =>
    have hi := ih (fun q hq => hn q (List.mem_cons_of_mem _ hq))
    have hQ := hn Q List.mem_cons_self
    simp only [List.map_cons, List.sum_cons, List.length_cons]
    nlinarith

@[expose] def auxiliaryContextCount {X : Type*} {K : ℕ} (cap J m : ℕ)
    (tape : NativeNoiseTape X K J) (trials : Fin m → NativeNoise X K) : ℕ :=
  if samplerCapCheck cap J m tape trials then nativeTapePoolSamples J tape + ∑ i, (trials i).2.1 else 0

theorem auxiliaryContextCount_bound {X : Type*} {K : ℕ} (cap J m : ℕ)
    (tape : NativeNoiseTape X K J) (trials : Fin m → NativeNoise X K) :
    auxiliaryContextCount cap J m tape trials ≤ (J + m) * cap := by
  unfold auxiliaryContextCount
  split_ifs with h
  · have hb := (samplerCapCheck_correct cap J m tape trials).mp h
    have ht := nativeTapePoolSamples_bound cap J tape hb.1
    have hs := Finset.sum_le_sum (s := Finset.univ) (fun i _ => hb.2 i)
    simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, Nat.cast_id] at hs
    nlinarith
  · omega

@[expose] def elementaryDrawBudget (K cap J m : ℕ) : ℕ := (J + m) + K * (J + m) * (cap + 1) + 1

theorem elementaryDrawCount_bound {X : Type*} {K : ℕ} (cap J m : ℕ)
    (tape : NativeNoiseTape X K J) (trials : Fin m → NativeNoise X K) :
    (J + m) + K * ((J + m) + auxiliaryContextCount cap J m tape trials) + 1 ≤ elementaryDrawBudget K cap J m := by
  have h := Nat.mul_le_mul_left K (auxiliaryContextCount_bound cap J m tape trials)
  unfold elementaryDrawBudget
  nlinarith

@[expose] def onlineWorkBudget (T K cap J m : ℕ) : ℕ :=
  samplerInternalBudget K cap J m +
    4 * K * (((cap * J ^ 2 + m * ((cap + 1) * J + 1)) * (K + 1)) * (T + cap + 1)) +
    4 * elementaryDrawBudget K cap J m + 16 * K * (m + 1) + 4 * (T ^ 2 + 1) + 32 * K * (T + 1)

theorem executeArraySampler_resource_certificate {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (T cap J m : ℕ) (ht : history.length ≤ T) (tape : NativeNoiseTape X K J) (trials : Fin m → NativeNoise X K) (x : X) :
    let run := executeArraySampler r lam B eta history oracle fallback cap J m tape trials x
    run.choice = cappedOracleChoice r lam B eta history oracle fallback cap J m tape trials x ∧
      run.queries.length ≤ (cap * J ^ 2 + m * ((cap + 1) * J + 1)) * (K + 1) ∧
      (∀ Q ∈ run.queries, Q.length ≤ T + cap + 1) ∧
      queryCoefficientCount K run.queries ≤ K * (((cap * J ^ 2 + m * ((cap + 1) * J + 1)) * (K + 1)) * (T + cap + 1)) ∧
      run.internalWork ≤ samplerInternalBudget K cap J m ∧ auxiliaryContextCount cap J m tape trials ≤ (J + m) * cap := by
  dsimp only
  have he := executeArraySampler_correct r lam B eta history oracle fallback cap J m tape trials x
  have hq := cappedOracleQueries_count r lam B eta history oracle fallback cap J m tape trials x
  have hlen : ∀ Q ∈ (executeArraySampler r lam B eta history oracle fallback cap J m tape trials x).queries,
      Q.length ≤ T + cap + 1 := by
    intro Q hQ
    rw [he.2] at hQ
    exact (cappedOracleQueries_input_length r lam B eta history oracle fallback cap J m tape trials x Q hQ).trans (by omega)
  refine ⟨he.1, by rwa [he.2], hlen, ?_, executeArraySampler_work r lam B eta history oracle fallback cap J m tape trials x,
    auxiliaryContextCount_bound cap J m tape trials⟩
  exact (queryCoefficientCount_bound K (T + cap + 1) _ hlen).trans (Nat.mul_le_mul_left _ (Nat.mul_le_mul_right _ (by rwa [he.2])))

theorem onlineWorkBudget_power_bound (H : ℝ) (hH : 2 ≤ H) (T K cap J m : ℕ)
    (hT : PowerBound H 1 T) (hK : PowerBound H 1 K) (hc : PowerBound H 94 cap)
    (hJ : PowerBound H 82 J) (hm : PowerBound H 15 m) :
    PowerBound H 512 (T * onlineWorkBudget T K cap J m) := by
  have hH0 : 0 ≤ H := by linarith
  have hH1 : 1 ≤ H := by linarith
  have h1 := powerBound_one H
  have h4 := powerBound_small hH 4 2 (by norm_num)
  have h32 := powerBound_small hH 32 5 (by norm_num)
  have h16 := powerBound_small hH 16 4 (by norm_num)
  have hQ := (finite_resource_expressions_power_bound H hH T K J m cap hT hK hJ hm hc).1
  have hlen : PowerBound H 96 ((T : ℝ) + cap + 1) := powerBound_add hH (powerBound_add hH hT hc) h1
  have hwords : PowerBound H 360 (4 * (K : ℝ) * (finiteQueryBudget K J m cap * (T + cap + 1))) :=
    powerBound_mul hH0 (powerBound_mul hH0 h4 hK) (powerBound_mul hH0 hQ hlen)
  have hd : PowerBound H 181 (elementaryDrawBudget K cap J m) := by
    unfold elementaryDrawBudget
    push_cast
    exact powerBound_add hH (powerBound_add hH (powerBound_add hH hJ hm)
      (powerBound_mul hH0 (powerBound_mul hH0 hK (powerBound_add hH hJ hm)) (powerBound_add hH hc h1))) h1
  have hfreq : PowerBound H 21 (16 * (K : ℝ) * (m + 1)) := powerBound_mul hH0 (powerBound_mul hH0 h16 hK) (powerBound_add hH hm h1)
  have hgrid : PowerBound H 5 (4 * ((T : ℝ) ^ 2 + 1)) := powerBound_mul hH0 h4 (powerBound_add hH (powerBound_sq hH0 hT) h1)
  have hhist : PowerBound H 8 (32 * (K : ℝ) * (T + 1)) := powerBound_mul hH0 (powerBound_mul hH0 h32 hK) (powerBound_add hH hT h1)
  have hi := samplerInternalBudget_power_bound H hH K cap J m hK hc hJ hm
  have hall : PowerBound H 365 (onlineWorkBudget T K cap J m) := by
    unfold onlineWorkBudget
    push_cast
    change PowerBound H 365 ((samplerInternalBudget K cap J m : ℝ) +
      4 * K * (finiteQueryBudget K J m cap * (T + cap + 1)) + 4 * elementaryDrawBudget K cap J m +
        16 * K * (m + 1) + 4 * (T ^ 2 + 1) + 32 * K * (T + 1))
    exact powerBound_add hH (powerBound_add hH (powerBound_add hH (powerBound_add hH (powerBound_add hH hi hwords) (powerBound_mul hH0 h4 hd)) hfreq) hgrid) hhist
  have ht : PowerBound H 366 ((T : ℝ) * onlineWorkBudget T K cap J m) := powerBound_mul hH0 hT hall
  simpa only [Nat.cast_mul] using powerBound_mono hH1 ht (by norm_num : 366 ≤ 512)
end
end PoissonAudit
