module
public import PoissonAudit.EmpiricalFrequency
public section
open MeasureTheory ProbabilityTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {A : Type*} [Fintype A] [MeasurableSpace A] [MeasurableSingletonClass A]

theorem variance_empiricalFrequency_le (p : A → ℝ) (hp : ∀ a, 0 ≤ p a) (hsum : ∑ a, p a = 1)
    (m : ℕ) (hm : 0 < m) (a : A) :
    variance (empiricalFrequency m a) (iidPool (actionPMF p hp hsum).toMeasure m) ≤ 1 / m := by
  let mu := (actionPMF p hp hsum).toMeasure
  have hmem : MemLp (actionIndicator a) 2 mu := memLp_of_bounded
    (Filter.Eventually.of_forall fun b => actionIndicator_mem a b) (measurable_of_finite _).aestronglyMeasurable 2
  have hv : variance (fun u : Fin m → A => ∑ i, actionIndicator a (u i)) (iidPool mu m) =
      (m : ℝ) * variance (actionIndicator a) mu := by
    have h := variance_sum_pi (μ := fun _ : Fin m => mu) (X := fun _ : Fin m => actionIndicator a) (fun _ => hmem)
    simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul] at h
    convert! h using 1
    congr 1
    funext u
    simp only [Finset.sum_apply]
  have heq : empiricalFrequency m a = fun u : Fin m → A => (1 / (m : ℝ)) * ∑ i, actionIndicator a (u i) := by
    funext u
    unfold empiricalFrequency
    ring
  rw [heq, variance_const_mul, hv]
  have h := mul_le_mul_of_nonneg_left (variance_actionIndicator_le_one p hp hsum a)
    (show 0 ≤ (1 / (m : ℝ)) ^ 2 * m from mul_nonneg (sq_nonneg _) (Nat.cast_nonneg _))
  have hm0 : (m : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (Nat.ne_of_gt hm)
  calc
    _ = ((1 / (m : ℝ)) ^ 2 * m) * variance (actionIndicator a) mu := by ring
    _ ≤ ((1 / (m : ℝ)) ^ 2 * m) * 1 := h
    _ = _ := by field_simp

theorem empiricalFrequency_mean_square_error (p : A → ℝ) (hp : ∀ a, 0 ≤ p a) (hsum : ∑ a, p a = 1)
    (m : ℕ) (hm : 0 < m) (a : A) :
    (∫ u, (empiricalFrequency m a u - p a) ^ 2 ∂iidPool (actionPMF p hp hsum).toMeasure m) ≤ 1 / m := by
  have h := variance_empiricalFrequency_le p hp hsum m hm a
  rw [variance_eq_integral (measurable_of_finite _).aemeasurable,
    integral_empiricalFrequency p hp hsum m hm a] at h
  exact h

theorem empiricalFrequency_absolute_error (p : A → ℝ) (hp : ∀ a, 0 ≤ p a) (hsum : ∑ a, p a = 1)
    (m : ℕ) (hm : 0 < m) (a : A) :
    (∫ u, |empiricalFrequency m a u - p a| ∂iidPool (actionPMF p hp hsum).toMeasure m) ≤ Real.sqrt (1 / m) := by
  let mu := iidPool (actionPMF p hp hsum).toMeasure m
  let err := fun u : Fin m → A => |empiricalFrequency m a u - p a|
  have hpa : p a ≤ 1 := by rw [← hsum]; exact Finset.single_le_sum (fun b _ => hp b) (Finset.mem_univ a)
  have hb (u : Fin m → A) : err u ∈ Set.Icc (0 : ℝ) 1 := by
    have hf := empiricalFrequency_mem m hm a u
    exact ⟨abs_nonneg _, abs_le.mpr ⟨by linarith [hf.1, hpa], by linarith [hf.2, hp a]⟩⟩
  have hmem : MemLp err 2 mu := memLp_of_bounded (Filter.Eventually.of_forall hb)
    (measurable_of_finite _).aestronglyMeasurable 2
  have hv := variance_nonneg err mu
  rw [variance_eq_sub hmem] at hv
  change 0 ≤ (∫ u, |empiricalFrequency m a u - p a| ^ 2 ∂mu) - (∫ u, err u ∂mu) ^ 2 at hv
  simp only [sq_abs] at hv
  have he := empiricalFrequency_mean_square_error p hp hsum m hm a
  change (∫ u, (empiricalFrequency m a u - p a) ^ 2 ∂mu) ≤ 1 / m at he
  have hsqrt := Real.sq_sqrt (div_nonneg (by norm_num : (0 : ℝ) ≤ 1) (Nat.cast_nonneg m))
  have hn : 0 ≤ ∫ u, err u ∂mu := integral_nonneg fun u => (hb u).1
  have hp0 := Real.sqrt_nonneg (1 / (m : ℝ))
  change (∫ u, err u ∂mu) ≤ _
  nlinarith

theorem empiricalFrequency_l1_error (p : A → ℝ) (hp : ∀ a, 0 ≤ p a) (hsum : ∑ a, p a = 1)
    (m : ℕ) (hm : 0 < m) :
    (∫ u, ∑ a, |empiricalFrequency m a u - p a| ∂iidPool (actionPMF p hp hsum).toMeasure m) ≤
      Fintype.card A * Real.sqrt (1 / m) := by
  rw [integral_finsetSum _ (fun _ _ => Integrable.of_finite)]
  have h := Finset.sum_le_sum (s := Finset.univ) fun a _ => empiricalFrequency_absolute_error p hp hsum m hm a
  simpa only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul] using h
end
end PoissonAudit
