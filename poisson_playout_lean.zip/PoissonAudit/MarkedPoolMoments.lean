module

public import PoissonAudit.MarkedPoolLaw
public import Mathlib.MeasureTheory.Constructions.BorelSpace.Order

public section

open MeasureTheory ProbabilityTheory
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {U : Type*} [MeasurableSpace U]

@[expose] def poolSum (g : U → ℝ) (pool : ℕ × (ℕ → U)) : ℝ :=
  ∑ i : Fin pool.1, g (pool.2 i)

theorem measurable_poolSum (g : U → ℝ) (hg : Measurable g) : Measurable (poolSum g) := by
  apply measurable_from_prod_countable_right
  intro m
  change Measurable (fun u : ℕ → U => ∑ i : Fin m, g (u i))
  apply Finset.measurable_sum
  intro i _
  exact hg.comp (measurable_pi_apply (i : ℕ))

theorem integrable_sequence_eval (mu : Measure U) [IsProbabilityMeasure mu]
    (g : U → ℝ) (hg : Integrable g mu) (i : ℕ) :
    Integrable (fun u : ℕ → U => g (u i)) (markSequence mu) :=
  (measurePreserving_eval_infinitePi (fun _ : ℕ => mu) i).integrable_comp_of_integrable hg

theorem integral_sequence_eval (mu : Measure U) [IsProbabilityMeasure mu]
    (g : U → ℝ) (hg : Measurable g) (i : ℕ) :
    (∫ u : ℕ → U, g (u i) ∂markSequence mu) = ∫ x, g x ∂mu := by
  have h := integral_map (μ := markSequence mu) (φ := fun u => u i)
    (measurable_pi_apply i).aemeasurable hg.aestronglyMeasurable
  change (∫ y, g y ∂(Measure.infinitePi (fun _ : ℕ => mu)).map (fun u => u i)) = _ at h
  rw [Measure.infinitePi_map_eval] at h
  exact h.symm

theorem integrable_poolSum_fixed (mu : Measure U) [IsProbabilityMeasure mu]
    (g : U → ℝ) (hg : Integrable g mu) (m : ℕ) :
    Integrable (fun u : ℕ → U => poolSum g (m, u)) (markSequence mu) := by
  change Integrable (fun u : ℕ → U => ∑ i : Fin m, g (u i)) (markSequence mu)
  exact integrable_finsetSum Finset.univ fun (i : Fin m) _ => integrable_sequence_eval mu g hg i

theorem integral_poolSum_fixed (mu : Measure U) [IsProbabilityMeasure mu]
    (g : U → ℝ) (hg : Measurable g) (hgi : Integrable g mu) (m : ℕ) :
    (∫ u : ℕ → U, poolSum g (m, u) ∂markSequence mu) = (m : ℝ) * ∫ x, g x ∂mu := by
  change (∫ u : ℕ → U, ∑ i : Fin m, g (u i) ∂markSequence mu) = _
  rw [integral_finsetSum Finset.univ fun (i : Fin m) _ => integrable_sequence_eval mu g hgi i]
  simp_rw [integral_sequence_eval mu g hg]
  simp

theorem integrable_poolSum_nonneg (r : NNReal) (mu : Measure U) [IsProbabilityMeasure mu]
    (g : U → ℝ) (hg : Measurable g) (hgi : Integrable g mu) (hg0 : ∀ x, 0 ≤ g x) :
    Integrable (poolSum g) (markedPoolLaw r mu) := by
  apply (integrable_prod_iff (measurable_poolSum g hg).aestronglyMeasurable).mpr
  constructor
  · exact Filter.Eventually.of_forall (integrable_poolSum_fixed mu g hgi)
  · have heq : (fun m => ∫ u : ℕ → U, ‖poolSum g (m, u)‖ ∂markSequence mu) =
        fun m : ℕ => (m : ℝ) * ∫ x, g x ∂mu := by
      funext m
      have hnorm : ∀ u : ℕ → U, ‖poolSum g (m, u)‖ = poolSum g (m, u) := by
        intro u
        rw [Real.norm_eq_abs, abs_of_nonneg]
        exact Finset.sum_nonneg fun _ _ => hg0 _
      simp_rw [hnorm]
      exact integral_poolSum_fixed mu g hg hgi m
    rw [heq]
    exact (integrable_poisson_count r).mul_const _

theorem integrable_poolSum (r : NNReal) (mu : Measure U) [IsProbabilityMeasure mu]
    (g : U → ℝ) (hg : Measurable g) (hgi : Integrable g mu) :
    Integrable (poolSum g) (markedPoolLaw r mu) := by
  apply (integrable_poolSum_nonneg r mu (fun x => |g x|)
    (continuous_abs.measurable.comp hg) hgi.abs (fun _ => abs_nonneg _)).mono'
    (measurable_poolSum g hg).aestronglyMeasurable
  filter_upwards [] with pool
  exact Finset.abs_sum_le_sum_abs _ _

theorem integral_poolSum (r : NNReal) (mu : Measure U) [IsProbabilityMeasure mu]
    (g : U → ℝ) (hg : Measurable g) (hgi : Integrable g mu) :
    (∫ pool, poolSum g pool ∂markedPoolLaw r mu) = (r : ℝ) * ∫ x, g x ∂mu := by
  change (∫ pool, poolSum g pool ∂(poissonMeasure r).prod (markSequence mu)) = _
  rw [integral_prod _ (integrable_poolSum r mu g hg hgi)]
  simp_rw [integral_poolSum_fixed mu g hg hgi]
  rw [integral_mul_const, integral_poisson_count]

end

end PoissonAudit
