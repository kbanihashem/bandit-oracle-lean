module

public import PoissonAudit.WinnerMomentIdentity
public import PoissonAudit.FreshObservable
public import PoissonAudit.LocationInformation

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {V P : Type*} [MeasurableSpace V] {K : ℕ}
    [Fintype P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem integrable_selected_winner_observable (nu : Measure V) [IsProbabilityMeasure nu]
    (W : (Fin K → ℝ) × V → P) (hW : Measurable W) (pick : P → Fin K) (a : Fin K)
    (g : ℝ → ℝ) (hg : Integrable g realLaplace) :
    Integrable (fun v => if pick (W v) = a then g (v.1 a) else 0) ((laplaceMeasure K).prod nu) := by
  classical
  have hE : MeasurableSet {v | pick (W v) = a} :=
    ((measurable_of_finite pick).comp hW) (measurableSet_singleton a)
  have h := integrable_event_coordinate_observable nu _ hE a g hg
  convert! h using 1
  funext v
  by_cases hp : pick (W v) = a <;> simp [hp]

variable {X : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X]
    [Nonempty P] [LinearOrder P]

@[expose] def locationActionMoment (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (g : ℝ → ℝ) (n : ℕ) (C : Fin n → X) : ℝ :=
  winnerGroupMoment (iidPool (laplaceMeasure K) n) (insertedLocationWinner predict sigma S x C)
    (fun p => predict p x) a g

@[expose] def locationActionEntropy (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (n : ℕ) (C : Fin n → X) : ℝ :=
  winnerActionEntropy (laplaceMeasure K) (iidPool (laplaceMeasure K) n)
    (insertedLocationWinner predict sigma S x C) (fun p => predict p x) a

theorem locationActionMoment_eq_iterated (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (g : ℝ → ℝ) (hg : Integrable g realLaplace) (n : ℕ) (C : Fin n → X) :
    locationActionMoment predict sigma S x a g n C =
      ∫ z0, ∫ Z, (if predict (insertedLocationWinner predict sigma S x C (z0, Z)) x = a
        then g (z0 a) else 0) ∂iidPool (laplaceMeasure K) n ∂laplaceMeasure K := by
  unfold locationActionMoment
  rw [winnerGroupMoment_eq_joint _ _ (measurable_insertedLocationWinner predict sigma S x C) _ _ g hg]
  exact integral_prod _ (integrable_selected_winner_observable _ _
    (measurable_insertedLocationWinner predict sigma S x C) (fun p => predict p x) a g hg)

theorem locationActionMoment_variational (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (n : ℕ) (C : Fin n → X) :
    (∀ t : ℝ, 0 < t → t ≤ 1 / 2 →
      t * |locationActionMoment predict sigma S x a (fun z => z) n C| ≤
        locationActionEntropy predict sigma S x a n C +
          (4 / 3 : ℝ) * t ^ 2 * locationActionMoment predict sigma S x a (fun _ => 1) n C) ∧
    (∀ t : ℝ, 0 < t →
      t * |locationActionMoment predict sigma S x a laplaceSign n C| ≤
        locationActionEntropy predict sigma S x a n C +
          (t ^ 2 / 2) * locationActionMoment predict sigma S x a (fun _ => 1) n C) := by
  have h := winnerGroupMoment_variational (iidPool (laplaceMeasure K) n)
    (insertedLocationWinner predict sigma S x C) (measurable_insertedLocationWinner predict sigma S x C)
    (fun p => predict p x) a
  have hp := winnerGroupMoment_one (iidPool (laplaceMeasure K) n)
    (insertedLocationWinner predict sigma S x C) (measurable_insertedLocationWinner predict sigma S x C)
    (fun p => predict p x) a
  rw [← hp] at h
  exact h

theorem locationActionEntropy_bounds (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (n : ℕ) (C : Fin n → X) :
    0 ≤ locationActionEntropy predict sigma S x a n C ∧
      locationActionEntropy predict sigma S x a n C ≤ Real.log (Fintype.card P) :=
  ⟨winnerActionEntropy_nonneg _ _ _ _ _, winnerActionEntropy_le_log_card _ _ _
    (measurable_insertedLocationWinner predict sigma S x C) _ _⟩

theorem sum_locationActionEntropy (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (n : ℕ) (C : Fin n → X) :
    (∑ a, locationActionEntropy predict sigma S x a n C) =
      insertedLocationInformationReal predict sigma S n (x, C) :=
  sum_winnerActionEntropy _ _ _ (measurable_insertedLocationWinner predict sigma S x C) _

theorem integrable_finiteInsertedMoment (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (g : ℝ → ℝ) (hg : Integrable g realLaplace) (n : ℕ) :
    Integrable (finiteInsertedMoment predict sigma S x a g n)
      ((laplaceMeasure K).prod (iidPool (contextLaplaceLaw D K) n)) := by
  have hm : Measurable (fun v : (Fin K → ℝ) × (Fin n → X × (Fin K → ℝ)) => ((x, v.1), v.2)) :=
    (measurable_const.prodMk measurable_fst).prodMk measurable_snd
  have hW := (measurable_insertedMarkWinner predict sigma S n).comp hm
  exact integrable_selected_winner_observable _ _ hW (fun p => predict p x) a g hg

end

end PoissonAudit
