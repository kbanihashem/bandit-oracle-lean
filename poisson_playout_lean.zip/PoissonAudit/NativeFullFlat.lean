module
public import PoissonAudit.FlatConditionalWinner
public import PoissonAudit.FiniteOutcomeStability
public import PoissonAudit.UninsertedAveraging
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section

@[expose] def joinLaplaceBlocksEquiv (m K : ℕ) :
    ((Fin K → ℝ) × (Fin m → Fin K → ℝ)) ≃ᵐ (Fin (m + 1) → Fin K → ℝ) where
  toFun := fun v => Fin.cons v.1 v.2
  invFun := splitMark 0
  left_inv := by intro v; simp [splitMark]
  right_inv := by
    intro z
    funext i
    refine Fin.cases ?_ (fun j => ?_) i <;> simp [splitMark]
  measurable_toFun := by
    apply Measurable.of_eval
    intro i
    refine Fin.cases ?_ (fun j => ?_) i
    · exact measurable_fst
    · exact (measurable_pi_apply j).comp measurable_snd
  measurable_invFun := (measurable_pi_apply 0).prodMk (Measurable.of_eval fun i => measurable_pi_apply i.succ)

theorem joinLaplaceBlocksEquiv_measurePreserving (m K : ℕ) :
    MeasurePreserving (joinLaplaceBlocksEquiv m K) ((laplaceMeasure K).prod (iidPool (laplaceMeasure K) m))
      (iidPool (laplaceMeasure K) (m + 1)) := by
  have h : MeasurePreserving (joinLaplaceBlocksEquiv m K).symm (iidPool (laplaceMeasure K) (m + 1))
      ((laplaceMeasure K).prod (iidPool (laplaceMeasure K) m)) := splitMark_measurePreserving _ 0
  exact MeasurePreserving.symm (joinLaplaceBlocksEquiv m K).symm h

@[expose] def fullInsertedFlatEquiv (m K : ℕ) :
    ((Fin K → ℝ) × (Fin m → Fin K → ℝ)) ≃ᵐ (Fin ((m + 1) * K) → ℝ) :=
  (joinLaplaceBlocksEquiv m K).trans (flatLaplacePoolEquiv (m + 1) K)

theorem fullInsertedFlatEquiv_measurePreserving (m K : ℕ) :
    MeasurePreserving (fullInsertedFlatEquiv m K) ((laplaceMeasure K).prod (iidPool (laplaceMeasure K) m))
      (iidPool realLaplace ((m + 1) * K)) := by
  rw [← laplaceMeasure_eq_iid]
  exact (flatLaplacePoolEquiv_measurePreserving (m + 1) K).comp (joinLaplaceBlocksEquiv_measurePreserving m K)

theorem fullInsertedFlatEquiv_apply (m K : ℕ) (v : (Fin K → ℝ) × (Fin m → Fin K → ℝ))
    (i : Fin (m + 1)) (a : Fin K) :
    fullInsertedFlatEquiv m K v (finProdFinEquiv (i, a)) = (Fin.cons v.1 v.2 : Fin (m + 1) → Fin K → ℝ) i a := by
  exact flatLaplacePoolEquiv_apply (m + 1) K (Fin.cons v.1 v.2) i a

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K m : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def fullFlatScale (sigma : X × Fin K → ℝ) (x : X) (C : Fin m → X)
    (j : Fin ((m + 1) * K)) : ℝ :=
  sigma ((Fin.cons x C : Fin (m + 1) → X) (finProdFinEquiv.symm j).1, (finProdFinEquiv.symm j).2)

theorem fullFlatScale_apply (sigma : X × Fin K → ℝ) (x : X) (C : Fin m → X) (i : Fin (m + 1)) (a : Fin K) :
    fullFlatScale sigma x C (finProdFinEquiv (i, a)) = sigma ((Fin.cons x C : Fin (m + 1) → X) i, a) := by
  simp [fullFlatScale]

@[expose] def fullFlatScore (predict : P → X → Fin K) (S : P → ℝ) (x : X) (C : Fin m → X)
    (p : P) (z : Fin ((m + 1) * K) → ℝ) : ℝ :=
  S p + ∑ i : Fin (m + 1), z (finProdFinEquiv (i, predict p ((Fin.cons x C : Fin (m + 1) → X) i)))

theorem measurable_fullFlatScore (predict : P → X → Fin K) (S : P → ℝ) (x : X) (C : Fin m → X) (p : P) :
    Measurable (fullFlatScore predict S x C p) := by unfold fullFlatScore; fun_prop

theorem fullFlatScore_eq_inserted (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (C : Fin m → X) (p : P)
    (v : (Fin K → ℝ) × (Fin m → Fin K → ℝ)) :
    fullFlatScore predict S x C p (scaleVector (fullFlatScale sigma x C) (fullInsertedFlatEquiv m K v)) =
      insertedPoolScore predict sigma S ((x, v.1), fun i => (C i, v.2 i)) p := by
  unfold fullFlatScore
  simp only [scaleVector, fullFlatScale_apply, fullInsertedFlatEquiv_apply]
  rw [Fin.sum_univ_succ]
  simp only [Fin.cons_zero, Fin.cons_succ, insertedPoolScore, markValue]
  ring

theorem fullFlatWinner_eq_inserted (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (C : Fin m → X) (v : (Fin K → ℝ) × (Fin m → Fin K → ℝ)) :
    winner (fun p => fullFlatScore predict S x C p (scaleVector (fullFlatScale sigma x C) (fullInsertedFlatEquiv m K v))) =
      insertedLocationWinner predict sigma S x C v := by
  apply congrArg winner
  funext p
  exact fullFlatScore_eq_inserted predict sigma S x C p v
end
end PoissonAudit
