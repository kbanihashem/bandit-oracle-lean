module
public import PoissonAudit.NativeCappedChoiceBound
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem integrable_nativeMixtureError_flagged (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (B gamma : ℝ) (x : X) (ref : Fin K → ℝ)
    (mu : Measure (NativeFlaggedState X K B)) [IsFiniteMeasure mu] :
    Integrable (fun state : NativeFlaggedState X K B =>
      ∑ a, |nativeBanditProbability r D predict state.1.2.val S gamma x a - ref a|) mu := by
  apply integrable_finsetSum
  intro a _
  have hp : Measurable (fun state : NativeFlaggedState X K B => experimentProbability r D predict state.1.2.val S x a) :=
    (measurable_experimentProbability_scale r D predict S x a).comp
      (measurable_subtype_coe.comp (measurable_snd.comp measurable_fst))
  have hi : Integrable (fun state : NativeFlaggedState X K B => experimentProbability r D predict state.1.2.val S x a) mu := by
    apply Integrable.of_bound hp.aestronglyMeasurable 1
    filter_upwards [] with state
    rw [Real.norm_eq_abs, abs_of_nonneg (experimentProbability_nonneg r D predict state.1.2.val S x a)]
    exact experimentProbability_le_one r D predict state.1.2.val S x a
  exact (((hi.const_mul (1 - gamma)).add (integrable_const (gamma / K))).sub (integrable_const (ref a))).abs

theorem native_capped_reference_error (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta gamma : ℝ) (hB : 1 ≤ B)
    (hK : 0 < K) (hg0 : 0 ≤ gamma) (hg1 : gamma ≤ 1) (cap J m : ℕ) (hc : 0 < cap) (hm : 0 < m)
    (x : X) (ref : Fin K → ℝ) (href : ∀ a, 0 ≤ ref a) (hres : ∑ a, ref a = 1) :
    (∫ choice, ∑ a, |choiceProbability K gamma m choice a - ref a|
      ∂(nativeCappedChoiceLaw r D predict S lam B eta hB cap J m x).toMeasure) ≤
        K * Real.sqrt (1 / m) +
          (∫ state : NativeFlaggedState X K B, ∑ a, |nativeBanditProbability r D predict state.1.2.val S gamma x a - ref a|
            ∂nativeFlaggedStateLaw r D predict S lam B eta hB cap J) +
              2 * ((J + m : ℕ) * ((r : ℝ) / cap)) := by
  let mu := nativeFlaggedStateLaw r D predict S lam B eta hB cap J
  let err := fun state : NativeFlaggedState X K B => ∑ a, |nativeBanditProbability r D predict state.1.2.val S gamma x a - ref a|
  have hei : Integrable err mu := integrable_nativeMixtureError_flagged r D predict S B gamma x ref mu
  have hp (state : NativeFlaggedState X K B) :
      (∫ u, ∑ a, |choiceProbability K gamma m (cappedOutcomeChoice (state.2, u)) a - ref a|
        ∂iidPool (nativeEnrichedLaw r D predict state.1.2.val S x cap).toMeasure m) ≤
          K * Real.sqrt (1 / m) + err state + 2 * (boolStatistic state.2 + m * ((r : ℝ) / cap)) := by
    let nu := iidPool (nativeEnrichedLaw r D predict state.1.2.val S x cap).toMeasure m
    have h := integral_mono (μ := nu) Integrable.of_finite Integrable.of_finite
      (fun u => capped_choice_error hK gamma ref href hres state.2 u)
    change _ ≤ ∫ u, (∑ a, |empiricalMixture K gamma m (fun i => (u i).1) a - ref a|) +
      2 * (boolStatistic state.2 + boolStatistic (trialAnyOverflow u)) ∂nu at h
    rw [integral_add Integrable.of_finite Integrable.of_finite, integral_const_mul,
      integral_add (integrable_const _) Integrable.of_finite, integral_const, probReal_univ, one_smul] at h
    have he := native_enriched_reference_error r D predict state.1.2.val S gamma hg0 hg1 x cap m hm ref
    have hb := native_enriched_trial_overflow_budget r D predict state.1.2.val S x cap m hc
    change _ ≤ K * Real.sqrt (1 / m) + err state at he
    change (∫ u, boolStatistic (trialAnyOverflow u) ∂nu) ≤ _ at hb
    change (∫ u, ∑ a, |empiricalMixture K gamma m (fun i => (u i).1) a - ref a| ∂nu) ≤ _ at he
    linarith
  rw [integral_nativeCappedChoiceLaw]
  have hi := integral_mono (nativeCappedKernel_test_integrable r D predict S lam B eta hB cap J m x
    (fun choice => ∑ a, |choiceProbability K gamma m choice a - ref a|))
    (((integrable_const _).add hei).add (((integrable_flagStatistic B mu).add (integrable_const _)).const_mul 2)) hp
  change _ ≤ ∫ state, K * Real.sqrt (1 / m) + err state + 2 * (boolStatistic state.2 + m * ((r : ℝ) / cap)) ∂mu at hi
  rw [integral_add (f := fun state => (K : ℝ) * Real.sqrt (1 / m) + err state)
    (g := fun state : NativeFlaggedState X K B => 2 * (boolStatistic state.2 + m * ((r : ℝ) / cap)))
    ((integrable_const _).add hei) (((integrable_flagStatistic B mu).add (integrable_const _)).const_mul 2),
    integral_add (f := fun _ => (K : ℝ) * Real.sqrt (1 / m)) (g := err) (integrable_const _) hei, integral_const_mul 2 (fun state : NativeFlaggedState X K B => boolStatistic state.2 + m * ((r : ℝ) / cap)),
    integral_add (f := fun state : NativeFlaggedState X K B => boolStatistic state.2)
      (g := fun _ => (m : ℝ) * ((r : ℝ) / cap)) (integrable_flagStatistic B mu) (integrable_const _)] at hi
  simp only [integral_const, probReal_univ, one_smul] at hi
  have hb := native_construction_overflow_budget r D predict S lam B eta hB cap hc J
  change (∫ state, boolStatistic state.2 ∂mu) ≤ _ at hb
  change _ ≤ K * Real.sqrt (1 / m) + (∫ state, err state ∂mu) + _
  simp only [Nat.cast_add]
  nlinarith
end
end PoissonAudit
