module
public import PoissonAudit.CostedArrayReplay
public section
open scoped BigOperators
namespace PoissonAudit
noncomputable section

structure ArrayConstructionRun (X : Type*) (K : ℕ) where
  records : List (ReplayRecord X K)
  queries : List (List (CostExample X K))
  internalWork : ℕ
  allocatedWords : ℕ

@[expose] def executeArrayConstruction {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K) :
    (J : ℕ) → NativeNoiseTape X K J → ArrayConstructionRun X K
  | 0, _ => ⟨[], [], 0, 0⟩
  | J + 1, tape =>
    let old := executeArrayConstruction r lam B eta history oracle fallback J tape.1
    let runs := Vector.ofFn (fun i : Fin tape.2.2.1 =>
      executeArrayReplay r lam B eta history oracle fallback old.records (tape.2.2.2 i).1)
    let examples := List.ofFn (fun i : Fin tape.2.2.1 =>
      let scale := (runs.get i).state.1
      let coeff := Vector.ofFn (fun a => vectorValues scale a * (tape.2.2.2 i).2 a)
      ((tape.2.2.2 i).1, vectorValues coeff))
    let requests := (runs.toList.map ArrayReplayRun.queries).flatten
    ⟨(tape.2.1, examples) :: old.records, old.queries ++ requests,
      old.internalWork + (∑ i : Fin tape.2.2.1, ((runs.get i).internalWork + 4 * K + 1)) +
        old.queries.length + requests.length + 1,
      old.allocatedWords + (∑ i : Fin tape.2.2.1, ((runs.get i).allocatedWords + K + 1)) +
        old.queries.length + requests.length + 1⟩

theorem executeArrayConstruction_correct {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (J : ℕ) (tape : NativeNoiseTape X K J) :
    (executeArrayConstruction r lam B eta history oracle fallback J tape).records =
      buildReplayRecords r lam B eta history oracle fallback J tape ∧
    (executeArrayConstruction r lam B eta history oracle fallback J tape).queries =
      buildReplayQueries r lam B eta history oracle fallback J tape := by
  induction J with
  | zero => exact ⟨rfl, rfl⟩
  | succ J ih =>
    have hold := ih tape.1
    constructor
    · dsimp only [executeArrayConstruction, buildReplayRecords]
      rw [hold.1]
      congr 1
      apply Prod.ext
      · rfl
      · unfold makeReplayRecord scaledPoolExamples
        apply congrArg List.ofFn
        funext i
        apply Prod.ext
        · rfl
        · rw [vectorValues_ofFn]
          funext a
          simp only [vectorGet_ofFn]
          have hv := congrArg Prod.fst (executeArrayReplay_correct r lam B eta history oracle fallback
            (buildReplayRecords r lam B eta history oracle fallback J tape.1) (tape.2.2.2 i).1).1
          exact congrFun hv a |> fun h => congrArg (fun z => z * (tape.2.2.2 i).2 a) h
    · dsimp only [executeArrayConstruction, buildReplayQueries]
      rw [hold.1, hold.2]
      congr 1
      simp only [Vector.toList_ofFn, List.map_ofFn]
      apply congrArg List.flatten
      apply congrArg List.ofFn
      funext i
      simp only [Function.comp_apply]
      exact (executeArrayReplay_correct r lam B eta history oracle fallback
        (buildReplayRecords r lam B eta history oracle fallback J tape.1) (tape.2.2.2 i).1).2
end
end PoissonAudit
