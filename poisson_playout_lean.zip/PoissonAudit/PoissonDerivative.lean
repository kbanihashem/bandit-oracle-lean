module

public import PoissonAudit.ContextPoolTies

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}

@[expose] def poissonScore (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (pool : ℕ × (ℕ → X × (Fin K → ℝ))) (p : P) : ℝ :=
  S p + ∑ j, sigma j * poissonCoefficient predict pool p j

theorem integrable_poisson_linear_score (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (p : P) :
    Integrable (fun pool => ∑ j, sigma j * poissonCoefficient predict pool p j)
      (markedPoolLaw r (contextLaplaceLaw D K)) :=
  integrable_finsetSum _ fun j _ => (integrable_poissonCoefficient r D predict p j).const_mul _

variable [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def poissonWinner (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (pool : ℕ × (ℕ → X × (Fin K → ℝ))) : P :=
  winner (poissonScore predict sigma S pool)

theorem measurable_poissonWinner (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) : Measurable (poissonWinner predict sigma S) :=
  measurable_winner (fun p pool => poissonScore predict sigma S pool p)
    (fun p => measurable_const.add (measurable_poisson_linear_score predict sigma p))

theorem hasDerivAt_poisson_potential (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma h : X × Fin K → ℝ)
    (hsigma : ∀ j, 0 < sigma j) (S : P → ℝ) :
    HasDerivAt
      (fun t : ℝ => affinePoolPotential (markedPoolLaw r (contextLaplaceLaw D K)) S
        (poissonCoefficient predict) (fun j => sigma j + t * h j))
      (∫ pool, ∑ j, h j * poissonCoefficient predict pool (poissonWinner predict sigma S pool) j
        ∂markedPoolLaw r (contextLaplaceLaw D K)) 0 := by
  classical
  let mu := markedPoolLaw r (contextLaplaceLaw D K)
  let A : P → (ℕ × (ℕ → X × (Fin K → ℝ))) → ℝ := fun p pool => poissonScore predict sigma S pool p
  let B : P → (ℕ × (ℕ → X × (Fin K → ℝ))) → ℝ := fun p pool => ∑ j, h j * poissonCoefficient predict pool p j
  let w := poissonWinner predict sigma S
  have hAi (p : P) : Integrable (A p) mu :=
    (integrable_const _).add (integrable_poisson_linear_score r D predict sigma p)
  have hBi (p : P) : Integrable (B p) mu := integrable_poisson_linear_score r D predict h p
  have hBm (p : P) : Measurable (B p) := measurable_poisson_linear_score predict h p
  have hwm : Measurable w := measurable_poissonWinner predict sigma S
  have hall : ∀ᵐ pool ∂mu, ∀ p q, A p pool = A q pool → B p pool = B q pool :=
    ae_all_iff.mpr fun p => ae_all_iff.mpr fun q => poisson_pool_tie_slopes r D predict sigma h hsigma S p q
  have hties : ∀ᵐ pool ∂mu, ∀ p, A p pool = A (w pool) pool → B p pool = B (w pool) pool := by
    filter_upwards [hall] with pool hp
    exact fun p => hp p (w pool)
  have hw : ∀ᵐ pool ∂mu, ∀ p, A p pool ≤ A (w pool) pool :=
    Filter.Eventually.of_forall fun pool p => (winner_spec (poissonScore predict sigma S pool)).1 p
  have hd := hasDerivAt_expected_lineMax mu A B hAi hBi hBm w hwm hw hties
  convert hd using 1
  funext t
  apply integral_congr_ae
  filter_upwards [] with pool
  change (Finset.univ.sup' Finset.univ_nonempty (fun p => S p + ∑ j,
    (sigma j + t * h j) * poissonCoefficient predict pool p j)) =
    Finset.univ.sup' Finset.univ_nonempty (fun p => A p pool + t * B p pool)
  apply Finset.sup'_congr Finset.univ_nonempty rfl
  intro p _
  change S p + (∑ j, (sigma j + t * h j) * poissonCoefficient predict pool p j) =
    (S p + ∑ j, sigma j * poissonCoefficient predict pool p j) + t * ∑ j, h j * poissonCoefficient predict pool p j
  simp only [add_mul, Finset.sum_add_distrib, mul_assoc, Finset.mul_sum, add_assoc]

theorem integrable_poisson_selected_slope (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma h : X × Fin K → ℝ) (S : P → ℝ) :
    Integrable (fun pool => ∑ j, h j * poissonCoefficient predict pool (poissonWinner predict sigma S pool) j)
      (markedPoolLaw r (contextLaplaceLaw D K)) := by
  classical
  let B : P → (ℕ × (ℕ → X × (Fin K → ℝ))) → ℝ := fun p pool => ∑ j, h j * poissonCoefficient predict pool p j
  have hBm (p : P) : Measurable (B p) := measurable_poisson_linear_score predict h p
  have hjoint : Measurable (fun v : (ℕ × (ℕ → X × (Fin K → ℝ))) × P => B v.2 v.1) :=
    measurable_from_prod_countable_left hBm
  have hsel := hjoint.comp (measurable_id.prodMk (measurable_poissonWinner predict sigma S))
  apply (integrable_finsetSum Finset.univ fun p _ =>
    (integrable_poisson_linear_score r D predict h p).abs).mono' hsel.aestronglyMeasurable
  filter_upwards [] with pool
  rw [Real.norm_eq_abs]
  exact Finset.single_le_sum (f := fun p : P => |B p pool|)
    (fun _ _ => abs_nonneg _) (Finset.mem_univ (poissonWinner predict sigma S pool))

end

end PoissonAudit
