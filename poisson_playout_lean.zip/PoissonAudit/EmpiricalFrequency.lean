module
public import PoissonAudit.ActionSampling
public import PoissonAudit.MarkedPoisson
public import Mathlib.Probability.Moments.Variance
public section
open MeasureTheory ProbabilityTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {A : Type*} [Fintype A] [MeasurableSpace A] [MeasurableSingletonClass A]

@[expose] def actionIndicator (a b : A) : ℝ := by
  classical
  exact if b = a then 1 else 0
@[expose] def empiricalFrequency (m : ℕ) (a : A) (u : Fin m → A) : ℝ :=
  (∑ i, actionIndicator a (u i)) / m

theorem actionIndicator_mem (a b : A) : actionIndicator a b ∈ Set.Icc (0 : ℝ) 1 := by
  classical
  unfold actionIndicator
  split_ifs <;> norm_num

theorem empiricalFrequency_mem (m : ℕ) (hm : 0 < m) (a : A) (u : Fin m → A) :
    empiricalFrequency m a u ∈ Set.Icc (0 : ℝ) 1 := by
  have hm0 : (0 : ℝ) < m := by exact_mod_cast hm
  constructor
  · exact div_nonneg (Finset.sum_nonneg fun i _ => (actionIndicator_mem a (u i)).1) hm0.le
  · apply (div_le_one hm0).mpr
    have h := Finset.sum_le_sum (s := Finset.univ) fun i _ => (actionIndicator_mem a (u i)).2
    simpa using h

theorem integral_actionIndicator (p : A → ℝ) (hp : ∀ a, 0 ≤ p a) (hsum : ∑ a, p a = 1) (a : A) :
    (∫ b, actionIndicator a b ∂(actionPMF p hp hsum).toMeasure) = p a := by
  classical
  rw [integral_actionPMF]
  simp [actionIndicator]

theorem iid_integral_actionIndicator (p : A → ℝ) (hp : ∀ a, 0 ≤ p a) (hsum : ∑ a, p a = 1)
    (m : ℕ) (i : Fin m) (a : A) :
    (∫ u : Fin m → A, actionIndicator a (u i) ∂iidPool (actionPMF p hp hsum).toMeasure m) = p a := by
  have hmp := measurePreserving_eval (fun _ : Fin m => (actionPMF p hp hsum).toMeasure) i
  have h := integral_map hmp.measurable.aemeasurable (f := actionIndicator a)
    (by rw [hmp.map_eq]; exact (measurable_of_finite _).aestronglyMeasurable)
  rw [hmp.map_eq, integral_actionIndicator] at h
  exact h.symm

theorem integral_empiricalFrequency (p : A → ℝ) (hp : ∀ a, 0 ≤ p a) (hsum : ∑ a, p a = 1)
    (m : ℕ) (hm : 0 < m) (a : A) :
    (∫ u, empiricalFrequency m a u ∂iidPool (actionPMF p hp hsum).toMeasure m) = p a := by
  unfold empiricalFrequency
  rw [integral_div, integral_finsetSum _ (fun _ _ => Integrable.of_finite)]
  simp only [iid_integral_actionIndicator, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
  have hm0 : (m : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (Nat.ne_of_gt hm)
  field_simp

theorem variance_actionIndicator_le_one (p : A → ℝ) (hp : ∀ a, 0 ≤ p a) (hsum : ∑ a, p a = 1) (a : A) :
    variance (actionIndicator a) (actionPMF p hp hsum).toMeasure ≤ 1 := by
  have h := variance_le_expectation_sq (μ := (actionPMF p hp hsum).toMeasure)
    (measurable_of_finite (actionIndicator a)).aestronglyMeasurable
  have heq : (actionIndicator a) ^ 2 = actionIndicator a := by
    funext b
    change (actionIndicator a b) ^ 2 = actionIndicator a b
    classical
    unfold actionIndicator
    split_ifs <;> norm_num
  rw [heq, integral_actionIndicator] at h
  have ha : p a ≤ 1 := by
    rw [← hsum]
    exact Finset.single_le_sum (fun b _ => hp b) (Finset.mem_univ a)
  exact h.trans ha
end
end PoissonAudit
