module
public import PoissonAudit.CostedArrayTrial
public section
open scoped BigOperators
namespace PoissonAudit
noncomputable section

@[expose] def tapeCapCheck {X : Type*} {K : ℕ} (cap : ℕ) : (J : ℕ) → NativeNoiseTape X K J → Bool
  | 0, _ => true
  | J + 1, tape => tapeCapCheck cap J tape.1 && decide (tape.2.2.1 ≤ cap)

theorem tapeCapCheck_correct {X : Type*} {K : ℕ} (cap J : ℕ) (tape : NativeNoiseTape X K J) :
    tapeCapCheck cap J tape = true ↔ nativeTapeCountsBounded cap J tape := by
  induction J with
  | zero => simp [tapeCapCheck, nativeTapeCountsBounded]
  | succ J ih => simpa only [tapeCapCheck, Bool.and_eq_true, decide_eq_true_eq, nativeTapeCountsBounded] using and_congr (ih tape.1) Iff.rfl

@[expose] def samplerCapCheck {X : Type*} {K : ℕ} (cap J m : ℕ)
    (tape : NativeNoiseTape X K J) (trials : Fin m → NativeNoise X K) : Bool :=
  tapeCapCheck cap J tape && (List.ofFn (fun i => (trials i).2.1)).all (fun n => decide (n ≤ cap))

theorem samplerCapCheck_correct {X : Type*} {K : ℕ} (cap J m : ℕ)
    (tape : NativeNoiseTape X K J) (trials : Fin m → NativeNoise X K) :
    samplerCapCheck cap J m tape trials = true ↔ nativeTapeCountsBounded cap J tape ∧ ∀ i, (trials i).2.1 ≤ cap := by
  simp [samplerCapCheck, tapeCapCheck_correct, List.all_eq_true, List.mem_ofFn]

structure ArraySamplerRun (X : Type*) (K m : ℕ) where
  choice : EmpiricalChoice K m
  queries : List (List (CostExample X K))
  internalWork : ℕ
  allocatedWords : ℕ

@[expose] def executeArraySampler {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (cap J m : ℕ) (tape : NativeNoiseTape X K J) (trials : Fin m → NativeNoise X K) (x : X) : ArraySamplerRun X K m :=
  if samplerCapCheck cap J m tape trials then
    let built := executeArrayConstruction r lam B eta history oracle fallback J tape
    let runs := Vector.ofFn (fun i => executeArrayTrial r lam B eta history oracle fallback built.records x (trials i))
    let actions := Vector.ofFn (fun i => (runs.get i).action)
    let requests := (runs.toList.map ArrayTrialRun.queries).flatten
    ⟨some actions.get, built.queries ++ requests,
      built.internalWork + (∑ i : Fin m, ((runs.get i).internalWork + 1)) +
        built.queries.length + requests.length + 4 * (J + m + 1),
      built.allocatedWords + (∑ i : Fin m, ((runs.get i).allocatedWords + 1)) +
        built.queries.length + requests.length + 4 * (J + m + 1)⟩
  else ⟨none, [], 4 * (J + m + 1), 4 * (J + m + 1)⟩

theorem executeArraySampler_correct {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (cap J m : ℕ) (tape : NativeNoiseTape X K J) (trials : Fin m → NativeNoise X K) (x : X) :
    (executeArraySampler r lam B eta history oracle fallback cap J m tape trials x).choice =
      cappedOracleChoice r lam B eta history oracle fallback cap J m tape trials x ∧
    (executeArraySampler r lam B eta history oracle fallback cap J m tape trials x).queries =
      cappedOracleQueries r lam B eta history oracle fallback cap J m tape trials x := by
  classical
  unfold executeArraySampler cappedOracleChoice cappedOracleQueries
  by_cases hc : samplerCapCheck cap J m tape trials = true
  · have hb := (samplerCapCheck_correct cap J m tape trials).mp hc
    simp only [hc, ite_true]
    rw [if_pos hb, if_pos hb]
    have hbuilt := executeArrayConstruction_correct r lam B eta history oracle fallback J tape
    constructor
    · congr 1
      funext i
      simp only [vectorGet_ofFn, hbuilt.1, (executeArrayTrial_correct r lam B eta history oracle fallback _ x _).1]
    · simp only [hbuilt.1, hbuilt.2, Vector.toList_ofFn, List.map_ofFn]
      congr 1
      apply congrArg List.flatten
      apply congrArg List.ofFn
      funext i
      exact (executeArrayTrial_correct r lam B eta history oracle fallback _ x _).2
  · have hb : ¬ (nativeTapeCountsBounded cap J tape ∧ ∀ i, (trials i).2.1 ≤ cap) := by
      rwa [← samplerCapCheck_correct]
    simp [hc, hb]

@[expose] def samplerInternalBudget (K cap J m : ℕ) : ℕ :=
  J * constructionStepBudget K cap J + m * (trialInternalBudget K cap J + 1) +
    cap * J ^ 2 * (K + 1) + m * (((cap + 1) * J + 1) * (K + 1)) + 4 * (J + m + 1)

theorem executeArraySampler_work {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (cap J m : ℕ) (tape : NativeNoiseTape X K J) (trials : Fin m → NativeNoise X K) (x : X) :
    (executeArraySampler r lam B eta history oracle fallback cap J m tape trials x).internalWork ≤
      samplerInternalBudget K cap J m := by
  unfold executeArraySampler
  split_ifs with hc
  · have hb := (samplerCapCheck_correct cap J m tape trials).mp hc
    let built := executeArrayConstruction r lam B eta history oracle fallback J tape
    let runs := Vector.ofFn (fun i => executeArrayTrial r lam B eta history oracle fallback built.records x (trials i))
    have hbuilt := executeArrayConstruction_correct r lam B eta history oracle fallback J tape
    have hlen : built.records.length = J := by rw [hbuilt.1, buildReplayRecords_length]
    have hbw := executeArrayConstruction_work r lam B eta history oracle fallback cap J J tape hb.1 (le_refl _)
    change built.internalWork ≤ _ at hbw
    have hbq : built.queries.length ≤ cap * J ^ 2 * (K + 1) := by
      rw [hbuilt.2]
      exact buildReplayQueries_count r lam B eta history oracle fallback cap J tape hb.1
    have hrun (i : Fin m) : (runs.get i).internalWork ≤ trialInternalBudget K cap J := by
      dsimp only [runs]
      rw [vectorGet_ofFn]
      have h := executeArrayTrial_work r lam B eta history oracle fallback built.records x (trials i) cap (hb.2 i)
      rwa [hlen] at h
    have hs : (∑ i : Fin m, ((runs.get i).internalWork + 1)) ≤ m * (trialInternalBudget K cap J + 1) := by
      have h := Finset.sum_le_sum (s := Finset.univ) (fun i _ => Nat.add_le_add_right (hrun i) 1)
      simpa only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, Nat.cast_id] using h
    have hreq : (runs.toList.map ArrayTrialRun.queries).flatten.length ≤ m * (((cap + 1) * J + 1) * (K + 1)) := by
      dsimp only [runs]
      simp only [Vector.toList_ofFn, List.map_ofFn, List.length_flatten, List.sum_ofFn, Function.comp_apply]
      simp only [(executeArrayTrial_correct r lam B eta history oracle fallback _ x _).2, replayTrialQueries_count, hlen]
      have h := Finset.sum_le_sum (s := Finset.univ) (fun i _ =>
        Nat.mul_le_mul_right (K + 1) (Nat.add_le_add_right (Nat.mul_le_mul_right J (Nat.add_le_add_right (hb.2 i) 1)) 1))
      simpa only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, Nat.cast_id] using h
    change built.internalWork + (∑ i : Fin m, ((runs.get i).internalWork + 1)) + built.queries.length +
      (runs.toList.map ArrayTrialRun.queries).flatten.length + 4 * (J + m + 1) ≤ _
    unfold samplerInternalBudget
    omega
  · simp only [ArraySamplerRun.internalWork]
    unfold samplerInternalBudget
    omega
end
end PoissonAudit
