module

public import PoissonAudit.ExperimentBeta

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X]
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]
    {K : ℕ}

theorem experimentEvent_none (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (hnone : ∀ p, predict p x ≠ a) :
    experimentActionEvent predict sigma S x a = ∅ := by
  ext v
  simp [experimentActionEvent, outcomeEvent, experimentAction, hnone]

theorem experimentEvent_all (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (hall : ∀ p, predict p x = a) :
    experimentActionEvent predict sigma S x a = Set.univ := by
  ext v
  simp [experimentActionEvent, outcomeEvent, experimentAction, hall]

theorem experimentProbability_none (r : NNReal) (D : Measure X)
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (hnone : ∀ p, predict p x ≠ a) :
    experimentProbability r D predict sigma S x a = 0 := by
  change ((insertedExperimentLaw r D K) (experimentActionEvent predict sigma S x a)).toReal = 0
  rw [experimentEvent_none predict sigma S x a hnone]
  simp

theorem experimentProbability_all (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (hall : ∀ p, predict p x = a) :
    experimentProbability r D predict sigma S x a = 1 := by
  change ((insertedExperimentLaw r D K) (experimentActionEvent predict sigma S x a)).toReal = 1
  rw [experimentEvent_all predict sigma S x a hall]
  simp

theorem experimentBeta_none (r : NNReal) (D : Measure X)
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (hnone : ∀ p, predict p x ≠ a) :
    experimentBeta r D predict sigma S x a = 0 := by
  unfold experimentBeta
  rw [experimentEvent_none predict sigma S x a hnone]
  simp

theorem integral_laplace_coordinate_sign (K : ℕ) (a : Fin K) :
    (∫ z : Fin K → ℝ, laplaceSign (z a) ∂laplaceMeasure K) = 0 := by
  rw [laplaceMeasure_eq_iid]
  have hmp := measurePreserving_eval (fun _ : Fin K => realLaplace) a
  have h := integral_map hmp.measurable.aemeasurable (f := laplaceSign)
    (by rw [hmp.map_eq]; exact measurable_laplaceSign.aestronglyMeasurable)
  rw [hmp.map_eq, integral_realLaplace_sign] at h
  exact h.symm

theorem integral_experiment_coordinate_sign (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (K : ℕ) (a : Fin K) :
    (∫ v : (Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ))), laplaceSign (v.1 a)
      ∂insertedExperimentLaw r D K) = 0 := by
  have hi : Integrable (fun v : (Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ))) => laplaceSign (v.1 a))
      ((laplaceMeasure K).prod (markedPoolLaw r (contextLaplaceLaw D K))) := by
    apply Integrable.of_bound
      (measurable_laplaceSign.comp ((measurable_pi_apply a).comp measurable_fst)).aestronglyMeasurable 1
    filter_upwards [] with v
    simp [Real.norm_eq_abs, abs_laplaceSign]
  change (∫ v, laplaceSign (v.1 a) ∂(laplaceMeasure K).prod (markedPoolLaw r (contextLaplaceLaw D K))) = 0
  rw [integral_prod _ hi]
  simp only [integral_const, probReal_univ, one_smul]
  exact integral_laplace_coordinate_sign K a

theorem experimentBeta_all (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (hall : ∀ p, predict p x = a) :
    experimentBeta r D predict sigma S x a = 0 := by
  unfold experimentBeta
  rw [experimentEvent_all predict sigma S x a hall]
  simp only [Set.indicator_univ, one_mul]
  exact integral_experiment_coordinate_sign r D K a

theorem insertedPotential_remainder_none (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (hnone : ∀ p, predict p x ≠ a) (b : ℝ) :
    insertedPotential r D predict sigma (actionPenaltyScore predict S x a b) x -
      insertedPotential r D predict sigma S x + b * experimentProbability r D predict sigma S x a = 0 := by
  have h := insertedPotential_action_change r D predict sigma S x a b
  simp_rw [experimentProbability_none r D predict sigma _ x a hnone] at h
  simp only [intervalIntegral.integral_zero, neg_zero] at h
  rw [h, experimentProbability_none r D predict sigma S x a hnone]
  ring

theorem insertedPotential_remainder_all (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (hall : ∀ p, predict p x = a) (b : ℝ) :
    insertedPotential r D predict sigma (actionPenaltyScore predict S x a b) x -
      insertedPotential r D predict sigma S x + b * experimentProbability r D predict sigma S x a = 0 := by
  have h := insertedPotential_action_change r D predict sigma S x a b
  simp_rw [experimentProbability_all r D predict sigma _ x a hall] at h
  simp only [intervalIntegral.integral_const, sub_zero, smul_eq_mul, mul_one] at h
  rw [h, experimentProbability_all r D predict sigma S x a hall]
  ring

end

end PoissonAudit
