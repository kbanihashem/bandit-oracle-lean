module

public import PoissonAudit.PoolLinearScore

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} {m K : ℕ}

theorem measurable_poolLinearScore (predict : P → X → Fin K)
    (sigma : X × Fin K → ℝ) (C : Fin m → X) (p : P) :
    Measurable (poolLinearScore predict sigma C p) := by
  change Measurable (fun z : Fin m → Fin K → ℝ => ∑ i, sigma (C i, predict p (C i)) * z i (predict p (C i)))
  fun_prop

theorem integrable_poolLinearScore (predict : P → X → Fin K)
    (sigma : X × Fin K → ℝ) (C : Fin m → X) (p : P) :
    Integrable (poolLinearScore predict sigma C p) (iidPool (laplaceMeasure K) m) := by
  change Integrable (fun z : Fin m → Fin K → ℝ => ∑ i, sigma (C i, predict p (C i)) * z i (predict p (C i))) _
  apply integrable_finsetSum
  intro i _
  exact ((measurePreserving_eval (fun _ : Fin m => laplaceMeasure K) i).integrable_comp_of_integrable
    (integrable_laplace_coordinate K (predict p (C i)))).const_mul _

theorem poolLinearScore_scale_line (predict : P → X → Fin K)
    (sigma h : X × Fin K → ℝ) (C : Fin m → X) (p : P)
    (t : ℝ) (z : Fin m → Fin K → ℝ) :
    poolLinearScore predict (fun j => sigma j + t * h j) C p z =
      poolLinearScore predict sigma C p z + t * poolLinearScore predict h C p z := by
  change (∑ i, (sigma (C i, predict p (C i)) + t * h (C i, predict p (C i))) * z i (predict p (C i))) =
    (∑ i, sigma (C i, predict p (C i)) * z i (predict p (C i))) + t * (∑ i, h (C i, predict p (C i)) * z i (predict p (C i)))
  simp only [add_mul, Finset.sum_add_distrib, mul_assoc, Finset.mul_sum]

variable [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem hasDerivAt_fixed_pool_expected_max (predict : P → X → Fin K)
    (sigma h : X × Fin K → ℝ) (hsigma : ∀ j, 0 < sigma j)
    (C : Fin m → X) (S : P → ℝ) :
    HasDerivAt
      (fun t : ℝ => ∫ z, Finset.univ.sup' Finset.univ_nonempty
        (fun p => S p + poolLinearScore predict (fun j => sigma j + t * h j) C p z)
        ∂iidPool (laplaceMeasure K) m)
      (∫ z, poolLinearScore predict h C
        (winner (fun p => S p + poolLinearScore predict sigma C p z)) z
        ∂iidPool (laplaceMeasure K) m) 0 := by
  classical
  let A : P → (Fin m → Fin K → ℝ) → ℝ := fun p z => S p + poolLinearScore predict sigma C p z
  let B : P → (Fin m → Fin K → ℝ) → ℝ := fun p z => poolLinearScore predict h C p z
  let w := fun z => winner (fun p => A p z)
  have hAi (p : P) : Integrable (A p) (iidPool (laplaceMeasure K) m) :=
    (integrable_const _).add (integrable_poolLinearScore predict sigma C p)
  have hBi (p : P) : Integrable (B p) (iidPool (laplaceMeasure K) m) :=
    integrable_poolLinearScore predict h C p
  have hBm (p : P) : Measurable (B p) := measurable_poolLinearScore predict h C p
  have hwm : Measurable w :=
    measurable_winner A (fun p => measurable_const.add (measurable_poolLinearScore predict sigma C p))
  have htie (p q : P) : ∀ᵐ z ∂iidPool (laplaceMeasure K) m, A p z = A q z → B p z = B q z := by
    filter_upwards [laplace_pool_tie_forces_agreement predict sigma hsigma C S p q] with z hz hA
    have hag := hz hA
    exact congrArg (fun L : (Fin m → Fin K → ℝ) →ₗ[ℝ] ℝ => L z)
      (poolLinearScore_eq_of_agree predict h C p q hag)
  have hall : ∀ᵐ z ∂iidPool (laplaceMeasure K) m, ∀ p q, A p z = A q z → B p z = B q z :=
    ae_all_iff.mpr fun p => ae_all_iff.mpr fun q => htie p q
  have hties : ∀ᵐ z ∂iidPool (laplaceMeasure K) m, ∀ p, A p z = A (w z) z → B p z = B (w z) z := by
    filter_upwards [hall] with z hz
    exact fun p => hz p (w z)
  have hw : ∀ᵐ z ∂iidPool (laplaceMeasure K) m, ∀ p, A p z ≤ A (w z) z :=
    Filter.Eventually.of_forall fun z p => (winner_spec (fun p => A p z)).1 p
  have hd := hasDerivAt_expected_lineMax (iidPool (laplaceMeasure K) m) A B hAi hBi hBm w hwm hw hties
  convert hd using 1
  funext t
  apply integral_congr_ae
  filter_upwards [] with z
  change (Finset.univ.sup' Finset.univ_nonempty (fun p => S p + poolLinearScore predict (fun j => sigma j + t * h j) C p z)) =
    Finset.univ.sup' Finset.univ_nonempty (fun p => A p z + t * B p z)
  apply Finset.sup'_congr Finset.univ_nonempty rfl
  intro p _
  rw [poolLinearScore_scale_line]
  change S p + (poolLinearScore predict sigma C p z + t * poolLinearScore predict h C p z) =
    (S p + poolLinearScore predict sigma C p z) + t * poolLinearScore predict h C p z
  ring

end

end PoissonAudit
