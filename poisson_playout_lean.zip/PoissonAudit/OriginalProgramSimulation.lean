module
public import PoissonAudit.OracleFeedbackHistory
public section
open MeasureTheory Set
namespace PoissonAudit
noncomputable section
variable {X Y P : Type*} [MeasurableSpace X] [MeasurableSpace Y] [MeasurableSingletonClass Y] [Fintype Y]
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P] {K : ℕ}

theorem arrayCappedChoice_quotient_law (f : X → Y) (hf : Measurable f) (r : NNReal)
    (D : Measure X) [IsProbabilityMeasure D] (predictX : P → X → Fin K) (predictY : P → Y → Fin K)
    (hpredict : ∀ p x, predictY p (f x) = predictX p x)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ)
    (horacle : ∀ Q, oracle Q = treeBestScore (queryScore predictX Q)) (fallback : Fin K)
    (lam B eta : ℝ) (hB : 1 ≤ B) (cap J m : ℕ) (x : X) :
    ((nativeNoiseTapeLaw (K := K) r D J).prod (iidPool (insertedExperimentLaw r D K) m)).map
      (fun v => arrayCappedChoice r lam B eta history oracle fallback cap J m v.1 v.2 x) =
        (nativeCappedChoiceLaw r (D.map f) predictY (queryScore predictY (mapCostQuery f history))
          lam B eta hB cap J m (f x)).toMeasure := by
  simp only [arrayCappedChoice_eq]
  exact cappedOracleChoice_quotient_law f hf r D predictX predictY hpredict history oracle horacle fallback lam B eta hB cap J m x

theorem feedback_only_program_simulation (f : X → Y) (hf : Measurable f) (r : NNReal)
    (D : Measure X) [IsProbabilityMeasure D] (predictX : P → X → Fin K) (predictY : P → Y → Fin K)
    (hpredict : ∀ p x, predictY p (f x) = predictX p x)
    (oracle : List (CostExample X K) → ℝ) (horacle : ∀ Q, oracle Q = treeBestScore (queryScore predictX Q))
    (fallback : Fin K) (lam B eta : ℝ) (hB : 1 ≤ B) (cap J m L : ℕ) (delta gamma : ℝ) :
    (∀ history x, ((nativeNoiseTapeLaw (K := K) r D J).prod (iidPool (insertedExperimentLaw r D K) m)).map
      (fun v => arrayCappedChoice r lam B eta history oracle fallback cap J m v.1 v.2 x) =
        (nativeCappedChoiceLaw r (D.map f) predictY (queryScore predictY (mapCostQuery f history))
          lam B eta hB cap J m (f x)).toMeasure) ∧
    (∀ history (rounds : List (ObservedBanditRound X K delta)),
      queryScore predictX (runObservedHistory L delta gamma history rounds) =
        runObservedScore predictX L delta gamma (queryScore predictX history) rounds) ∧
    (∀ history (rounds : List (ObservedBanditRound X K delta)),
      (runObservedHistory L delta gamma history rounds).length = history.length + rounds.length) :=
  ⟨fun history x => arrayCappedChoice_quotient_law f hf r D predictX predictY hpredict history oracle horacle fallback lam B eta hB cap J m x,
    fun history rounds => runObservedHistory_score predictX L delta gamma history rounds,
    fun history rounds => runObservedHistory_length L delta gamma history rounds⟩
end
end PoissonAudit
