module

public import PoissonAudit.LinearTies
public import PoissonAudit.ExpectedMaxDerivative
public import PoissonAudit.Winner

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} {m K : ℕ}

@[expose] def poolLinearScore (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (C : Fin m → X) (p : P) : (Fin m → Fin K → ℝ) →ₗ[ℝ] ℝ where
  toFun := fun z => ∑ i, sigma (C i, predict p (C i)) * z i (predict p (C i))
  map_add' z y := by simp only [Pi.add_apply, mul_add, Finset.sum_add_distrib]
  map_smul' r z := by
    simp only [Pi.smul_apply, smul_eq_mul, RingHom.id_apply, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i _
    ring

theorem poolLinearScore_eq_of_agree (predict : P → X → Fin K)
    (sigma : X × Fin K → ℝ) (C : Fin m → X) (p q : P)
    (hag : ∀ i, predict p (C i) = predict q (C i)) :
    poolLinearScore predict sigma C p = poolLinearScore predict sigma C q := by
  ext z
  simp only [poolLinearScore, LinearMap.coe_mk, AddHom.coe_mk, hag]

theorem poolLinearScore_sub_ne_zero (predict : P → X → Fin K)
    (sigma : X × Fin K → ℝ) (hsigma : ∀ j, 0 < sigma j)
    (C : Fin m → X) (p q : P) (i : Fin m) (hdiff : predict p (C i) ≠ predict q (C i)) :
    poolLinearScore predict sigma C p - poolLinearScore predict sigma C q ≠ 0 := by
  classical
  let z : Fin m → Fin K → ℝ := fun j a => if j = i ∧ a = predict p (C i) then 1 else 0
  have hp : poolLinearScore predict sigma C p z = sigma (C i, predict p (C i)) := by
    simp [poolLinearScore, z, ite_and, mul_ite]
  have hq : poolLinearScore predict sigma C q z = 0 := by
    simp [poolLinearScore, z, ite_and, mul_ite, hdiff.symm]
  intro hzero
  have h := congrArg (fun L : (Fin m → Fin K → ℝ) →ₗ[ℝ] ℝ => L z) hzero
  change poolLinearScore predict sigma C p z - poolLinearScore predict sigma C q z = 0 at h
  rw [hp, hq, sub_zero] at h
  exact (hsigma _).ne' h

theorem laplace_pool_tie_forces_agreement (predict : P → X → Fin K)
    (sigma : X × Fin K → ℝ) (hsigma : ∀ j, 0 < sigma j)
    (C : Fin m → X) (S : P → ℝ) (p q : P) :
    ∀ᵐ z ∂iidPool (laplaceMeasure K) m,
      S p + poolLinearScore predict sigma C p z = S q + poolLinearScore predict sigma C q z →
        ∀ i, predict p (C i) = predict q (C i) := by
  classical
  by_cases hag : ∀ i, predict p (C i) = predict q (C i)
  · exact Filter.Eventually.of_forall fun _ _ => hag
  · obtain ⟨i, hi⟩ := not_forall.mp hag
    have hL := poolLinearScore_sub_ne_zero predict sigma hsigma C p q i hi
    have hn := laplace_pool_ae_linear_ne m K _ hL (S q - S p)
    filter_upwards [hn] with z hz htie
    apply False.elim
    apply hz
    change poolLinearScore predict sigma C p z - poolLinearScore predict sigma C q z = S q - S p
    linarith

end

end PoissonAudit
