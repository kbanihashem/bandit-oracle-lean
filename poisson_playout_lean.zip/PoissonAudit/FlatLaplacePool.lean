module

public import PoissonAudit.LaplaceProductLaw
public import Mathlib.Logic.Equiv.Fin.Basic

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

@[expose] def flatLaplacePoolEquiv (m K : ℕ) :
    (Fin m → Fin K → ℝ) ≃ᵐ (Fin (m * K) → ℝ) :=
  (MeasurableEquiv.curry (Fin m) (Fin K) ℝ).symm.trans
    (MeasurableEquiv.piCongrLeft (fun _ : Fin (m * K) => ℝ) finProdFinEquiv)

theorem flatLaplacePoolEquiv_apply (m K : ℕ) (z : Fin m → Fin K → ℝ) (i : Fin m) (a : Fin K) :
    flatLaplacePoolEquiv m K z (finProdFinEquiv (i, a)) = z i a := by
  change MeasurableEquiv.piCongrLeft (fun _ : Fin (m * K) => ℝ) finProdFinEquiv
    (Function.uncurry z) (finProdFinEquiv (i, a)) = _
  rw [MeasurableEquiv.piCongrLeft_apply_apply]
  rfl

theorem flatLaplacePoolEquiv_measurePreserving (m K : ℕ) :
    MeasurePreserving (flatLaplacePoolEquiv m K) (iidPool (laplaceMeasure K) m) (laplaceMeasure (m * K)) := by
  rw [laplaceMeasure_eq_iid K, laplaceMeasure_eq_iid (m * K)]
  refine ⟨(flatLaplacePoolEquiv m K).measurable, ?_⟩
  symm
  unfold iidPool
  apply Measure.pi_eq
  intro s hs
  rw [Measure.map_apply (flatLaplacePoolEquiv m K).measurable (MeasurableSet.univ_pi hs)]
  have hpre : flatLaplacePoolEquiv m K ⁻¹' Set.pi Set.univ s =
      Set.pi Set.univ (fun i : Fin m => Set.pi Set.univ (fun a : Fin K => s (finProdFinEquiv (i, a)))) := by
    ext z
    simp only [Set.mem_preimage, Set.mem_pi, Set.mem_univ, forall_const]
    constructor
    · intro h i a
      simpa only [flatLaplacePoolEquiv_apply] using h (finProdFinEquiv (i, a))
    · intro h j
      obtain ⟨⟨i, a⟩, rfl⟩ := finProdFinEquiv.surjective j
      simpa only [flatLaplacePoolEquiv_apply] using h i a
  rw [hpre, Measure.pi_pi]
  simp_rw [Measure.pi_pi]
  have hp := Fintype.prod_equiv finProdFinEquiv
    (fun q : Fin m × Fin K => realLaplace (s (finProdFinEquiv q)))
    (fun j : Fin (m * K) => realLaplace (s j)) (fun _ => rfl)
  simpa only [Fintype.prod_prod_type] using hp

end

end PoissonAudit
