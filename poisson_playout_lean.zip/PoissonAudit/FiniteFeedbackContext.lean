module
public import PoissonAudit.OracleQuotientLaw
public import Mathlib.MeasureTheory.Function.Floor
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section

@[expose] def roundedLossCode (L : ℕ) (c : ℝ) : Fin (L + 1) := ⟨min L ⌊(L : ℝ) * c⌋₊, Nat.lt_succ_of_le (min_le_left _ _)⟩
@[expose] def roundedLossValue (L : ℕ) (c : ℝ) : ℝ := (roundedLossCode L c).val / L

theorem roundedLossCode_of_unit (L : ℕ) (c : ℝ) (hc : c ≤ 1) : (roundedLossCode L c).val = ⌊(L : ℝ) * c⌋₊ := by
  have hbound : ⌊(L : ℝ) * c⌋₊ ≤ L := Nat.floor_le_of_le (a := (L : ℝ) * c) (n := L) (by nlinarith [show (0 : ℝ) ≤ L from Nat.cast_nonneg L])
  exact min_eq_right hbound

theorem roundedLossValue_bounds (L : ℕ) (hL : 0 < L) (c : ℝ) (hc0 : 0 ≤ c) (hc1 : c ≤ 1) :
    0 ≤ roundedLossValue L c ∧ roundedLossValue L c ≤ c ∧ c ≤ roundedLossValue L c + 1 / L := by
  have hL0 : (0 : ℝ) < L := by exact_mod_cast hL
  have hfloor := Nat.floor_le (mul_nonneg hL0.le hc0)
  have hnear := (Nat.lt_floor_add_one ((L : ℝ) * c)).le
  simp only [roundedLossValue, roundedLossCode_of_unit L c hc1]
  refine ⟨div_nonneg (Nat.cast_nonneg _) hL0.le, (div_le_iff₀ hL0).mpr ?_, ?_⟩
  · nlinarith only [hfloor]
  · have he : c ≤ ((⌊(L : ℝ) * c⌋₊ : ℝ) + 1) / L := (le_div_iff₀ hL0).mpr (by nlinarith only [hnear])
    simpa only [add_div] using he

theorem measurable_roundedLossCode (L : ℕ) : Measurable (roundedLossCode L) := by
  exact (measurable_of_countable (fun n : ℕ => (⟨min L n, Nat.lt_succ_of_le (min_le_left _ _)⟩ : Fin (L + 1)))).comp
    ((measurable_const.mul measurable_id).nat_floor)

@[expose] abbrev FiniteFeedbackContext (P : Type*) (K T L : ℕ) := (P → Fin K) × (Fin T → Fin K → Fin (L + 1))

@[expose] def feedbackContext {X P : Type*} {K T : ℕ} (predict : P → X → Fin K) (cost : Fin T → X → Fin K → ℝ)
    (L : ℕ) (x : X) : FiniteFeedbackContext P K T L :=
  (fun p => predict p x, fun t a => roundedLossCode L (cost t x a))

@[expose] def feedbackPrediction {P : Type*} {K T L : ℕ} (p : P) (y : FiniteFeedbackContext P K T L) : Fin K := y.1 p
@[expose] def feedbackCost {P : Type*} {K T L : ℕ} (t : Fin T) (y : FiniteFeedbackContext P K T L) (a : Fin K) : ℝ := (y.2 t a).val / L

theorem feedbackPrediction_factor {X P : Type*} {K T : ℕ} (predict : P → X → Fin K) (cost : Fin T → X → Fin K → ℝ)
    (L : ℕ) (p : P) (x : X) : feedbackPrediction p (feedbackContext predict cost L x) = predict p x := rfl

theorem feedbackCost_factor {X P : Type*} {K T : ℕ} (predict : P → X → Fin K) (cost : Fin T → X → Fin K → ℝ)
    (L : ℕ) (t : Fin T) (x : X) (a : Fin K) :
    feedbackCost t (feedbackContext predict cost L x) a = roundedLossValue L (cost t x a) := rfl

theorem feedbackCost_bounds {P : Type*} {K T L : ℕ} (hL : 0 < L) (t : Fin T) (y : FiniteFeedbackContext P K T L) (a : Fin K) :
    0 ≤ feedbackCost t y a ∧ feedbackCost t y a ≤ 1 := by
  have hL0 : (0 : ℝ) < L := by exact_mod_cast hL
  constructor
  · exact div_nonneg (Nat.cast_nonneg _) hL0.le
  · apply (div_le_one hL0).mpr
    exact_mod_cast Nat.le_of_lt_succ (y.2 t a).isLt

theorem measurable_feedbackContext {X P : Type*} [MeasurableSpace X] [Fintype P] {K T : ℕ}
    (predict : P → X → Fin K) (hp : ∀ p, Measurable (predict p)) (cost : Fin T → X → Fin K → ℝ)
    (hc : ∀ t a, Measurable (fun x => cost t x a)) (L : ℕ) : Measurable (feedbackContext predict cost L) := by
  apply Measurable.prodMk
  · exact Measurable.of_eval hp
  · apply Measurable.of_eval
    intro t
    apply Measurable.of_eval
    intro a
    exact (measurable_roundedLossCode L).comp (hc t a)

theorem rounded_realized_regret_le {X P : Type*} [Fintype P] [Nonempty P] [LinearOrder P] {K T : ℕ}
    (predict : P → X → Fin K) (cost : Fin T → X → Fin K → ℝ) (L : ℕ) (hL : 0 < L)
    (hc0 : ∀ t x a, 0 ≤ cost t x a) (hc1 : ∀ t x a, cost t x a ≤ 1)
    (contexts : Fin T → X) (actions : Fin T → Fin K) :
    (∑ t, cost t (contexts t) (actions t)) + treeBestScore (fun p => -(∑ t, cost t (contexts t) (predict p (contexts t)))) ≤
      (∑ t, roundedLossValue L (cost t (contexts t) (actions t))) +
        treeBestScore (fun p => -(∑ t, roundedLossValue L (cost t (contexts t) (predict p (contexts t))))) + (T : ℝ) / L := by
  have hloss := Finset.sum_le_sum (s := Finset.univ) (fun t _ =>
    (roundedLossValue_bounds L hL (cost t (contexts t) (actions t)) (hc0 t (contexts t) (actions t)) (hc1 t (contexts t) (actions t))).2.2)
  simp only [Finset.sum_add_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul] at hloss
  have hscore : treeBestScore (fun p => -(∑ t, cost t (contexts t) (predict p (contexts t)))) ≤
      treeBestScore (fun p => -(∑ t, roundedLossValue L (cost t (contexts t) (predict p (contexts t))))) := by
    apply treeBestScore_le
    intro p
    have hs := Finset.sum_le_sum (s := Finset.univ) (fun t _ =>
      (roundedLossValue_bounds L hL (cost t (contexts t) (predict p (contexts t)))
        (hc0 t (contexts t) (predict p (contexts t))) (hc1 t (contexts t) (predict p (contexts t)))).2.1)
    exact (neg_le_neg hs).trans (score_le_treeBestScore
      (fun p => -(∑ t, roundedLossValue L (cost t (contexts t) (predict p (contexts t))))) p)
  rw [mul_one_div] at hloss
  linarith
end
end PoissonAudit
