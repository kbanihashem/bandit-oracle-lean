module
public import PoissonAudit.NativeInitialValue
public import PoissonAudit.FiniteBanditLaw
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem context_mass_sum (D : Measure X) [IsProbabilityMeasure D] :
    (∑ x : X, (D {x}).toReal) = 1 := by
  have h := integral_fintype (μ := D) (f := fun _ : X => (1 : ℝ)) Integrable.of_finite
  simpa only [integral_const, probReal_univ, one_smul, Measure.real, smul_eq_mul, mul_one, measure_univ, ENNReal.toReal_one] using h.symm

theorem nativeBanditProbability_sum (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (gamma : ℝ) (hK : 0 < K) (x : X) :
    (∑ a, nativeBanditProbability r D predict sigma S gamma x a) = 1 := by
  simp only [nativeBanditProbability, explorationProbability, Finset.sum_add_distrib, ← Finset.mul_sum,
    sum_experimentProbability, mul_one, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
  have hk : (K : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (Nat.ne_of_gt hK)
  field_simp
  ring

@[expose] def nativeOptimalScale (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B : ℝ) (hB : 1 ≤ B) (S : P → ℝ) : X × Fin K → ℝ :=
  optimalScale (markedPoolLaw r (contextLaplaceLaw D K)) (poissonCoefficient predict)
    (integrable_poissonCoefficient r D predict) (fun j => (D {j.1}).toReal) lam B hB S

@[expose] def nativeIdealRule (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B gamma : ℝ) (hB : 1 ≤ B) (S : P → ℝ) : X → Fin K → ℝ :=
  nativeBanditProbability r D predict (nativeOptimalScale r D predict lam B hB S) S gamma

@[expose] def nativeRoundSlack (P : Type*) [Fintype P] (r : NNReal) (K : ℕ) (lam B gamma : ℝ) : ℝ :=
  gamma + (Real.exp 1 - 2) / (1 - gamma) * (4 * Real.log (Fintype.card P) / lam + K / B) +
    2 * Real.exp 1 * Real.log (Fintype.card P) / r

theorem treeUpdatedScore_eq_actionPenalty (predict : P → X → Fin K) (S : P → ℝ)
    (q c : Fin K → ℝ) (x : X) (a : Fin K) :
    treeUpdatedScore S q c (fun p => predict p x) a = actionPenaltyScore predict S x a (c a / q a) := by
  classical
  funext p
  simp only [treeUpdatedScore, treeEstimatedPolicyLoss, actionPenaltyScore, actionSlope]
  split_ifs <;> ring

theorem native_sum_round_bound
    (r : NNReal) (hr : 0 < (r : ℝ)) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B gamma : ℝ) (hK : 0 < K) (hg : 0 < gamma) (hgsmall : gamma ≤ 1 / 2)
    (hlamp : 0 < lam) (hB : 1 ≤ B) (hcap : (K : ℝ) / gamma ≤ B)
    (hlam : 4 * (r : ℝ) * explorationLog K gamma ≤ lam)
    (c : X → Fin K → ℝ) (hc0 : ∀ x a, 0 ≤ c x a) (hc1 : ∀ x a, c x a ≤ 1) (S : P → ℝ) :
    (∑ x, (D {x}).toReal * ∑ a, nativeIdealRule r D predict lam B gamma hB S x a *
      (c x a + nativeVariationalValue r D predict lam B hB
        (treeUpdatedScore S (nativeIdealRule r D predict lam B gamma hB S x) (c x) (fun p => predict p x) a))) ≤
      nativeVariationalValue r D predict lam B hB S + nativeRoundSlack P r K lam B gamma := by
  let sigma := nativeOptimalScale r D predict lam B hB S
  let q := nativeIdealRule r D predict lam B gamma hB S
  let R := nativeVariationalValue r D predict lam B hB
  have hs := optimalScale_spec (markedPoolLaw r (contextLaplaceLaw D K)) (poissonCoefficient predict)
    (integrable_poissonCoefficient r D predict) (fun j => (D {j.1}).toReal) lam B hB S
  have h := native_one_round_bound r hr D predict sigma S lam B gamma hK hg hgsmall hlamp hB hcap hlam hs.1 hs.2 c hc0 hc1
  rw [integral_fintype Integrable.of_finite] at h
  simp only [Measure.real, smul_eq_mul] at h
  have hqs (x : X) : ∑ a, q x a = 1 := nativeBanditProbability_sum r D predict sigma S gamma hK x
  have heq : (∑ x, (D {x}).toReal * ∑ a, q x a * (c x a + R
        (treeUpdatedScore S (q x) (c x) (fun p => predict p x) a))) =
      (∑ x, (D {x}).toReal * ((∑ a, q x a * c x a) + ∑ a, q x a *
        (R (actionPenaltyScore predict S x a (nativeBanditUpdate r D predict sigma S gamma x a (c x a))) - R S))) + R S := by
    calc
      _ = ∑ x, (D {x}).toReal * ∑ a, q x a * ((c x a + R
          (treeUpdatedScore S (q x) (c x) (fun p => predict p x) a) - R S) + R S) := by simp
      _ = (∑ x, (D {x}).toReal * ∑ a, q x a * (c x a + R
          (treeUpdatedScore S (q x) (c x) (fun p => predict p x) a) - R S)) + R S :=
        finite_weighted_add_const _ q (context_mass_sum D) hqs _ _
      _ = _ := by
        congr 1
        apply Finset.sum_congr rfl
        intro x _
        congr 1
        rw [← Finset.sum_add_distrib]
        apply Finset.sum_congr rfl
        intro a _
        rw [treeUpdatedScore_eq_actionPenalty]
        change q x a * (c x a + R (actionPenaltyScore predict S x a (c x a / q x a)) - R S) =
          q x a * c x a + q x a * (R (actionPenaltyScore predict S x a (c x a / q x a)) - R S)
        ring
  change _ ≤ R S + nativeRoundSlack P r K lam B gamma
  rw [heq]
  change (∑ x, (D {x}).toReal * ((∑ a, q x a * c x a) + ∑ a, q x a *
    (R (actionPenaltyScore predict S x a (nativeBanditUpdate r D predict sigma S gamma x a (c x a))) - R S))) ≤ nativeRoundSlack P r K lam B gamma at h
  linarith

theorem native_ideal_finite_context_regret
    (r : NNReal) (hr : 0 < (r : ℝ)) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B gamma : ℝ) (hK : 0 < K) (hg : 0 < gamma) (hgsmall : gamma ≤ 1 / 2)
    (hlamp : 0 < lam) (hB : 1 ≤ B) (hcap : (K : ℝ) / gamma ≤ B)
    (hlam : 4 * (r : ℝ) * explorationLog K gamma ≤ lam)
    (costs : List (X → Fin K → ℝ)) (hc0 : ∀ c ∈ costs, ∀ x a, 0 ≤ c x a)
    (hc1 : ∀ c ∈ costs, ∀ x a, c x a ≤ 1) :
    finiteBanditLoss (fun x => (D {x}).toReal) predict (nativeIdealRule r D predict lam B gamma hB) costs (fun _ => 0) +
      contextBestScore (fun x => (D {x}).toReal) predict costs (fun _ => 0) ≤
        6 * (r : ℝ) * K + lam * K * Real.log B + costs.length * nativeRoundSlack P r K lam B gamma := by
  let q := nativeIdealRule r D predict lam B gamma hB
  have hq (S : P → ℝ) (x : X) (a : Fin K) : 0 < q S x a :=
    exploration_positive hK hg (experimentProbability_nonneg r D predict _ S x a) (by linarith)
  have hqs (S : P → ℝ) (x : X) : ∑ a, q S x a = 1 := nativeBanditProbability_sum r D predict _ S gamma hK x
  have h := finiteBandit_regret (fun x => (D {x}).toReal) (fun _ => ENNReal.toReal_nonneg)
    (context_mass_sum D) predict q hq hqs (nativeVariationalValue r D predict lam B hB)
    (fun S p => poisson_variationalValue_ge_score r D predict S lam B hlamp.le hB p)
    (nativeRoundSlack P r K lam B gamma) costs
    (fun c hc S => native_sum_round_bound r hr D predict lam B gamma hK hg hgsmall hlamp hB hcap hlam c (hc0 c hc) (hc1 c hc) S) (fun _ => 0)
  have hi := native_initial_value_bound r D predict lam B hB
  linarith
@[expose] def nativeIdealLaw (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B gamma : ℝ) (hB : 1 ≤ B)
    (hK : 0 < K) (hg : 0 < gamma) (hg1 : gamma ≤ 1)
    (costs : List (X → Fin K → ℝ)) : PMF (banditPaths costs) :=
  banditPathLaw (fun x => (D {x}).toReal) (fun _ => ENNReal.toReal_nonneg) (context_mass_sum D)
    predict (nativeIdealRule r D predict lam B gamma hB)
    (fun S x a => (exploration_positive hK hg (experimentProbability_nonneg r D predict _ S x a) hg1).le)
    (fun S x => nativeBanditProbability_sum r D predict _ S gamma hK x) costs (fun _ => 0)

theorem native_ideal_expected_regret
    (r : NNReal) (hr : 0 < (r : ℝ)) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B gamma : ℝ) (hK : 0 < K) (hg : 0 < gamma) (hgsmall : gamma ≤ 1 / 2)
    (hlamp : 0 < lam) (hB : 1 ≤ B) (hcap : (K : ℝ) / gamma ≤ B)
    (hlam : 4 * (r : ℝ) * explorationLog K gamma ≤ lam)
    (costs : List (X → Fin K → ℝ)) (hc0 : ∀ c ∈ costs, ∀ x a, 0 ≤ c x a)
    (hc1 : ∀ c ∈ costs, ∀ x a, c x a ≤ 1) :
    (∫ path, banditPathLoss costs path + treeBestScore (banditPathTrueScore predict costs (fun _ => 0) path)
      ∂(nativeIdealLaw r D predict lam B gamma hB hK hg (by linarith) costs).toMeasure) ≤
        6 * (r : ℝ) * K + lam * K * Real.log B + costs.length * nativeRoundSlack P r K lam B gamma := by
  unfold nativeIdealLaw
  erw [integral_banditPath_regret]
  exact native_ideal_finite_context_regret r hr D predict lam B gamma hK hg hgsmall hlamp hB hcap hlam costs hc0 hc1

end
end PoissonAudit
