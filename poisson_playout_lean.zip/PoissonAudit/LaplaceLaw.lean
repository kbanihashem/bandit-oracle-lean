module

public import PoissonAudit.LaplaceKernel
public import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap

public section

open MeasureTheory
open scoped BigOperators

namespace PoissonAudit

noncomputable section

theorem measurable_laplaceKernel (K : ℕ) : Measurable (@laplaceKernel K) := by
  unfold laplaceKernel l1
  fun_prop

theorem l1_add_le {K : ℕ} (x y : Fin K → ℝ) : l1 (x + y) ≤ l1 x + l1 y := by
  unfold l1
  rw [← Finset.sum_add_distrib]
  exact Finset.sum_le_sum fun a _ => abs_add_le _ _

theorem l1_smul {K : ℕ} (r : ℝ) (x : Fin K → ℝ) : l1 (r • x) = |r| * l1 x := by
  simp [l1, abs_mul, Finset.mul_sum]

theorem laplaceKernel_midpoint {K : ℕ} (x y : Fin K → ℝ) :
    Real.sqrt (laplaceKernel x) * Real.sqrt (laplaceKernel y) ≤
      laplaceKernel ((1 / 2 : ℝ) • (x + y)) := by
  have hl : 2 * l1 ((1 / 2 : ℝ) • (x + y)) ≤ l1 x + l1 y := by
    rw [l1_smul]
    norm_num
    linarith [l1_add_le x y]
  apply (sq_le_sq₀ (mul_nonneg (Real.sqrt_nonneg _) (Real.sqrt_nonneg _))
    (laplaceKernel_pos _).le).mp
  rw [mul_pow, Real.sq_sqrt (laplaceKernel_pos x).le,
    Real.sq_sqrt (laplaceKernel_pos y).le]
  unfold laplaceKernel
  rw [pow_two, ← Real.exp_add, ← Real.exp_add]
  exact Real.exp_le_exp.mpr (by linarith)

@[expose] def laplaceDensity {K : ℕ} (z : Fin K → ℝ) : ℝ := laplaceKernel z / 2 ^ K

theorem laplaceDensity_pos {K : ℕ} (z : Fin K → ℝ) : 0 < laplaceDensity z :=
  div_pos (laplaceKernel_pos z) (by positivity)

theorem measurable_laplaceDensity (K : ℕ) : Measurable (@laplaceDensity K) :=
  (measurable_laplaceKernel K).div_const _

theorem integrable_laplaceDensity (K : ℕ) : Integrable (@laplaceDensity K) :=
  (integrable_laplaceKernel K).div_const _

theorem integral_laplaceDensity (K : ℕ) : (∫ z : Fin K → ℝ, laplaceDensity z) = 1 := by
  unfold laplaceDensity
  rw [integral_div, integral_laplaceKernel]
  exact div_self (by positivity)

@[expose] def laplaceMeasure (K : ℕ) : Measure (Fin K → ℝ) :=
  volume.withDensity (fun z => ENNReal.ofReal (laplaceDensity z))

instance laplaceMeasure_isProbability (K : ℕ) : IsProbabilityMeasure (laplaceMeasure K) := by
  refine ⟨?_⟩
  unfold laplaceMeasure
  rw [withDensity_apply _ MeasurableSet.univ, Measure.restrict_univ,
    ← ofReal_integral_eq_lintegral_ofReal (integrable_laplaceDensity K)
      (Filter.Eventually.of_forall fun z => (laplaceDensity_pos z).le), integral_laplaceDensity]
  simp

theorem integral_laplaceMeasure {K : ℕ} (f : (Fin K → ℝ) → ℝ) :
    (∫ z, f z ∂laplaceMeasure K) = ∫ z, f z * laplaceDensity z := by
  unfold laplaceMeasure
  rw [integral_withDensity_eq_integral_toReal_smul
    (measurable_laplaceDensity K).ennreal_ofReal
    (Filter.Eventually.of_forall fun _ => ENNReal.ofReal_lt_top) f]
  simp only [ENNReal.toReal_ofReal (laplaceDensity_pos _).le, smul_eq_mul, mul_comm]

theorem integral_laplaceMeasure_kernel {K : ℕ} (f : (Fin K → ℝ) → ℝ) :
    (∫ z, f z ∂laplaceMeasure K) = (2 ^ K : ℝ)⁻¹ * ∫ z, f z * laplaceKernel z := by
  rw [integral_laplaceMeasure]
  simp only [laplaceDensity, ← mul_div_assoc]
  rw [integral_div]
  ring

theorem integral_laplaceMeasure_zero (f : (Fin 0 → ℝ) → ℝ) :
    (∫ z, f z ∂laplaceMeasure 0) = f 0 := by
  have heq : f = fun _ => f 0 := by
    funext z
    exact congrArg f (Subsingleton.elim z 0)
  rw [heq]
  simp

end

end PoissonAudit
