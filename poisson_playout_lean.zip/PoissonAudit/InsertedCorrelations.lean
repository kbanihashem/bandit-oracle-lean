module

public import PoissonAudit.GradientInsertion

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def insertedActionCoefficient (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (a : Fin K) (n : ℕ)
    (v : (Fin K → ℝ) × (Fin n → X × (Fin K → ℝ))) : ℝ := by
  classical
  exact if predict (insertedMarkWinner predict sigma S ((x, v.1), v.2)) x = a then v.1 a else 0

@[expose] def insertedAlpha (r : NNReal) (D : Measure X)
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) : ℝ :=
  ∫ n, (∫ z0, ∫ pool, insertedActionCoefficient predict sigma S x a n (z0, pool)
    ∂iidPool (contextLaplaceLaw D K) n ∂laplaceMeasure K) ∂ProbabilityTheory.poissonMeasure r

theorem inserted_mean_context_factor (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (j : X × Fin K) (n : ℕ) :
    (∫ u0, ∫ pool, insertedContribution predict sigma S j n (u0, pool)
      ∂iidPool (contextLaplaceLaw D K) n ∂contextLaplaceLaw D K) =
    (D {j.1}).toReal * ∫ z0, ∫ pool, insertedActionCoefficient predict sigma S j.1 j.2 n (z0, pool)
      ∂iidPool (contextLaplaceLaw D K) n ∂laplaceMeasure K := by
  classical
  have hi := (integrable_insertedContribution D predict sigma S j n).integral_prod_left
  change (∫ u0, (∫ pool, insertedContribution predict sigma S j n (u0, pool)
    ∂iidPool (contextLaplaceLaw D K) n) ∂D.prod (laplaceMeasure K)) = _
  rw [integral_prod _ hi]
  have hf := integral_fintype (μ := D)
    (f := fun x => ∫ z0, ∫ pool, insertedContribution predict sigma S j n ((x, z0), pool)
      ∂iidPool (contextLaplaceLaw D K) n ∂laplaceMeasure K) Integrable.of_finite
  rw [hf, Finset.sum_eq_single j.1]
  · change (D {j.1}).toReal * (∫ z0, ∫ pool, insertedContribution predict sigma S j n ((j.1, z0), pool)
      ∂iidPool (contextLaplaceLaw D K) n ∂laplaceMeasure K) = _
    congr 1
    apply integral_congr_ae
    filter_upwards [] with z0
    apply integral_congr_ae
    filter_upwards [] with pool
    simp [insertedContribution, singleMarkCoefficient, insertedActionCoefficient]
  · intro x _ hx
    simp [insertedContribution, singleMarkCoefficient, hx]
  · simp

theorem insertedCorrelationMass_eq (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (j : X × Fin K) :
    insertedCorrelationMass r D predict sigma S j = (D {j.1}).toReal * insertedAlpha r D predict sigma S j.1 j.2 := by
  unfold insertedCorrelationMass insertedAlpha
  simp_rw [inserted_mean_context_factor D predict sigma S j]
  exact integral_const_mul _ _

theorem poisson_minimizer_first_order_lower (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (lam B : ℝ) (hB : 1 ≤ B)
    (hsigma : sigma ∈ scaleBox (X × Fin K) B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun j => (D {j.1}).toReal) lam B) (scaleBox (X × Fin K) B) sigma)
    (j : X × Fin K) (hj : sigma j < B) (hpos : 0 < (D {j.1}).toReal) :
    lam ≤ (r : ℝ) * sigma j * insertedAlpha r D predict sigma S j.1 j.2 := by
  have h := poisson_minimizer_inserted_lower r D predict sigma S lam B hB hsigma hmin j hj
  rw [insertedCorrelationMass_eq] at h
  have hh : lam * (D {j.1}).toReal ≤
      ((r : ℝ) * sigma j * insertedAlpha r D predict sigma S j.1 j.2) * (D {j.1}).toReal := by nlinarith
  exact (mul_le_mul_iff_of_pos_right hpos).mp hh

theorem poisson_minimizer_first_order_upper (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (lam B : ℝ) (hB : 1 ≤ B)
    (hsigma : sigma ∈ scaleBox (X × Fin K) B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun j => (D {j.1}).toReal) lam B) (scaleBox (X × Fin K) B) sigma)
    (j : X × Fin K) (hj : 1 < sigma j) (hpos : 0 < (D {j.1}).toReal) :
    (r : ℝ) * sigma j * insertedAlpha r D predict sigma S j.1 j.2 ≤ lam := by
  have h := poisson_minimizer_inserted_upper r D predict sigma S lam B hB hsigma hmin j hj
  rw [insertedCorrelationMass_eq] at h
  have hh : ((r : ℝ) * sigma j * insertedAlpha r D predict sigma S j.1 j.2) * (D {j.1}).toReal ≤
      lam * (D {j.1}).toReal := by nlinarith
  exact (mul_le_mul_iff_of_pos_right hpos).mp hh

end

end PoissonAudit
