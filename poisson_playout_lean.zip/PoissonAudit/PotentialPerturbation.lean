module

public import PoissonAudit.Perturbation

public section

open scoped BigOperators

namespace PoissonAudit

noncomputable section

@[expose] def lossDrop {P : Type*} (R : (P → ℝ) → ℝ) (S f : P → ℝ) (b : ℝ) : ℝ :=
  R S - R (fun pi => S pi - b * f pi)

theorem lossDrop_zero {P : Type*} (R : (P → ℝ) → ℝ) (S f : P → ℝ) :
    lossDrop R S f 0 = 0 := by simp [lossDrop]

theorem lossDrop_mono {P : Type*} (R : (P → ℝ) → ℝ) (S f : P → ℝ)
    (hR : Monotone R) (hf : ∀ pi, 0 ≤ f pi) :
    Monotone (lossDrop R S f) := by
  intro a b hab
  have h : (fun pi => S pi - b * f pi) ≤ (fun pi => S pi - a * f pi) := by
    intro pi
    have := mul_le_mul_of_nonneg_right hab (hf pi)
    linarith
  have := hR h
  simp only [lossDrop]
  linarith

theorem lossDrop_le {P : Type*} (R : (P → ℝ) → ℝ) (S f : P → ℝ)
    (hR : Monotone R)
    (htrans : ∀ U : P → ℝ, ∀ d : ℝ, R (fun pi => U pi + d) = R U + d)
    (hf : ∀ pi, f pi ≤ 1) {b : ℝ} (hb : 0 ≤ b) :
    lossDrop R S f b ≤ b := by
  have h : (fun pi => S pi + -b) ≤ (fun pi => S pi - b * f pi) := by
    intro pi
    have := mul_le_mul_of_nonneg_left (hf pi) hb
    linarith
  have := hR h
  rw [htrans] at this
  simp only [lossDrop]
  linarith

theorem lossDrop_concave {P : Type*} (R : (P → ℝ) → ℝ) (S f : P → ℝ)
    (hR : ConvexOn ℝ Set.univ R) :
    ConcaveOn ℝ (Set.Ici 0) (lossDrop R S f) := by
  refine ⟨convex_Ici _, ?_⟩
  intro x _ y _ a b ha hb hab
  have h := hR.2 (Set.mem_univ (fun pi => S pi - x * f pi))
    (Set.mem_univ (fun pi => S pi - y * f pi)) ha hb hab
  have hid : a • (fun pi => S pi - x * f pi) + b • (fun pi => S pi - y * f pi) =
      (fun pi => S pi - (a * x + b * y) * f pi) := by
    funext pi
    simp only [Pi.add_apply, Pi.smul_apply, smul_eq_mul]
    calc
      _ = (a + b) * S pi - (a * x + b * y) * f pi := by ring
      _ = _ := by rw [hab]; ring
  rw [hid] at h
  simp only [lossDrop, smul_eq_mul] at *
  nlinarith [congrArg (fun z : ℝ => z * R S) hab]

theorem one_step_probability_lipschitz {P A : Type*} [Fintype A]
    (R : (P → ℝ) → ℝ) (S : P → ℝ) (f : A → P → ℝ)
    (q r c : A → ℝ) (floor : ℝ)
    (hfloor : 0 < floor) (hq : ∀ a, floor ≤ q a) (hr : ∀ a, floor ≤ r a)
    (hc0 : ∀ a, 0 ≤ c a) (hc1 : ∀ a, c a ≤ 1)
    (hf0 : ∀ a pi, 0 ≤ f a pi) (hf1 : ∀ a pi, f a pi ≤ 1)
    (hmono : Monotone R) (hconv : ConvexOn ℝ Set.univ R)
    (htrans : ∀ U : P → ℝ, ∀ d : ℝ, R (fun pi => U pi + d) = R U + d) :
    |((∑ a, q a * c a) - ∑ a, q a * lossDrop R S (f a) (c a / q a)) -
      ((∑ a, r a * c a) - ∑ a, r a * lossDrop R S (f a) (c a / r a))| ≤
      (1 + 1 / floor) * ∑ a, |q a - r a| := by
  have hscalar : ∀ a,
      |q a * lossDrop R S (f a) (c a / q a) -
        r a * lossDrop R S (f a) (c a / r a)| ≤ (1 / floor) * |q a - r a| := by
    intro a
    exact perspective_lipschitz (lossDrop R S (f a)) floor (c a) (q a) (r a)
      hfloor (hc0 a) (hc1 a) (hq a) (hr a)
      ((lossDrop_mono R S (f a) hmono (hf0 a)).monotoneOn (Set.Ici 0))
      (fun b hb => lossDrop_le R S (f a) hmono htrans (hf1 a) hb)
      (lossDrop_concave R S (f a) hconv) (lossDrop_zero R S (f a))
  have hlin : |(∑ a, q a * c a) - ∑ a, r a * c a| ≤ ∑ a, |q a - r a| := by
    rw [← Finset.sum_sub_distrib]
    calc
      _ ≤ ∑ a, |q a * c a - r a * c a| := Finset.abs_sum_le_sum_abs _ _
      _ ≤ ∑ a, |q a - r a| := by
        apply Finset.sum_le_sum
        intro a _
        rw [← sub_mul, abs_mul, abs_of_nonneg (hc0 a)]
        nlinarith [abs_nonneg (q a - r a), hc1 a]
  have hnonlin : |(∑ a, q a * lossDrop R S (f a) (c a / q a)) -
      ∑ a, r a * lossDrop R S (f a) (c a / r a)| ≤
      (1 / floor) * ∑ a, |q a - r a| := by
    rw [← Finset.sum_sub_distrib, Finset.mul_sum]
    exact (Finset.abs_sum_le_sum_abs _ _).trans (Finset.sum_le_sum fun a _ => hscalar a)
  have heq :
      ((∑ a, q a * c a) - ∑ a, q a * lossDrop R S (f a) (c a / q a)) -
      ((∑ a, r a * c a) - ∑ a, r a * lossDrop R S (f a) (c a / r a)) =
      ((∑ a, q a * c a) - ∑ a, r a * c a) -
      ((∑ a, q a * lossDrop R S (f a) (c a / q a)) -
        ∑ a, r a * lossDrop R S (f a) (c a / r a)) := by ring
  rw [heq]
  calc
    _ ≤ |(∑ a, q a * c a) - ∑ a, r a * c a| +
        |(∑ a, q a * lossDrop R S (f a) (c a / q a)) -
          ∑ a, r a * lossDrop R S (f a) (c a / r a)| := abs_sub _ _
    _ ≤ (∑ a, |q a - r a|) + (1 / floor) * ∑ a, |q a - r a| := add_le_add hlin hnonlin
    _ = _ := by ring

end

end PoissonAudit
