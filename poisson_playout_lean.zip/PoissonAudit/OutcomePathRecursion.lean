module
public import PoissonAudit.ContextTranscript
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {Y O A P : Type*} [Fintype Y] [MeasurableSpace Y] [MeasurableSingletonClass Y] [Fintype O] [MeasurableSpace O] [MeasurableSingletonClass O] [Fintype A] [Fintype P] [Nonempty P]

@[expose] def emptyOutcomePath (Y O A : Type*) : outcomePaths (X := Y) (A := A) O [] := fun i => Fin.elim0 i

@[expose] def outcomePathCons (c : Y → A → ℝ) (cs : List (Y → A → ℝ)) (y : Y) (o : O)
    (path : outcomePaths O cs) : outcomePaths O (c :: cs) := (y, o, path)

theorem outcomePathLaw_cons (d : Y → ℝ) (hd : ∀ y, 0 ≤ d y) (hdsum : ∑ y, d y = 1)
    (w : (P → ℝ) → Y → O → ℝ) (hw : ∀ S y o, 0 ≤ w S y o) (hwsum : ∀ S y, ∑ o, w S y o = 1)
    (U : (P → ℝ) → Y → (A → ℝ) → O → P → ℝ) (c : Y → A → ℝ) (cs : List (Y → A → ℝ)) (S : P → ℝ) :
    (outcomePathLaw d hd hdsum w U hw hwsum (c :: cs) S).toMeasure =
      ∑ y, ∑ o, ENNReal.ofReal (d y * w S y o) •
        (outcomePathLaw d hd hdsum w U hw hwsum cs (U S y (c y) o)).toMeasure.map (β := outcomePaths O (c :: cs))
          (outcomePathCons c cs y o) := by
  classical
  apply Measure.ext_of_singleton
  intro path
  let y0 := path.1
  let o0 := path.2.1
  let tail := path.2.2
  have hpre (y : Y) (o : O) :
      (outcomePathCons c cs y o) ⁻¹' ({path} : Set (outcomePaths O (c :: cs))) =
        if y = y0 ∧ o = o0 then {tail} else ∅ := by
    ext z
    change (y, o, z) = (y0, o0, tail) ↔ z ∈ (if y = y0 ∧ o = o0 then {tail} else ∅)
    by_cases hy : y = y0 <;> by_cases ho : o = o0 <;> simp [hy, ho]
  have hsingle : MeasurableSet ({path} : Set (outcomePaths O (c :: cs))) := measurableSet_singleton _
  rw [PMF.toMeasure_apply_singleton (outcomePathLaw d hd hdsum w U hw hwsum (c :: cs) S)
    path hsingle]
  simp only [Measure.finsetSum_apply, Measure.smul_apply, smul_eq_mul]
  simp_rw [Measure.map_apply (measurable_of_finite _) hsingle, hpre]
  simp only [apply_ite, measure_empty, mul_ite, mul_zero]
  simp only [ite_and, Finset.sum_const_zero, Finset.sum_ite_irrel, Finset.sum_ite_eq, Finset.sum_ite_eq', Finset.mem_univ, ite_true]
  rw [PMF.toMeasure_apply_singleton _ _ (measurableSet_singleton _)]
  apply (ENNReal.toReal_eq_toReal_iff' (PMF.apply_ne_top _ _) (ENNReal.mul_ne_top ENNReal.ofReal_ne_top (PMF.apply_ne_top _ _))).mp
  simp only [outcomePathLaw, actionPMF_toReal, ENNReal.toReal_mul, ENNReal.toReal_ofReal (mul_nonneg (hd _) (hw _ _ _))]
  rfl
end
end PoissonAudit
