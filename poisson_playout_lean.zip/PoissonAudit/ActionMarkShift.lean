module

public import PoissonAudit.ConditionalShiftCharge

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

@[expose] def actionMarkShift {K : ℕ} (sigma : ℝ) (a : Fin K) (s : ℝ) : Fin K → ℝ :=
  fun b => if b = a then s / sigma else 0

theorem l1_actionMarkShift {K : ℕ} (sigma : ℝ) (a : Fin K) (s : ℝ) :
    l1 (actionMarkShift sigma a s) = |s / sigma| := by
  classical
  simp [l1, actionMarkShift, apply_ite]

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K m : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem insertedPoolScore_action_shift (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (a : Fin K) (s : ℝ) (hsigma : sigma (x, a) ≠ 0)
    (z0 : Fin K → ℝ) (pool : Fin m → X × (Fin K → ℝ)) (p : P) :
    insertedPoolScore predict sigma (actionPenaltyScore predict S x a s) ((x, z0), pool) p =
      insertedPoolScore predict sigma S ((x, z0 - actionMarkShift (sigma (x, a)) a s), pool) p := by
  classical
  unfold insertedPoolScore actionPenaltyScore actionSlope markValue
  simp only [Pi.sub_apply, actionMarkShift]
  by_cases hp : predict p x = a
  · simp only [hp, ite_true]
    field_simp <;> ring
  · simp [hp]

theorem finitePoolScore_action_clamp (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (a : Fin K) (s : ℝ) (hsigma : sigma (x, a) ≠ 0)
    (pool : Fin m → X × (Fin K → ℝ)) (p : P) :
    finitePoolScore predict sigma (actionPenaltyScore predict S x a s) pool p =
      insertedPoolScore predict sigma S ((x, -actionMarkShift (sigma (x, a)) a s), pool) p := by
  classical
  unfold finitePoolScore insertedPoolScore actionPenaltyScore actionSlope markValue
  simp only [Pi.neg_apply, actionMarkShift]
  by_cases hp : predict p x = a
  · simp only [hp, ite_true]
    field_simp <;> ring
  · simp [hp]

theorem insertedLocationWinner_action_shift (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (a : Fin K) (s : ℝ) (hsigma : sigma (x, a) ≠ 0)
    (C : Fin m → X) (z0 : Fin K → ℝ) (Z : Fin m → Fin K → ℝ) :
    insertedLocationWinner predict sigma (actionPenaltyScore predict S x a s) x C (z0, Z) =
      insertedLocationWinner predict sigma S x C (z0 - actionMarkShift (sigma (x, a)) a s, Z) := by
  apply congrArg winner
  funext p
  exact insertedPoolScore_action_shift predict sigma S x a s hsigma z0 (fun i => (C i, Z i)) p

theorem locationWinner_action_clamp (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (a : Fin K) (s : ℝ) (hsigma : sigma (x, a) ≠ 0)
    (C : Fin m → X) (Z : Fin m → Fin K → ℝ) :
    locationWinner predict sigma (actionPenaltyScore predict S x a s) C Z =
      insertedLocationWinner predict sigma S x C (-actionMarkShift (sigma (x, a)) a s, Z) := by
  apply congrArg winner
  funext p
  exact finitePoolScore_action_clamp predict sigma S x a s hsigma (fun i => (C i, Z i)) p

theorem location_channel_action_shift (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (a : Fin K) (s : ℝ) (hsigma : sigma (x, a) ≠ 0)
    (C : Fin m → X) (p : P) (z0 : Fin K → ℝ) :
    eventChannel (iidPool (laplaceMeasure K) m)
      (outcomeEvent (insertedLocationWinner predict sigma (actionPenaltyScore predict S x a s) x C) p) z0 =
    eventChannel (iidPool (laplaceMeasure K) m)
      (outcomeEvent (insertedLocationWinner predict sigma S x C) p) (z0 - actionMarkShift (sigma (x, a)) a s) := by
  classical
  have hE1 : MeasurableSet (outcomeEvent (insertedLocationWinner predict sigma (actionPenaltyScore predict S x a s) x C) p) :=
    measurable_insertedLocationWinner predict sigma _ x C (measurableSet_singleton p)
  have hE0 : MeasurableSet (outcomeEvent (insertedLocationWinner predict sigma S x C) p) :=
    measurable_insertedLocationWinner predict sigma S x C (measurableSet_singleton p)
  rw [eventChannel_eq_integral_indicator _ _ hE1, eventChannel_eq_integral_indicator _ _ hE0]
  apply integral_congr_ae
  filter_upwards [] with Z
  simp only [Set.indicator_apply, outcomeEvent, Set.mem_ofPred_eq]
  simp only [insertedLocationWinner_action_shift predict sigma S x a s hsigma C z0 Z]

end

end PoissonAudit
