module

public import PoissonAudit.FlatLaplacePool
public import PoissonAudit.LocationInformation
public import PoissonAudit.WinnerLogConcavity
public import PoissonAudit.RealChannelDiscrepancy

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K m : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def flatInsertedScore (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (C : Fin m → X) (p : P)
    (v : (Fin K → ℝ) × (Fin (m * K) → ℝ)) : ℝ :=
  S p + sigma (x, predict p x) * v.1 (predict p x) +
    ∑ i, sigma (C i, predict p (C i)) * v.2 (finProdFinEquiv (i, predict p (C i)))

theorem measurable_flatInsertedScore (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (C : Fin m → X) (p : P) : Measurable (flatInsertedScore predict sigma S x C p) := by
  unfold flatInsertedScore
  fun_prop

theorem affine_flatInsertedScore (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (C : Fin m → X) (p : P)
    (u v : (Fin K → ℝ) × (Fin (m * K) → ℝ)) (a b : ℝ) (hab : a + b = 1) :
    flatInsertedScore predict sigma S x C p (a • u + b • v) =
      a * flatInsertedScore predict sigma S x C p u + b * flatInsertedScore predict sigma S x C p v := by
  change S p + sigma (x, predict p x) * (a * u.1 (predict p x) + b * v.1 (predict p x)) +
    (∑ i, sigma (C i, predict p (C i)) *
      (a * u.2 (finProdFinEquiv (i, predict p (C i))) + b * v.2 (finProdFinEquiv (i, predict p (C i))))) = _
  have hsum : (∑ i, sigma (C i, predict p (C i)) *
      (a * u.2 (finProdFinEquiv (i, predict p (C i))) + b * v.2 (finProdFinEquiv (i, predict p (C i))))) =
      a * (∑ i, sigma (C i, predict p (C i)) * u.2 (finProdFinEquiv (i, predict p (C i)))) +
      b * (∑ i, sigma (C i, predict p (C i)) * v.2 (finProdFinEquiv (i, predict p (C i)))) := by
    rw [Finset.mul_sum, Finset.mul_sum, ← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro i _
    ring
  rw [hsum]
  unfold flatInsertedScore
  linear_combination -(S p) * hab

theorem flatInsertedScore_eq_native (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (C : Fin m → X) (p : P) (z0 : Fin K → ℝ) (Z : Fin m → Fin K → ℝ) :
    flatInsertedScore predict sigma S x C p (z0, flatLaplacePoolEquiv m K Z) =
      insertedPoolScore predict sigma S ((x, z0), fun i => (C i, Z i)) p := by
  unfold flatInsertedScore insertedPoolScore markValue
  simp only [flatLaplacePoolEquiv_apply]

theorem flatInsertedWinner_eq_native (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (C : Fin m → X) (z0 : Fin K → ℝ) (Z : Fin m → Fin K → ℝ) :
    winner (fun p => flatInsertedScore predict sigma S x C p (z0, flatLaplacePoolEquiv m K Z)) =
      insertedLocationWinner predict sigma S x C (z0, Z) := by
  apply congrArg winner
  funext p
  exact flatInsertedScore_eq_native predict sigma S x C p z0 Z

theorem native_conditional_channel_eq_flat (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (C : Fin m → X) (p : P) :
    eventChannel (iidPool (laplaceMeasure K) m) (outcomeEvent (insertedLocationWinner predict sigma S x C) p) =
      winnerChannel (laplaceMeasure (m * K)) (flatInsertedScore predict sigma S x C) p := by
  classical
  funext z0
  have hE : MeasurableSet (outcomeEvent (insertedLocationWinner predict sigma S x C) p) :=
    measurable_insertedLocationWinner predict sigma S x C (measurableSet_singleton p)
  rw [eventChannel_eq_integral_indicator (iidPool (laplaceMeasure K) m) _ hE]
  unfold winnerChannel
  rw [← (flatLaplacePoolEquiv_measurePreserving m K).integral_comp'
    (fun Z => winningIndicator (flatInsertedScore predict sigma S x C) p (z0, Z))]
  apply integral_congr_ae
  filter_upwards [] with Z
  have h := flatInsertedWinner_eq_native predict sigma S x C z0 Z
  have hiff : insertedLocationWinner predict sigma S x C (z0, Z) = p ↔
      IsWinner (fun q => flatInsertedScore predict sigma S x C q (z0, flatLaplacePoolEquiv m K Z)) p := by
    rw [← h]
    exact winner_eq_iff _ _
  by_cases hp : insertedLocationWinner predict sigma S x C (z0, Z) = p
  · simp [outcomeEvent, winningIndicator, hp, hiff.mp hp]
  · have hn := mt hiff.mpr hp
    simp [outcomeEvent, winningIndicator, hp, hn]

end

end PoissonAudit
