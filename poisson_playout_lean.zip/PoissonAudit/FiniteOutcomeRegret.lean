module
public import PoissonAudit.FiniteBanditRegret
public section
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X A P O : Type*} [Fintype X] [Fintype A] [Fintype P] [Nonempty P] [Fintype O]

@[expose] def finiteOutcomeTerminal (d : X → ℝ) (w : (P → ℝ) → X → O → ℝ)
    (U : (P → ℝ) → X → (A → ℝ) → O → P → ℝ) (f : (P → ℝ) → ℝ) :
    List (X → A → ℝ) → (P → ℝ) → ℝ
  | [], S => f S
  | c :: cs, S => ∑ x, d x * ∑ o, w S x o * finiteOutcomeTerminal d w U f cs (U S x (c x) o)

@[expose] def finiteOutcomeLoss (d : X → ℝ) (action : O → A) (w : (P → ℝ) → X → O → ℝ)
    (U : (P → ℝ) → X → (A → ℝ) → O → P → ℝ) : List (X → A → ℝ) → (P → ℝ) → ℝ
  | [], _ => 0
  | c :: cs, S => ∑ x, d x * ∑ o, w S x o * (c x (action o) + finiteOutcomeLoss d action w U cs (U S x (c x) o))

theorem contextBestScore_indexed_weighted_le (d : X → ℝ) (hd : ∀ x, 0 ≤ d x)
    (predict : P → X → A) (costs : List (X → A → ℝ))
    (w : O → ℝ) (hw : ∀ a, 0 ≤ w a) (hsum : ∑ a, w a = 1) (v : O → P → ℝ) :
    contextBestScore d predict costs (fun p => ∑ a, w a * v a p) ≤
      ∑ a, w a * contextBestScore d predict costs (v a) := by
  classical
  induction costs generalizing v with
  | nil => exact treeBestScore_weighted_le w hw v
  | cons c cs ih =>
    have heq (x : X) : trueScoreStep predict (fun p => ∑ a, w a * v a p) c x =
        fun p => ∑ a, w a * trueScoreStep predict (v a) c x p := by
      funext p
      simp only [trueScoreStep, mul_sub, Finset.sum_sub_distrib, ← Finset.sum_mul, hsum, one_mul]
    simp only [contextBestScore]
    have h := Finset.sum_le_sum (s := Finset.univ) (fun x _ =>
      mul_le_mul_of_nonneg_left (ih (fun a => trueScoreStep predict (v a) c x)) (hd x))
    simp only [← heq] at h
    calc
      _ ≤ ∑ x, d x * ∑ a, w a * contextBestScore d predict cs (trueScoreStep predict (v a) c x) := h
      _ = _ := by
        simp_rw [Finset.mul_sum]
        rw [Finset.sum_comm]
        apply Finset.sum_congr rfl
        intro a _
        apply Finset.sum_congr rfl
        intro x _
        ring

theorem finiteOutcome_comparator (d : X → ℝ) (hd : ∀ x, 0 ≤ d x)
    (predict : P → X → A) (w : (P → ℝ) → X → O → ℝ)
    (hw : ∀ S x o, 0 ≤ w S x o) (hsum : ∀ S x, ∑ o, w S x o = 1)
    (U : (P → ℝ) → X → (A → ℝ) → O → P → ℝ)
    (hmean : ∀ S x c, (fun p => ∑ o, w S x o * U S x c o p) = fun p => S p - c (predict p x))
    (costs : List (X → A → ℝ)) (S : P → ℝ) :
    contextBestScore d predict costs S ≤ finiteOutcomeTerminal d w U treeBestScore costs S := by
  classical
  induction costs generalizing S with
  | nil => rfl
  | cons c cs ih =>
    apply Finset.sum_le_sum
    intro x _
    apply mul_le_mul_of_nonneg_left _ (hd x)
    have hj := contextBestScore_indexed_weighted_le d hd predict cs (w S x) (hw S x)
      (hsum S x) (fun o => U S x (c x) o)
    rw [hmean] at hj
    exact hj.trans (Finset.sum_le_sum fun o _ => mul_le_mul_of_nonneg_left (ih _) (hw S x o))

theorem finiteOutcomeTerminal_mono (d : X → ℝ) (hd : ∀ x, 0 ≤ d x)
    (action : O → A) (q : (P → ℝ) → X → O → ℝ)
    (U : (P → ℝ) → X → (A → ℝ) → O → P → ℝ)
    (hq : ∀ S x o, 0 ≤ q S x o) (f g : (P → ℝ) → ℝ) (hfg : ∀ S, f S ≤ g S)
    (costs : List (X → A → ℝ)) (S : P → ℝ) :
    finiteOutcomeTerminal d q U f costs S ≤ finiteOutcomeTerminal d q U g costs S := by
  classical
  induction costs generalizing S with
  | nil => exact hfg S
  | cons c cs ih =>
    apply Finset.sum_le_sum
    intro x _
    apply mul_le_mul_of_nonneg_left _ (hd x)
    exact Finset.sum_le_sum fun o _ => mul_le_mul_of_nonneg_left (ih _) (hq S x o)

theorem finiteOutcome_potential_bound (d : X → ℝ) (hd : ∀ x, 0 ≤ d x) (hdsum : ∑ x, d x = 1)
    (action : O → A) (q : (P → ℝ) → X → O → ℝ)
    (U : (P → ℝ) → X → (A → ℝ) → O → P → ℝ)
    (hq : ∀ S x o, 0 ≤ q S x o) (hqsum : ∀ S x, ∑ o, q S x o = 1)
    (R : (P → ℝ) → ℝ) (u : ℝ) (costs : List (X → A → ℝ))
    (hround : ∀ c ∈ costs, ∀ S, (∑ x, d x * ∑ o, q S x o *
      (c x (action o) + R (U S x (c x) o))) ≤ R S + u)
    (S : P → ℝ) :
    finiteOutcomeLoss d action q U costs S + finiteOutcomeTerminal d q U R costs S ≤
      R S + costs.length * u := by
  classical
  induction costs generalizing S with
  | nil => simp [finiteOutcomeLoss, finiteOutcomeTerminal]
  | cons c cs ih =>
    have hi (S : P → ℝ) := ih (fun c hc => hround c (List.mem_cons_of_mem _ hc)) S
    have hpoint (x : X) (o : O) := add_le_add (le_refl (c x (action o)))
      (hi (U S x (c x) o))
    have h := Finset.sum_le_sum (s := Finset.univ) (fun x _ =>
      mul_le_mul_of_nonneg_left (Finset.sum_le_sum (s := Finset.univ) (fun o _ =>
        mul_le_mul_of_nonneg_left (hpoint x o) (hq S x o))) (hd x))
    have hr := hround c (List.mem_cons_self) S
    calc
      _ = ∑ x, d x * ∑ o, q S x o * (c x (action o) + (finiteOutcomeLoss d action q U cs
          (U S x (c x) o) +
          finiteOutcomeTerminal d q U R cs (U S x (c x) o))) := by
        simp only [finiteOutcomeLoss, finiteOutcomeTerminal, ← Finset.sum_add_distrib, ← mul_add]
        apply Finset.sum_congr rfl
        intro x _
        congr 1
        apply Finset.sum_congr rfl
        intro o _
        ring
      _ ≤ ∑ x, d x * ∑ o, q S x o * (c x (action o) + (R (U S x (c x) o) + cs.length * u)) := h
      _ = (∑ x, d x * ∑ o, q S x o * (c x (action o) + R (U S x (c x) o))) + cs.length * u := by
        simp_rw [← add_assoc]
        exact finite_weighted_add_const d (q S) hdsum (hqsum S) _ _
      _ ≤ R S + (c :: cs).length * u := by simp only [List.length_cons, Nat.cast_add, Nat.cast_one]; linarith

theorem finiteOutcome_regret (d : X → ℝ) (hd : ∀ x, 0 ≤ d x) (hdsum : ∑ x, d x = 1)
    (predict : P → X → A) (action : O → A) (w : (P → ℝ) → X → O → ℝ)
    (hw : ∀ S x o, 0 ≤ w S x o) (hsum : ∀ S x, ∑ o, w S x o = 1)
    (U : (P → ℝ) → X → (A → ℝ) → O → P → ℝ)
    (hmean : ∀ S x c, (fun p => ∑ o, w S x o * U S x c o p) = fun p => S p - c (predict p x))
    (R : (P → ℝ) → ℝ) (hterminal : ∀ S p, S p ≤ R S) (u : ℝ)
    (costs : List (X → A → ℝ))
    (hround : ∀ c ∈ costs, ∀ S, (∑ x, d x * ∑ o, w S x o * (c x (action o) + R (U S x (c x) o))) ≤ R S + u)
    (S : P → ℝ) :
    finiteOutcomeLoss d action w U costs S + contextBestScore d predict costs S ≤ R S + costs.length * u := by
  have hc := finiteOutcome_comparator d hd predict w hw hsum U hmean costs S
  have ht := finiteOutcomeTerminal_mono d hd action w U hw treeBestScore R
    (fun S => treeBestScore_le (hterminal S)) costs S
  have hp := finiteOutcome_potential_bound d hd hdsum action w U hw hsum R u costs hround S
  linarith
end
end PoissonAudit
