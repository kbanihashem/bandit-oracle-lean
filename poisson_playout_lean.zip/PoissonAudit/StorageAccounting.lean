module
public import PoissonAudit.CostedArraySampler
public section
open scoped BigOperators
namespace PoissonAudit
noncomputable section

theorem executeValueCall_allocation {X : Type*} {K : ℕ} (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (Q : List (CostExample X K)) (x : X) (v : Vector ℝ K) :
    (executeValueCall oracle fallback Q x v).allocatedWords ≤ (executeValueCall oracle fallback Q x v).scalarWork := by
  dsimp only [executeValueCall]
  omega

theorem executeArrayLocalStep_allocation {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (j : ℕ) (record : ReplayRecord X K) (x : X) (state : ArrayReplayState K) :
    (executeArrayLocalStep r lam B eta history oracle fallback j record x state).allocatedWords ≤
      (executeArrayLocalStep r lam B eta history oracle fallback j record x state).internalWork := by
  have h := executeValueCall_allocation oracle fallback (history ++ record.2) x
    (Vector.ofFn (fun a => vectorValues state.1 a * record.1 a))
  dsimp only [executeArrayLocalStep]
  rw [executeArrayCoordinates_steps]
  omega

theorem executeArrayReplay_allocation {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (records : List (ReplayRecord X K)) (x : X) :
    (executeArrayReplay r lam B eta history oracle fallback records x).allocatedWords ≤
      (executeArrayReplay r lam B eta history oracle fallback records x).internalWork := by
  induction records with
  | nil => exact le_refl _
  | cons record records ih =>
    have hl := executeArrayLocalStep_allocation r lam B eta history oracle fallback records.length record x
      (executeArrayReplay r lam B eta history oracle fallback records x).state
    dsimp only [executeArrayReplay]
    omega

theorem executeArrayConstruction_allocation {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (J : ℕ) (tape : NativeNoiseTape X K J) :
    (executeArrayConstruction r lam B eta history oracle fallback J tape).allocatedWords ≤
      (executeArrayConstruction r lam B eta history oracle fallback J tape).internalWork := by
  induction J with
  | zero => exact le_refl _
  | succ J ih =>
    have hi := ih tape.1
    have hs : (∑ i : Fin tape.2.2.1, ((executeArrayReplay r lam B eta history oracle fallback
        (executeArrayConstruction r lam B eta history oracle fallback J tape.1).records (tape.2.2.2 i).1).allocatedWords + K + 1)) ≤
        ∑ i : Fin tape.2.2.1, ((executeArrayReplay r lam B eta history oracle fallback
        (executeArrayConstruction r lam B eta history oracle fallback J tape.1).records (tape.2.2.2 i).1).internalWork + 4 * K + 1) := by
      apply Finset.sum_le_sum
      intro i _
      have h := executeArrayReplay_allocation r lam B eta history oracle fallback
        (executeArrayConstruction r lam B eta history oracle fallback J tape.1).records (tape.2.2.2 i).1
      omega
    dsimp only [executeArrayConstruction]
    simp only [vectorGet_ofFn]
    omega

theorem executeArrayTrial_allocation {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (records : List (ReplayRecord X K)) (x : X) (v : NativeNoise X K) :
    (executeArrayTrial r lam B eta history oracle fallback records x v).allocatedWords ≤
      (executeArrayTrial r lam B eta history oracle fallback records x v).internalWork := by
  have hx := executeArrayReplay_allocation r lam B eta history oracle fallback records x
  have hs : (∑ i : Fin v.2.1, ((executeArrayReplay r lam B eta history oracle fallback records (v.2.2 i).1).allocatedWords + K + 1)) ≤
      ∑ i : Fin v.2.1, ((executeArrayReplay r lam B eta history oracle fallback records (v.2.2 i).1).internalWork + 4 * K + 1) := by
    apply Finset.sum_le_sum
    intro i _
    have h := executeArrayReplay_allocation r lam B eta history oracle fallback records (v.2.2 i).1
    omega
  dsimp only [executeArrayTrial]
  simp only [vectorGet_ofFn]
  have hc := executeValueCall_allocation oracle fallback
    (history ++ List.ofFn (fun i : Fin v.2.1 => ((v.2.2 i).1, vectorValues (Vector.ofFn (fun a =>
      vectorValues (executeArrayReplay r lam B eta history oracle fallback records (v.2.2 i).1).state.2 a * (v.2.2 i).2 a))))) x
    (Vector.ofFn (fun a => vectorValues (executeArrayReplay r lam B eta history oracle fallback records x).state.2 a * v.1 a))
  omega

theorem executeArraySampler_allocation {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (cap J m : ℕ) (tape : NativeNoiseTape X K J) (trials : Fin m → NativeNoise X K) (x : X) :
    (executeArraySampler r lam B eta history oracle fallback cap J m tape trials x).allocatedWords ≤
      (executeArraySampler r lam B eta history oracle fallback cap J m tape trials x).internalWork := by
  unfold executeArraySampler
  split_ifs
  · have hb := executeArrayConstruction_allocation r lam B eta history oracle fallback J tape
    have hs : (∑ i : Fin m, ((executeArrayTrial r lam B eta history oracle fallback
        (executeArrayConstruction r lam B eta history oracle fallback J tape).records x (trials i)).allocatedWords + 1)) ≤
        ∑ i : Fin m, ((executeArrayTrial r lam B eta history oracle fallback
        (executeArrayConstruction r lam B eta history oracle fallback J tape).records x (trials i)).internalWork + 1) := by
      apply Finset.sum_le_sum
      intro i _
      exact Nat.add_le_add_right (executeArrayTrial_allocation r lam B eta history oracle fallback _ x _) 1
    dsimp only
    simp only [vectorGet_ofFn]
    omega
  · exact le_refl _
end
end PoissonAudit
