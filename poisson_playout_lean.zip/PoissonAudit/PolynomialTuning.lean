module
public import PoissonAudit.PolynomialBudget
public import PoissonAudit.NativeTuning
public section
namespace PoissonAudit
noncomputable section

theorem concrete_tuning_power_bounds (k t L : ℝ) (hk : 1 ≤ k) (ht : 1 ≤ t) (hL : 1 ≤ L) :
    let H := 2 + k + t + L
    let A := Real.sqrt (k * t * L)
    let B := k * (t + 1)
    let r := A / (k * (1 + Real.log B))
    let lam := 4 * A / k
    let gamma := 1 / (t + 1)
    let delta := gamma / (t * (gamma + k))
    let eps := lam * delta ^ 2 / (32 * B ^ 2 * (r + 1) ^ 2 * k)
    2 ≤ H ∧ 0 < r ∧ 0 < lam ∧ 0 < delta ∧ 0 < eps ∧
      PowerBound H 3 r ∧ PowerBound H 1 k ∧ PowerBound H 4 lam ∧ PowerBound H 3 B ∧
        PowerBound H 30 (1 / eps) ∧ PowerBound H 4 (1 / delta) := by
  dsimp only
  let H := 2 + k + t + L
  let A := Real.sqrt (k * t * L)
  let B := k * (t + 1)
  let r := A / (k * (1 + Real.log B))
  let lam := 4 * A / k
  let gamma := 1 / (t + 1)
  let delta := gamma / (t * (gamma + k))
  let eps := lam * delta ^ 2 / (32 * B ^ 2 * (r + 1) ^ 2 * k)
  have hH : 2 ≤ H := by dsimp [H]; linarith
  have hH1 : 1 ≤ H := by linarith
  have hH0 : 0 ≤ H := by linarith
  have hk0 : 0 < k := by linarith
  have ht0 : 0 < t := by linarith
  have hkH : k ≤ H := by dsimp [H]; linarith
  have htH : t ≤ H := by dsimp [H]; linarith
  have hLH : L ≤ H := by dsimp [H]; linarith
  have ht1H : t + 1 ≤ H := by dsimp [H]; linarith
  have hk1H : k + 1 ≤ H := by dsimp [H]; linarith
  have hkt : 1 ≤ k * t := by nlinarith
  have hprod : 1 ≤ k * t * L := by nlinarith
  have hA0 : 0 ≤ A := Real.sqrt_nonneg _
  have hA2 : A ^ 2 = k * t * L := Real.sq_sqrt (by positivity)
  have hA1 : 1 ≤ A := by nlinarith
  have hAH : A ≤ H ^ 2 := by
    have hp : k * t * L ≤ H ^ 3 := by
      have h := mul_le_mul (mul_le_mul hkH htH (by linarith) hH0) hLH (by linarith) (mul_nonneg hH0 hH0)
      convert! h using 1 <;> ring
    have hpow : H ^ 3 ≤ H ^ 4 := pow_le_pow_right₀ hH1 (by norm_num)
    nlinarith only [hA2, hp, hpow, hA0, sq_nonneg (H ^ 2)]
  have hAP : PowerBound H 2 A := ⟨hA0, hAH⟩
  have hB1 : 1 ≤ B := by dsimp [B]; nlinarith
  have hBH : B ≤ H ^ 2 := by
    have h := mul_le_mul hkH ht1H (by linarith) hH0
    change k * (t + 1) ≤ H ^ 2
    nlinarith only [h]
  have hBP : PowerBound H 3 B := powerBound_mono hH1 ⟨by linarith, hBH⟩ (by norm_num)
  have hell : 1 ≤ 1 + Real.log B := by linarith [Real.log_nonneg hB1]
  have hr0 : 0 < r := by dsimp [r]; positivity
  have hdenr : 1 ≤ k * (1 + Real.log B) := by nlinarith
  have hrA : r ≤ A := div_le_self hA0 hdenr
  have hrP : PowerBound H 3 r := powerBound_mono hH1 ⟨hr0.le, hrA.trans hAH⟩ (by norm_num)
  have hlam0 : 0 < lam := by dsimp [lam]; positivity
  have hlamA : lam ≤ 4 * A := div_le_self (by positivity) hk
  have hlamP : PowerBound H 4 lam := by
    have hs : PowerBound H 4 (4 * A) := by convert! powerBound_scale hH hAP 2 using 1 <;> norm_num
    exact ⟨hlam0.le, hlamA.trans hs.2⟩
  have hklam : k * lam = 4 * A := by dsimp [lam]; field_simp
  have hinvlam : 1 / lam ≤ k := (div_le_iff₀ hlam0).mpr (by nlinarith only [hklam, hA1])
  have hinvlamP : PowerBound H 2 (1 / lam) := powerBound_mono hH1
    (show PowerBound H 1 (1 / lam) from ⟨by positivity, by simpa only [pow_one] using hinvlam.trans hkH⟩) (by norm_num)
  have hg0 : 0 < gamma := by dsimp [gamma]; positivity
  have hg1 : gamma ≤ 1 := by
    dsimp [gamma]
    exact (div_le_one (by positivity : 0 < t + 1)).mpr (by linarith)
  have hd0 : 0 < delta := by dsimp [delta]; positivity
  have heps0 : 0 < eps := by dsimp [eps]; positivity
  have hinvd : 1 / delta = t * (gamma + k) * (t + 1) := by
    dsimp [delta, gamma]
    have ht1 : t + 1 ≠ 0 := by positivity
    have hden : 1 + k * (t + 1) ≠ 0 := by positivity
    field_simp
    <;> ring
  have hdBound : 1 / delta ≤ H ^ 3 := by
    rw [hinvd]
    have hmid : gamma + k ≤ H := by linarith
    have h := mul_le_mul (mul_le_mul htH hmid (by positivity) hH0) ht1H (by positivity) (mul_nonneg hH0 hH0)
    nlinarith only [h]
  have hdP : PowerBound H 4 (1 / delta) := powerBound_mono hH1 ⟨by positivity, hdBound⟩ (by norm_num)
  have hkP : PowerBound H 1 k := ⟨hk0.le, by simpa using hkH⟩
  have hrAdd : PowerBound H 4 (r + 1) := powerBound_add hH hrP (powerBound_one H)
  have hepsInv : 1 / eps = 32 * B ^ 2 * (r + 1) ^ 2 * k * (1 / lam) * (1 / delta) ^ 2 := by
    dsimp [eps]
    field_simp
    <;> ring
  have hepsP : PowerBound H 30 (1 / eps) := by
    rw [hepsInv]
    have h := powerBound_mul hH0 (powerBound_mul hH0
      (powerBound_mul hH0 (powerBound_mul hH0 (powerBound_scale hH (powerBound_sq hH0 hBP) 5)
        (powerBound_sq hH0 hrAdd)) hkP) hinvlamP) (powerBound_sq hH0 hdP)
    convert! h using 1 <;> norm_num
  exact ⟨hH, hr0, hlam0, hd0, heps0, hrP, hkP, hlamP, hBP, hepsP, hdP⟩
end
end PoissonAudit
