module

public import PoissonAudit.PoissonActionIntegration
public import PoissonAudit.FiniteGroupMaximum
public import PoissonAudit.ThresholdRemainder

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X]
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]
    {n : ℕ}

@[expose] def experimentRemainderLaw (r : NNReal) (D : Measure X) (n : ℕ) :
    Measure ((Fin n → ℝ) × (ℕ × (ℕ → X × (Fin (n + 1) → ℝ)))) :=
  (iidPool realLaplace n).prod (markedPoolLaw r (contextLaplaceLaw D (n + 1)))

instance experimentRemainderLaw_isProbability (r : NNReal) (D : Measure X) [IsProbabilityMeasure D] :
    IsProbabilityMeasure (experimentRemainderLaw r D n) := by unfold experimentRemainderLaw; infer_instance

@[expose] def restoreExperimentEquiv (a : Fin (n + 1)) :
    (((Fin n → ℝ) × (ℕ × (ℕ → X × (Fin (n + 1) → ℝ)))) × ℝ) ≃ᵐ
      ((Fin (n + 1) → ℝ) × (ℕ × (ℕ → X × (Fin (n + 1) → ℝ)))) :=
  MeasurableEquiv.prodComm.trans (coordinateSplitEquiv a _).symm

theorem restoreExperimentEquiv_apply (a : Fin (n + 1))
    (v : ((Fin n → ℝ) × (ℕ × (ℕ → X × (Fin (n + 1) → ℝ)))) × ℝ) :
    restoreExperimentEquiv a v = (a.insertNth v.2 v.1.1, v.1.2) := rfl

theorem restoreExperimentEquiv_measurePreserving (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (a : Fin (n + 1)) : MeasurePreserving (restoreExperimentEquiv a)
      ((experimentRemainderLaw r D n).prod realLaplace) (insertedExperimentLaw r D (n + 1)) := by
  have hsplit := coordinateSplitEquiv_measurePreserving (markedPoolLaw r (contextLaplaceLaw D (n + 1))) a
  exact (MeasurePreserving.symm (coordinateSplitEquiv a _) hsplit).comp
    (Measure.measurePreserving_swap (μ := experimentRemainderLaw r D n) (ν := realLaplace))

theorem insertNth_value_irrel (a q : Fin (n + 1)) (hq : q ≠ a) (u v : ℝ) (z : Fin n → ℝ) :
    Fin.insertNth (α := fun _ : Fin (n + 1) => ℝ) a u z q = Fin.insertNth (α := fun _ : Fin (n + 1) => ℝ) a v z q := by
  rcases a.eq_self_or_eq_succAbove q with heq | ⟨j, rfl⟩
  · exact False.elim (hq heq)
  · simp

@[expose] def coordinateBaseScore (predict : P → X → Fin (n + 1))
    (sigma : X × Fin (n + 1) → ℝ) (S : P → ℝ) (x : X) (a : Fin (n + 1))
    (v : (Fin n → ℝ) × (ℕ × (ℕ → X × (Fin (n + 1) → ℝ)))) (p : P) : ℝ :=
  experimentScore predict sigma S x (restoreExperimentEquiv a (v, 0)) p

theorem measurable_coordinateBaseScore (predict : P → X → Fin (n + 1))
    (sigma : X × Fin (n + 1) → ℝ) (S : P → ℝ) (x : X) (a : Fin (n + 1)) (p : P) :
    Measurable (fun v => coordinateBaseScore predict sigma S x a v p) :=
  (measurable_experimentScore predict sigma S x p).comp
    ((restoreExperimentEquiv a).measurable.comp (measurable_id.prodMk measurable_const))

@[expose] def actionPolicyGroup (predict : P → X → Fin (n + 1)) (x : X) (a : Fin (n + 1)) : Finset P :=
  Finset.univ.filter (fun p => predict p x = a)

theorem mem_actionPolicyGroup (predict : P → X → Fin (n + 1)) (x : X) (a : Fin (n + 1)) (p : P) :
    p ∈ actionPolicyGroup predict x a ↔ predict p x = a := by simp [actionPolicyGroup]

theorem restored_experimentScore (predict : P → X → Fin (n + 1))
    (sigma : X × Fin (n + 1) → ℝ) (S : P → ℝ) (x : X) (a : Fin (n + 1)) (s : ℝ)
    (v : ((Fin n → ℝ) × (ℕ × (ℕ → X × (Fin (n + 1) → ℝ)))) × ℝ) (p : P) :
    experimentScore predict sigma (actionPenaltyScore predict S x a s) x (restoreExperimentEquiv a v) p =
      coordinateBaseScore predict sigma S x a v.1 p +
        if p ∈ actionPolicyGroup predict x a then sigma (x, a) * v.2 - s else 0 := by
  classical
  simp only [mem_actionPolicyGroup]
  unfold coordinateBaseScore experimentScore markValue actionPenaltyScore actionSlope
  simp only [restoreExperimentEquiv_apply, Prod.fst, Prod.snd]
  by_cases hp : predict p x = a
  · simp [hp]
    ring
  · rw [if_neg hp, if_neg hp, insertNth_value_irrel a (predict p x) hp v.2 0 v.1.1]
    ring

@[expose] def experimentThreshold (predict : P → X → Fin (n + 1))
    (sigma : X × Fin (n + 1) → ℝ) (S : P → ℝ) (x : X) (a : Fin (n + 1))
    (hE : (actionPolicyGroup predict x a).Nonempty) (hEc : (actionPolicyGroup predict x a)ᶜ.Nonempty)
    (v : (Fin n → ℝ) × (ℕ × (ℕ → X × (Fin (n + 1) → ℝ)))) : ℝ :=
  groupThreshold (coordinateBaseScore predict sigma S x a v) (actionPolicyGroup predict x a) hE hEc (sigma (x, a))

theorem measurable_experimentThreshold (predict : P → X → Fin (n + 1))
    (sigma : X × Fin (n + 1) → ℝ) (S : P → ℝ) (x : X) (a : Fin (n + 1))
    (hE : (actionPolicyGroup predict x a).Nonempty) (hEc : (actionPolicyGroup predict x a)ᶜ.Nonempty) :
    Measurable (experimentThreshold predict sigma S x a hE hEc) :=
  ((measurable_groupMaximum (fun p v => coordinateBaseScore predict sigma S x a v p)
      (measurable_coordinateBaseScore predict sigma S x a) _ hEc).sub
    (measurable_groupMaximum (fun p v => coordinateBaseScore predict sigma S x a v p)
      (measurable_coordinateBaseScore predict sigma S x a) _ hE)).div_const _

end

end PoissonAudit
