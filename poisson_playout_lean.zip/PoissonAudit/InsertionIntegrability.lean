module

public import PoissonAudit.FiniteInsertion

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem measurable_selected_singleMarkCoefficient {Omega : Type*} [MeasurableSpace Omega]
    (predict : P → X → Fin K) (j : X × Fin K) (w : Omega → P) (hw : Measurable w)
    (u : Omega → X × (Fin K → ℝ)) (hu : Measurable u) :
    Measurable (fun omega => singleMarkCoefficient predict (w omega) j (u omega)) := by
  have hjoint : Measurable (fun v : Omega × P => singleMarkCoefficient predict v.2 j (u v.1)) :=
    measurable_from_prod_countable_left fun p => (measurable_singleMarkCoefficient predict p j).comp hu
  exact hjoint.comp (measurable_id.prodMk hw)

theorem abs_singleMarkCoefficient_le (predict : P → X → Fin K) (p : P) (j : X × Fin K)
    (u : X × (Fin K → ℝ)) : |singleMarkCoefficient predict p j u| ≤ |u.2 j.2| := by
  classical
  by_cases hp : predict p j.1 = j.2
  · by_cases hx : u.1 = j.1 <;> simp [singleMarkCoefficient, hp, hx, abs_nonneg]
  · simp [singleMarkCoefficient, hp, abs_nonneg]

theorem measurable_insertedContribution (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (j : X × Fin K) (n : ℕ) : Measurable (insertedContribution predict sigma S j n) :=
  measurable_selected_singleMarkCoefficient predict j _ (measurable_insertedMarkWinner predict sigma S n)
    Prod.fst measurable_fst

theorem measurable_finitePoolGradient (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (j : X × Fin K) (n : ℕ) :
    Measurable (fun u : Fin n → X × (Fin K → ℝ) => finitePoolGradient predict sigma S j u) := by
  apply Finset.measurable_sum
  intro i _
  exact measurable_selected_singleMarkCoefficient predict j _ (measurable_finiteMarkWinner predict sigma S n)
    (fun u => u i) (measurable_pi_apply i)

theorem integrable_context_laplace_coordinate (D : Measure X) [IsProbabilityMeasure D] (a : Fin K) :
    Integrable (fun u : X × (Fin K → ℝ) => u.2 a) (contextLaplaceLaw D K) := by
  change Integrable (fun u : X × (Fin K → ℝ) => u.2 a) (D.prod (laplaceMeasure K))
  simpa only [one_mul] using (integrable_const (1 : ℝ) (μ := D)).mul_prod (integrable_laplace_coordinate K a)

theorem integrable_inserted_coordinate (D : Measure X) [IsProbabilityMeasure D] (a : Fin K) (n : ℕ) :
    Integrable (fun v : (X × (Fin K → ℝ)) × (Fin n → X × (Fin K → ℝ)) => |v.1.2 a|)
      ((contextLaplaceLaw D K).prod (iidPool (contextLaplaceLaw D K) n)) := by
  simpa only [mul_one] using (integrable_context_laplace_coordinate D a).abs.mul_prod
    (integrable_const (1 : ℝ) (μ := iidPool (contextLaplaceLaw D K) n))

theorem integrable_insertedContribution (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (j : X × Fin K) (n : ℕ) :
    Integrable (insertedContribution predict sigma S j n)
      ((contextLaplaceLaw D K).prod (iidPool (contextLaplaceLaw D K) n)) := by
  apply (integrable_inserted_coordinate D j.2 n).mono'
    (measurable_insertedContribution predict sigma S j n).aestronglyMeasurable
  filter_upwards [] with v
  rw [Real.norm_eq_abs]
  exact abs_singleMarkCoefficient_le predict _ j v.1

theorem integrable_finitePoolGradient (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (j : X × Fin K) (n : ℕ) :
    Integrable (fun u : Fin n → X × (Fin K → ℝ) => finitePoolGradient predict sigma S j u)
      (iidPool (contextLaplaceLaw D K) n) := by
  apply integrable_finsetSum
  intro i _
  have hdom := (measurePreserving_eval (fun _ : Fin n => contextLaplaceLaw D K) i).integrable_comp_of_integrable
    (integrable_context_laplace_coordinate D j.2).abs
  apply hdom.mono'
    (measurable_selected_singleMarkCoefficient predict j _ (measurable_finiteMarkWinner predict sigma S n)
      (fun u => u i) (measurable_pi_apply i)).aestronglyMeasurable
  filter_upwards [] with u
  rw [Real.norm_eq_abs]
  exact abs_singleMarkCoefficient_le predict _ j (u i)

theorem abs_insertionMean_le (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (j : X × Fin K) (n : ℕ) :
    |insertionMean (contextLaplaceLaw D K) (insertedContribution predict sigma S j) n| ≤
      ∫ u : X × (Fin K → ℝ), |u.2 j.2| ∂contextLaplaceLaw D K := by
  unfold insertionMean
  calc
    _ ≤ ∫ v, |insertedContribution predict sigma S j n v|
        ∂(contextLaplaceLaw D K).prod (iidPool (contextLaplaceLaw D K) n) := abs_integral_le_integral_abs
    _ ≤ ∫ v : (X × (Fin K → ℝ)) × (Fin n → X × (Fin K → ℝ)), |v.1.2 j.2|
        ∂(contextLaplaceLaw D K).prod (iidPool (contextLaplaceLaw D K) n) := by
      apply integral_mono (integrable_insertedContribution D predict sigma S j n).abs
        (integrable_inserted_coordinate D j.2 n)
      exact fun v => abs_singleMarkCoefficient_le predict _ j v.1
    _ = _ := by
      have h := integral_prod_mul (μ := contextLaplaceLaw D K) (ν := iidPool (contextLaplaceLaw D K) n)
        (fun u : X × (Fin K → ℝ) => |u.2 j.2|) (fun _ => (1 : ℝ))
      simpa only [mul_one, integral_const, probReal_univ, smul_eq_mul, one_mul] using h

theorem integrable_insertionMean (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (j : X × Fin K) :
    Integrable (insertionMean (contextLaplaceLaw D K) (insertedContribution predict sigma S j))
      (ProbabilityTheory.poissonMeasure r) := by
  apply Integrable.of_bound (measurable_of_countable _).aestronglyMeasurable
    (∫ u : X × (Fin K → ℝ), |u.2 j.2| ∂contextLaplaceLaw D K)
  filter_upwards [] with n
  rw [Real.norm_eq_abs]
  exact abs_insertionMean_le D predict sigma S j n

theorem finite_gradient_poisson_insertion (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (j : X × Fin K) :
    (∫ n, (∫ u : Fin n → X × (Fin K → ℝ), finitePoolGradient predict sigma S j u
      ∂iidPool (contextLaplaceLaw D K) n) ∂ProbabilityTheory.poissonMeasure r) =
    (r : ℝ) * ∫ n, (∫ u0, ∫ pool, insertedContribution predict sigma S j n (u0, pool)
      ∂iidPool (contextLaplaceLaw D K) n ∂contextLaplaceLaw D K) ∂ProbabilityTheory.poissonMeasure r := by
  have hh := marked_poisson_insertion r (contextLaplaceLaw D K) (insertedContribution predict sigma S j)
    (integrable_insertedContribution D predict sigma S j) (integrable_insertionMean r D predict sigma S j)
  have hdel (n : ℕ) (u : Fin n → X × (Fin K → ℝ)) :
      deletionSum (insertedContribution predict sigma S j) n u = finitePoolGradient predict sigma S j u := by
    cases n with
    | zero => simp [deletionSum, finitePoolGradient]
    | succ n => exact deletion_insertedContribution predict sigma S j n u
  simpa only [hdel] using hh

end

end PoissonAudit
