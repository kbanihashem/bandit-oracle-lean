module

public import PoissonAudit.RealLaplaceMoments
public import PoissonAudit.MarkedPoisson

public section

open MeasureTheory Set
open scoped BigOperators ENNReal

namespace PoissonAudit

noncomputable section

theorem laplaceDensity_eq_prod (K : ℕ) (z : Fin K → ℝ) :
    laplaceDensity z = ∏ i, realLaplaceDensity (z i) := by
  simp [laplaceDensity, laplaceKernel_eq_prod, realLaplaceDensity, Finset.prod_div_distrib]

theorem laplaceMeasure_eq_iid (K : ℕ) : laplaceMeasure K = iidPool realLaplace K := by
  classical
  symm
  unfold iidPool
  apply Measure.pi_eq
  intro s hs
  have hset : MeasurableSet (Set.pi Set.univ s) := MeasurableSet.univ_pi hs
  change (volume.withDensity (fun z => ENNReal.ofReal (laplaceDensity z))) (Set.pi Set.univ s) = _
  rw [withDensity_apply _ hset,
    ← ofReal_integral_eq_lintegral_ofReal (integrable_laplaceDensity K).restrict
      (Filter.Eventually.of_forall fun z => (laplaceDensity_pos z).le)]
  simp_rw [laplaceDensity_eq_prod]
  change ENNReal.ofReal (∫ z, ∏ i, realLaplaceDensity (z i)
    ∂(Measure.pi (fun _ : Fin K => (volume : Measure ℝ))).restrict (Set.pi Set.univ s)) = _
  rw [Measure.restrict_pi_pi, integral_fintype_prod_eq_prod]
  have hscalar (i : Fin K) :
      ENNReal.ofReal (∫ z in s i, realLaplaceDensity z) = realLaplace (s i) := by
    unfold realLaplace
    rw [withDensity_apply _ (hs i)]
    exact ofReal_integral_eq_lintegral_ofReal integrable_realLaplaceDensity.restrict
      (Filter.Eventually.of_forall fun z => (realLaplaceDensity_pos z).le)
  rw [ENNReal.ofReal_prod_of_nonneg (fun i _ => integral_nonneg fun z => (realLaplaceDensity_pos z).le)]
  exact Finset.prod_congr rfl fun i _ => hscalar i

theorem integrable_laplace_coordinate (K : ℕ) (a : Fin K) :
    Integrable (fun z : Fin K → ℝ => z a) (laplaceMeasure K) := by
  rw [laplaceMeasure_eq_iid]
  exact (measurePreserving_eval (fun _ : Fin K => realLaplace) a).integrable_comp_of_integrable
    integrable_realLaplace_id

theorem integral_laplace_coordinate (K : ℕ) (a : Fin K) :
    (∫ z : Fin K → ℝ, z a ∂laplaceMeasure K) = 0 := by
  rw [laplaceMeasure_eq_iid]
  have h := integral_map (μ := iidPool realLaplace K) (φ := fun z => z a)
    (measurable_pi_apply a).aemeasurable (f := fun z : ℝ => z) (by fun_prop)
  change (∫ y : ℝ, y ∂(Measure.pi (fun _ : Fin K => realLaplace)).map (Function.eval a)) = _ at h
  rw [(measurePreserving_eval (fun _ : Fin K => realLaplace) a).map_eq,
    integral_realLaplace_id] at h
  exact h.symm

end

end PoissonAudit
