module
public import PoissonAudit.NativeEmpiricalRule
public section
open Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {P : Type*} [Fintype P] [Nonempty P] [LinearOrder P] {K : ℕ}

theorem score_le_treeBestScore (S : P → ℝ) (p : P) : S p ≤ treeBestScore S :=
  Finset.le_sup' (s := Finset.univ) (f := S) (Finset.mem_univ p)

theorem winner_score_eq_treeBestScore (S : P → ℝ) : S (winner S) = treeBestScore S := by
  apply le_antisymm (score_le_treeBestScore S _)
  exact Finset.sup'_le _ _ (fun p _ => winner_maximizes S p)

@[expose] def actionBoostScore (S : P → ℝ) (predict : P → Fin K) (a : Fin K) (p : P) : ℝ := by
  classical
  exact S p + if predict p = a then 1 else 0

theorem boosted_value_action_iff (S : P → ℝ) (predict : P → Fin K) (a : Fin K) :
    treeBestScore (actionBoostScore S predict a) = treeBestScore S + 1 ↔
      ∃ p, S p = treeBestScore S ∧ predict p = a := by
  classical
  constructor
  · intro h
    let p := winner (actionBoostScore S predict a)
    have hw : actionBoostScore S predict a p = treeBestScore (actionBoostScore S predict a) := winner_score_eq_treeBestScore _
    have hp := score_le_treeBestScore S p
    by_cases ha : predict p = a
    · refine ⟨p, ?_, ha⟩
      simp only [actionBoostScore, ha, ite_true] at hw
      linarith
    · simp only [actionBoostScore, ha, ite_false, add_zero] at hw
      linarith
  · rintro ⟨p, hp, ha⟩
    apply le_antisymm
    · apply treeBestScore_le
      intro q
      have hq := score_le_treeBestScore S q
      unfold actionBoostScore
      split_ifs <;> linarith
    · have h := score_le_treeBestScore (actionBoostScore S predict a) p
      simpa only [actionBoostScore, hp, ha, ite_true] using h

theorem exists_boosted_value_action (S : P → ℝ) (predict : P → Fin K) :
    ∃ a, treeBestScore (actionBoostScore S predict a) = treeBestScore S + 1 := by
  refine ⟨predict (winner S), (boosted_value_action_iff S predict _).mpr ?_⟩
  exact ⟨winner S, winner_score_eq_treeBestScore S, rfl⟩

@[expose] def actionFromValueTable (base : ℝ) (table : Fin K → ℝ)
    (hgood : ∃ a, table a = base + 1) : Fin K := by
  classical
  exact (Finset.univ.filter (fun a => table a = base + 1)).min' (by
    obtain ⟨a, ha⟩ := hgood
    exact ⟨a, by simp [ha]⟩)

theorem actionFromValueTable_spec (base : ℝ) (table : Fin K → ℝ) (hgood : ∃ a, table a = base + 1) :
    table (actionFromValueTable base table hgood) = base + 1 := by
  classical
  have h := Finset.min'_mem (Finset.univ.filter (fun a => table a = base + 1)) (by
    obtain ⟨a, ha⟩ := hgood
    exact ⟨a, by simp [ha]⟩)
  exact (Finset.mem_filter.mp h).2

theorem exact_value_table_winning_action (S : P → ℝ) (predict : P → Fin K)
    (base : ℝ) (table : Fin K → ℝ) (hbase : base = treeBestScore S)
    (htable : ∀ a, table a = treeBestScore (actionBoostScore S predict a))
    (hgood : ∃ a, table a = base + 1) :
    ∃ p, S p = treeBestScore S ∧ predict p = actionFromValueTable base table hgood := by
  apply (boosted_value_action_iff S predict _).mp
  rw [← htable, ← hbase]
  exact actionFromValueTable_spec base table hgood

theorem exact_value_table_unique_action (S : P → ℝ) (predict : P → Fin K)
    (base : ℝ) (table : Fin K → ℝ) (hbase : base = treeBestScore S)
    (htable : ∀ a, table a = treeBestScore (actionBoostScore S predict a))
    (hgood : ∃ a, table a = base + 1)
    (hunique : ∀ p q, S p = treeBestScore S → S q = treeBestScore S → predict p = predict q) :
    actionFromValueTable base table hgood = predict (winner S) := by
  obtain ⟨p, hp, ha⟩ := exact_value_table_winning_action S predict base table hbase htable hgood
  exact ha.symm.trans (hunique p (winner S) hp (winner_score_eq_treeBestScore S))
end
end PoissonAudit
