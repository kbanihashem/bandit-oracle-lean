module

public import PoissonAudit.MarginalDensity
public import PoissonAudit.ChannelDiscrepancy

public section

open MeasureTheory ProbabilityTheory InformationTheory
open scoped ENNReal

namespace PoissonAudit

noncomputable section

variable {A B : Type*} [MeasurableSpace A] [MeasurableSpace B]

theorem measurable_eventSectionMass (nu : Measure B) [SFinite nu]
    (E : Set (A × B)) (hE : MeasurableSet E) : Measurable (eventSectionMass nu E) :=
  (measurable_const.indicator hE).lintegral_prod_right'

omit [MeasurableSpace A] in
theorem eventSectionMass_le_one (nu : Measure B) [IsProbabilityMeasure nu]
    (E : Set (A × B)) (a : A) : eventSectionMass nu E a ≤ 1 := by
  calc
    _ ≤ ∫⁻ _ : B, (1 : ENNReal) ∂nu := by
      apply lintegral_mono
      intro b
      classical
      by_cases h : (a, b) ∈ E <;> simp [h]
    _ = 1 := by simp

omit [MeasurableSpace A] in
theorem eventSectionMass_ne_top (nu : Measure B) [IsProbabilityMeasure nu]
    (E : Set (A × B)) (a : A) : eventSectionMass nu E a ≠ ∞ :=
  ne_top_of_le_ne_top (by simp) (eventSectionMass_le_one nu E a)

@[expose] def eventChannel (nu : Measure B) (E : Set (A × B)) (a : A) : ℝ :=
  (eventSectionMass nu E a).toReal

omit [MeasurableSpace A] in
theorem eventChannel_mem_Icc (nu : Measure B) [IsProbabilityMeasure nu]
    (E : Set (A × B)) (a : A) : eventChannel nu E a ∈ Set.Icc 0 1 := by
  constructor
  · exact ENNReal.toReal_nonneg
  · have h := ENNReal.toReal_mono (by simp : (1 : ENNReal) ≠ ∞)
      (eventSectionMass_le_one nu E a)
    simpa only [eventChannel, ENNReal.toReal_one] using h

theorem integrable_eventChannel (mu : Measure A) (nu : Measure B)
    [IsProbabilityMeasure mu] [IsProbabilityMeasure nu]
    (E : Set (A × B)) (hE : MeasurableSet E) : Integrable (eventChannel nu E) mu := by
  apply Integrable.of_mem_Icc 0 1 (measurable_eventSectionMass nu E hE).ennreal_toReal.aemeasurable
  exact Filter.Eventually.of_forall (eventChannel_mem_Icc nu E)

theorem eventChannel_eq_integral_indicator (nu : Measure B) [IsProbabilityMeasure nu]
    (E : Set (A × B)) (hE : MeasurableSet E) (a : A) :
    eventChannel nu E a = ∫ b, E.indicator (fun _ => (1 : ℝ)) (a, b) ∂nu := by
  classical
  have hf : Measurable (fun b => E.indicator (fun _ => (1 : ENNReal)) (a, b)) :=
    (measurable_const.indicator hE).comp (measurable_const.prodMk measurable_id)
  have hfin : ∀ᵐ b ∂nu, E.indicator (fun _ => (1 : ENNReal)) (a, b) < ∞ := by
    filter_upwards [] with b
    by_cases h : (a, b) ∈ E <;> simp [h]
  unfold eventChannel eventSectionMass
  rw [← integral_toReal hf.aemeasurable hfin]
  apply integral_congr_ae
  filter_upwards [] with b
  by_cases h : (a, b) ∈ E <;> simp [h]

theorem integral_eventChannel (mu : Measure A) (nu : Measure B)
    [IsProbabilityMeasure mu] [IsProbabilityMeasure nu]
    (E : Set (A × B)) (hE : MeasurableSet E) :
    (∫ a, eventChannel nu E a ∂mu) = (mu.prod nu E).toReal := by
  have hi : ENNReal.ofReal (∫ a, eventChannel nu E a ∂mu) = mu.prod nu E := by
    rw [ofReal_integral_eq_lintegral_ofReal (integrable_eventChannel mu nu E hE)
      (Filter.Eventually.of_forall fun a => (eventChannel_mem_Icc nu E a).1)]
    calc
      _ = ∫⁻ a, eventSectionMass nu E a ∂mu := by
        apply lintegral_congr_ae
        filter_upwards [] with a
        exact ENNReal.ofReal_toReal (eventSectionMass_ne_top nu E a)
      _ = ∫⁻ p, E.indicator (fun _ => (1 : ENNReal)) p ∂mu.prod nu :=
        (lintegral_prod _ (measurable_const.indicator hE).aemeasurable).symm
      _ = _ := by
        change (∫⁻ p, E.indicator (1 : A × B → ENNReal) p ∂mu.prod nu) = _
        exact lintegral_indicator_one hE
  have h := congrArg ENNReal.toReal hi
  rwa [ENNReal.toReal_ofReal (integral_nonneg fun a => (eventChannel_mem_Icc nu E a).1)] at h

theorem fst_conditioned_product_channel_density (mu : Measure A) (nu : Measure B)
    [IsProbabilityMeasure mu] [IsProbabilityMeasure nu]
    (E : Set (A × B)) (hE : MeasurableSet E) (hp : mu.prod nu E ≠ 0) :
    ((mu.prod nu)[|E]).fst = mu.withDensity (fun a =>
      ENNReal.ofReal (eventChannel nu E a / (mu.prod nu E).toReal)) := by
  rw [fst_conditioned_product mu nu E hE]
  congr 1
  funext a
  change (mu.prod nu E)⁻¹ * eventSectionMass nu E a =
    ENNReal.ofReal ((eventSectionMass nu E a).toReal / (mu.prod nu E).toReal)
  rw [ENNReal.ofReal_div_of_pos (ENNReal.toReal_pos hp (measure_ne_top _ _)),
    ENNReal.ofReal_toReal (eventSectionMass_ne_top nu E a),
    ENNReal.ofReal_toReal (measure_ne_top _ _)]
  exact mul_comm _ _

theorem eventChannel_discrepancy_le_marginal_kl (mu : Measure A) (nu : Measure B)
    [IsProbabilityMeasure mu] [IsProbabilityMeasure nu]
    (E : Set (A × B)) (hE : MeasurableSet E) (hp : mu.prod nu E ≠ 0) :
    ENNReal.ofReal (∫ a, (Real.sqrt (eventChannel nu E a) -
      Real.sqrt (mu.prod nu E).toReal) ^ 2 ∂mu) ≤
      mu.prod nu E * klDiv ((mu.prod nu)[|E]).fst mu := by
  rw [fst_conditioned_product_channel_density mu nu E hE hp]
  have h := channel_discrepancy_le_posterior_kl mu (eventChannel nu E)
    (measurable_eventSectionMass nu E hE).ennreal_toReal
    (fun a => (eventChannel_mem_Icc nu E a).1) (integrable_eventChannel mu nu E hE)
    (mu.prod nu E).toReal (ENNReal.toReal_pos hp (measure_ne_top _ _))
    (integral_eventChannel mu nu E hE)
  rwa [ENNReal.ofReal_toReal (measure_ne_top _ _)] at h

theorem eventChannel_discrepancy_zero (mu : Measure A) (nu : Measure B)
    [IsProbabilityMeasure mu] [IsProbabilityMeasure nu]
    (E : Set (A × B)) (hE : MeasurableSet E) (hp : mu.prod nu E = 0) :
    (∫ a, (Real.sqrt (eventChannel nu E a) - Real.sqrt (mu.prod nu E).toReal) ^ 2 ∂mu) = 0 := by
  have hmean : (∫ a, eventChannel nu E a ∂mu) = 0 := by
    rw [integral_eventChannel mu nu E hE, hp, ENNReal.toReal_zero]
  have hz : eventChannel nu E =ᵐ[mu] 0 :=
    (integral_eq_zero_iff_of_nonneg (fun a => (eventChannel_mem_Icc nu E a).1)
      (integrable_eventChannel mu nu E hE)).mp hmean
  have heq : (fun a => (Real.sqrt (eventChannel nu E a) - Real.sqrt (mu.prod nu E).toReal) ^ 2)
      =ᵐ[mu] (fun _ => (0 : ℝ)) := by
    filter_upwards [hz] with a ha
    simp [ha, hp]
  rw [integral_congr_ae heq, integral_zero]

theorem eventChannel_discrepancy_le_posterior (mu : Measure A) (nu : Measure B)
    [IsProbabilityMeasure mu] [IsProbabilityMeasure nu]
    (E : Set (A × B)) (hE : MeasurableSet E) :
    ENNReal.ofReal (∫ a, (Real.sqrt (eventChannel nu E a) -
      Real.sqrt (mu.prod nu E).toReal) ^ 2 ∂mu) ≤
      mu.prod nu E * klDiv (eventPosterior (mu.prod nu) E).fst mu := by
  classical
  by_cases hp : mu.prod nu E = 0
  · rw [eventChannel_discrepancy_zero mu nu E hE hp, hp]
    simp
  · rw [eventPosterior, ite_eq_right hp]
    exact eventChannel_discrepancy_le_marginal_kl mu nu E hE hp

end

end PoissonAudit
