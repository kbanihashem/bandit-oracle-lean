module

public import PoissonAudit.PoissonCurvature

public section

open MeasureTheory Set Filter
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {Omega : Type*} [MeasurableSpace Omega]

theorem integrable_random_thresholdSign (mu : Measure Omega) [IsProbabilityMeasure mu]
    (theta : Omega → ℝ) (htheta : Measurable theta) (sigma s : ℝ) :
    Integrable (fun v : Omega × ℝ => if theta v.1 + s / sigma < v.2 then laplaceSign v.2 else 0)
      (mu.prod realLaplace) := by
  have hm : Measurable (fun v : Omega × ℝ => if theta v.1 + s / sigma < v.2 then laplaceSign v.2 else 0) :=
    (measurable_laplaceSign.comp measurable_snd).ite
      (measurableSet_lt ((htheta.comp measurable_fst).add_const _) measurable_snd) measurable_const
  apply Integrable.of_bound hm.aestronglyMeasurable 1
  filter_upwards [] with v
  split <;> simp [Real.norm_eq_abs, abs_laplaceSign]

theorem integral_random_thresholdSign (mu : Measure Omega) [IsProbabilityMeasure mu]
    (theta : Omega → ℝ) (htheta : Measurable theta) (sigma s : ℝ) :
    (∫ v : Omega × ℝ, (if theta v.1 + s / sigma < v.2 then laplaceSign v.2 else 0) ∂mu.prod realLaplace) =
      ∫ omega, realLaplaceDensity (theta omega + s / sigma) ∂mu := by
  rw [integral_prod _ (integrable_random_thresholdSign mu theta htheta sigma s)]
  apply integral_congr_ae
  filter_upwards [] with omega
  change (∫ z, (Ioi (theta omega + s / sigma)).indicator laplaceSign z ∂realLaplace) = _
  rw [integral_indicator measurableSet_Ioi]
  exact integral_laplaceSign_tail _

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X]
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]
    {K n : ℕ}

@[expose] def experimentBeta (r : NNReal) (D : Measure X)
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) : ℝ :=
  ∫ v, (experimentActionEvent predict sigma S x a).indicator (fun _ => (1 : ℝ)) v * laplaceSign (v.1 a)
    ∂insertedExperimentLaw r D K

theorem integrable_experiment_beta (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) :
    Integrable (fun v => (experimentActionEvent predict sigma S x a).indicator (fun _ => (1 : ℝ)) v * laplaceSign (v.1 a))
      (insertedExperimentLaw r D K) := by
  have hE := measurable_experimentActionEvent predict sigma S x a
  have hm : Measurable (fun v => (experimentActionEvent predict sigma S x a).indicator
      (fun _ => (1 : ℝ)) v * laplaceSign (v.1 a)) := (measurable_const.indicator hE).mul
    (measurable_laplaceSign.comp ((measurable_pi_apply a).comp measurable_fst))
  apply Integrable.of_bound hm.aestronglyMeasurable 1
  filter_upwards [] with v
  by_cases h : v ∈ experimentActionEvent predict sigma S x a <;>
    simp [h, Real.norm_eq_abs, abs_laplaceSign]

theorem experimentBeta_eq_thresholdDensity (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin (n + 1)) (sigma : X × Fin (n + 1) → ℝ) (S : P → ℝ)
    (x : X) (a : Fin (n + 1)) (hsigma : 0 < sigma (x, a))
    (hE : (actionPolicyGroup predict x a).Nonempty) (hEc : (actionPolicyGroup predict x a)ᶜ.Nonempty)
    (s : ℝ) :
    experimentBeta r D predict sigma (actionPenaltyScore predict S x a s) x a =
      ∫ v, realLaplaceDensity (experimentThreshold predict sigma S x a hE hEc v + s / sigma (x, a))
        ∂experimentRemainderLaw r D n := by
  classical
  unfold experimentBeta
  rw [← (restoreExperimentEquiv_measurePreserving r D a).integral_comp'
    (fun v => (experimentActionEvent predict sigma (actionPenaltyScore predict S x a s) x a).indicator
      (fun _ => (1 : ℝ)) v * laplaceSign (v.1 a))]
  calc
    _ = ∫ v : ((Fin n → ℝ) × (ℕ × (ℕ → X × (Fin (n + 1) → ℝ)))) × ℝ,
        (if experimentThreshold predict sigma S x a hE hEc v.1 + s / sigma (x, a) < v.2
          then laplaceSign v.2 else 0) ∂(experimentRemainderLaw r D n).prod realLaplace := by
      apply integral_congr_ae
      filter_upwards [ae_restored_experimentIndicator r D predict sigma S x a hsigma hE hEc s] with v hv
      rw [hv]
      simp only [restoreExperimentEquiv_apply, Fin.insertNth_apply_same]
      unfold thresholdSlope
      simp only [threshold_positive_iff _ _ _ _ hsigma]
      split <;> simp_all
    _ = _ := integral_random_thresholdSign _ _ (measurable_experimentThreshold predict sigma S x a hE hEc) _ _

theorem thresholdCurvature_eq_experimentBeta (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin (n + 1)) (sigma : X × Fin (n + 1) → ℝ) (S : P → ℝ)
    (x : X) (a : Fin (n + 1)) (hsigma : 0 < sigma (x, a))
    (hE : (actionPolicyGroup predict x a).Nonempty) (hEc : (actionPolicyGroup predict x a)ᶜ.Nonempty) :
    thresholdCurvature (experimentRemainderLaw r D n) (experimentThreshold predict sigma S x a hE hEc)
      (sigma (x, a)) 0 = experimentBeta r D predict sigma S x a / sigma (x, a) := by
  have h := experimentBeta_eq_thresholdDensity r D predict sigma S x a hsigma hE hEc 0
  rw [actionPenaltyScore_zero] at h
  simp only [zero_div, add_zero] at h
  unfold thresholdCurvature
  simp only [zero_div, add_zero]
  rw [h]

end

end PoissonAudit
