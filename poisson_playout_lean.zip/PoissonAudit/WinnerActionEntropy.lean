module

public import PoissonAudit.EventInformationCharge

public section

open MeasureTheory InformationTheory
open scoped BigOperators ENNReal

namespace PoissonAudit

noncomputable section

@[expose] def winnerActionEntropy {U V P : Type*} [MeasurableSpace U] [MeasurableSpace V]
    [Fintype P] {K : ℕ} (mu : Measure U) (nu : Measure V) (W : U × V → P)
    (pick : P → Fin K) (a : Fin K) : ℝ :=
  ∑ p, if pick p = a then eventInformationCharge mu nu (outcomeEvent W p) else 0

theorem winnerActionEntropy_nonneg {U V P : Type*} [MeasurableSpace U] [MeasurableSpace V]
    [Fintype P] {K : ℕ} (mu : Measure U) (nu : Measure V) (W : U × V → P)
    (pick : P → Fin K) (a : Fin K) : 0 ≤ winnerActionEntropy mu nu W pick a := by
  apply Finset.sum_nonneg
  intro p _
  split
  · exact eventInformationCharge_nonneg _ _ _
  · exact le_refl 0

theorem sum_winnerActionEntropy {U V P : Type*} [MeasurableSpace U] [MeasurableSpace V]
    [MeasurableSpace P] [MeasurableSingletonClass P] [Fintype P] [Nonempty P]
    {K : ℕ} (mu : Measure U) (nu : Measure V) [IsProbabilityMeasure mu] [IsProbabilityMeasure nu]
    (W : U × V → P) (hW : Measurable W) (pick : P → Fin K) :
    (∑ a, winnerActionEntropy mu nu W pick a) = (firstBlockInformation mu nu W).toReal := by
  rw [firstBlockInformation_toReal mu nu W hW]
  unfold winnerActionEntropy
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro p _
  simp

theorem winnerActionEntropy_le_log_card {U V P : Type*} [MeasurableSpace U] [MeasurableSpace V]
    [MeasurableSpace P] [MeasurableSingletonClass P] [Fintype P] [Nonempty P]
    {K : ℕ} (mu : Measure U) (nu : Measure V) [IsProbabilityMeasure mu] [IsProbabilityMeasure nu]
    (W : U × V → P) (hW : Measurable W) (pick : P → Fin K) (a : Fin K) :
    winnerActionEntropy mu nu W pick a ≤ Real.log (Fintype.card P) := by
  have hsum := Finset.single_le_sum (f := fun a => winnerActionEntropy mu nu W pick a)
    (fun a _ => winnerActionEntropy_nonneg mu nu W pick a) (Finset.mem_univ a)
  rw [sum_winnerActionEntropy mu nu W hW pick] at hsum
  have hbudget := ENNReal.toReal_mono ENNReal.ofReal_ne_top (firstBlockInformation_le_log_card mu nu W hW)
  have hlog : 0 ≤ Real.log (Fintype.card P : ℝ) := Real.log_nonneg (by
    exact_mod_cast Nat.succ_le_of_lt (Fintype.card_pos : 0 < Fintype.card P))
  rw [ENNReal.toReal_ofReal hlog] at hbudget
  exact hsum.trans hbudget

theorem sum_variational_bound {P : Type*} (E : Finset P) (alpha p D : P → ℝ)
    (t C : ℝ) (ht : 0 ≤ t) (hvar : ∀ pi ∈ E, t * |alpha pi| ≤ D pi + C * p pi) :
    t * |∑ pi ∈ E, alpha pi| ≤ (∑ pi ∈ E, D pi) + C * ∑ pi ∈ E, p pi := by
  calc
    _ ≤ t * ∑ pi ∈ E, |alpha pi| := mul_le_mul_of_nonneg_left (Finset.abs_sum_le_sum_abs _ _) ht
    _ = ∑ pi ∈ E, t * |alpha pi| := Finset.mul_sum _ _ _
    _ ≤ ∑ pi ∈ E, (D pi + C * p pi) := Finset.sum_le_sum hvar
    _ = _ := by rw [Finset.sum_add_distrib, Finset.mul_sum]

theorem integral_variational_bound {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) (alpha p D : Omega → ℝ)
    (ha : Integrable alpha mu) (hp : Integrable p mu) (hD : Integrable D mu)
    (t C : ℝ) (ht : 0 ≤ t) (hvar : ∀ omega, t * |alpha omega| ≤ D omega + C * p omega) :
    t * |∫ omega, alpha omega ∂mu| ≤ (∫ omega, D omega ∂mu) + C * ∫ omega, p omega ∂mu := by
  calc
    _ ≤ t * ∫ omega, |alpha omega| ∂mu :=
      mul_le_mul_of_nonneg_left abs_integral_le_integral_abs ht
    _ = ∫ omega, t * |alpha omega| ∂mu := (integral_const_mul _ _).symm
    _ ≤ ∫ omega, D omega + C * p omega ∂mu := integral_mono (ha.abs.const_mul t) (hD.add (hp.const_mul C)) hvar
    _ = _ := by rw [integral_add hD (hp.const_mul C), integral_const_mul]

end

end PoissonAudit
