module

public import PoissonAudit.WinnerActionEntropy

public section

open MeasureTheory Set
open scoped ENNReal BigOperators

namespace PoissonAudit

noncomputable section

variable {V P : Type*} [MeasurableSpace V] {K : ℕ}

theorem integrable_event_coordinate_observable (nu : Measure V) [IsProbabilityMeasure nu]
    (E : Set ((Fin K → ℝ) × V)) (hE : MeasurableSet E) (a : Fin K)
    (g : ℝ → ℝ) (hg : Integrable g realLaplace) :
    Integrable (fun v => E.indicator (fun _ => (1 : ℝ)) v * g (v.1 a)) ((laplaceMeasure K).prod nu) := by
  classical
  have hgi : Integrable (fun v : (Fin K → ℝ) × V => g (v.1 a)) ((laplaceMeasure K).prod nu) := by
    simpa only [mul_one] using (integrable_laplace_coordinate_comp K a g hg).mul_prod
      (integrable_const (1 : ℝ) (μ := nu))
  convert! hgi.indicator hE using 1
  funext v
  by_cases hv : v ∈ E <;> simp [hv]

theorem eventChannel_moment_eq_joint (nu : Measure V) [IsProbabilityMeasure nu]
    (E : Set ((Fin K → ℝ) × V)) (hE : MeasurableSet E) (a : Fin K)
    (g : ℝ → ℝ) (hg : Integrable g realLaplace) :
    (∫ z, eventChannel nu E z * g (z a) ∂laplaceMeasure K) =
      ∫ v, E.indicator (fun _ => (1 : ℝ)) v * g (v.1 a) ∂(laplaceMeasure K).prod nu := by
  rw [integral_prod _ (integrable_event_coordinate_observable nu E hE a g hg)]
  apply integral_congr_ae
  filter_upwards [] with z
  rw [eventChannel_eq_integral_indicator nu E hE, ← integral_mul_const]

variable [Fintype P]

@[expose] def winnerGroupMoment (nu : Measure V) (W : (Fin K → ℝ) × V → P)
    (pick : P → Fin K) (a : Fin K) (g : ℝ → ℝ) : ℝ :=
  ∑ p, if pick p = a then ∫ z, eventChannel nu (outcomeEvent W p) z * g (z a) ∂laplaceMeasure K else 0

@[expose] def winnerGroupMass (nu : Measure V) (W : (Fin K → ℝ) × V → P)
    (pick : P → Fin K) (a : Fin K) : ℝ :=
  ∑ p, if pick p = a then outcomeMass ((laplaceMeasure K).prod nu) W p else 0

variable [MeasurableSpace P] [MeasurableSingletonClass P]

theorem winnerGroupMoment_one (nu : Measure V) [IsProbabilityMeasure nu]
    (W : (Fin K → ℝ) × V → P) (hW : Measurable W) (pick : P → Fin K) (a : Fin K) :
    winnerGroupMoment nu W pick a (fun _ => 1) = winnerGroupMass nu W pick a := by
  unfold winnerGroupMoment winnerGroupMass
  apply Finset.sum_congr rfl
  intro p _
  by_cases hp : pick p = a
  · simp only [hp, ite_true, mul_one]
    exact integral_eventChannel _ nu _ (hW (measurableSet_singleton p))
  · simp [hp]

theorem winnerGroupMoment_variational (nu : Measure V) [IsProbabilityMeasure nu]
    (W : (Fin K → ℝ) × V → P) (hW : Measurable W) (pick : P → Fin K) (a : Fin K) :
    (∀ t : ℝ, 0 < t → t ≤ 1 / 2 →
      t * |winnerGroupMoment nu W pick a (fun z => z)| ≤
        winnerActionEntropy (laplaceMeasure K) nu W pick a + (4 / 3 : ℝ) * t ^ 2 * winnerGroupMass nu W pick a) ∧
    (∀ t : ℝ, 0 < t →
      t * |winnerGroupMoment nu W pick a laplaceSign| ≤
        winnerActionEntropy (laplaceMeasure K) nu W pick a + (t ^ 2 / 2) * winnerGroupMass nu W pick a) := by
  classical
  let E := Finset.univ.filter (fun p => pick p = a)
  have hmean (g : ℝ → ℝ) : winnerGroupMoment nu W pick a g =
      ∑ p ∈ E, ∫ z, eventChannel nu (outcomeEvent W p) z * g (z a) ∂laplaceMeasure K := by
    simp [winnerGroupMoment, E, Finset.sum_filter]
  have hmass : winnerGroupMass nu W pick a =
      ∑ p ∈ E, ((laplaceMeasure K).prod nu (outcomeEvent W p)).toReal := by
    simp [winnerGroupMass, outcomeMass, E, Finset.sum_filter]
  have hcharge : winnerActionEntropy (laplaceMeasure K) nu W pick a =
      ∑ p ∈ E, eventInformationCharge (laplaceMeasure K) nu (outcomeEvent W p) := by
    simp [winnerActionEntropy, E, Finset.sum_filter]
  constructor
  · intro t ht ht1
    rw [hmean, hmass, hcharge]
    apply sum_variational_bound _ _ _ _ t ((4 / 3 : ℝ) * t ^ 2) ht.le
    intro p _
    exact (laplace_event_weighted_variational K a nu (outcomeEvent W p) (hW (measurableSet_singleton p))).1 t ht ht1
  · intro t ht
    rw [hmean, hmass, hcharge]
    apply sum_variational_bound _ _ _ _ t (t ^ 2 / 2) ht.le
    intro p _
    exact (laplace_event_weighted_variational K a nu (outcomeEvent W p) (hW (measurableSet_singleton p))).2 t ht

end

end PoissonAudit
