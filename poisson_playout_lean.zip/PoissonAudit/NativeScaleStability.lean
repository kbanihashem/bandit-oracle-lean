module
public import PoissonAudit.NativeConditionalScaleStability
public import PoissonAudit.NativeActionEntropy
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section

theorem sum_abs_integral_difference {Omega A : Type*} [MeasurableSpace Omega] [Fintype A]
    (mu : Measure Omega) (f g : A → Omega → ℝ) (hf : ∀ a, Integrable (f a) mu) (hg : ∀ a, Integrable (g a) mu) :
    (∑ a, |(∫ z, f a z ∂mu) - (∫ z, g a z ∂mu)|) ≤ ∫ z, ∑ a, |f a z - g a z| ∂mu := by
  rw [integral_finsetSum (f := fun (a : A) (z : Omega) => |f a z - g a z|) _ (fun a _ => ((hf a).sub (hg a)).abs)]
  apply Finset.sum_le_sum
  intro a _
  rw [← integral_sub (hf a) (hg a)]
  exact abs_integral_le_integral_abs

@[expose] def scaleActionDifference {X : Type*} {K : ℕ} (sigma tau : X × Fin K → ℝ) (x : X) : ℝ :=
  ∑ a, |sigma (x, a) - tau (x, a)|

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem native_scale_stability_at_context (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma tau : X × Fin K → ℝ) (S : P → ℝ)
    (hsigma : ∀ j, 1 ≤ sigma j) (htau : ∀ j, 1 ≤ tau j) (x : X) :
    (∑ a, |experimentProbability r D predict sigma S x a - experimentProbability r D predict tau S x a|) ≤
      2 * (scaleActionDifference sigma tau x + (r : ℝ) * ∫ y, scaleActionDifference sigma tau y ∂D) := by
  let mu := markedPoolLaw r D
  let g := scaleActionDifference sigma tau
  let f := fun a => contextPrefixField (locationActionMoment predict sigma S x a (fun _ => 1))
  let h := fun a => contextPrefixField (locationActionMoment predict tau S x a (fun _ => 1))
  have hfi (a) : Integrable (f a) mu := integrable_locationActionMoment_field r D predict sigma S x a _ measurable_const (integrable_const 1)
  have hhi (a) : Integrable (h a) mu := integrable_locationActionMoment_field r D predict tau S x a _ measurable_const (integrable_const 1)
  have hfe (a) : (∫ pool, f a pool ∂mu) = experimentProbability r D predict sigma S x a := by
    rw [integral_locationActionMoment_field r D predict sigma S x a _ measurable_const (integrable_const 1), experimentMoment_one]
  have hhe (a) : (∫ pool, h a pool ∂mu) = experimentProbability r D predict tau S x a := by
    rw [integral_locationActionMoment_field r D predict tau S x a _ measurable_const (integrable_const 1), experimentMoment_one]
  have hmix := sum_abs_integral_difference mu f h hfi hhi
  simp only [hfe, hhe] at hmix
  have hpool : Integrable (poolSum g) mu := integrable_poolSum r D g (measurable_of_finite _) Integrable.of_finite
  have hbound (pool) : (∑ a, |f a pool - h a pool|) ≤ 2 * (g x + poolSum g pool) :=
    native_conditional_scale_stability predict sigma tau S hsigma htau x (poolPrefix pool.1 pool.2)
  have hint := integral_mono (integrable_finsetSum _ (fun a _ => ((hfi a).sub (hhi a)).abs))
    (((integrable_const (g x)).add hpool).const_mul 2) hbound
  change (∫ pool, ∑ a, |f a pool - h a pool| ∂mu) ≤ ∫ pool, 2 * (g x + poolSum g pool) ∂mu at hint
  rw [integral_const_mul, integral_add (integrable_const _) hpool, integral_const, probReal_univ, one_smul,
    integral_poolSum r D g (measurable_of_finite _) Integrable.of_finite] at hint
  exact hmix.trans hint

theorem native_mean_scale_stability (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma tau : X × Fin K → ℝ) (S : P → ℝ)
    (hsigma : ∀ j, 1 ≤ sigma j) (htau : ∀ j, 1 ≤ tau j) :
    (∫ x, ∑ a, |experimentProbability r D predict sigma S x a - experimentProbability r D predict tau S x a| ∂D) ≤
      2 * ((r : ℝ) + 1) * ∫ x, scaleActionDifference sigma tau x ∂D := by
  have h := integral_mono (μ := D) Integrable.of_finite Integrable.of_finite
    (fun x => native_scale_stability_at_context r D predict sigma tau S hsigma htau x)
  rw [integral_const_mul, integral_add Integrable.of_finite (integrable_const _), integral_const, probReal_univ, one_smul] at h
  convert! h using 1 <;> ring
end
end PoissonAudit
