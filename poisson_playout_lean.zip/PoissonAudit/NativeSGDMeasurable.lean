module
public import PoissonAudit.NativeSGDOneStep
public section
open MeasureTheory Set
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] abbrev NativeNoise (X : Type*) (K : ℕ) :=
  (Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ)))

@[expose] abbrev NativeScaleBox (X : Type*) (K : ℕ) (B : ℝ) :=
  {sigma : X × Fin K → ℝ // sigma ∈ scaleBox (X × Fin K) B}

instance nativeScaleBox_compactSpace (B : ℝ) : CompactSpace (NativeScaleBox X K B) :=
  isCompact_iff_compactSpace.mp isCompact_Icc

@[expose] def nativeUnitScale (B : ℝ) (hB : 1 ≤ B) : NativeScaleBox X K B :=
  ⟨1, fun _ => le_rfl, fun _ => hB⟩

theorem measurable_joint_experimentScore (predict : P → X → Fin K) (S : P → ℝ) (x : X) (p : P) :
    Measurable (fun v : (X × Fin K → ℝ) × NativeNoise X K => experimentScore predict v.1 S x v.2 p) := by
  change Measurable (fun v : (X × Fin K → ℝ) × NativeNoise X K =>
    S p + v.1 (x, predict p x) * v.2.1 (predict p x) +
      ∑ j, v.1 j * poissonCoefficient predict v.2.2 p j)
  have hc (j : X × Fin K) : Measurable (fun v : (X × Fin K → ℝ) × NativeNoise X K =>
      poissonCoefficient predict v.2.2 p j) :=
    (measurable_poolSum _ (measurable_singleMarkCoefficient predict p j)).comp (measurable_snd.comp measurable_snd)
  apply (measurable_const.add (((measurable_pi_apply (x, predict p x)).comp measurable_fst).mul
    ((measurable_pi_apply (predict p x)).comp (measurable_fst.comp measurable_snd)))).add
  exact Finset.measurable_sum _ (fun j _ => ((measurable_pi_apply j).comp measurable_fst).mul (hc j))

theorem measurable_joint_experimentWinner (predict : P → X → Fin K) (S : P → ℝ) (x : X) :
    Measurable (fun v : (X × Fin K → ℝ) × NativeNoise X K => experimentWinner predict v.1 S x v.2) :=
  measurable_winner (fun (p : P) (v : (X × Fin K → ℝ) × NativeNoise X K) => experimentScore predict v.1 S x v.2 p)
    (measurable_joint_experimentScore predict S x)

theorem measurable_joint_nativeSampledGradient (r : NNReal) (predict : P → X → Fin K)
    (S : P → ℝ) (lam : ℝ) (j : X × Fin K) :
    Measurable (fun v : (X × Fin K → ℝ) × NativeNoise X K => nativeSampledGradient r predict v.1 S lam v.2 j) := by
  let E : Set ((X × Fin K → ℝ) × NativeNoise X K) :=
    {v | predict (experimentWinner predict v.1 S j.1 v.2) j.1 = j.2}
  have hE : MeasurableSet E :=
    ((measurable_of_finite (fun p => predict p j.1)).comp
      (measurable_joint_experimentWinner predict S j.1)) (measurableSet_singleton j.2)
  have h : Measurable (fun v : (X × Fin K → ℝ) × NativeNoise X K =>
      (r : ℝ) * (E.indicator (fun _ => (1 : ℝ)) v * v.2.1 j.2) - lam / v.1 j) :=
    (measurable_const.mul ((measurable_const.indicator hE).mul
      ((measurable_pi_apply j.2).comp (measurable_fst.comp measurable_snd)))).sub
        (measurable_const.div ((measurable_pi_apply j).comp measurable_fst))
  convert! h using 1

theorem measurable_joint_nativeSGDNext (r : NNReal) (predict : P → X → Fin K)
    (S : P → ℝ) (lam B eta : ℝ) :
    Measurable (fun v : (X × Fin K → ℝ) × NativeNoise X K => nativeSGDNext r predict S lam B eta v.1 v.2) := by
  apply Measurable.of_eval
  intro j
  have hclip : Continuous (boxClip B) := by unfold boxClip; fun_prop
  exact hclip.measurable.comp (((measurable_pi_apply j).comp measurable_fst).sub
    ((measurable_joint_nativeSampledGradient r predict S lam j).const_mul eta))

@[expose] def nativeBoxObjective (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B : ℝ) (sigma : NativeScaleBox X K B) : ℝ :=
  scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
    (fun j => (D {j.1}).toReal) lam B sigma.val

theorem continuous_nativeBoxObjective (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B : ℝ) (hB : 1 ≤ B) :
    Continuous (nativeBoxObjective r D predict S lam B) := by
  have h := (continuousOn_affinePoolPotential (markedPoolLaw r (contextLaplaceLaw D K)) S
    (poissonCoefficient predict) (integrable_poissonCoefficient r D predict) B hB).add
      (continuousOn_scalePenalty (fun j : X × Fin K => (D {j.1}).toReal) lam B hB)
  exact continuousOn_iff_continuous_restrict.mp h
end
end PoissonAudit
