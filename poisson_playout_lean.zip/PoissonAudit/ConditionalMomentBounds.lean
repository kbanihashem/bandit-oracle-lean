module

public import PoissonAudit.ContextSplitMoment

public section

open MeasureTheory Set

namespace PoissonAudit

noncomputable section

variable {V P : Type*} [MeasurableSpace V] {K : ℕ}
    [Fintype P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem winnerGroupMoment_abs_bound (nu : Measure V) [IsProbabilityMeasure nu]
    (W : (Fin K → ℝ) × V → P) (hW : Measurable W) (pick : P → Fin K) (a : Fin K)
    (g : ℝ → ℝ) (hgm : Measurable g) (hgi : Integrable g realLaplace) :
    |winnerGroupMoment nu W pick a g| ≤ ∫ z, |g z| ∂realLaplace := by
  have hcoord : Integrable (fun v : (Fin K → ℝ) × V => |g (v.1 a)|) ((laplaceMeasure K).prod nu) := by
    simpa only [mul_one] using (integrable_laplace_coordinate_comp K a g hgi).abs.mul_prod
      (integrable_const (1 : ℝ) (μ := nu))
  rw [winnerGroupMoment_eq_joint nu W hW pick a g hgi]
  calc
    _ ≤ ∫ v, |if pick (W v) = a then g (v.1 a) else 0| ∂(laplaceMeasure K).prod nu :=
      abs_integral_le_integral_abs
    _ ≤ ∫ v, |g (v.1 a)| ∂(laplaceMeasure K).prod nu := by
      apply integral_mono (integrable_selected_winner_observable nu W hW pick a g hgi).abs hcoord
      intro v
      by_cases h : pick (W v) = a <;> simp [h, abs_nonneg]
    _ = ∫ z, |g (z a)| ∂laplaceMeasure K := by
      rw [integral_prod _ hcoord]
      simp only [integral_const, probReal_univ, one_smul]
    _ = _ := laplace_coordinate_integral K a _ (continuous_abs.measurable.comp hgm)

variable {X : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X]
    [Nonempty P] [LinearOrder P]

theorem locationActionMoment_abs_bound (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (g : ℝ → ℝ) (hgm : Measurable g) (hgi : Integrable g realLaplace)
    (n : ℕ) (C : Fin n → X) :
    |locationActionMoment predict sigma S x a g n C| ≤ ∫ z, |g z| ∂realLaplace :=
  winnerGroupMoment_abs_bound _ _ (measurable_insertedLocationWinner predict sigma S x C) _ a g hgm hgi

end

end PoissonAudit
