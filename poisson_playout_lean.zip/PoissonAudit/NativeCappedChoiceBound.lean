module
public import PoissonAudit.NativeCappedChoiceLaw
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section

@[expose] def choiceProbability (K : ℕ) (gamma : ℝ) (m : ℕ) (choice : EmpiricalChoice K m) (a : Fin K) : ℝ :=
  match choice with
  | none => 1 / K
  | some u => empiricalMixture K gamma m u a

@[expose] def choiceOverflow {K m : ℕ} (choice : EmpiricalChoice K m) : ℝ :=
  match choice with
  | none => 1
  | some _ => 0

theorem choiceProbability_sum {K : ℕ} (hK : 0 < K) (gamma : ℝ) (m : ℕ) (hm : 0 < m) (choice : EmpiricalChoice K m) :
    (∑ a, choiceProbability K gamma m choice a) = 1 := by
  cases choice with
  | none => simp [choiceProbability, Nat.ne_of_gt hK]
  | some u => exact empiricalMixture_sum hK gamma m hm u

theorem choiceProbability_floor {K : ℕ} (gamma : ℝ) (hg1 : gamma ≤ 1) (m : ℕ) (hm : 0 < m)
    (choice : EmpiricalChoice K m) (a : Fin K) : gamma / K ≤ choiceProbability K gamma m choice a := by
  cases choice with
  | none => exact div_le_div_of_nonneg_right hg1 (Nat.cast_nonneg K)
  | some u => exact empiricalMixture_floor gamma hg1 m hm u a

theorem choiceProbability_nonneg {K : ℕ} (gamma : ℝ) (hg0 : 0 ≤ gamma) (hg1 : gamma ≤ 1) (m : ℕ) (hm : 0 < m)
    (choice : EmpiricalChoice K m) (a : Fin K) : 0 ≤ choiceProbability K gamma m choice a :=
  (div_nonneg hg0 (Nat.cast_nonneg K)).trans (choiceProbability_floor gamma hg1 m hm choice a)

theorem choiceProbability_pos {K : ℕ} (hK : 0 < K) (gamma : ℝ) (hg0 : 0 < gamma) (hg1 : gamma ≤ 1) (m : ℕ) (hm : 0 < m)
    (choice : EmpiricalChoice K m) (a : Fin K) : 0 < choiceProbability K gamma m choice a :=
  (div_pos hg0 (by exact_mod_cast hK)).trans_le (choiceProbability_floor gamma hg1 m hm choice a)

theorem choiceOverflow_capped {K m : ℕ} (b : Bool) (u : Fin m → Fin K × Bool) :
    choiceOverflow (cappedOutcomeChoice (b, u)) = boolStatistic (b || trialAnyOverflow u) := by
  cases h : b || trialAnyOverflow u <;> simp [cappedOutcomeChoice, h, choiceOverflow, boolStatistic]

theorem boolStatistic_or_le (b c : Bool) : boolStatistic (b || c) ≤ boolStatistic b + boolStatistic c := by
  cases b <;> cases c <;> norm_num [boolStatistic]

theorem capped_choice_error {K m : ℕ} (hK : 0 < K) (gamma : ℝ) (ref : Fin K → ℝ)
    (href : ∀ a, 0 ≤ ref a) (hres : ∑ a, ref a = 1) (b : Bool) (u : Fin m → Fin K × Bool) :
    (∑ a, |choiceProbability K gamma m (cappedOutcomeChoice (b, u)) a - ref a|) ≤
      (∑ a, |empiricalMixture K gamma m (fun i => (u i).1) a - ref a|) +
        2 * (boolStatistic b + boolStatistic (trialAnyOverflow u)) := by
  have hnon : 0 ≤ ∑ a, |empiricalMixture K gamma m (fun i => (u i).1) a - ref a| := Finset.sum_nonneg fun a _ => abs_nonneg _
  cases h : b || trialAnyOverflow u with
  | false =>
    have hb : b = false := by cases b <;> simp_all
    have hu : trialAnyOverflow u = false := by simpa [hb] using h
    simp [cappedOutcomeChoice, h, choiceProbability, boolStatistic, hb, hu]
  | true =>
    have hor := boolStatistic_or_le b (trialAnyOverflow u)
    rw [h] at hor
    have huni : (∑ a : Fin K, (1 : ℝ) / K) = 1 := by simp [Nat.ne_of_gt hK]
    have htwo := finite_probability_l1_le_two (fun _ : Fin K => (1 : ℝ) / K) ref
      (fun _ => div_nonneg zero_le_one (Nat.cast_nonneg K)) href huni hres
    simp only [cappedOutcomeChoice, h, Bool.true_eq, ite_true, choiceProbability]
    change (∑ a, |1 / (K : ℝ) - ref a|) ≤ _
    change (1 : ℝ) ≤ boolStatistic b + boolStatistic (trialAnyOverflow u) at hor
    linarith

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem nativeCappedKernel_test_integrable (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ) (hB : 1 ≤ B) (cap J m : ℕ) (x : X)
    (f : EmpiricalChoice K m → ℝ) :
    Integrable (fun state : NativeFlaggedState X K B =>
      ∫ u, f (cappedOutcomeChoice (state.2, u)) ∂iidPool (nativeEnrichedLaw r D predict state.1.2.val S x cap).toMeasure m)
      (nativeFlaggedStateLaw r D predict S lam B eta hB cap J) := by
  let mu := nativeFlaggedStateLaw r D predict S lam B eta hB cap J
  let q := nativeCappedKernel r D predict S B x cap m
  have hi (o : CappedRawOutcome K m) : Integrable (fun state => q state o * f (cappedOutcomeChoice o)) mu :=
    (integrable_finiteKernelWeight mu q (nativeCappedKernel_nonneg r D predict S B x cap m)
      (nativeCappedKernel_sum r D predict S B x cap m) (measurable_nativeCappedKernel r D predict S B x cap m) o).mul_const _
  have hall := integrable_finsetSum Finset.univ (fun o _ => hi o)
  convert! hall using 1
  funext state
  rw [nativeCappedKernel_test_sum]
  exact integral_iid_actionPMF (nativeEnrichedProbability r D predict state.1.2.val S x cap)
    (nativeEnrichedProbability_nonneg r D predict state.1.2.val S x cap)
    (nativeEnrichedProbability_sum r D predict state.1.2.val S x cap) m (fun u => f (cappedOutcomeChoice (state.2, u)))

theorem native_capped_overflow_budget (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ) (hB : 1 ≤ B) (cap J m : ℕ) (hc : 0 < cap) (x : X) :
    (∫ choice, choiceOverflow choice ∂(nativeCappedChoiceLaw r D predict S lam B eta hB cap J m x).toMeasure) ≤
      (J + m : ℕ) * ((r : ℝ) / cap) := by
  let mu := nativeFlaggedStateLaw r D predict S lam B eta hB cap J
  have hp (state : NativeFlaggedState X K B) :
      (∫ u, choiceOverflow (cappedOutcomeChoice (state.2, u))
        ∂iidPool (nativeEnrichedLaw r D predict state.1.2.val S x cap).toMeasure m) ≤
          boolStatistic state.2 + m * ((r : ℝ) / cap) := by
    have h := integral_mono (μ := iidPool (nativeEnrichedLaw r D predict state.1.2.val S x cap).toMeasure m)
      Integrable.of_finite Integrable.of_finite
      (fun u => show choiceOverflow (cappedOutcomeChoice (state.2, u)) ≤ boolStatistic state.2 + boolStatistic (trialAnyOverflow u) by
        rw [choiceOverflow_capped]; exact boolStatistic_or_le _ _)
    rw [integral_add (integrable_const _) Integrable.of_finite, integral_const, probReal_univ, one_smul] at h
    exact h.trans (add_le_add_right (native_enriched_trial_overflow_budget r D predict state.1.2.val S x cap m hc) _)
  rw [integral_nativeCappedChoiceLaw]
  have hi := integral_mono (nativeCappedKernel_test_integrable r D predict S lam B eta hB cap J m x choiceOverflow)
    ((integrable_flagStatistic B mu).add (integrable_const _)) hp
  change _ ≤ ∫ state, boolStatistic state.2 + m * ((r : ℝ) / cap) ∂mu at hi
  rw [integral_add (integrable_flagStatistic B mu) (integrable_const _), integral_const, probReal_univ, one_smul] at hi
  have hb := native_construction_overflow_budget r D predict S lam B eta hB cap hc J
  simp only [Nat.cast_add]
  change (∫ state, boolStatistic state.2 ∂mu) ≤ _ at hb
  nlinarith
end
end PoissonAudit
