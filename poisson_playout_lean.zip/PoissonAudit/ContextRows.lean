module
public import PoissonAudit.ContextSchedule
public import PoissonAudit.MarkedPoisson
public import Mathlib.Probability.ConditionalProbability
public section

open MeasureTheory Set ProbabilityTheory
open scoped ENNReal BigOperators

namespace PoissonAudit
noncomputable section

variable {X Y : Type*} [MeasurableSpace X] [MeasurableSpace Y] [Fintype Y] [MeasurableSingletonClass Y]

@[expose] def contextFiber (D : Measure X) (g : X → Y) (y : Y) : Measure X :=
  if D (g ⁻¹' {y}) = 0 then D else ProbabilityTheory.cond D (g ⁻¹' {y})

instance contextFiber_prob (D : Measure X) [IsProbabilityMeasure D] (g : X → Y) (y : Y) :
    IsProbabilityMeasure (contextFiber D g y) := by
  unfold contextFiber
  split_ifs with h
  · infer_instance
  · exact cond_isProbabilityMeasure h

theorem contextFiber_weight (D : Measure X) [IsProbabilityMeasure D] (g : X → Y) (hg : Measurable g)
    (y : Y) : (D.map g) {y} • contextFiber D g y = D.restrict (g ⁻¹' {y}) := by
  rw [Measure.map_apply hg (measurableSet_singleton _)]
  unfold contextFiber
  split_ifs with h
  · simp [h, Measure.restrict_eq_zero.mpr h]
  · unfold ProbabilityTheory.cond
    rw [smul_smul, ENNReal.mul_inv_cancel h (measure_ne_top _ _), one_smul]

theorem contextFiber_joint (D : Measure X) [IsProbabilityMeasure D] (g : X → Y) (hg : Measurable g)
    (s : Set (Y × X)) (hs : MeasurableSet s) :
    ∑ y, contextFiber D g y (Prod.mk y ⁻¹' s) * (D.map g) {y} =
      D.map (fun x => (g x,x)) s := by
  classical
  have hm : Measurable (fun x => (g x,x)) := hg.prodMk measurable_id
  rw [Measure.map_apply hm hs]
  calc
    _ = ∑ y, (D.restrict (g ⁻¹' {y})) ((fun x => (g x,x)) ⁻¹' s) := by
      apply Finset.sum_congr rfl
      intro y _
      rw [mul_comm, ← smul_eq_mul, ← Measure.smul_apply, contextFiber_weight D g hg]
      rw [Measure.restrict_apply (measurable_prodMk_left hs), Measure.restrict_apply (hm hs)]
      congr 1
      ext x
      by_cases h : g x = y <;> simp [h]
    _ = D ((fun x => (g x,x)) ⁻¹' s) := by
      rw [← Measure.finsetSum_apply, sum_restrict_fibers D g hg]

@[expose] def rowLookup (T : ℕ) (z : (Fin T → Y → X) × (Fin T → Y)) : Fin T → Y × X :=
  fun t => (z.2 t,z.1 t (z.2 t))

theorem measurable_rowLookup (T : ℕ) : Measurable (rowLookup (X := X) (Y := Y) T) := by
  apply Measurable.of_eval
  intro t
  have h : Measurable (fun z : (Fin T → Y → X) × (Fin T → Y) => z.2 t) := (measurable_pi_apply t).comp measurable_snd
  apply h.prodMk
  let e : Y × (Y → X) → X := fun p => p.2 p.1
  have he : Measurable e := measurable_from_prod_countable_right (fun y => measurable_pi_apply y)
  exact he.comp (h.prodMk ((measurable_pi_apply t).comp measurable_fst))

theorem rowLookup_preserves_iid (D : Measure X) [IsProbabilityMeasure D] (g : X → Y) (hg : Measurable g)
    (T : ℕ) :
    MeasurePreserving (rowLookup (X := X) (Y := Y) T)
      ((iidPool (Measure.pi (contextFiber D g)) T).prod (iidPool (D.map g) T))
      (iidPool (D.map (fun x => (g x,x))) T) := by
  classical
  let R := Measure.pi (contextFiber D g)
  haveI : IsProbabilityMeasure (D.map g) := (Measure.isProbabilityMeasure_map_iff hg.aemeasurable).mpr inferInstance
  have hj : Measurable (fun x => (g x,x)) := hg.prodMk measurable_id
  haveI : IsProbabilityMeasure (D.map (fun x => (g x,x))) := (Measure.isProbabilityMeasure_map_iff hj.aemeasurable).mpr inferInstance
  refine ⟨measurable_rowLookup T, (Measure.pi_eq (fun s hs => ?_)).symm⟩
  rw [Measure.map_apply (measurable_rowLookup T) (MeasurableSet.univ_pi hs),
    Measure.prod_apply_symm ((measurable_rowLookup T) (MeasurableSet.univ_pi hs)), lintegral_fintype]
  have hrows (ys : Fin T → Y) :
      iidPool R T ((fun rows => rowLookup T (rows,ys)) ⁻¹' univ.pi s) =
      ∏ t, contextFiber D g (ys t) (Prod.mk (ys t) ⁻¹' s t) := by
    change Measure.pi (fun _ : Fin T => R) (univ.pi (fun t => (fun row : Y → X => (ys t,row (ys t))) ⁻¹' s t)) = _
    rw [Measure.pi_pi]
    apply Finset.prod_congr rfl
    intro t _
    have hp := measurePreserving_eval (contextFiber D g) (ys t)
    have hmap := congrArg (fun μ : Measure X => μ (Prod.mk (ys t) ⁻¹' s t)) hp.map_eq
    rw [Measure.map_apply hp.measurable (measurable_prodMk_left (hs t))] at hmap
    exact hmap
  have hW (ys : Fin T → Y) : iidPool (D.map g) T {ys} = ∏ t, D.map g {ys t} := Measure.pi_singleton _ _
  change (∑ ys, iidPool R T ((fun rows => rowLookup T (rows,ys)) ⁻¹' univ.pi s) * iidPool (D.map g) T {ys}) = _
  simp_rw [hrows, hW, ← Finset.prod_mul_distrib, ← contextFiber_joint D g hg _ (hs _)]
  exact (Fintype.prod_sum (fun (t : Fin T) (y : Y) => contextFiber D g y (Prod.mk y ⁻¹' s t) * D.map g {y})).symm

end
end PoissonAudit
