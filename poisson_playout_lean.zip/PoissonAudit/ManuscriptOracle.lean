module
public import PoissonAudit.ManuscriptResources
public import PoissonAudit.StorageAccounting
public import PoissonAudit.ProbabilityTableExecution
public import PoissonAudit.ValueOracleProtocol
public import PoissonAudit.FiniteInputDependency
public section
open MeasureTheory Set
namespace PoissonAudit
noncomputable section

theorem manuscript_winner {X P : Type*} [Fintype P] [Nonempty P] [LinearOrder P] {K : ℕ}
    (predict : P → X → Fin K) (oracle : List (CostExample X K) → ℝ)
    (ho : ∀ Q, oracle Q = treeBestScore (queryScore predict Q))
    (Q : List (CostExample X K)) (x : X) (v : Fin K → ℝ) (fallback : Fin K) :
    let val := fun a => oracle (boostedDesignatedQuery Q x v a)
    let a := valueOracleAction oracle fallback Q x v
    (∀ b, val b ≤ val a) ∧ (∀ b, val b = val a → a ≤ b) := by
  classical
  intro val a
  obtain ⟨hg,_⟩ := cost_sensitive_value_action predict Q x v oracle ho
  let base := oracle (Q ++ [(x,v)])
  have he : a = actionFromValueTable base val hg := dif_pos hg
  have ha : val a = base + 1 := he ▸ actionFromValueTable_spec base val hg
  constructor
  · intro b
    rw [ha]
    change oracle (boostedDesignatedQuery Q x v b) ≤ oracle (Q ++ [(x,v)]) + 1
    rw [ho,ho,queryScore_boosted]
    apply treeBestScore_le
    intro i
    unfold actionBoostScore
    split_ifs <;> linarith [score_le_treeBestScore (queryScore predict (Q ++ [(x,v)])) i]
  · intro b hb
    rw [he]
    apply Finset.min'_le
    simp [hb,ha]

theorem capped_waiting_time_budget (K cap J m : ℕ) (hk : 0 < K) :
    (J+m)*(cap+1) ≤ elementaryDrawBudget K cap J m := by
  unfold elementaryDrawBudget
  nlinarith only [Nat.mul_le_mul_right (cap+1) (Nat.mul_le_mul_right (J+m) (show 1 ≤ K from hk))]

theorem manuscript_oracle_round {X Y P : Type*} [MeasurableSpace X] [MeasurableSpace Y]
    [MeasurableSingletonClass Y] [Fintype Y] [Fintype P] [Nonempty P] [LinearOrder P]
    [MeasurableSpace P] [MeasurableSingletonClass P] {K : ℕ} (p : BanditParameters) (hB : 1 ≤ p.B)
    (f : X → Y) (hf : Measurable f) (D : Measure X) [IsProbabilityMeasure D]
    (predictX : P → X → Fin K) (predictY : P → Y → Fin K) (hp : ∀ a x, predictY a (f x) = predictX a x)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ)
    (ho : ∀ Q, (∀ i, oracle Q ≤ queryScore predictX Q i) ∧ ∃ i, oracle Q = queryScore predictX Q i)
    (fallback : Fin K) (x : X) (o : paperNativeFiniteOutcome K p.delta) :
    let J := paperIterations K p.r p.lam p.B p.eps
    let m := paperTrials K p.delta
    let cap := paperCap p.r (J+m) p.delta
    let eta := paperStep K p.r p.lam p.B p.eps
    let val := fun Q => -oracle (negateCostQuery Q)
    ((((nativeNoiseTapeLaw (K := K) p.r D J).prod (iidPool (insertedExperimentLaw p.r D K) m)).map
      (fun v => (executeArraySampler p.r p.lam p.B eta history val fallback cap J m v.1 v.2 x).choice)) {o.1}).toReal *
      vectorValues (executeProbabilityTable K p.gamma m o.1).1 o.2 =
      paperNativeFiniteOutcomeWeight p.r (D.map f) predictY p.lam p.B p.eps p.delta p.gamma hB
        (queryScore predictX history) (f x) o := by
  intro J m cap eta val
  haveI : IsProbabilityMeasure (D.map f) := (Measure.isProbabilityMeasure_map_iff hf.aemeasurable).mpr inferInstance
  simp only [(executeArraySampler_correct p.r p.lam p.B eta history val fallback cap J m _ _ x).1]
  rw [cappedOracleChoice_quotient_law f hf p.r D predictX predictY hp history val
    (maximizing_value_from_minimizing predictX oracle ho) fallback p.lam p.B eta hB cap J m x]
  rw [show queryScore predictY (mapCostQuery f history) = queryScore predictX history from
    funext (queryScore_context_map f predictX predictY hp history)]
  rw [PMF.toMeasure_apply_singleton _ _ (measurableSet_singleton _)]
  rw [executeProbabilityTable_values]
  apply congrArg (fun z : ℝ => z * choiceProbability K p.gamma m o.1 o.2)
  exact actionPMF_toReal _ _ _ o.1

@[expose] def manuscriptUpdate {X : Type*} {K m : ℕ} (gamma : ℝ) (history : List (CostExample X K))
    (x : X) (choice : EmpiricalChoice K m) (a : Fin K) (observed : ℝ) : List (CostExample X K) :=
  appendBanditObservation history x a (observed / vectorValues (executeProbabilityTable K gamma m choice).1 a)

theorem manuscript_scalar_feedback {X P : Type*} {K : ℕ} (predict : P → X → Fin K)
    (history : List (CostExample X K)) (x : X) (c : Fin K → ℝ) (delta gamma : ℝ)
    (o : paperNativeFiniteOutcome K delta) :
    queryScore predict (manuscriptUpdate gamma history x o.1 o.2 (c o.2)) =
      paperNativeFiniteOutcomeUpdate predict delta gamma (queryScore predict history) x c o := by
  rw [manuscriptUpdate,executeProbabilityTable_values,queryScore_appendBanditObservation]
  funext i
  simp only [paperNativeFiniteOutcomeUpdate, treeUpdatedScore, treeEstimatedPolicyLoss, actionPenaltyScore, actionSlope]
  split_ifs <;> ring

theorem manuscript_round_budget {X : Type*} {K : ℕ} (r : NNReal) (lam B eta gamma : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (T cap J m : ℕ) (hK : 0 < K) (ht : history.length ≤ T)
    (tape : NativeNoiseTape X K J) (trials : Fin m → NativeNoise X K) (x : X) :
    let run := executeArraySampler r lam B eta history oracle fallback cap J m tape trials x
    let update := (executeProbabilityTable K gamma m run.choice).2 + 4*K + K*history.length + 16
    run.internalWork + 4*queryCoefficientCount K run.queries + 4*elementaryDrawBudget K cap J m + update ≤
      onlineWorkBudget T K cap J m ∧
    run.allocatedWords + probabilityTableAllocation K m run.choice + 3*K + K*history.length + 16 ≤
      onlineWorkBudget T K cap J m := by
  intro run update
  have h := executeArraySampler_resource_certificate r lam B eta history oracle fallback T cap J m ht tape trials x
  change run.choice = _ ∧ _ ∧ _ ∧ queryCoefficientCount K run.queries ≤ _ ∧ run.internalWork ≤ _ ∧ _ at h
  have hq := executeProbabilityTable_work K gamma m run.choice
  have ha := executeProbabilityTable_allocation K gamma m run.choice
  have hh := Nat.mul_le_mul_left K ht
  have hs : 4*K + K*T + 16 ≤ 32*K*(T+1) := by nlinarith
  have hw : run.allocatedWords ≤ run.internalWork := executeArraySampler_allocation r lam B eta history oracle fallback cap J m tape trials x
  dsimp only [update,onlineWorkBudget]
  constructor <;> nlinarith only [h.2.2.2.1,h.2.2.2.2.1,hq,ha,hh,hs,hw]

end
end PoissonAudit
