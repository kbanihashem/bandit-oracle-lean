module
public import PoissonAudit.TranscriptRegret
public section
open MeasureTheory Set
namespace PoissonAudit
noncomputable section

@[expose] def feedbackLossList (P : Type*) (K T L : ℕ) : List (FiniteFeedbackContext P K T L → Fin K → ℝ) :=
  List.ofFn (fun t : Fin T => feedbackCost t)

theorem feedbackLossList_length (P : Type*) (K T L : ℕ) : (feedbackLossList P K T L).length = T := by simp [feedbackLossList]

@[expose] def feedbackContextList {X P : Type*} {K : ℕ} (predict : P → X → Fin K)
    (costs : List (X → Fin K → ℝ)) (L : ℕ) : X → FiniteFeedbackContext P K costs.length L :=
  feedbackContext predict (fun t => costs.get t) L

@[expose] def feedbackOriginalCost {X P : Type*} {K : ℕ} (costs : List (X → Fin K → ℝ)) (L : ℕ) :
    Fin (feedbackLossList P K costs.length L).length → X → Fin K → ℝ :=
  fun t => costs.get (Fin.cast (feedbackLossList_length P K costs.length L) t)

theorem feedbackLossList_factor {X P : Type*} {K : ℕ} (predict : P → X → Fin K)
    (costs : List (X → Fin K → ℝ)) (L : ℕ)
    (t : Fin (feedbackLossList P K costs.length L).length) (x : X) (a : Fin K) :
    (feedbackLossList P K costs.length L).get t (feedbackContextList predict costs L x) a =
      roundedLossValue L (feedbackOriginalCost (P := P) costs L t x a) := by
  have heq := List.get_ofFn (fun i : Fin costs.length =>
    (feedbackCost i : FiniteFeedbackContext P K costs.length L → Fin K → ℝ))
    (show Fin (List.ofFn (fun i : Fin costs.length =>
      (feedbackCost i : FiniteFeedbackContext P K costs.length L → Fin K → ℝ))).length from t)
  exact congrArg (fun c => c (feedbackContextList predict costs L x) a) heq

theorem feedbackLossList_nonneg (P : Type*) (K T L : ℕ) (hL : 0 < L)
    (c : FiniteFeedbackContext P K T L → Fin K → ℝ) (hc : c ∈ feedbackLossList P K T L) : ∀ y a, 0 ≤ c y a := by
  obtain ⟨t, rfl⟩ := List.mem_ofFn.mp hc
  exact fun y a => (feedbackCost_bounds hL t y a).1

theorem feedbackLossList_le_one (P : Type*) (K T L : ℕ) (hL : 0 < L)
    (c : FiniteFeedbackContext P K T L → Fin K → ℝ) (hc : c ∈ feedbackLossList P K T L) : ∀ y a, c y a ≤ 1 := by
  obtain ⟨t, rfl⟩ := List.mem_ofFn.mp hc
  exact fun y a => (feedbackCost_bounds hL t y a).2

theorem feedbackOriginalCost_mem {X P : Type*} {K : ℕ} (costs : List (X → Fin K → ℝ)) (L : ℕ)
    (t : Fin (feedbackLossList P K costs.length L).length) : feedbackOriginalCost (P := P) costs L t ∈ costs :=
  List.get_mem _ _

theorem measurable_feedbackContextList {X P : Type*} [MeasurableSpace X] [Fintype P] {K : ℕ}
    (predict : P → X → Fin K) (hp : ∀ p, Measurable (predict p)) (costs : List (X → Fin K → ℝ))
    (hc : ∀ c ∈ costs, ∀ a, Measurable (fun x => c x a)) (L : ℕ) : Measurable (feedbackContextList predict costs L) :=
  measurable_feedbackContext predict hp (fun t => costs.get t) (fun t a => hc _ (List.get_mem _ _) a) L
end
end PoissonAudit
