module

public import PoissonAudit.Poisson
public import Mathlib.MeasureTheory.Integral.Pi

public section

open MeasureTheory ProbabilityTheory
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {U : Type*} [MeasurableSpace U]

@[expose] def iidPool (mu : Measure U) (n : ℕ) : Measure (Fin n → U) :=
  Measure.pi fun _ => mu

instance iidPool_sigmaFinite (mu : Measure U) [SigmaFinite mu] (n : ℕ) :
    SigmaFinite (iidPool mu n) := by unfold iidPool; infer_instance

instance iidPool_isProbability (mu : Measure U) [IsProbabilityMeasure mu] (n : ℕ) :
    IsProbabilityMeasure (iidPool mu n) := by unfold iidPool; infer_instance

@[expose] def splitMark {n : ℕ} (i : Fin (n + 1)) (u : Fin (n + 1) → U) :
    U × (Fin n → U) := (u i, fun j => u (i.succAbove j))

theorem splitMark_measurePreserving (mu : Measure U) [SigmaFinite mu]
    {n : ℕ} (i : Fin (n + 1)) :
    MeasurePreserving (splitMark i) (iidPool mu (n + 1)) (mu.prod (iidPool mu n)) := by
  exact measurePreserving_piFinSuccAbove (fun _ => mu) i

theorem iid_split_integral (mu : Measure U) [SigmaFinite mu]
    {n : ℕ} (i : Fin (n + 1)) (h : U × (Fin n → U) → ℝ) :
    (∫ u, h (splitMark i u) ∂iidPool mu (n + 1)) =
      ∫ p, h p ∂mu.prod (iidPool mu n) := by
  exact (splitMark_measurePreserving mu i).integral_comp'
    (f := MeasurableEquiv.piFinSuccAbove (fun _ : Fin (n + 1) => U) i) h

theorem iid_split_integrable (mu : Measure U) [SigmaFinite mu]
    {n : ℕ} (i : Fin (n + 1)) (h : U × (Fin n → U) → ℝ)
    (hh : Integrable h (mu.prod (iidPool mu n))) :
    Integrable (fun u => h (splitMark i u)) (iidPool mu (n + 1)) := by
  exact ((splitMark_measurePreserving mu i).integrable_comp_emb
    (MeasurableEquiv.piFinSuccAbove (fun _ : Fin (n + 1) => U) i).measurableEmbedding).2 hh

theorem iid_deletion_integral (mu : Measure U) [SigmaFinite mu]
    (n : ℕ) (h : U × (Fin n → U) → ℝ)
    (hh : Integrable h (mu.prod (iidPool mu n))) :
    (∫ u, ∑ i : Fin (n + 1), h (splitMark i u) ∂iidPool mu (n + 1)) =
      ((n + 1 : ℕ) : ℝ) * ∫ p, h p ∂mu.prod (iidPool mu n) := by
  rw [integral_finsetSum _ (fun i _ => iid_split_integrable mu i h hh)]
  simp_rw [iid_split_integral mu]
  simp

@[expose] def deletionSum (h : (n : ℕ) → U × (Fin n → U) → ℝ) :
    (m : ℕ) → (Fin m → U) → ℝ
  | 0 => fun _ => 0
  | n + 1 => fun u => ∑ i : Fin (n + 1), h n (splitMark i u)

@[expose] def insertionMean (mu : Measure U) (h : (n : ℕ) → U × (Fin n → U) → ℝ)
    (n : ℕ) : ℝ := ∫ p, h n p ∂mu.prod (iidPool mu n)

theorem deletionMean_eq (mu : Measure U) [SigmaFinite mu]
    (h : (n : ℕ) → U × (Fin n → U) → ℝ)
    (hh : ∀ n, Integrable (h n) (mu.prod (iidPool mu n))) (m : ℕ) :
    (∫ u, deletionSum h m u ∂iidPool mu m) =
      (m : ℝ) * insertionMean mu h (m - 1) := by
  cases m with
  | zero => simp [deletionSum]
  | succ n =>
    simpa [deletionSum, insertionMean] using iid_deletion_integral mu n (h n) (hh n)

theorem marked_poisson_insertion (rate : NNReal) (mu : Measure U) [SigmaFinite mu]
    (h : (n : ℕ) → U × (Fin n → U) → ℝ)
    (hh : ∀ n, Integrable (h n) (mu.prod (iidPool mu n)))
    (hmean : Integrable (insertionMean mu h) (poissonMeasure rate)) :
    (∫ m, (∫ u, deletionSum h m u ∂iidPool mu m) ∂poissonMeasure rate) =
      (rate : ℝ) *
        ∫ m, (∫ u, ∫ pool, h m (u, pool) ∂iidPool mu m ∂mu) ∂poissonMeasure rate := by
  simp_rw [deletionMean_eq mu h hh]
  rw [poisson_integral_insertion rate (insertionMean mu h) hmean]
  congr 1
  apply integral_congr_ae
  filter_upwards [] with m
  exact integral_prod _ (hh m)

end

end PoissonAudit
