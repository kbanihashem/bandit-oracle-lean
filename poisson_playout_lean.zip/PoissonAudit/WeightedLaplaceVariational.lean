module

public import PoissonAudit.LaplaceCoordinateVariational

public section

open MeasureTheory InformationTheory
open scoped ENNReal

namespace PoissonAudit

noncomputable section

@[expose] def channelEntropyCharge (K : ℕ) (r : (Fin K → ℝ) → ℝ) (p : ℝ) : ℝ :=
  p * (klDiv ((laplaceMeasure K).withDensity (fun z => ENNReal.ofReal (r z / p))) (laplaceMeasure K)).toReal

theorem weighted_laplace_channel_variational (K : ℕ) (a : Fin K)
    (r : (Fin K → ℝ) → ℝ) (hr : Measurable r) (hr0 : ∀ z, 0 ≤ r z) (hr1 : ∀ z, r z ≤ 1) :
    let p := ∫ z, r z ∂laplaceMeasure K
    (∀ t : ℝ, 0 < t → t ≤ 1 / 2 →
      t * |∫ z, r z * z a ∂laplaceMeasure K| ≤
        channelEntropyCharge K r p + (4 / 3 : ℝ) * t ^ 2 * p) ∧
    (∀ t : ℝ, 0 < t →
      t * |∫ z, r z * laplaceSign (z a) ∂laplaceMeasure K| ≤
        channelEntropyCharge K r p + (t ^ 2 / 2) * p) := by
  dsimp only
  let p := ∫ z, r z ∂laplaceMeasure K
  have hri : Integrable r (laplaceMeasure K) :=
    Integrable.of_mem_Icc 0 1 hr.aemeasurable (Filter.Eventually.of_forall fun z => ⟨hr0 z, hr1 z⟩)
  have hp0 : 0 ≤ p := integral_nonneg hr0
  by_cases hpz : p = 0
  · have hrzero : r =ᵐ[laplaceMeasure K] 0 :=
      (integral_eq_zero_iff_of_nonneg hr0 hri).mp hpz
    have hzero (g : (Fin K → ℝ) → ℝ) : (∫ z, r z * g z ∂laplaceMeasure K) = 0 := by
      apply integral_eq_zero_of_ae
      filter_upwards [hrzero] with z hz
      simp [hz]
    constructor
    · intro t _ _
      rw [hzero]
      simp [channelEntropyCharge, p, hpz]
    · intro t _
      rw [hzero]
      simp [channelEntropyCharge, p, hpz]
  have hp : 0 < p := lt_of_le_of_ne hp0 (Ne.symm hpz)
  let f := fun z => r z / p
  have hfm : Measurable f := hr.div_const p
  have hf0 : ∀ z, 0 ≤ f z := fun z => div_nonneg (hr0 z) hp.le
  have hfC : ∀ z, f z ≤ 1 / p := fun z => div_le_div_of_nonneg_right (hr1 z) hp.le
  have hfi : Integrable f (laplaceMeasure K) := by
    apply Integrable.of_bound hfm.aestronglyMeasurable (1 / p)
    filter_upwards [] with z
    change |f z| ≤ 1 / p
    simpa only [abs_of_nonneg (hf0 z)] using hfC z
  have hnorm : (∫ z, f z ∂laplaceMeasure K) = 1 := by
    change (∫ z, r z / p ∂laplaceMeasure K) = 1
    rw [integral_div]
    exact div_self hp.ne'
  have hki := integrable_klFun_bounded (laplaceMeasure K) f hfm hf0 hfC
  have hfzi : Integrable (fun z => f z * z a) (laplaceMeasure K) := by
    apply (integrable_laplace_coordinate K a).bdd_mul hfm.aestronglyMeasurable
    filter_upwards [] with z
    simpa only [Real.norm_eq_abs, abs_of_nonneg (hf0 z)] using hfC z
  have hfsi : Integrable (fun z => f z * laplaceSign (z a)) (laplaceMeasure K) := by
    convert! hfi.bdd_mul (c := 1)
      (measurable_laplaceSign.comp (measurable_pi_apply a)).aestronglyMeasurable
      (Filter.Eventually.of_forall fun z => by simp [Real.norm_eq_abs, abs_laplaceSign]) using 1
    funext z
    simp only [Function.comp_apply]
    ring
  let d := ∫ z, klFun (f z) ∂laplaceMeasure K
  have hcharge : channelEntropyCharge K r p = p * d := by
    unfold channelEntropyCharge
    rw [density_kl_toReal _ _ hfm hf0 hfi hnorm]
  have hmoment (g : (Fin K → ℝ) → ℝ) :
      (∫ z, f z * g z ∂laplaceMeasure K) = (∫ z, r z * g z ∂laplaceMeasure K) / p := by
    simp_rw [show ∀ z, f z * g z = (r z * g z) / p from fun z => by unfold f; ring]
    exact integral_div _ _
  constructor
  · intro t ht ht1
    have htt : |t| < 1 := by rw [abs_of_pos ht]; linarith
    have hpv := laplace_coordinate_density_mean_variational K a f hf0 hfi hnorm hki hfzi htt
    have hnv := laplace_coordinate_density_mean_variational K a f hf0 hfi hnorm hki hfzi
      (t := -t) (by simpa only [abs_neg] using htt)
    rw [neg_sq] at hnv
    have hl := neg_log_one_sub_sq_le ht.le ht1
    have hab : t * |∫ z, f z * z a ∂laplaceMeasure K| ≤ d + (4 / 3 : ℝ) * t ^ 2 := by
      have hboth : |t * ∫ z, f z * z a ∂laplaceMeasure K| ≤ d + (4 / 3 : ℝ) * t ^ 2 := by
        rw [abs_le]
        constructor <;> linarith
      simpa only [abs_mul, abs_of_pos ht] using hboth
    rw [hmoment] at hab
    have hh := mul_le_mul_of_nonneg_left hab hp.le
    rw [hcharge]
    rw [abs_div, abs_of_pos hp] at hh
    convert! hh using 1 <;> field_simp [hp.ne'] <;> ring
  · intro t ht
    have hpv := laplace_coordinate_density_sign_variational K a f hf0 hfi hnorm hki hfsi t
    have hnv := laplace_coordinate_density_sign_variational K a f hf0 hfi hnorm hki hfsi (-t)
    rw [neg_sq] at hnv
    have hab : t * |∫ z, f z * laplaceSign (z a) ∂laplaceMeasure K| ≤ d + t ^ 2 / 2 := by
      have hboth : |t * ∫ z, f z * laplaceSign (z a) ∂laplaceMeasure K| ≤ d + t ^ 2 / 2 := by
        rw [abs_le]
        constructor <;> linarith
      simpa only [abs_mul, abs_of_pos ht] using hboth
    rw [hmoment] at hab
    have hh := mul_le_mul_of_nonneg_left hab hp.le
    rw [hcharge]
    rw [abs_div, abs_of_pos hp] at hh
    convert! hh using 1 <;> field_simp [hp.ne'] <;> ring

end

end PoissonAudit
