module

public import PoissonAudit.Vendor.Isoperimetric.PrekopaLeindler
public import Mathlib.MeasureTheory.Measure.Haar.NormedSpace
public import Mathlib.Tactic

public section

open MeasureTheory
open scoped BigOperators ENNReal

namespace PoissonAudit

noncomputable section

theorem lintegral_half_smul (m : ℕ) (f : (Fin m → ℝ) → ENNReal) (hf : Measurable f) :
    (∫⁻ x, f ((1 / 2 : ℝ) • x)) =
      (ENNReal.ofReal ((1 / 2 : ℝ) ^ m))⁻¹ * ∫⁻ x, f x := by
  have hsm : Measurable (fun x : Fin m → ℝ => (1 / 2 : ℝ) • x) :=
    measurable_const_smul (1 / 2 : ℝ)
  rw [← lintegral_map hf hsm,
    Measure.map_addHaar_smul (volume : Measure (Fin m → ℝ)) (by norm_num : (1 / 2 : ℝ) ≠ 0),
    lintegral_smul_measure]
  simp only [Module.finrank_pi, Fintype.card_fin, smul_eq_mul]
  rw [abs_of_pos (by positivity), ENNReal.ofReal_inv_of_pos (by positivity)]

theorem ofReal_sqrt (x : ℝ) (hx : 0 ≤ x) :
    (ENNReal.ofReal x) ^ (1 / 2 : ℝ) = ENNReal.ofReal (Real.sqrt x) := by
  rw [ENNReal.ofReal_rpow_of_nonneg hx (by norm_num), Real.sqrt_eq_rpow]

theorem prekopa_leindler_midpoint {d : ℕ}
    (f g h : (Fin (d + 1) → ℝ) → ℝ)
    (hf : Measurable f) (hg : Measurable g) (hh : Measurable h)
    (hf0 : ∀ x, 0 ≤ f x) (hg0 : ∀ x, 0 ≤ g x) (hh0 : ∀ x, 0 ≤ h x)
    (hfi : Integrable f) (hgi : Integrable g) (hhi : Integrable h)
    (hmid : ∀ x y, Real.sqrt (f x) * Real.sqrt (g y) ≤ h ((1 / 2 : ℝ) • (x + y))) :
    Real.sqrt (∫ x, f x) * Real.sqrt (∫ x, g x) ≤ ∫ x, h x := by
  let F := fun x => ENNReal.ofReal (f x)
  let G := fun x => ENNReal.ofReal (g x)
  let H := fun x => ENNReal.ofReal (h ((1 / 2 : ℝ) • x))
  have hc : 0 < (1 / 2 : ℝ) ^ (d + 1) := by positivity
  have hpl : PLConditions (d + 1) (1 / 2) F G H := by
    refine ⟨by norm_num, by norm_num, hf.ennreal_ofReal, hg.ennreal_ofReal, ?_, ?_⟩
    · exact (hh.comp (show Measurable (fun x : Fin (d + 1) → ℝ => (1 / 2 : ℝ) • x) from
        measurable_const_smul (1 / 2 : ℝ))).ennreal_ofReal
    · intro x y
      change ENNReal.ofReal (f x) ^ (1 - (1 / 2 : ℝ)) *
        ENNReal.ofReal (g y) ^ (1 / 2 : ℝ) ≤ ENNReal.ofReal (h ((1 / 2 : ℝ) • (x + y)))
      norm_num only [show (1 : ℝ) - 1 / 2 = 1 / 2 by norm_num]
      rw [ofReal_sqrt _ (hf0 x), ofReal_sqrt _ (hg0 y),
        ← ENNReal.ofReal_mul (Real.sqrt_nonneg _)]
      exact ENNReal.ofReal_le_ofReal (hmid x y)
  have hbound := prekopa_leindler hpl
  have hconstant : (1 - (1 / 2 : ℝ)) ^ (((d + 1 : ℕ) : ℝ) * (1 - 1 / 2)) *
      (1 / 2 : ℝ) ^ (((d + 1 : ℕ) : ℝ) * (1 / 2)) = (1 / 2 : ℝ) ^ (d + 1) := by
    norm_num only [show (1 : ℝ) - 1 / 2 = 1 / 2 by norm_num]
    rw [← Real.rpow_add (by norm_num : 0 < (1 / 2 : ℝ))]
    have he : ((d + 1 : ℕ) : ℝ) * (1 / 2) + ((d + 1 : ℕ) : ℝ) * (1 / 2) =
        ((d + 1 : ℕ) : ℝ) := by ring
    rw [he, Real.rpow_natCast]
  push_cast at hconstant
  rw [hconstant] at hbound
  change _ ≤ ∫⁻ x, ENNReal.ofReal (h ((1 / 2 : ℝ) • x)) at hbound
  rw [lintegral_half_smul _ _ hh.ennreal_ofReal] at hbound
  simp only [ENNReal.ofReal_inv_of_pos hc] at hbound
  have hcancel := mul_le_mul_right hbound (ENNReal.ofReal ((1 / 2 : ℝ) ^ (d + 1)))
  simp only [← mul_assoc, ENNReal.mul_inv_cancel (by positivity :
    ENNReal.ofReal ((1 / 2 : ℝ) ^ (d + 1)) ≠ 0) ENNReal.ofReal_ne_top, one_mul] at hcancel
  change (∫⁻ x, ENNReal.ofReal (f x)) ^ (1 - (1 / 2 : ℝ)) *
    (∫⁻ x, ENNReal.ofReal (g x)) ^ (1 / 2 : ℝ) ≤ ∫⁻ x, ENNReal.ofReal (h x) at hcancel
  rw [← ofReal_integral_eq_lintegral_ofReal hfi (Filter.Eventually.of_forall hf0),
    ← ofReal_integral_eq_lintegral_ofReal hgi (Filter.Eventually.of_forall hg0),
    ← ofReal_integral_eq_lintegral_ofReal hhi (Filter.Eventually.of_forall hh0)] at hcancel
  norm_num only [show (1 : ℝ) - 1 / 2 = 1 / 2 by norm_num] at hcancel
  rw [ofReal_sqrt _ (integral_nonneg hf0), ofReal_sqrt _ (integral_nonneg hg0),
    ← ENNReal.ofReal_mul (Real.sqrt_nonneg _)] at hcancel
  exact (ENNReal.ofReal_le_ofReal_iff (integral_nonneg hh0)).mp hcancel

end

end PoissonAudit
