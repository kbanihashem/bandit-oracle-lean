module

public import PoissonAudit.Algebra
public import Mathlib.MeasureTheory.Function.ConditionalExpectation.Basic

public section

open MeasureTheory
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {Omega P : Type*} [m0 : MeasurableSpace Omega] [Fintype P] [Nonempty P]

def bestScore (s : P → ℝ) : ℝ := Finset.univ.sup' Finset.univ_nonempty s

theorem bestScore_le {s : P → ℝ} {b : ℝ} (h : ∀ p, s p ≤ b) : bestScore s ≤ b :=
  Finset.sup'_le _ _ (fun p _ => h p)

theorem conditional_terminal_comparison
    (mu : Measure Omega) (m : MeasurableSpace Omega) (hm : m ≤ m0)
    [SigmaFinite (mu.trim hm)]
    (estimated trueScore : P → Omega → ℝ) (terminal : Omega → ℝ)
    (hest : ∀ p, Integrable (estimated p) mu) (hterm : Integrable terminal mu)
    (hdom : ∀ p, estimated p ≤ᵐ[mu] terminal)
    (hunbiased : ∀ p, mu[estimated p | m] =ᵐ[mu] trueScore p) :
    (fun omega => bestScore (fun p => trueScore p omega)) ≤ᵐ[mu] mu[terminal | m] := by
  have hp : ∀ p, trueScore p ≤ᵐ[mu] mu[terminal | m] := by
    intro p
    have hmono := condExp_mono (m := m) (hest p) hterm (hdom p)
    filter_upwards [hunbiased p, hmono] with omega he hd
    simpa only [he] using hd
  have hall : ∀ᵐ omega ∂mu, ∀ p, trueScore p omega ≤ mu[terminal | m] omega :=
    ae_all_iff.mpr hp
  filter_upwards [hall] with omega hs
  exact bestScore_le hs

theorem expected_terminal_comparison
    (mu : Measure Omega) (m : MeasurableSpace Omega) (hm : m ≤ m0)
    [SigmaFinite (mu.trim hm)]
    (estimated trueScore : P → Omega → ℝ) (terminal : Omega → ℝ)
    (hest : ∀ p, Integrable (estimated p) mu) (hterm : Integrable terminal mu)
    (htrue : Integrable (fun omega => bestScore (fun p => trueScore p omega)) mu)
    (hdom : ∀ p, estimated p ≤ᵐ[mu] terminal)
    (hunbiased : ∀ p, mu[estimated p | m] =ᵐ[mu] trueScore p) :
    (∫ omega, bestScore (fun p => trueScore p omega) ∂mu) ≤ ∫ omega, terminal omega ∂mu := by
  have h := integral_mono_ae htrue (integrable_condExp (m := m) (μ := mu))
    (conditional_terminal_comparison (m0 := m0) mu m hm estimated trueScore terminal hest hterm hdom hunbiased)
  rwa [integral_condExp hm] at h

theorem conditional_relaxation_regret
    (mu : Measure Omega) [IsProbabilityMeasure mu] (T : ℕ)
    (past : ℕ → MeasurableSpace Omega)
    (hpast : ∀ t, past t ≤ m0)
    (loss potential : ℕ → Omega → ℝ)
    (hloss : ∀ t, Integrable (loss t) mu) (hpotential : ∀ t, Integrable (potential t) mu)
    (initial slack : ℝ) (hinit : potential 0 =ᵐ[mu] fun _ => initial)
    (hround : ∀ t < T,
      mu[(fun omega => loss t omega + potential (t + 1) omega - potential t omega) | past t]
        ≤ᵐ[mu] fun _ => slack)
    (contextSigma : MeasurableSpace Omega) (hcontext : contextSigma ≤ m0)
    (estimated trueScore : P → Omega → ℝ)
    (hest : ∀ p, Integrable (estimated p) mu)
    (htrue : Integrable (fun omega => bestScore (fun p => trueScore p omega)) mu)
    (hdom : ∀ p, estimated p ≤ᵐ[mu] potential T)
    (hunbiased : ∀ p, mu[estimated p | contextSigma] =ᵐ[mu] trueScore p) :
    (∫ omega, (∑ t ∈ Finset.range T, loss t omega) +
      bestScore (fun p => trueScore p omega) ∂mu) ≤ initial + T * slack := by
  have hstep : ∀ t < T,
      (∫ omega, loss t omega ∂mu) + (∫ omega, potential (t + 1) omega ∂mu) -
        (∫ omega, potential t omega ∂mu) ≤ slack := by
    intro t ht
    have h := integral_mono_ae
      (integrable_condExp (m := past t) (μ := mu)) (integrable_const slack) (hround t ht)
    rw [integral_condExp (hpast t), integral_const, probReal_univ, one_smul] at h
    change (∫ omega, (loss t + potential (t + 1)) omega - potential t omega ∂mu) ≤ slack at h
    rw [integral_sub ((hloss t).add (hpotential (t + 1))) (hpotential t)] at h
    change (∫ omega, loss t omega + potential (t + 1) omega ∂mu) - _ ≤ _ at h
    rw [integral_add (hloss t) (hpotential (t + 1))] at h
    exact h
  have hterminal := expected_terminal_comparison (m0 := m0) mu contextSigma hcontext
    estimated trueScore (potential T) hest (hpotential T) htrue hdom hunbiased
  have htel := telescope T
    (fun t => ∫ omega, loss t omega ∂mu) (fun t => ∫ omega, potential t omega ∂mu)
    slack (-(∫ omega, bestScore (fun p => trueScore p omega) ∂mu)) hstep (by simpa using hterminal)
  have hi : (∫ omega, potential 0 omega ∂mu) = initial := by
    rw [integral_congr_ae hinit, integral_const, probReal_univ, one_smul]
  rw [hi] at htel
  rw [integral_add (integrable_finsetSum _ (fun t _ => hloss t)) htrue,
    integral_finsetSum _ (fun t _ => hloss t)]
  linarith

end

end PoissonAudit
