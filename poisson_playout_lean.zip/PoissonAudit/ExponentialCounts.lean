module
public import Mathlib.Probability.Distributions.Exponential
public import Mathlib.Probability.Distributions.Poisson.Basic
public import Mathlib.Analysis.SpecialFunctions.Integrals.Basic
public import Mathlib.Tactic
public section

open MeasureTheory ProbabilityTheory Set
namespace PoissonAudit
noncomputable section

abbrev WaitTape : ℕ → Type
  | 0 => Unit
  | n+1 => ℝ × WaitTape n

instance waitSpace : (n : ℕ) → MeasurableSpace (WaitTape n)
  | 0 => inferInstanceAs (MeasurableSpace Unit)
  | n+1 => @Prod.instMeasurableSpace _ _ _ (waitSpace n)

def waitLaw : (n : ℕ) → Measure (WaitTape n)
  | 0 => Measure.dirac ()
  | n+1 => (expMeasure 1).prod (waitLaw n)

local instance : IsProbabilityMeasure (expMeasure 1) := isProbabilityMeasure_expMeasure (by norm_num)

instance waitProbability : (n : ℕ) → IsProbabilityMeasure (waitLaw n)
  | 0 => inferInstanceAs (IsProbabilityMeasure (Measure.dirac ()))
  | n+1 => by
    haveI := waitProbability n
    exact inferInstanceAs (IsProbabilityMeasure ((expMeasure 1).prod (waitLaw n)))

def waitCount : (n : ℕ) → ℝ → WaitTape n → ℕ
  | 0, _, _ => 0
  | n+1, t, v => if v.1 ≤ t then 1 + waitCount n (t-v.1) v.2 else 0

structure WaitRun where
  count : ℕ
  draws : ℕ
  operations : ℕ

def runWaits : (fuel : ℕ) → ℝ → WaitTape fuel → WaitRun
  | 0, _, _ => ⟨0,0,0⟩
  | fuel+1, t, tape =>
    if tape.1 ≤ t then
      let next := runWaits fuel (t-tape.1) tape.2
      ⟨1+next.count,1+next.draws,3+next.operations⟩
    else ⟨0,1,1⟩

theorem runWaits_spec (fuel : ℕ) (t : ℝ) (tape : WaitTape fuel) :
    (runWaits fuel t tape).count = waitCount fuel t tape ∧
    (runWaits fuel t tape).draws ≤ fuel ∧ (runWaits fuel t tape).operations ≤ 3*fuel := by
  induction fuel generalizing t with
  | zero => simp [runWaits,waitCount]
  | succ n ih =>
    have h := ih (t-tape.1) tape.2
    by_cases c : tape.1 ≤ t <;> simp [runWaits,waitCount,c,h.1] <;> omega

theorem waitCount_le (n : ℕ) (t : ℝ) (v : WaitTape n) : waitCount n t v ≤ n := by
  induction n generalizing t with
  | zero => rfl
  | succ n ih =>
    simp only [waitCount]
    have := ih (t-v.1) v.2
    split_ifs <;> omega

theorem measurable_waitCount {Ω : Type*} [MeasurableSpace Ω] (n : ℕ)
    (t : Ω → ℝ) (v : Ω → WaitTape n) (ht : Measurable t) (hv : Measurable v) :
    Measurable (fun z => waitCount n (t z) (v z)) := by
  induction n generalizing t with
  | zero => exact measurable_const
  | succ n ih =>
    have hv' : Measurable (v : Ω → ℝ × WaitTape n) := hv
    exact Measurable.ite (measurableSet_le hv'.fst ht)
      (measurable_const.add (ih _ _ (ht.sub hv'.fst) hv'.snd)) measurable_const

private def mass (k : ℕ) (t : ℝ) := Real.exp (-t) * t^k / k.factorial

private theorem arrival_integral (k : ℕ) (t : ℝ) (ht : 0 ≤ t) :
    (∫ s in Iic t, mass k (t-s) ∂expMeasure 1) = mass (k+1) t := by
  change (∫ s in Iic t, mass k (t-s) ∂volume.withDensity (exponentialPDF 1)) = _
  rw [setIntegral_withDensity_eq_setIntegral_toReal_smul
    (f := exponentialPDF 1) (show Measurable (exponentialPDF 1) from (measurable_exponentialPDFReal 1).ennreal_ofReal)
    (Filter.Eventually.of_forall fun _ => ENNReal.ofReal_lt_top) _ measurableSet_Iic]
  have he : ∀ s : ℝ, (exponentialPDF 1 s).toReal • mass k (t-s) =
      (Ici (0 : ℝ)).indicator (fun x => (Real.exp (-t) / k.factorial) * (t-x)^k) s := by
    intro s
    by_cases hs : 0 ≤ s
    · rw [Set.indicator_of_mem hs, exponentialPDF_of_nonneg hs, ENNReal.toReal_ofReal (by positivity)]
      simp only [one_mul, smul_eq_mul, mass]
      rw [show Real.exp (-s) * (Real.exp (-(t-s)) * (t-s)^k / k.factorial) =
        (Real.exp (-s) * Real.exp (-(t-s))) / k.factorial * (t-s)^k by ring, ← Real.exp_add]
      ring_nf
    · rw [Set.indicator_of_notMem hs, exponentialPDF_of_neg (lt_of_not_ge hs)]
      simp
  simp_rw [he]
  rw [setIntegral_indicator measurableSet_Ici, Iic_inter_Ici, integral_Icc_eq_integral_Ioc,
    ← intervalIntegral.integral_of_le ht, intervalIntegral.integral_const_mul,
    intervalIntegral.integral_comp_sub_left (fun x : ℝ => x^k)]
  simp only [sub_self, sub_zero, integral_pow, Nat.cast_add, Nat.cast_one, zero_pow (by omega : k+1 ≠ 0), sub_zero]
  unfold mass
  rw [Nat.factorial_succ, Nat.cast_mul, Nat.cast_add, Nat.cast_one]
  simp only [div_eq_mul_inv,mul_inv_rev]
  ring

private theorem no_arrival (t : ℝ) (ht : 0 ≤ t) :
    (expMeasure 1).real (Ioi t) = Real.exp (-t) := by
  rw [← compl_Iic, measureReal_compl measurableSet_Iic, probReal_univ, ← cdf_eq_real,
    cdf_expMeasure_eq (by norm_num) t, if_pos ht]
  ring

private theorem count_mass (n k : ℕ) (hk : k < n) (t : ℝ) (ht : 0 ≤ t) :
    (waitLaw n).real {v | waitCount n t v = k} = mass k t := by
  induction n generalizing k t with
  | zero => omega
  | succ n ih =>
    let E := {v : ℝ × WaitTape n | waitCount (n+1) t v = k}
    have hm : MeasurableSet E :=
      (measurable_waitCount (n+1) (fun _ => t) id measurable_const measurable_id) (measurableSet_singleton k)
    change ((expMeasure 1).prod (waitLaw n)).real E = _
    rw [measureReal_def, Measure.prod_apply hm, ← integral_toReal]
    · cases k with
      | zero =>
        have hh (s : ℝ) : ((waitLaw n) (Prod.mk s ⁻¹' E)).toReal =
            (Ioi t).indicator (fun _ => (1 : ℝ)) s := by
          by_cases h : s ≤ t
          · have hz : Prod.mk s ⁻¹' E = ∅ := by ext a; simp [E,waitCount,h]
            rw [hz, Set.indicator_of_notMem (not_lt.mpr h)]
            simp
          · have hu : Prod.mk s ⁻¹' E = univ := by ext a; simp [E,waitCount,h,lt_of_not_ge h]
            rw [hu, Set.indicator_of_mem (lt_of_not_ge h)]
            simp
        simp_rw [hh]
        rw [integral_indicator_const _ measurableSet_Ioi,smul_eq_mul,mul_one,no_arrival t ht]
        simp [mass]
      | succ k =>
        have hh (s : ℝ) : ((waitLaw n) (Prod.mk s ⁻¹' E)).toReal =
            (Iic t).indicator (fun s => mass k (t-s)) s := by
          by_cases h : s ≤ t
          · have he : Prod.mk s ⁻¹' E = {v | waitCount n (t-s) v = k} := by
              ext a
              simp [E,waitCount,h] <;> omega
            rw [he,Set.indicator_of_mem h]
            exact ih k (by omega) (t-s) (sub_nonneg.mpr h)
          · have he : Prod.mk s ⁻¹' E = ∅ := by ext a; simp [E,waitCount,h]
            rw [he,Set.indicator_of_notMem h]
            simp
        simp_rw [hh]
        rw [integral_indicator measurableSet_Iic, arrival_integral k t ht]
    · exact (measurable_measure_prodMk_left hm).aemeasurable
    · exact Filter.Eventually.of_forall fun _ => measure_lt_top _ _

theorem waitCount_law (n : ℕ) (r : NNReal) :
    (waitLaw n).map (waitCount n r) = (poissonMeasure r).map (fun k => min k n) := by
  let μ := (waitLaw n).map (waitCount n r)
  let ν := (poissonMeasure r).map (fun k => min k n)
  have hw : Measurable (waitCount n r) := measurable_waitCount n _ _ measurable_const measurable_id
  have hp : Measurable (fun k : ℕ => min k n) := .of_discrete
  haveI : IsProbabilityMeasure μ := (Measure.isProbabilityMeasure_map_iff hw.aemeasurable).mpr inferInstance
  haveI : IsProbabilityMeasure ν := (Measure.isProbabilityMeasure_map_iff hp.aemeasurable).mpr inferInstance
  have hother (k : ℕ) (hk : k ≠ n) : μ {k} = ν {k} := by
    dsimp [μ,ν]
    rw [Measure.map_apply hw (measurableSet_singleton _),Measure.map_apply hp (measurableSet_singleton _)]
    by_cases hlt : k < n
    · have he : (fun j : ℕ => min j n) ⁻¹' {k} = {k} := by
        ext j
        simp only [mem_preimage,mem_singleton_iff]
        omega
      rw [he]
      apply (ENNReal.toReal_eq_toReal_iff' (measure_ne_top _ _) (measure_ne_top _ _)).mp
      exact (count_mass n k hlt r r.coe_nonneg).trans (poissonMeasure_real_singleton r k).symm
    · have e₁ : (waitCount n r) ⁻¹' {k} = ∅ := by
        ext v
        simp only [mem_preimage,mem_singleton_iff,mem_empty_iff_false,iff_false]
        have := waitCount_le n r v
        omega
      have e₂ : (fun j : ℕ => min j n) ⁻¹' {k} = ∅ := by
        ext j
        simp only [mem_preimage,mem_singleton_iff,mem_empty_iff_false,iff_false]
        omega
      simp [e₁,e₂]
  change μ = ν
  apply Measure.ext_of_singleton
  intro k
  by_cases hk : k = n
  · subst k
    have hc : μ ({n}ᶜ) = ν ({n}ᶜ) := by
      rw [← Measure.tsum_indicator_apply_singleton μ _ (measurableSet_singleton n).compl,
        ← Measure.tsum_indicator_apply_singleton ν _ (measurableSet_singleton n).compl]
      apply tsum_congr
      intro j
      by_cases h : j = n
      · simp [h]
      · simp [Set.indicator,h,hother j h]
    have hr : μ.real ({n}ᶜ) = ν.real ({n}ᶜ) := congrArg ENNReal.toReal hc
    rw [measureReal_compl (measurableSet_singleton n), measureReal_compl (measurableSet_singleton n),
      probReal_univ,probReal_univ] at hr
    exact (ENNReal.toReal_eq_toReal_iff' (measure_ne_top _ _) (measure_ne_top _ _)).mp (sub_right_inj.mp hr)
  · exact hother k hk

theorem runWaits_law (cap : ℕ) (r : NNReal) :
    (waitLaw (cap+1)).map (fun tape => (runWaits (cap+1) r tape).count) =
      (poissonMeasure r).map (fun k => min k (cap+1)) := by
  simp only [(runWaits_spec _ _ _).1]
  exact waitCount_law (cap+1) r

end
end PoissonAudit
