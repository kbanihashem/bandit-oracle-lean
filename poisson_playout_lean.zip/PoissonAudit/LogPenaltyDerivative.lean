module

public import PoissonAudit.LogStrongConvexity

public section

open scoped BigOperators Topology

namespace PoissonAudit

theorem hasDerivAt_log_scale_line {B sigma h : ℝ} (hB : 0 < B) (hsigma : 0 < sigma) :
    HasDerivAt (fun t : ℝ => Real.log (B / (sigma + t * h))) (-h / sigma) 0 := by
  have hpath : HasDerivAt (fun t : ℝ => sigma + t * h) h 0 := by
    convert! (hasDerivAt_const 0 sigma).add ((hasDerivAt_id 0).mul_const h) using 1 <;> simp [neg_div]
  have hlog := hpath.log (by simpa only [zero_mul, add_zero] using hsigma.ne')
  have hd : HasDerivAt (fun t : ℝ => Real.log B - Real.log (sigma + t * h)) (-h / sigma) 0 := by
    convert! (hasDerivAt_const 0 (Real.log B)).sub hlog using 1 <;> simp [neg_div]
  apply hd.congr_of_eventuallyEq
  have hp := (continuousAt_const : ContinuousAt (fun _ : ℝ => (0 : ℝ)) 0).eventually_lt hpath.continuousAt
    (by simpa only [zero_mul, add_zero] using hsigma)
  filter_upwards [hp] with t ht
  exact Real.log_div hB.ne' ht.ne'

theorem hasDerivAt_scalePenalty_line {Q : Type*} [Fintype Q]
    (w sigma h : Q → ℝ) (lam B : ℝ) (hB : 0 < B) (hsigma : ∀ j, 0 < sigma j) :
    HasDerivAt (fun t : ℝ => scalePenalty w lam B (fun j => sigma j + t * h j))
      (-(lam * ∑ j, w j * h j / sigma j)) 0 := by
  classical
  have hj (j : Q) := (hasDerivAt_log_scale_line (h := h j) hB (hsigma j)).const_mul (w j)
  have hd := (HasDerivAt.sum (u := Finset.univ) fun j _ => hj j).const_mul lam
  convert! hd using 1
  · funext t
    simp only [scalePenalty, Finset.sum_apply]
  · change -(lam * ∑ j, w j * h j / sigma j) = lam * ∑ j, w j * (-h j / sigma j)
    simp only [neg_div, mul_neg, Finset.sum_neg_distrib, mul_div_assoc]

end PoissonAudit
