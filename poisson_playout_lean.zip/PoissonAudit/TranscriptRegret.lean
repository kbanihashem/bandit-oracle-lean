module
public import PoissonAudit.TranscriptFiniteViews
public import PoissonAudit.FiniteFeedbackContext
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section

@[expose] def transcriptOriginalRegret {X O P : Type*} [Fintype P] [Nonempty P] {K T : ℕ}
    (predict : P → X → Fin K) (cost : Fin T → X → Fin K → ℝ) (action : O → Fin K)
    (path : ContextTranscript X O T) : ℝ :=
  (∑ t, cost t (transcriptContexts T path t) (action (transcriptOutcomes T path t))) +
    treeBestScore (fun p => -(∑ t, cost t (transcriptContexts T path t) (predict p (transcriptContexts T path t))))

theorem integrable_transcriptOriginalRegret {X O P : Type*} [MeasurableSpace X] [MeasurableSpace O]
    [MeasurableSingletonClass O] [Fintype O] [Fintype P] [Nonempty P] {K T : ℕ}
    (predict : P → X → Fin K) (hp : ∀ p, Measurable (predict p)) (cost : Fin T → X → Fin K → ℝ)
    (hc : ∀ t a, Measurable (fun x => cost t x a)) (hc0 : ∀ t x a, 0 ≤ cost t x a) (hc1 : ∀ t x a, cost t x a ≤ 1)
    (action : O → Fin K) (mu : Measure (ContextTranscript X O T)) [IsFiniteMeasure mu] :
    Integrable (transcriptOriginalRegret predict cost action) mu := by
  classical
  have hctx (t : Fin T) : Measurable (fun path : ContextTranscript X O T => transcriptContexts T path t) :=
    (measurable_pi_apply t).comp (measurable_transcriptContexts T)
  have hout (t : Fin T) : Measurable (fun path : ContextTranscript X O T => action (transcriptOutcomes T path t)) :=
    (measurable_of_finite action).comp ((measurable_pi_apply t).comp (measurable_transcriptOutcomes T))
  have hselected (t : Fin T) (g : ContextTranscript X O T → Fin K) (hg : Measurable g) :
      Integrable (fun path => cost t (transcriptContexts T path t) (g path)) mu := by
    have hm : Measurable (fun q : X × Fin K => cost t q.1 q.2) := measurable_from_prod_countable_left (hc t)
    apply Integrable.of_bound (hm.comp ((hctx t).prodMk hg)).aestronglyMeasurable 1
    filter_upwards [] with path
    change ‖cost t (transcriptContexts T path t) (g path)‖ ≤ 1
    rw [Real.norm_eq_abs, abs_of_nonneg (hc0 t _ _)]
    exact hc1 t _ _
  apply Integrable.add
  · exact integrable_finsetSum _ (fun t _ => hselected t _ (hout t))
  · apply integrable_finset_max mu Finset.univ Finset.univ_nonempty
    intro p _
    exact (integrable_finsetSum _ (fun t _ => hselected t _ ((hp p).comp (hctx t)))).neg

theorem transcriptOriginalRegret_le_quotient {X Y O P : Type*} [Fintype Y] [Fintype O]
    [Fintype P] [Nonempty P] [LinearOrder P] {K : ℕ}
    (f : X → Y) (predictX : P → X → Fin K) (predictY : P → Y → Fin K)
    (hpredict : ∀ p x, predictY p (f x) = predictX p x) (costs : List (Y → Fin K → ℝ))
    (cost : Fin costs.length → X → Fin K → ℝ) (L : ℕ) (hL : 0 < L)
    (hc0 : ∀ t x a, 0 ≤ cost t x a) (hc1 : ∀ t x a, cost t x a ≤ 1)
    (hcost : ∀ t x a, costs.get t (f x) a = roundedLossValue L (cost t x a))
    (action : O → Fin K) (path : ContextTranscript X O costs.length) :
    transcriptOriginalRegret predictX cost action path ≤
      outcomePathLoss action costs (transcriptToOutcomePath f costs path) +
        treeBestScore (outcomePathTrueScore predictY costs (fun _ => 0) (transcriptToOutcomePath f costs path)) + (costs.length : ℝ) / L := by
  have h := rounded_realized_regret_le predictX cost L hL hc0 hc1 (transcriptContexts costs.length path)
    (fun t => action (transcriptOutcomes costs.length path t))
  rw [outcomePathLoss_eq_sum, outcomePathTrueScore_eq_sum,
    transcriptToOutcomePath_contexts, transcriptToOutcomePath_outcomes]
  simp only [hpredict, hcost, zero_sub]
  exact h

theorem integral_original_regret_le_quotient {X Y O P : Type*} [MeasurableSpace X]
    [MeasurableSpace Y] [MeasurableSingletonClass Y] [Fintype Y]
    [MeasurableSpace O] [MeasurableSingletonClass O] [Fintype O]
    [Fintype P] [Nonempty P] [LinearOrder P] {K : ℕ}
    (D : Measure X) [IsProbabilityMeasure D] (f : X → Y) (hf : Measurable f)
    (predictX : P → X → Fin K) (hp : ∀ p, Measurable (predictX p)) (predictY : P → Y → Fin K)
    (hpredict : ∀ p x, predictY p (f x) = predictX p x)
    (w : (P → ℝ) → Y → O → ℝ) (hw : ∀ S y o, 0 ≤ w S y o) (hwsum : ∀ S y, ∑ o, w S y o = 1)
    (U : (P → ℝ) → Y → (Fin K → ℝ) → O → P → ℝ) (costs : List (Y → Fin K → ℝ))
    (cost : Fin costs.length → X → Fin K → ℝ) (hc : ∀ t a, Measurable (fun x => cost t x a))
    (L : ℕ) (hL : 0 < L) (hc0 : ∀ t x a, 0 ≤ cost t x a) (hc1 : ∀ t x a, cost t x a ≤ 1)
    (hcost : ∀ t x a, costs.get t (f x) a = roundedLossValue L (cost t x a)) (action : O → Fin K) :
    (∫ path, transcriptOriginalRegret predictX cost action path ∂liftedContextLaw D f w U costs (fun _ => 0)) ≤
      finiteOutcomeLoss (fun y => ((D.map f) {y}).toReal) action w U costs (fun _ => 0) +
        contextBestScore (fun y => ((D.map f) {y}).toReal) predictY costs (fun _ => 0) + (costs.length : ℝ) / L := by
  haveI : IsProbabilityMeasure (D.map f) := (Measure.isProbabilityMeasure_map_iff hf.aemeasurable).mpr inferInstance
  let mu := liftedContextLaw D f w U costs (fun _ => 0)
  have hcert := liftedContextLaw_certificate D f hf w hw hwsum U costs (fun _ => 0)
  haveI : IsProbabilityMeasure mu := hcert.1
  let target := outcomePathLaw (fun y => ((D.map f) {y}).toReal) (fun _ => ENNReal.toReal_nonneg)
    (context_mass_sum (D.map f)) w U hw hwsum costs (fun _ => 0)
  let R := fun path : outcomePaths O costs => outcomePathLoss action costs path + treeBestScore (outcomePathTrueScore predictY costs (fun _ => 0) path)
  have hmp : MeasurePreserving (transcriptToOutcomePath f costs) mu target.toMeasure :=
    ⟨measurable_transcriptToOutcomePath f hf costs, hcert.2⟩
  have hrit : Integrable R target.toMeasure := Integrable.of_finite
  have hri : Integrable (fun path => R (transcriptToOutcomePath f costs path)) mu := hmp.integrable_comp_of_integrable hrit
  have hoi := integrable_transcriptOriginalRegret predictX hp cost hc hc0 hc1 action mu
  have hpoint := transcriptOriginalRegret_le_quotient f predictX predictY hpredict costs cost L hL hc0 hc1 hcost action
  have hi := integral_mono hoi (hri.add (integrable_const ((costs.length : ℝ) / L))) hpoint
  change _ ≤ ∫ path, R (transcriptToOutcomePath f costs path) + (costs.length : ℝ) / L ∂mu at hi
  rw [integral_add hri (integrable_const _), integral_const, probReal_univ, one_smul] at hi
  have hmap := integral_map hmp.measurable.aemeasurable (f := R)
    (by rw [hmp.map_eq]; exact (measurable_of_finite R).aestronglyMeasurable)
  rw [hmp.map_eq] at hmap
  change (∫ path, R path ∂target.toMeasure) = ∫ path, R (transcriptToOutcomePath f costs path) ∂mu at hmap
  rw [← hmap] at hi
  have hid := integral_outcomePath_regret predictY action (fun y => ((D.map f) {y}).toReal)
    (fun _ => ENNReal.toReal_nonneg) (context_mass_sum (D.map f)) w U hw hwsum costs (fun _ => 0)
  change (∫ path, R path ∂target.toMeasure) = _ at hid
  rw [hid] at hi
  exact hi
end
end PoissonAudit
