module
public import PoissonAudit.FiniteRegret
public import PoissonAudit.OracleSamplerCorrect
public section

open MeasureTheory Set
namespace PoissonAudit
noncomputable section

variable {Y P Ω : Type*} [MeasurableSpace Y] [MeasurableSingletonClass Y] [Fintype Y]
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]
    [MeasurableSpace Ω] {K : ℕ}

theorem measurable_variable_winner (predict : P → Y → Fin K) (y : Y)
    {S : Ω → P → ℝ} {s : Ω → Y × Fin K → ℝ} {v : Ω → NativeNoise Y K}
    (hS : Measurable S) (hs : Measurable s) (hv : Measurable v) :
    Measurable (fun z => experimentWinner predict (s z) (S z) y (v z)) := by
  apply measurable_winner
  intro p
  have h := (measurable_joint_experimentScore predict (fun _ => 0) y p).comp (hs.prodMk hv)
  have h' := ((measurable_pi_apply p).comp hS).add h
  simpa [Function.comp_def, Pi.add_def, experimentScore, add_assoc] using h'

theorem measurable_variable_state (predict : P → Y → Fin K) (r : NNReal) (lam B eta : ℝ) (hB : 1 ≤ B)
    (j : ℕ) {S : Ω → P → ℝ} {v : Ω → NativeNoiseTape Y K j}
    (hS : Measurable S) (hv : Measurable v) :
    Measurable (fun z => nativeTapeState r predict (S z) lam B eta hB j (v z)) := by
  induction j with
  | zero => exact measurable_const
  | succ j ih =>
    have hp := ih (measurable_fst.comp hv)
    let s := fun z => (nativeTapeState r predict (S z) lam B eta hB j (v z).1).1.val
    have hs : Measurable s := measurable_subtype_coe.comp (measurable_fst.comp hp)
    have hn := measurable_snd.comp hv
    apply Measurable.prodMk
    · apply Measurable.subtype_mk
      apply Measurable.of_eval
      intro a
      have hW := measurable_variable_winner predict a.1 hS hs hn
      let E := {z | predict (experimentWinner predict (s z) (S z) a.1 (v z).2) a.1 = a.2}
      have hE : MeasurableSet E :=
        ((measurable_of_finite (fun p => predict p a.1)).comp hW) (measurableSet_singleton a.2)
      let g := fun z => (r : ℝ) * (E.indicator (fun _ => (1 : ℝ)) z * (v z).2.1 a.2) - lam / s z a
      have hg : Measurable g := (measurable_const.mul ((measurable_const.indicator hE).mul
        ((measurable_pi_apply a.2).comp (measurable_fst.comp hn)))).sub
          (measurable_const.div ((measurable_pi_apply a).comp hs))
      have hclip : Continuous (boxClip B) := by unfold boxClip; fun_prop
      convert! hclip.measurable.comp (((measurable_pi_apply a).comp hs).sub (hg.const_mul eta)) using 1
    · have h := (measurable_snd.comp (measurable_nativeSGDTransition r predict (fun _ => 0) lam B eta hB j)).comp (hp.prodMk hn)
      exact h

theorem measurable_choice_in_score (predict : P → Y → Fin K) (r : NNReal) (lam B eta : ℝ)
    (hB : 1 ≤ B) (cap J m : ℕ) (y : Y) :
    Measurable (fun z : (P → ℝ) × (NativeNoiseTape Y K J × (Fin m → NativeNoise Y K)) =>
      canonicalTapeChoice r predict z.1 lam B eta hB cap J m y z.2) := by
  apply (measurable_of_finite (cappedOutcomeChoice (K := K) (m := m))).comp
  apply Measurable.prodMk
  · exact (measurable_snd.comp (measurable_nativeTapeFlaggedState r predict (fun _ => 0) lam B eta hB cap J)).comp (measurable_fst.comp measurable_snd)
  · apply Measurable.of_eval
    intro i
    have ht := measurable_variable_state predict r lam B eta hB J (Ω := (P → ℝ) × (NativeNoiseTape Y K J × (Fin m → NativeNoise Y K))) measurable_fst (measurable_fst.comp measurable_snd)
    have hn : Measurable (fun z : (P → ℝ) × (NativeNoiseTape Y K J × (Fin m → NativeNoise Y K)) => z.2.2 i) := by fun_prop
    exact (((measurable_of_finite (fun p => predict p y)).comp (measurable_variable_winner predict y measurable_fst (measurable_subtype_coe.comp (measurable_snd.comp ht)) hn)).prodMk ((measurable_nativeOverflowBool cap).comp hn))

theorem measurable_paper_weight (r : NNReal) (D : Measure Y) [IsProbabilityMeasure D]
    (predict : P → Y → Fin K) (lam B eps δ γ : ℝ) (hB : 1 ≤ B) (y : Y) (o : paperNativeFiniteOutcome K δ) :
    Measurable (fun S => paperNativeFiniteOutcomeWeight r D predict lam B eps δ γ hB S y o) := by
  let J := paperIterations K r lam B eps
  let m := paperTrials K δ
  let η := paperStep K r lam B eps
  let cap := paperCap r (J+m) δ
  let μ := (nativeNoiseTapeLaw (K := K) r D J).prod (iidPool (insertedExperimentLaw r D K) m)
  have h := measurable_outcomeMass_parameter μ _ (measurable_choice_in_score predict r lam B η hB cap J m y) o.1
  apply Measurable.mul_const _ (choiceProbability K γ m o.1 o.2)
  convert! h using 1
  funext S
  have hm := canonicalTapeChoice_measurePreserving r D predict S lam B η hB cap J m y
  have hh := congrArg (fun (ν : Measure (EmpiricalChoice K m)) => (ν {o.1}).toReal) hm.map_eq
  rw [Measure.map_apply hm.measurable (measurableSet_singleton _), PMF.toMeasure_apply_singleton _ _ (measurableSet_singleton _)] at hh
  exact (actionPMF_toReal _ _ _ _).symm.trans hh.symm

end
end PoissonAudit
