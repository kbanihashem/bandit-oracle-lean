module
public import PoissonAudit.OracleSampler
public import PoissonAudit.NativeCappedRealization
public section
open MeasureTheory Set
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def canonicalTapeChoice (r : NNReal) (predict : P → X → Fin K) (S : P → ℝ)
    (lam B eta : ℝ) (hB : 1 ≤ B) (cap J m : ℕ) (x : X)
    (v : NativeNoiseTape X K J × (Fin m → NativeNoise X K)) : EmpiricalChoice K m :=
  cappedOutcomeChoice (nativeRawCappedOutcome predict S B x cap m
    (nativeTapeFlaggedState r predict S lam B eta hB cap J v.1, v.2))

theorem canonicalTapeChoice_measurePreserving (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ) (hB : 1 ≤ B) (cap J m : ℕ) (x : X) :
    MeasurePreserving (canonicalTapeChoice r predict S lam B eta hB cap J m x)
      ((nativeNoiseTapeLaw r D J).prod (iidPool (insertedExperimentLaw r D K) m))
      (nativeCappedChoiceLaw r D predict S lam B eta hB cap J m x).toMeasure :=
  (nativeChoiceCappedOutcome_measurePreserving r D predict S lam B eta hB cap J m x).comp
    ((nativeTapeFlaggedState_measurePreserving r D predict S lam B eta hB cap J).prod
      (MeasurePreserving.id (iidPool (insertedExperimentLaw r D K) m)))

@[expose] def nativeSamplerGood (r : NNReal) (predict : P → X → Fin K) (S : P → ℝ)
    (lam B eta : ℝ) (hB : 1 ≤ B) (J m : ℕ)
    (v : NativeNoiseTape X K J × (Fin m → NativeNoise X K)) : Prop :=
  nativeTapeGood r predict S lam B eta hB J v.1 ∧
    ∀ i, nativeStateTieGood predict S B
      ((nativeTapeState r predict S lam B eta hB J v.1).2, (nativeTapeState r predict S lam B eta hB J v.1).2) (v.2 i)

theorem measurableSet_nativeSamplerGood (r : NNReal) (predict : P → X → Fin K) (S : P → ℝ)
    (lam B eta : ℝ) (hB : 1 ≤ B) (J m : ℕ) :
    MeasurableSet {v | nativeSamplerGood r predict S lam B eta hB J m v} := by
  have hs : Measurable (fun v : NativeNoiseTape X K J × (Fin m → NativeNoise X K) =>
      ((nativeTapeState r predict S lam B eta hB J v.1).2, (nativeTapeState r predict S lam B eta hB J v.1).2)) :=
    ((measurable_snd.comp (measurable_nativeTapeState r predict S lam B eta hB J)).comp measurable_fst).prodMk
      ((measurable_snd.comp (measurable_nativeTapeState r predict S lam B eta hB J)).comp measurable_fst)
  unfold nativeSamplerGood
  simp only [Set.setOf_and]
  apply (measurable_fst (measurableSet_nativeTapeGood r predict S lam B eta hB J)).inter
  simp only [Set.setOf_forall]
  apply MeasurableSet.iInter
  intro i
  exact (hs.prodMk ((measurable_pi_apply i).comp measurable_snd)) (measurableSet_nativeStateTieGood predict S B)

theorem nativeSamplerGood_ae (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ) (hB : 1 ≤ B) (J m : ℕ) :
    ∀ᵐ v ∂(nativeNoiseTapeLaw r D J).prod (iidPool (insertedExperimentLaw r D K) m),
      nativeSamplerGood r predict S lam B eta hB J m v := by
  apply (Measure.ae_prod_iff_ae_ae (measurableSet_nativeSamplerGood r predict S lam B eta hB J m)).mpr
  filter_upwards [nativeTapeGood_ae r D predict S lam B eta hB J] with tape htape
  let state := nativeTapeState r predict S lam B eta hB J tape
  have hpos (q : X × Fin K) : 0 < state.2.val q := lt_of_lt_of_le zero_lt_one (state.2.property.1 q)
  have hall (i : Fin m) : ∀ᵐ u ∂iidPool (insertedExperimentLaw r D K) m,
      nativeStateTieGood predict S B (state.2, state.2) (u i) :=
    (measurePreserving_eval (fun _ : Fin m => insertedExperimentLaw r D K) i).quasiMeasurePreserving.ae
      (native_inserted_all_context_ties r D predict state.2.val S hpos)
  filter_upwards [ae_all_iff.mpr hall] with u hu
  exact ⟨htape, hu⟩

theorem cappedOracleChoice_eq_canonical (r : NNReal) (predict : P → X → Fin K)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ)
    (horacle : ∀ Q, oracle Q = treeBestScore (queryScore predict Q)) (fallback : Fin K)
    (lam B eta : ℝ) (hB : 1 ≤ B) (cap J m : ℕ) (x : X)
    (v : NativeNoiseTape X K J × (Fin m → NativeNoise X K))
    (hgood : nativeSamplerGood r predict (queryScore predict history) lam B eta hB J m v) :
    cappedOracleChoice r lam B eta history oracle fallback cap J m v.1 v.2 x =
      canonicalTapeChoice r predict (queryScore predict history) lam B eta hB cap J m x v := by
  classical
  let state := nativeTapeState r predict (queryScore predict history) lam B eta hB J v.1
  let E := fun i => nativeEnrichedTrial predict state.2.val (queryScore predict history) x cap (v.2 i)
  have hscale : (fun y => (replayAt r lam B eta history oracle fallback
      (buildReplayRecords r lam B eta history oracle fallback J v.1) y).2) = fun y a => state.2.val (y, a) := by
    funext y
    exact congrArg Prod.snd (replayAt_build_native r predict history oracle horacle fallback lam B eta hB J v.1 hgood.1 y)
  have hact (i : Fin m) : replayTrialAction r lam B eta history oracle fallback
      (buildReplayRecords r lam B eta history oracle fallback J v.1) x (v.2 i) = (E i).1 := by
    unfold replayTrialAction
    rw [hscale]
    apply native_valueOracleAction_eq predict history oracle horacle fallback state.2.val (v.2 i)
    intro y p hp
    apply hgood.2 i y p (experimentWinner predict state.2.val (queryScore predict history) y (v.2 i))
    exact hp.trans (winner_score_eq_treeBestScore _).symm
  have htrial : trialAnyOverflow E = false ↔ ∀ i, (v.2 i).2.1 ≤ cap := by
    simp [trialAnyOverflow, E, nativeEnrichedTrial, nativeOverflowBool]
  have hflag : (nativeTapeFlag cap J v.1 || trialAnyOverflow E) = false ↔
      nativeTapeCountsBounded cap J v.1 ∧ ∀ i, (v.2 i).2.1 ≤ cap := by
    rw [Bool.or_eq_false_iff, nativeTapeFlag_false_iff, htrial]
  change (if nativeTapeCountsBounded cap J v.1 ∧ ∀ i, (v.2 i).2.1 ≤ cap then
    some (fun i => replayTrialAction r lam B eta history oracle fallback
      (buildReplayRecords r lam B eta history oracle fallback J v.1) x (v.2 i)) else none) =
        (if nativeTapeFlag cap J v.1 || trialAnyOverflow E then none else some (fun i => (E i).1))
  by_cases hc : nativeTapeCountsBounded cap J v.1 ∧ ∀ i, (v.2 i).2.1 ≤ cap
  · have hb := hflag.mpr hc
    simp only [if_pos hc, hb, Bool.false_eq_true, ite_false]
    congr 1
    funext i
    exact hact i
  · have hb : (nativeTapeFlag cap J v.1 || trialAnyOverflow E) = true := by
      cases h : nativeTapeFlag cap J v.1 || trialAnyOverflow E with
      | false => exact False.elim (hc (hflag.mp h))
      | true => rfl
    simp only [if_neg hc, hb, ite_true]

theorem cappedOracleChoice_law (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ)
    (horacle : ∀ Q, oracle Q = treeBestScore (queryScore predict Q)) (fallback : Fin K)
    (lam B eta : ℝ) (hB : 1 ≤ B) (cap J m : ℕ) (x : X) :
    ((nativeNoiseTapeLaw r D J).prod (iidPool (insertedExperimentLaw r D K) m)).map
      (fun v => cappedOracleChoice r lam B eta history oracle fallback cap J m v.1 v.2 x) =
        (nativeCappedChoiceLaw r D predict (queryScore predict history) lam B eta hB cap J m x).toMeasure := by
  have heq : (fun v => cappedOracleChoice r lam B eta history oracle fallback cap J m v.1 v.2 x) =ᵐ[
      (nativeNoiseTapeLaw r D J).prod (iidPool (insertedExperimentLaw r D K) m)]
        canonicalTapeChoice r predict (queryScore predict history) lam B eta hB cap J m x := by
    filter_upwards [nativeSamplerGood_ae r D predict (queryScore predict history) lam B eta hB J m] with v hv
    exact cappedOracleChoice_eq_canonical r predict history oracle horacle fallback lam B eta hB cap J m x v hv
  rw [Measure.map_congr heq]
  exact (canonicalTapeChoice_measurePreserving r D predict (queryScore predict history) lam B eta hB cap J m x).map_eq
end
end PoissonAudit
