module

public import PoissonAudit.NativeOneRound
public import PoissonAudit.LaplaceCoordinateVariational

public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section

theorem integral_realLaplace_abs_le_six : (∫ z : ℝ, |z| ∂realLaplace) ≤ 6 := by
  have hp := integrable_realLaplace_exp (t := 1 / 2) (by norm_num)
  have hn := integrable_realLaplace_exp (t := -(1 / 2)) (by norm_num)
  have h := integral_mono integrable_realLaplace_id.abs ((hp.add hn).const_mul 2) (fun z => by
    change |z| ≤ 2 * (Real.exp ((1 / 2) * z) + Real.exp (-(1 / 2) * z))
    rcases le_total 0 z with hz | hz
    · rw [abs_of_nonneg hz]
      nlinarith [Real.add_one_le_exp ((1 / 2) * z), Real.exp_pos (-(1 / 2) * z)]
    · rw [abs_of_nonpos hz]
      nlinarith [Real.add_one_le_exp (-(1 / 2) * z), Real.exp_pos ((1 / 2) * z)])
  change (∫ z : ℝ, |z| ∂realLaplace) ≤ ∫ z, 2 * (Real.exp ((1 / 2) * z) + Real.exp (-(1 / 2) * z)) ∂realLaplace at h
  rw [integral_const_mul, integral_add hp hn, integral_realLaplace_exp (t := 1 / 2) (by norm_num),
    integral_realLaplace_exp (t := -(1 / 2)) (by norm_num)] at h
  norm_num at h ⊢
  linarith

@[expose] def laplaceMarkEnvelope {X : Type*} {K : ℕ} (u : X × (Fin K → ℝ)) : ℝ := ∑ a, |u.2 a|

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem integrable_laplaceMarkEnvelope (D : Measure X) [IsProbabilityMeasure D] :
    Integrable (laplaceMarkEnvelope (X := X) (K := K)) (contextLaplaceLaw D K) := by
  change Integrable (fun u : X × (Fin K → ℝ) => ∑ a, |u.2 a|) (D.prod (laplaceMeasure K))
  apply integrable_finsetSum
  intro a _
  exact (((integrable_laplace_coordinate K a).abs).comp_snd D)

theorem integral_laplaceMarkEnvelope_le (D : Measure X) [IsProbabilityMeasure D] :
    (∫ u, laplaceMarkEnvelope (K := K) u ∂contextLaplaceLaw D K) ≤ 6 * K := by
  unfold laplaceMarkEnvelope contextLaplaceLaw
  rw [integral_prod (fun u : X × (Fin K → ℝ) => ∑ a, |u.2 a|) (integrable_laplaceMarkEnvelope D)]
  simp only [integral_const, probReal_univ, one_smul]
  rw [integral_finsetSum _ (fun a _ => (integrable_laplace_coordinate K a).abs)]
  have h (a : Fin K) : (∫ z : Fin K → ℝ, |z a| ∂laplaceMeasure K) ≤ 6 := by
    rw [laplace_coordinate_integral K a (fun y : ℝ => |y|) continuous_abs.measurable]
    exact integral_realLaplace_abs_le_six
  have hs := Finset.sum_le_sum (s := Finset.univ) (fun a _ => h a)
  simpa [mul_comm] using hs

theorem native_initial_value_bound (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B : ℝ) (hB : 1 ≤ B) :
    nativeVariationalValue r D predict lam B hB (fun _ => 0) ≤
      6 * (r : ℝ) * K + lam * K * Real.log B := by
  classical
  have hs : (1 : X × Fin K → ℝ) ∈ scaleBox (X × Fin K) B := ⟨fun _ => le_rfl, fun _ => hB⟩
  have hv := variationalValue_le (markedPoolLaw r (contextLaplaceLaw D K)) (poissonCoefficient predict)
    (integrable_poissonCoefficient r D predict) (fun j => (D {j.1}).toReal) lam B hB (fun _ => 0) 1 hs
  have hg : Measurable (laplaceMarkEnvelope (X := X) (K := K)) := by unfold laplaceMarkEnvelope; fun_prop
  have hgi := integrable_laplaceMarkEnvelope (K := K) D
  have hpool := integrable_poolSum r (contextLaplaceLaw D K) _ hg hgi
  have hf : affinePoolPotential (markedPoolLaw r (contextLaplaceLaw D K)) (fun _ : P => 0)
      (poissonCoefficient predict) 1 ≤ 6 * (r : ℝ) * K := by
    have h := integral_mono (integrable_affinePoolMax _ (fun _ : P => 0) _ (integrable_poissonCoefficient r D predict) 1)
      hpool (fun pool => by
        apply Finset.sup'_le
        intro p _
        simp only [zero_add]
        rw [poissonCoefficient_expansion]
        apply Finset.sum_le_sum
        intro i _
        change 1 * (pool.2 i).2 (predict p (pool.2 i).1) ≤ ∑ a, |(pool.2 i).2 a|
        simp only [one_mul]
        exact (le_abs_self _).trans (Finset.single_le_sum (f := fun a : Fin K => |(pool.2 i).2 a|) (fun a _ => abs_nonneg _) (Finset.mem_univ (predict p (pool.2 i).1))))
    rw [integral_poolSum r (contextLaplaceLaw D K) _ hg hgi] at h
    have hb := mul_le_mul_of_nonneg_left (integral_laplaceMarkEnvelope_le (K := K) D) r.coe_nonneg
    change affinePoolPotential _ _ _ _ ≤ _ at h
    nlinarith
  have hpen : scalePenalty (fun j : X × Fin K => (D {j.1}).toReal) lam B 1 = lam * K * Real.log B := by
    rw [poisson_scalePenalty_eq]
    simp [div_one, Finset.sum_const, mul_assoc, integral_const, probReal_univ]
  change nativeVariationalValue r D predict lam B hB (fun _ => 0) ≤ _ at hv
  unfold scaleObjective at hv
  rw [hpen] at hv
  linarith

end
end PoissonAudit
