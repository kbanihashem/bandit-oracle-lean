module
public import PoissonAudit.NativeEmpiricalRule
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {A Omega : Type*} [Fintype A] [MeasurableSpace A] [MeasurableSingletonClass A] [MeasurableSpace Omega]

@[expose] def finiteProductWeight (p : A → ℝ) (m : ℕ) (u : Fin m → A) : ℝ := ∏ i, p (u i)

theorem finiteProductWeight_nonneg (p : A → ℝ) (hp : ∀ a, 0 ≤ p a) (m : ℕ) (u : Fin m → A) :
    0 ≤ finiteProductWeight p m u := Finset.prod_nonneg fun i _ => hp (u i)

theorem finiteProductWeight_sum (p : A → ℝ) (hsum : ∑ a, p a = 1) (m : ℕ) :
    (∑ u : Fin m → A, finiteProductWeight p m u) = 1 := by
  classical
  have h := Fintype.prod_sum (fun (_ : Fin m) (a : A) => p a)
  rw [hsum] at h
  simpa only [Finset.prod_const_one, finiteProductWeight] using h.symm

theorem finiteProductWeight_le_one (p : A → ℝ) (hp : ∀ a, 0 ≤ p a) (hsum : ∑ a, p a = 1)
    (m : ℕ) (u : Fin m → A) : finiteProductWeight p m u ≤ 1 := by
  apply Finset.prod_le_one₀
  · intro i _; exact hp (u i)
  · intro i _
    rw [← hsum]
    exact Finset.single_le_sum (fun a _ => hp a) (Finset.mem_univ (u i))

theorem integral_iid_actionPMF (p : A → ℝ) (hp : ∀ a, 0 ≤ p a) (hsum : ∑ a, p a = 1)
    (m : ℕ) (f : (Fin m → A) → ℝ) :
    (∫ u, f u ∂iidPool (actionPMF p hp hsum).toMeasure m) = ∑ u, finiteProductWeight p m u * f u := by
  have hbase (a : A) : (((actionPMF p hp hsum).toMeasure) {a}).toReal = p a := by
    rw [PMF.toMeasure_apply_singleton _ a (measurableSet_singleton a), actionPMF_toReal]
  rw [integral_fintype Integrable.of_finite]
  simp only [iidPool, Measure.real, Measure.pi_singleton, ENNReal.toReal_prod, hbase, smul_eq_mul, finiteProductWeight]

@[expose] def finiteProductMixtureWeight (mu : Measure Omega) (p : Omega → A → ℝ) (m : ℕ) (u : Fin m → A) : ℝ :=
  ∫ z, finiteProductWeight (p z) m u ∂mu

theorem integrable_finiteProductWeight_parameter (mu : Measure Omega) [IsProbabilityMeasure mu]
    (p : Omega → A → ℝ) (hp : ∀ z a, 0 ≤ p z a) (hsum : ∀ z, ∑ a, p z a = 1)
    (hpm : ∀ a, Measurable (fun z => p z a)) (m : ℕ) (u : Fin m → A) :
    Integrable (fun z => finiteProductWeight (p z) m u) mu := by
  have hm : Measurable (fun z => finiteProductWeight (p z) m u) := Finset.measurable_prod _ (fun i _ => hpm (u i))
  apply Integrable.of_bound hm.aestronglyMeasurable 1
  filter_upwards [] with z
  rw [Real.norm_eq_abs, abs_of_nonneg (finiteProductWeight_nonneg (p z) (hp z) m u)]
  exact finiteProductWeight_le_one (p z) (hp z) (hsum z) m u

theorem finiteProductMixtureWeight_nonneg (mu : Measure Omega) (p : Omega → A → ℝ)
    (hp : ∀ z a, 0 ≤ p z a) (m : ℕ) (u : Fin m → A) :
    0 ≤ finiteProductMixtureWeight mu p m u := integral_nonneg fun z => finiteProductWeight_nonneg (p z) (hp z) m u

theorem finiteProductMixtureWeight_sum (mu : Measure Omega) [IsProbabilityMeasure mu]
    (p : Omega → A → ℝ) (hp : ∀ z a, 0 ≤ p z a) (hsum : ∀ z, ∑ a, p z a = 1)
    (hpm : ∀ a, Measurable (fun z => p z a)) (m : ℕ) :
    (∑ u, finiteProductMixtureWeight mu p m u) = 1 := by
  unfold finiteProductMixtureWeight
  rw [← integral_finsetSum _ (fun u _ => integrable_finiteProductWeight_parameter mu p hp hsum hpm m u)]
  simp only [finiteProductWeight_sum _ (hsum _), integral_const, probReal_univ, one_smul]

@[expose] def finiteProductMixtureLaw (mu : Measure Omega) [IsProbabilityMeasure mu]
    (p : Omega → A → ℝ) (hp : ∀ z a, 0 ≤ p z a) (hsum : ∀ z, ∑ a, p z a = 1)
    (hpm : ∀ a, Measurable (fun z => p z a)) (m : ℕ) : PMF (Fin m → A) :=
  actionPMF (finiteProductMixtureWeight mu p m) (finiteProductMixtureWeight_nonneg mu p hp m)
    (finiteProductMixtureWeight_sum mu p hp hsum hpm m)

theorem integral_finiteProductMixtureLaw (mu : Measure Omega) [IsProbabilityMeasure mu]
    (p : Omega → A → ℝ) (hp : ∀ z a, 0 ≤ p z a) (hsum : ∀ z, ∑ a, p z a = 1)
    (hpm : ∀ a, Measurable (fun z => p z a)) (m : ℕ) (f : (Fin m → A) → ℝ) :
    (∫ u, f u ∂(finiteProductMixtureLaw mu p hp hsum hpm m).toMeasure) =
      ∫ z, ∑ u, finiteProductWeight (p z) m u * f u ∂mu := by
  unfold finiteProductMixtureLaw
  rw [integral_actionPMF, integral_finsetSum _ (fun u _ =>
    (integrable_finiteProductWeight_parameter mu p hp hsum hpm m u).mul_const (f u))]
  apply Finset.sum_congr rfl
  intro u _
  exact (integral_mul_const _ _).symm
end
end PoissonAudit
