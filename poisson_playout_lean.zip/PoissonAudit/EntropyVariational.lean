module

public import PoissonAudit.DensityHellinger
public import Mathlib.Analysis.SpecialFunctions.Trigonometric.Series
public import Mathlib.MeasureTheory.Integral.IntegrableOn

public section

open MeasureTheory InformationTheory
open scoped ENNReal

namespace PoissonAudit

theorem entropy_exp_young {x : ℝ} (hx : 0 ≤ x) (y : ℝ) :
    x * y ≤ klFun x + Real.exp y - 1 := by
  by_cases h : x = 0
  · simp [h, klFun_zero, Real.exp_nonneg]
  have hp : 0 < x := lt_of_le_of_ne hx (Ne.symm h)
  have hh := mul_le_mul_of_nonneg_left (Real.add_one_le_exp (y - Real.log x)) hx
  have he : x * Real.exp (y - Real.log x) = Real.exp y := by
    rw [Real.exp_sub, Real.exp_log hp]
    field_simp
  rw [he] at hh
  rw [klFun_apply]
  nlinarith

theorem integrable_klFun_bounded {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) [IsFiniteMeasure mu] (f : Omega → ℝ)
    (hf : Measurable f) (hf0 : ∀ x, 0 ≤ f x) {C : ℝ} (hfC : ∀ x, f x ≤ C) :
    Integrable (fun x => klFun (f x)) mu := by
  obtain ⟨M, hM⟩ := (isCompact_Icc.bddAbove_image continuous_klFun.continuousOn :
    BddAbove (klFun '' Set.Icc 0 C))
  apply Integrable.of_bound (measurable_klFun.comp hf).aestronglyMeasurable M
  filter_upwards [] with x
  change ‖klFun (f x)‖ ≤ M
  rw [Real.norm_eq_abs, abs_of_nonneg (klFun_nonneg (hf0 x))]
  exact hM (Set.mem_image_of_mem _ ⟨hf0 x, hfC x⟩)

theorem density_kl_toReal {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) [IsProbabilityMeasure mu] (f : Omega → ℝ)
    (hf : Measurable f) (hf0 : ∀ x, 0 ≤ f x)
    (hfi : Integrable f mu) (hnorm : (∫ x, f x ∂mu) = 1) :
    (klDiv (mu.withDensity (fun x => ENNReal.ofReal (f x))) mu).toReal =
      ∫ x, klFun (f x) ∂mu := by
  let Q := mu.withDensity (fun x => ENNReal.ofReal (f x))
  have hprob : IsProbabilityMeasure Q := by
    refine ⟨?_⟩
    change (mu.withDensity (fun x => ENNReal.ofReal (f x))) Set.univ = 1
    rw [withDensity_apply _ MeasurableSet.univ, Measure.restrict_univ,
      ← ofReal_integral_eq_lintegral_ofReal hfi (Filter.Eventually.of_forall hf0), hnorm]
    simp
  let _ := hprob
  have hac : Q ≪ mu := withDensity_absolutelyContinuous _ _
  change (klDiv Q mu).toReal = _
  rw [toReal_klDiv_eq_integral_klFun hac]
  apply integral_congr_ae
  filter_upwards [Measure.rnDeriv_withDensity mu hf.ennreal_ofReal] with x hx
  rw [hx, ENNReal.toReal_ofReal (hf0 x)]

theorem density_entropy_variational {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) [IsProbabilityMeasure mu]
    (f g : Omega → ℝ) (hf0 : ∀ x, 0 ≤ f x)
    (hfi : Integrable f mu) (hnorm : (∫ x, f x ∂mu) = 1)
    (hki : Integrable (fun x => klFun (f x)) mu)
    (hfgi : Integrable (fun x => f x * g x) mu)
    (hegi : Integrable (fun x => Real.exp (g x)) mu)
    (hZ : 0 < ∫ x, Real.exp (g x) ∂mu) :
    (∫ x, f x * g x ∂mu) ≤ (∫ x, klFun (f x) ∂mu) +
      Real.log (∫ x, Real.exp (g x) ∂mu) := by
  let Z := ∫ x, Real.exp (g x) ∂mu
  have hZ' : 0 < Z := hZ
  have heqi : Integrable (fun x => Real.exp (g x - Real.log Z)) mu := by
    simp only [Real.exp_sub, Real.exp_log hZ']
    exact hegi.div_const Z
  have heqm : (∫ x, Real.exp (g x - Real.log Z) ∂mu) = 1 := by
    simp only [Real.exp_sub, Real.exp_log hZ']
    rw [integral_div]
    exact div_self hZ.ne'
  have hlefti : Integrable (fun x => f x * (g x - Real.log Z)) mu := by
    simp_rw [mul_sub]
    exact hfgi.sub (hfi.mul_const _)
  have hh := integral_mono hlefti ((hki.add heqi).sub (integrable_const (1 : ℝ)))
    (fun x => entropy_exp_young (hf0 x) (g x - Real.log Z))
  simp only [Pi.add_apply, Pi.sub_apply] at hh
  simp_rw [mul_sub] at hh
  have hsub : (∫ x, klFun (f x) + Real.exp (g x - Real.log Z) - 1 ∂mu) =
      (∫ x, klFun (f x) + Real.exp (g x - Real.log Z) ∂mu) - ∫ _ : Omega, (1 : ℝ) ∂mu :=
    integral_sub (hki.add heqi) (integrable_const (1 : ℝ))
  have hadd : (∫ x, klFun (f x) + Real.exp (g x - Real.log Z) ∂mu) =
      (∫ x, klFun (f x) ∂mu) + ∫ x, Real.exp (g x - Real.log Z) ∂mu :=
    integral_add hki heqi
  rw [integral_sub hfgi (hfi.mul_const _), integral_mul_const, hnorm,
    hsub, hadd, heqm] at hh
  simp only [integral_const, probReal_univ, smul_eq_mul, one_mul] at hh
  linarith

end PoissonAudit
