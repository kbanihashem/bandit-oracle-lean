module
public import PoissonAudit.OracleSamplerCorrect
public section
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X : Type*} {K : ℕ}

theorem buildReplayQueries_input_length (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (cap j : ℕ) (tape : NativeNoiseTape X K j) (hc : nativeTapeCountsBounded cap j tape)
    (Q : List (CostExample X K)) (hQ : Q ∈ buildReplayQueries r lam B eta history oracle fallback j tape) :
    Q.length ≤ history.length + cap + 1 := by
  induction j with
  | zero => simp [buildReplayQueries] at hQ
  | succ j ih =>
    rcases List.mem_append.mp hQ with hQ | hQ
    · exact ih tape.1 hc.1 hQ
    · obtain ⟨qs, hqs, hQ⟩ := List.mem_flatten.mp hQ
      obtain ⟨i, rfl⟩ := List.mem_ofFn.mp hqs
      exact replayQueries_input_length r lam B eta history oracle fallback cap _
        (buildReplayRecords_capped r lam B eta history oracle fallback cap j tape.1 hc.1) _ Q hQ

theorem replayTrialQueries_input_length (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (cap : ℕ) (records : List (ReplayRecord X K)) (hc : ∀ record ∈ records, record.2.length ≤ cap)
    (x : X) (v : NativeNoise X K) (hv : v.2.1 ≤ cap) (Q : List (CostExample X K))
    (hQ : Q ∈ replayTrialQueries r lam B eta history oracle fallback records x v) :
    Q.length ≤ history.length + cap + 1 := by
  rcases List.mem_append.mp hQ with hQ | hQ
  · rcases List.mem_append.mp hQ with hQ | hQ
    · exact replayQueries_input_length r lam B eta history oracle fallback cap records hc x Q hQ
    · obtain ⟨qs, hqs, hQ⟩ := List.mem_flatten.mp hQ
      obtain ⟨i, rfl⟩ := List.mem_ofFn.mp hqs
      exact replayQueries_input_length r lam B eta history oracle fallback cap records hc _ Q hQ
  · have hlen := actionValueQueries_length (history ++ (makeReplayRecord
        (fun y => (replayAt r lam B eta history oracle fallback records y).2) v).2) x
        (fun a => (replayAt r lam B eta history oracle fallback records x).2 a * v.1 a) Q hQ
    rw [hlen, List.length_append, makeReplayRecord_length]
    omega

@[expose] def cappedOracleQueries (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (cap J m : ℕ) (tape : NativeNoiseTape X K J) (trials : Fin m → NativeNoise X K) (x : X) :
    List (List (CostExample X K)) := by
  classical
  exact if nativeTapeCountsBounded cap J tape ∧ ∀ i, (trials i).2.1 ≤ cap then
    buildReplayQueries r lam B eta history oracle fallback J tape ++
      (List.ofFn (fun i => replayTrialQueries r lam B eta history oracle fallback
        (buildReplayRecords r lam B eta history oracle fallback J tape) x (trials i))).flatten else []

theorem cappedOracleQueries_count (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (cap J m : ℕ) (tape : NativeNoiseTape X K J) (trials : Fin m → NativeNoise X K) (x : X) :
    (cappedOracleQueries r lam B eta history oracle fallback cap J m tape trials x).length ≤
      (cap * J ^ 2 + m * ((cap + 1) * J + 1)) * (K + 1) := by
  classical
  unfold cappedOracleQueries
  split_ifs with hc
  · have hb := buildReplayQueries_count r lam B eta history oracle fallback cap J tape hc.1
    simp only [List.length_append, List.length_flatten, List.map_ofFn, List.sum_ofFn, Function.comp_apply,
      replayTrialQueries_count, buildReplayRecords_length]
    have hm : (∑ i : Fin m, (((trials i).2.1 + 1) * J + 1) * (K + 1)) ≤
        m * (((cap + 1) * J + 1) * (K + 1)) := by
      have h := Finset.sum_le_sum (s := Finset.univ) (fun i _ =>
        Nat.mul_le_mul_right (K + 1) (Nat.add_le_add_right (Nat.mul_le_mul_right J (Nat.add_le_add_right (hc.2 i) 1)) 1))
      simpa only [Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul, Nat.cast_id] using h
    calc
      _ ≤ cap * J ^ 2 * (K + 1) + m * (((cap + 1) * J + 1) * (K + 1)) := add_le_add hb hm
      _ = _ := by ring
  · simp

theorem cappedOracleQueries_input_length (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (cap J m : ℕ) (tape : NativeNoiseTape X K J) (trials : Fin m → NativeNoise X K) (x : X)
    (Q : List (CostExample X K)) (hQ : Q ∈ cappedOracleQueries r lam B eta history oracle fallback cap J m tape trials x) :
    Q.length ≤ history.length + cap + 1 := by
  classical
  unfold cappedOracleQueries at hQ
  split_ifs at hQ with hc
  · rcases List.mem_append.mp hQ with hQ | hQ
    · exact buildReplayQueries_input_length r lam B eta history oracle fallback cap J tape hc.1 Q hQ
    · obtain ⟨qs, hqs, hQ⟩ := List.mem_flatten.mp hQ
      obtain ⟨i, rfl⟩ := List.mem_ofFn.mp hqs
      exact replayTrialQueries_input_length r lam B eta history oracle fallback cap _
        (buildReplayRecords_capped r lam B eta history oracle fallback cap J tape hc.1) x (trials i) (hc.2 i) Q hQ
  · simp at hQ

@[expose] def nativeTapePoolSamples : (j : ℕ) → NativeNoiseTape X K j → ℕ
  | 0, _ => 0
  | j + 1, tape => nativeTapePoolSamples j tape.1 + tape.2.2.1

theorem nativeTapePoolSamples_bound (cap J : ℕ) (tape : NativeNoiseTape X K J) (hc : nativeTapeCountsBounded cap J tape) :
    nativeTapePoolSamples J tape ≤ J * cap := by
  induction J with
  | zero => simp [nativeTapePoolSamples]
  | succ j ih =>
    have hi := ih tape.1 hc.1
    change nativeTapePoolSamples j tape.1 + tape.2.2.1 ≤ _
    nlinarith [hc.2]
end
end PoissonAudit
