module
public import PoissonAudit.EmpiricalVariance
public import PoissonAudit.WinnerInformation
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {Omega A : Type*} [MeasurableSpace Omega] [Fintype A] [MeasurableSpace A] [MeasurableSingletonClass A]

theorem outcome_measurePreserving (mu : Measure Omega) [IsProbabilityMeasure mu]
    (W : Omega → A) (hW : Measurable W) :
    MeasurePreserving W mu (actionPMF (outcomeMass mu W) (outcomeMass_nonneg mu W) (sum_outcomeMass mu W hW)).toMeasure := by
  refine ⟨hW, ?_⟩
  apply Measure.ext_of_singleton
  intro a
  rw [Measure.map_apply hW (measurableSet_singleton a), PMF.toMeasure_apply_singleton _ a (measurableSet_singleton a)]
  apply (ENNReal.toReal_eq_toReal_iff' (measure_ne_top _ _) (PMF.apply_ne_top _ a)).mp
  rw [actionPMF_toReal]
  rfl

theorem iid_outcome_measurePreserving (mu : Measure Omega) [IsProbabilityMeasure mu]
    (W : Omega → A) (hW : Measurable W) (m : ℕ) :
    MeasurePreserving (fun u : Fin m → Omega => fun i => W (u i)) (iidPool mu m)
      (iidPool (actionPMF (outcomeMass mu W) (outcomeMass_nonneg mu W) (sum_outcomeMass mu W hW)).toMeasure m) :=
  measurePreserving_pi (fun _ : Fin m => mu) (fun _ => _)
    (fun _ => outcome_measurePreserving mu W hW)

theorem empirical_outcome_l1_error (mu : Measure Omega) [IsProbabilityMeasure mu]
    (W : Omega → A) (hW : Measurable W) (m : ℕ) (hm : 0 < m) :
    (∫ u : Fin m → Omega, ∑ a, |empiricalFrequency m a (fun i => W (u i)) - outcomeMass mu W a| ∂iidPool mu m) ≤
      Fintype.card A * Real.sqrt (1 / m) := by
  let p := outcomeMass mu W
  let cat := (actionPMF p (outcomeMass_nonneg mu W) (sum_outcomeMass mu W hW)).toMeasure
  have hmp := iid_outcome_measurePreserving mu W hW m
  let f := fun u : Fin m → A => ∑ a, |empiricalFrequency m a u - p a|
  have h := integral_map hmp.measurable.aemeasurable (f := f)
    (by rw [hmp.map_eq]; exact (measurable_of_finite f).aestronglyMeasurable)
  rw [hmp.map_eq] at h
  change (∫ u, f u ∂iidPool cat m) = _ at h
  rw [← h]
  exact empiricalFrequency_l1_error p (outcomeMass_nonneg mu W) (sum_outcomeMass mu W hW) m hm
end
end PoissonAudit
