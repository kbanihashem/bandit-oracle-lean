module
public import PoissonAudit.FiniteKernelMixture
public import PoissonAudit.NativeOverflowBudget
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def nativeEnrichedTrial (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (cap : ℕ) (v : NativeNoise X K) : Fin K × Bool :=
  (experimentAction predict sigma S x v, nativeOverflowBool cap v)

theorem measurable_nativeEnrichedTrial (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (cap : ℕ) : Measurable (nativeEnrichedTrial predict sigma S x cap) :=
  (measurable_experimentAction predict sigma S x).prodMk (measurable_nativeOverflowBool cap)

theorem measurable_joint_nativeEnrichedTrial (predict : P → X → Fin K) (S : P → ℝ) (x : X) (cap : ℕ) :
    Measurable (fun v : (X × Fin K → ℝ) × NativeNoise X K => nativeEnrichedTrial predict v.1 S x cap v.2) :=
  ((measurable_of_finite (fun p => predict p x)).comp (measurable_joint_experimentWinner predict S x)).prodMk
    ((measurable_nativeOverflowBool cap).comp measurable_snd)

@[expose] def nativeEnrichedProbability (r : NNReal) (D : Measure X) (predict : P → X → Fin K)
    (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (cap : ℕ) (a : Fin K × Bool) : ℝ :=
  outcomeMass (insertedExperimentLaw r D K) (nativeEnrichedTrial predict sigma S x cap) a

theorem nativeEnrichedProbability_nonneg (r : NNReal) (D : Measure X) (predict : P → X → Fin K)
    (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (cap : ℕ) (a : Fin K × Bool) :
    0 ≤ nativeEnrichedProbability r D predict sigma S x cap a := outcomeMass_nonneg _ _ _

theorem nativeEnrichedProbability_sum (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (cap : ℕ) :
    (∑ a, nativeEnrichedProbability r D predict sigma S x cap a) = 1 :=
  sum_outcomeMass _ _ (measurable_nativeEnrichedTrial predict sigma S x cap)

theorem measurable_nativeEnrichedProbability_scale (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (x : X) (cap : ℕ) (a : Fin K × Bool) :
    Measurable (fun sigma : X × Fin K → ℝ => nativeEnrichedProbability r D predict sigma S x cap a) :=
  measurable_outcomeMass_parameter (insertedExperimentLaw r D K)
    (fun v : (X × Fin K → ℝ) × NativeNoise X K => nativeEnrichedTrial predict v.1 S x cap v.2)
    (measurable_joint_nativeEnrichedTrial predict S x cap) a

@[expose] def nativeEnrichedLaw (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (cap : ℕ) : PMF (Fin K × Bool) :=
  actionPMF (nativeEnrichedProbability r D predict sigma S x cap)
    (nativeEnrichedProbability_nonneg r D predict sigma S x cap) (nativeEnrichedProbability_sum r D predict sigma S x cap)

@[expose] def nativeActionLaw (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) : PMF (Fin K) :=
  actionPMF (experimentProbability r D predict sigma S x) (experimentProbability_nonneg r D predict sigma S x)
    (sum_experimentProbability r D predict sigma S x)

theorem nativeEnrichedLaw_measurePreserving (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (cap : ℕ) :
    MeasurePreserving (nativeEnrichedTrial predict sigma S x cap) (insertedExperimentLaw r D K)
      (nativeEnrichedLaw r D predict sigma S x cap).toMeasure :=
  outcome_measurePreserving _ _ (measurable_nativeEnrichedTrial predict sigma S x cap)

theorem nativeEnrichedLaw_action_projection (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (cap : ℕ) :
    MeasurePreserving Prod.fst (nativeEnrichedLaw r D predict sigma S x cap).toMeasure
      (nativeActionLaw r D predict sigma S x).toMeasure := by
  have he := nativeEnrichedLaw_measurePreserving r D predict sigma S x cap
  have ha := outcome_measurePreserving (insertedExperimentLaw r D K) (experimentAction predict sigma S x)
    (measurable_experimentAction predict sigma S x)
  refine ⟨measurable_fst, ?_⟩
  rw [← he.map_eq, Measure.map_map measurable_fst he.measurable]
  exact ha.map_eq

theorem nativeEnrichedLaw_overflow_mean (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (cap : ℕ) :
    (∫ a : Fin K × Bool, boolStatistic a.2 ∂(nativeEnrichedLaw r D predict sigma S x cap).toMeasure) =
      (insertedExperimentLaw r D K).real (nativeOverflowEvent cap) := by
  have he := nativeEnrichedLaw_measurePreserving r D predict sigma S x cap
  have h := integral_map he.measurable.aemeasurable (f := fun a : Fin K × Bool => boolStatistic a.2)
    (by rw [he.map_eq]; exact (measurable_of_finite _).aestronglyMeasurable)
  rw [he.map_eq] at h
  change (∫ a : Fin K × Bool, boolStatistic a.2 ∂(nativeEnrichedLaw r D predict sigma S x cap).toMeasure) =
    ∫ v, boolStatistic (nativeOverflowBool cap v) ∂insertedExperimentLaw r D K at h
  rw [integral_nativeOverflowStatistic r D cap] at h
  exact h
end
end PoissonAudit
