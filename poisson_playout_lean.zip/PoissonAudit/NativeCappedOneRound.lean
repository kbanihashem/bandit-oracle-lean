module
public import PoissonAudit.NativeCappedMeanAccuracy
public import PoissonAudit.NativeProbabilityPerturbation
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem native_capped_one_round_bound (r : NNReal) (hr : 0 < (r : ℝ)) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eps delta gamma : ℝ)
    (hlam : 0 < lam) (hB : 1 ≤ B) (heps : 0 < eps) (hd : 0 < delta) (hK : 0 < K)
    (hg : 0 < gamma) (hgsmall : gamma ≤ 1 / 2) (hcap : (K : ℝ) / gamma ≤ B)
    (hlamBudget : 4 * (r : ℝ) * explorationLog K gamma ≤ lam)
    (s : NativeScaleBox X K B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun q => (D {q.1}).toReal) lam B) (scaleBox (X × Fin K) B) s.val)
    (hepsBudget : eps ≤ lam * delta ^ 2 / (32 * B ^ 2 * ((r : ℝ) + 1) ^ 2 * K))
    (c : X → Fin K → ℝ) (hc0 : ∀ x a, 0 ≤ c x a) (hc1 : ∀ x a, c x a ≤ 1) :
    let J := nativeSGDIterations r K lam B eps
    let m := nativeEmpiricalTrials K delta
    let cap := nativeCountCap r (J + m) delta
    let eta := eps / (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2))
    (∫ x, ∫ choice, nativeRoundFunctional r D predict lam B hB S x (c x) (choiceProbability K gamma m choice)
      ∂(nativeCappedChoiceLaw r D predict S lam B eta hB cap J m x).toMeasure ∂D) ≤
        nativeRoundSlack P r K lam B gamma + (1 + K / gamma) * delta := by
  dsimp only
  let J := nativeSGDIterations r K lam B eps
  let m := nativeEmpiricalTrials K delta
  let cap := nativeCountCap r (J + m) delta
  let eta := eps / (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2))
  let nu := fun x => (nativeCappedChoiceLaw r D predict S lam B eta hB cap J m x).toMeasure
  let ideal := nativeBanditProbability r D predict s.val S gamma
  let err := fun x choice => ∑ a, |choiceProbability K gamma m choice a - ideal x a|
  let Phi := fun x q => nativeRoundFunctional r D predict lam B hB S x (c x) q
  let C : ℝ := 1 + K / gamma
  have hC : 0 ≤ C := by dsimp [C]; positivity
  have hgm : gamma ≤ 1 := by linarith
  have hm : 0 < m := nativeEmpiricalTrials_pos K delta
  have hp (x : X) (choice : EmpiricalChoice K m) : Phi x (choiceProbability K gamma m choice) ≤ Phi x (ideal x) + C * err x choice := by
    have h := native_probability_perturbation r D predict lam B gamma hlam.le hB hK hg S x (c x)
      (choiceProbability K gamma m choice) (ideal x) (hc0 x) (hc1 x)
      (choiceProbability_floor gamma hgm m hm choice)
      (fun a => exploration_floor (experimentProbability_nonneg r D predict s.val S x a) hgm)
    have hab := (le_abs_self _).trans h
    change Phi x (choiceProbability K gamma m choice) - Phi x (ideal x) ≤ C * err x choice at hab
    linarith
  have hx (x : X) : (∫ choice, Phi x (choiceProbability K gamma m choice) ∂nu x) ≤
      Phi x (ideal x) + C * (∫ choice, err x choice ∂nu x) := by
    have h := integral_mono (μ := nu x) Integrable.of_finite Integrable.of_finite (hp x)
    rw [integral_add (integrable_const _) Integrable.of_finite, integral_const_mul,
      integral_const, probReal_univ, one_smul] at h
    exact h
  have houter := integral_mono (μ := D) Integrable.of_finite Integrable.of_finite hx
  rw [integral_add Integrable.of_finite Integrable.of_finite, integral_const_mul] at houter
  have hac := native_capped_mean_action_accuracy r D predict S lam B eps delta gamma hlam hB heps hd hK hg.le hgm s hmin hepsBudget
  change (∫ x, ∫ choice, err x choice ∂nu x ∂D) ≤ delta at hac
  have hideal := native_one_round_bound r hr D predict s.val S lam B gamma hK hg hgsmall hlam hB hcap hlamBudget s.property hmin c hc0 hc1
  change (∫ x, Phi x (ideal x) ∂D) ≤ nativeRoundSlack P r K lam B gamma at hideal
  have hacc := mul_le_mul_of_nonneg_left hac hC
  change _ ≤ nativeRoundSlack P r K lam B gamma + C * delta
  linarith
end
end PoissonAudit
