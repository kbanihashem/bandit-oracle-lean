module
public import PoissonAudit.NativeTuning
public section
namespace PoissonAudit
noncomputable section

theorem powerSearch_exists (b : ℝ) (hb : 1 < b) (x : ℝ) : ∃ n : ℕ, x ≤ b ^ n := by
  by_cases hx : x ≤ 1
  · exact ⟨0, by simpa using hx⟩
  · obtain ⟨n, _, hn⟩ := exists_nat_pow_near (le_of_not_ge hx) hb
    exact ⟨n + 1, hn.le⟩

@[expose] def powerSearch (b : ℝ) (hb : 1 < b) (x : ℝ) : ℕ :=
  Nat.find (powerSearch_exists b hb x)

theorem powerSearch_spec (b : ℝ) (hb : 1 < b) (x : ℝ) : x ≤ b ^ powerSearch b hb x :=
  Nat.find_spec (powerSearch_exists b hb x)

theorem powerSearch_previous (b : ℝ) (hb : 1 < b) (x : ℝ) {n : ℕ} (hn : n < powerSearch b hb x) : b ^ n < x :=
  lt_of_not_ge (Nat.find_min (powerSearch_exists b hb x) hn)

theorem powerSearch_upper (b : ℝ) (hb : 1 < b) (x : ℝ) (hx : 1 ≤ x) :
    b ^ powerSearch b hb x ≤ b * x := by
  generalize hn : powerSearch b hb x = n
  cases n with
  | zero => simp only [pow_zero]; nlinarith
  | succ n =>
    have h := powerSearch_previous b hb x (n := n) (by omega)
    rw [pow_succ]
    nlinarith

theorem powerSearch_log_bound (b : ℝ) (hb : 1 < b) (x : ℝ) (hx : 1 ≤ x) :
    (powerSearch b hb x : ℝ) * Real.log b ≤ Real.log b + Real.log x := by
  have h := Real.log_le_log (pow_pos (by linarith : 0 < b) _) (powerSearch_upper b hb x hx)
  rwa [Real.log_pow, Real.log_mul (by linarith : b ≠ 0) (by linarith : x ≠ 0)] at h

@[expose] def arithmeticTuningA (x : ℝ) : ℝ := 2 ^ powerSearch 4 (by norm_num) x
@[expose] def arithmeticTuningLog (B : ℝ) : ℝ := 1 + powerSearch 2 (by norm_num) B

theorem arithmeticTuningA_bounds (x : ℝ) (hx : 1 ≤ x) :
    1 ≤ arithmeticTuningA x ∧ x ≤ arithmeticTuningA x ^ 2 ∧ arithmeticTuningA x ^ 2 ≤ 4 * x := by
  have he : arithmeticTuningA x ^ 2 = 4 ^ powerSearch 4 (by norm_num) x := by
    unfold arithmeticTuningA
    rw [← pow_mul, Nat.mul_comm, pow_mul]
    norm_num
  refine ⟨(show 1 ≤ (2 : ℝ) ^ powerSearch 4 (by norm_num) x from one_le_pow₀ (by norm_num)), ?_, ?_⟩
  · rw [he]; exact powerSearch_spec 4 (by norm_num) x
  · rw [he]; exact powerSearch_upper 4 (by norm_num) x hx

theorem arithmeticTuningLog_bounds (B : ℝ) (hB : 1 ≤ B) :
    1 ≤ arithmeticTuningLog B ∧ 1 + Real.log B ≤ arithmeticTuningLog B ∧
      arithmeticTuningLog B ≤ 3 * (1 + Real.log B) := by
  have hlog2 : (1 : ℝ) / 2 ≤ Real.log 2 := by
    have h := Real.one_sub_inv_le_log_of_pos (by norm_num : (0 : ℝ) < 2)
    norm_num at h ⊢
    exact h
  have hlog2u : Real.log 2 ≤ 1 := by linarith [Real.log_le_sub_one_of_pos (by norm_num : (0 : ℝ) < 2)]
  have hn0 : (0 : ℝ) ≤ powerSearch 2 (by norm_num) B := Nat.cast_nonneg _
  have hl := powerSearch_log_bound 2 (by norm_num) B hB
  have hlo := Real.log_le_log (by linarith : 0 < B) (powerSearch_spec 2 (by norm_num) B)
  rw [Real.log_pow] at hlo
  dsimp only [arithmeticTuningLog]
  refine ⟨by linarith, ?_, ?_⟩
  · nlinarith
  · nlinarith [Real.log_nonneg hB]

theorem arithmetic_tuning_charges {k t L z : ℝ} (hk : 1 ≤ k) (ht : 1 ≤ t) (hL : 1 ≤ L)
    (hz : 0 ≤ z) (hzL : z ≤ L) :
    let B := k * (t + 1)
    let gamma := 1 / (t + 1)
    let ell := arithmeticTuningLog B
    let A := arithmeticTuningA (k * t * L)
    let r := A / (k * ell)
    let lam := 4 * A / k
    0 < r ∧ 0 < lam ∧ 1 ≤ B ∧ 0 < gamma ∧ gamma ≤ 1 / 2 ∧ k / gamma = B ∧
      4 * r * (1 + Real.log B) ≤ lam ∧
      (6 * r * k + lam * k * Real.log B +
        t * (gamma + (Real.exp 1 - 2) / (1 - gamma) * (4 * z / lam + k / B) +
          2 * Real.exp 1 * z / r) ≤ 10 * Real.exp 1 * A * ell) := by
  dsimp only
  let B := k * (t + 1)
  let gamma := 1 / (t + 1)
  let ell := arithmeticTuningLog B
  let A := arithmeticTuningA (k * t * L)
  let r := A / (k * ell)
  let lam := 4 * A / k
  have hk0 : 0 < k := by linarith
  have ht0 : 0 < t := by linarith
  have ht1 : 0 < t + 1 := by linarith
  have hB : 1 ≤ B := by dsimp [B]; nlinarith
  have hB0 : 0 < B := by linarith
  have hel := arithmeticTuningLog_bounds B hB
  have hell : 1 ≤ ell := hel.1
  have hell0 : 0 < ell := by linarith
  have hprod : 1 ≤ k * t * L := by nlinarith [mul_le_mul hk ht (by linarith) (by linarith)]
  have hAb := arithmeticTuningA_bounds (k * t * L) hprod
  have hA : 1 ≤ A := hAb.1
  have hA2 : k * t * L ≤ A ^ 2 := hAb.2.1
  have hAp : 0 < A := by linarith
  have hr : 0 < r := div_pos hAp (mul_pos hk0 hell0)
  have hlam : 0 < lam := div_pos (by positivity) hk0
  have hg : 0 < gamma := one_div_pos.mpr ht1
  have hgs : gamma ≤ 1 / 2 := by dsimp [gamma]; apply (div_le_iff₀ ht1).mpr; linarith
  have hcap : k / gamma = B := by dsimp [gamma, B]; field_simp
  have hrate : 4 * r * ell = lam := by dsimp [r, lam]; field_simp
  have hrateLe : 4 * r * (1 + Real.log B) ≤ lam := by rw [← hrate]; exact mul_le_mul_of_nonneg_left hel.2.1 (by positivity)
  have hlamK : lam * k = 4 * A := by dsimp [lam]; field_simp
  have hrK : r * k ≤ A := by
    have heq : r * k = A / ell := by dsimp [r]; field_simp
    rw [heq]
    apply (div_le_iff₀ hell0).mpr
    nlinarith
  have hTg : t * gamma ≤ 1 := by dsimp [gamma]; rw [mul_one_div]; apply (div_le_one ht1).mpr; linarith
  have hTB : t * k / B ≤ 1 := by apply (div_le_one hB0).mpr; dsimp [B]; nlinarith
  have htz : k * t * z ≤ k * t * L := mul_le_mul_of_nonneg_left hzL (by positivity)
  have hTL : 4 * t * z / lam ≤ A := by
    apply (div_le_iff₀ hlam).mpr
    dsimp [lam]
    rw [← mul_div_assoc]
    apply (le_div_iff₀ hk0).mpr
    nlinarith
  have hTn : t * z / r ≤ A * ell := by
    apply (div_le_iff₀ hr).mpr
    dsimp [r]
    rw [← mul_div_assoc]
    apply (le_div_iff₀ (mul_pos hk0 hell0)).mpr
    nlinarith [mul_nonneg (by linarith : 0 ≤ A ^ 2 - k * t * z) (sq_nonneg ell)]
  exact ⟨hr, hlam, hB, hg, hgs, hcap, hrateLe,
    tuned_regret_charges ht0.le hk0 hz hA hell hr hlam hB0 hgs hTg hTB hTL hTn hrK hlamK (by linarith [hel.2.1])⟩
end
end PoissonAudit
