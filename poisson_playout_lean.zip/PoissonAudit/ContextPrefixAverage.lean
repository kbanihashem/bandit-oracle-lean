module

public import PoissonAudit.ConditionalMomentBounds

public section

open MeasureTheory Set

namespace PoissonAudit

noncomputable section

variable {X : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X]

@[expose] def contextPrefixField (f : (n : ℕ) → (Fin n → X) → ℝ) (pool : ℕ × (ℕ → X)) : ℝ :=
  f pool.1 (poolPrefix pool.1 pool.2)

theorem measurable_contextPrefixField (f : (n : ℕ) → (Fin n → X) → ℝ) :
    Measurable (contextPrefixField f) :=
  measurable_from_prod_countable_right fun n =>
    (measurable_of_finite (f n)).comp (measurable_poolPrefix n)

theorem integrable_contextPrefixField (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (f : (n : ℕ) → (Fin n → X) → ℝ) (B : ℝ) (hB : ∀ n C, |f n C| ≤ B) :
    Integrable (contextPrefixField f) (markedPoolLaw r D) := by
  apply Integrable.of_bound (measurable_contextPrefixField f).aestronglyMeasurable B
  filter_upwards [] with pool
  exact hB pool.1 (poolPrefix pool.1 pool.2)

theorem integral_contextPrefixField (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (f : (n : ℕ) → (Fin n → X) → ℝ) (B : ℝ) (hB : ∀ n C, |f n C| ≤ B) :
    (∫ pool, contextPrefixField f pool ∂markedPoolLaw r D) =
      ∫ n, (∫ C, f n C ∂iidPool D n) ∂ProbabilityTheory.poissonMeasure r := by
  have hi := integrable_contextPrefixField r D f B hB
  change (∫ pool, contextPrefixField f pool ∂(ProbabilityTheory.poissonMeasure r).prod (markSequence D)) = _
  rw [integral_prod _ hi]
  apply integral_congr_ae
  filter_upwards [] with n
  change (∫ u, f n (poolPrefix n u) ∂markSequence D) = _
  have hmp := poolPrefix_measurePreserving D n
  have h := integral_map hmp.measurable.aemeasurable (f := f n)
    (by rw [hmp.map_eq]; exact (measurable_of_finite (f n)).aestronglyMeasurable)
  rw [hmp.map_eq] at h
  exact h.symm

end

end PoissonAudit
