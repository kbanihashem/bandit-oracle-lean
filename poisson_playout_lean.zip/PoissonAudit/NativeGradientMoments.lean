module
public import PoissonAudit.NativeSampledGradient
public import PoissonAudit.BoxGradientStep
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem context_action_mass_sum (D : Measure X) [IsProbabilityMeasure D] :
    (∑ j : X × Fin K, (D {j.1}).toReal) = K := by
  simp only [Fintype.sum_prod_type, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
  rw [← Finset.mul_sum, context_mass_sum D, mul_one]

@[expose] def nativeGradientSquaredNorm (D : Measure X) (g : X × Fin K → ℝ) : ℝ :=
  ∑ j, (D {j.1}).toReal * (g j) ^ 2

@[expose] def nativeGradientInner (D : Measure X) (sigma s g : X × Fin K → ℝ) : ℝ :=
  ∑ j, (sigma j - s j) * ((D {j.1}).toReal * g j)

theorem integrable_nativeGradientSquaredNorm (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (lam : ℝ)
    (hs : ∀ j, 1 ≤ sigma j) :
    Integrable (fun v => nativeGradientSquaredNorm D (nativeSampledGradient r predict sigma S lam v))
      (insertedExperimentLaw r D K) := by
  exact integrable_finsetSum _ (fun j _ =>
    (integrable_nativeSampledGradient_square r D predict sigma S lam j (hs j)).const_mul _)

theorem nativeGradientSquaredNorm_expectation (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (lam : ℝ)
    (hs : ∀ j, 1 ≤ sigma j) :
    (∫ v, nativeGradientSquaredNorm D (nativeSampledGradient r predict sigma S lam v)
      ∂insertedExperimentLaw r D K) ≤ K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2) := by
  unfold nativeGradientSquaredNorm
  rw [integral_finsetSum _ (fun j _ =>
    (integrable_nativeSampledGradient_square r D predict sigma S lam j (hs j)).const_mul _)]
  simp only [integral_const_mul]
  have h := Finset.sum_le_sum (s := Finset.univ) fun j _ => mul_le_mul_of_nonneg_left
    (integral_nativeSampledGradient_square_le r D predict sigma S lam j (hs j)) (show 0 ≤ (D {j.1}).toReal from ENNReal.toReal_nonneg)
  rw [← Finset.sum_mul, context_action_mass_sum D] at h
  exact h

theorem integrable_nativeGradientInner (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma s : X × Fin K → ℝ) (S : P → ℝ) (lam : ℝ) :
    Integrable (fun v => nativeGradientInner D sigma s (nativeSampledGradient r predict sigma S lam v))
      (insertedExperimentLaw r D K) := by
  exact integrable_finsetSum _ (fun j _ =>
    ((integrable_nativeSampledGradient r D predict sigma S lam j).const_mul _).const_mul _)

theorem nativeGradientInner_expectation (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma s : X × Fin K → ℝ) (S : P → ℝ) (lam : ℝ) :
    (∫ v, nativeGradientInner D sigma s (nativeSampledGradient r predict sigma S lam v)
      ∂insertedExperimentLaw r D K) =
      ∑ j, (sigma j - s j) * poissonCoordinateGradient r D predict sigma S lam j := by
  unfold nativeGradientInner
  rw [integral_finsetSum _ (fun j _ =>
    ((integrable_nativeSampledGradient r D predict sigma S lam j).const_mul _).const_mul _)]
  simp only [integral_const_mul, nativeSampledGradient_mean]

theorem native_stochastic_supporting (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (sigma s : X × Fin K → ℝ)
    (lam B : ℝ) (hlam : 0 ≤ lam) (hB : 0 < B)
    (hsigma : ∀ j, 0 < sigma j) (hs : ∀ j, 0 < s j) :
    scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun j => (D {j.1}).toReal) lam B sigma -
      scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
        (fun j => (D {j.1}).toReal) lam B s ≤
      (∫ v, nativeGradientInner D sigma s (nativeSampledGradient r predict sigma S lam v)
        ∂insertedExperimentLaw r D K) := by
  rw [nativeGradientInner_expectation]
  exact poisson_objective_supporting r D predict S sigma s lam B hlam hB hsigma hs
end
end PoissonAudit
