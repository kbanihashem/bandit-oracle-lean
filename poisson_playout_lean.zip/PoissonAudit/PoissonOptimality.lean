module

public import PoissonAudit.PoissonDerivative
public import PoissonAudit.LogPenaltyDerivative
public import PoissonAudit.BoxOptimality

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem hasDerivAt_poisson_objective (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma h : X × Fin K → ℝ)
    (hsigma : ∀ j, 0 < sigma j) (S : P → ℝ) (lam B : ℝ) (hB : 0 < B) :
    HasDerivAt
      (fun t : ℝ => scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
        (fun j => (D {j.1}).toReal) lam B (fun j => sigma j + t * h j))
      ((∫ pool, ∑ j, h j * poissonCoefficient predict pool (poissonWinner predict sigma S pool) j
        ∂markedPoolLaw r (contextLaplaceLaw D K)) - lam * ∑ j, (D {j.1}).toReal * h j / sigma j) 0 := by
  have hF := hasDerivAt_poisson_potential r D predict sigma h hsigma S
  have hC := hasDerivAt_scalePenalty_line (fun j => (D {j.1}).toReal) sigma h lam B hB hsigma
  convert! hF.add hC using 1

@[expose] def poissonCoordinateGradient (r : NNReal) (D : Measure X)
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (lam : ℝ) (j : X × Fin K) : ℝ :=
  (∫ pool, poissonCoefficient predict pool (poissonWinner predict sigma S pool) j
    ∂markedPoolLaw r (contextLaplaceLaw D K)) - lam * (D {j.1}).toReal / sigma j

theorem hasDerivAt_poisson_coordinate (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (hsigma : ∀ j, 0 < sigma j) (S : P → ℝ) (lam B : ℝ) (hB : 0 < B) (j : X × Fin K) :
    HasDerivAt (fun t : ℝ => scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun k => (D {k.1}).toReal) lam B (coordinateLine sigma j t))
      (poissonCoordinateGradient r D predict sigma S lam j) 0 := by
  classical
  have h := hasDerivAt_poisson_objective r D predict sigma (coordinateDirection j) hsigma S lam B hB
  have hslope (pool : ℕ × (ℕ → X × (Fin K → ℝ))) :
      (∑ k, coordinateDirection j k * poissonCoefficient predict pool (poissonWinner predict sigma S pool) k) =
      poissonCoefficient predict pool (poissonWinner predict sigma S pool) j := by
    simp [coordinateDirection, ite_mul]
  have hpen : (∑ k, (D {k.1}).toReal * coordinateDirection j k / sigma k) =
      (D {j.1}).toReal / sigma j := by
    simp [coordinateDirection, mul_ite, ite_div]
  simp_rw [hslope] at h
  rw [hpen] at h
  convert! h using 1
  unfold poissonCoordinateGradient
  ring

theorem poisson_minimizer_gradient_nonneg (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (lam B : ℝ) (hB : 1 ≤ B)
    (hsigma : sigma ∈ scaleBox (X × Fin K) B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun j => (D {j.1}).toReal) lam B) (scaleBox (X × Fin K) B) sigma)
    (j : X × Fin K) (hj : sigma j < B) : 0 ≤ poissonCoordinateGradient r D predict sigma S lam j := by
  apply box_minimizer_derivative_nonneg _ sigma B hsigma hmin j hj
  apply hasDerivAt_poisson_coordinate r D predict sigma _ S lam B (by linarith) j
  intro k
  have hk : (1 : ℝ) ≤ sigma k := hsigma.1 k
  linarith

theorem poisson_minimizer_gradient_nonpos (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (lam B : ℝ) (hB : 1 ≤ B)
    (hsigma : sigma ∈ scaleBox (X × Fin K) B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun j => (D {j.1}).toReal) lam B) (scaleBox (X × Fin K) B) sigma)
    (j : X × Fin K) (hj : 1 < sigma j) : poissonCoordinateGradient r D predict sigma S lam j ≤ 0 := by
  apply box_minimizer_derivative_nonpos _ sigma B hsigma hmin j hj
  apply hasDerivAt_poisson_coordinate r D predict sigma _ S lam B (by linarith) j
  intro k
  have hk : (1 : ℝ) ≤ sigma k := hsigma.1 k
  linarith

theorem poisson_minimizer_gradient_eq_zero (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (lam B : ℝ) (hB : 1 ≤ B)
    (hsigma : sigma ∈ scaleBox (X × Fin K) B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun j => (D {j.1}).toReal) lam B) (scaleBox (X × Fin K) B) sigma)
    (j : X × Fin K) (hj0 : 1 < sigma j) (hj1 : sigma j < B) :
    poissonCoordinateGradient r D predict sigma S lam j = 0 :=
  le_antisymm (poisson_minimizer_gradient_nonpos r D predict sigma S lam B hB hsigma hmin j hj0)
    (poisson_minimizer_gradient_nonneg r D predict sigma S lam B hB hsigma hmin j hj1)

end

end PoissonAudit
