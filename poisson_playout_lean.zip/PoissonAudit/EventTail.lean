module

public import PoissonAudit.LaplaceEntropy
public import PoissonAudit.ScalarProbabilityControl

public section

open MeasureTheory InformationTheory Set
open scoped ENNReal

namespace PoissonAudit

noncomputable section

@[expose] def eventDensity {Omega : Type*} [MeasurableSpace Omega] (mu : Measure Omega) (E : Set Omega)
    (omega : Omega) : ℝ := E.indicator (fun _ => (1 : ℝ)) omega / (mu E).toReal

theorem integral_eventIndicator {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) (E : Set Omega) (hE : MeasurableSet E) :
    (∫ omega, E.indicator (fun _ => (1 : ℝ)) omega ∂mu) = (mu E).toReal := by
  rw [integral_indicator hE]
  simp [Measure.real]

theorem measurable_eventDensity {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) (E : Set Omega) (hE : MeasurableSet E) : Measurable (eventDensity mu E) :=
  (measurable_const.indicator hE).div_const _

theorem integrable_eventDensity {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) [IsProbabilityMeasure mu] (E : Set Omega) (hE : MeasurableSet E) :
    Integrable (eventDensity mu E) mu :=
  ((integrable_const (1 : ℝ)).indicator hE).div_const _

theorem eventDensity_nonneg {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) (E : Set Omega) (omega : Omega) : 0 ≤ eventDensity mu E omega := by
  classical
  by_cases h : omega ∈ E <;> simp [eventDensity, h, ENNReal.toReal_nonneg]

theorem eventDensity_le {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) (E : Set Omega) (hp : 0 < (mu E).toReal) (omega : Omega) :
    eventDensity mu E omega ≤ 1 / (mu E).toReal := by
  classical
  apply div_le_div_of_nonneg_right _ hp.le
  by_cases h : omega ∈ E <;> simp [h]

theorem integral_eventDensity {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) [IsProbabilityMeasure mu] (E : Set Omega) (hE : MeasurableSet E)
    (hp : 0 < (mu E).toReal) : (∫ omega, eventDensity mu E omega ∂mu) = 1 := by
  unfold eventDensity
  rw [integral_div, integral_eventIndicator mu E hE]
  exact div_self hp.ne'

theorem entropy_eventDensity {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) [IsProbabilityMeasure mu] (E : Set Omega) (hE : MeasurableSet E)
    (hp : 0 < (mu E).toReal) :
    (∫ omega, klFun (eventDensity mu E omega) ∂mu) = -Real.log (mu E).toReal := by
  classical
  let p := (mu E).toReal
  have hgi := (integrable_const (1 : ℝ) (μ := mu)).indicator hE
  have heq : (fun omega => klFun (eventDensity mu E omega)) =
      fun omega => (klFun (1 / p) - 1) * E.indicator (fun _ => (1 : ℝ)) omega + 1 := by
    funext omega
    by_cases h : omega ∈ E <;> simp [eventDensity, h, p, klFun_zero]
  rw [heq, integral_add (hgi.const_mul _) (integrable_const (1 : ℝ)), integral_const_mul,
    integral_eventIndicator mu E hE]
  simp only [integral_const, probReal_univ, smul_eq_mul, one_mul]
  change (klFun (1 / p) - 1) * p + 1 = -Real.log p
  have hpne : p ≠ 0 := hp.ne'
  rw [klFun_apply, Real.log_div (by norm_num) hpne, Real.log_one]
  field_simp [hpne]
  ring

theorem laplace_event_mean_le {B : Type*} [MeasurableSpace B]
    (nu : Measure B) [IsProbabilityMeasure nu] (E : Set (ℝ × B)) (hE : MeasurableSet E)
    (hp : 0 < (realLaplace.prod nu E).toReal) :
    (∫ v : ℝ × B, E.indicator (fun _ => (1 : ℝ)) v * v.1 ∂realLaplace.prod nu) ≤
      2 * (realLaplace.prod nu E).toReal * (1 - Real.log (realLaplace.prod nu E).toReal) := by
  classical
  let mu := realLaplace.prod nu
  let p := (mu E).toReal
  let f := eventDensity mu E
  have hf0 : ∀ v, 0 ≤ f v := eventDensity_nonneg mu E
  have hfm : Measurable f := measurable_eventDensity mu E hE
  have hfi := integrable_eventDensity mu E hE
  have hfn := integral_eventDensity mu E hE hp
  have hki := integrable_klFun_bounded mu f hfm hf0 (eventDensity_le mu E hp)
  have hzi : Integrable (fun v : ℝ × B => v.1) mu := by
    simpa only [mul_one] using integrable_realLaplace_id.mul_prod (integrable_const (1 : ℝ) (μ := nu))
  have hfzi : Integrable (fun v : ℝ × B => f v * v.1) mu := by
    apply hzi.bdd_mul (c := 1 / p) hfm.aestronglyMeasurable
    filter_upwards [] with v
    simpa only [Real.norm_eq_abs, abs_of_nonneg (hf0 v)] using eventDensity_le mu E hp v
  have hexpi : Integrable (fun v : ℝ × B => Real.exp ((1 / 2) * v.1)) mu := by
    simpa only [mul_one] using (integrable_realLaplace_exp (t := 1 / 2) (by norm_num)).mul_prod
      (integrable_const (1 : ℝ) (μ := nu))
  have hmgf : (∫ v : ℝ × B, Real.exp ((1 / 2) * v.1) ∂mu) = 4 / 3 := by
    have h := integral_prod_mul (μ := realLaplace) (ν := nu)
      (fun z : ℝ => Real.exp ((1 / 2) * z)) (fun _ => (1 : ℝ))
    rw [integral_realLaplace_exp (by norm_num : |(1 / 2 : ℝ)| < 1)] at h
    norm_num at h
    exact h
  have hvar := density_entropy_variational mu f (fun v : ℝ × B => (1 / 2) * v.1)
    hf0 hfi hfn hki
    (by convert! hfzi.const_mul (1 / 2 : ℝ) using 1; funext v; ring) hexpi
    (by rw [hmgf]; norm_num)
  rw [entropy_eventDensity mu E hE hp, hmgf] at hvar
  have heq : (∫ v : ℝ × B, f v * ((1 / 2) * v.1) ∂mu) =
      (1 / 2 : ℝ) * ((∫ v : ℝ × B, E.indicator (fun _ => (1 : ℝ)) v * v.1 ∂mu) / p) := by
    calc
      _ = ∫ v : ℝ × B, (1 / 2 : ℝ) * (E.indicator (fun _ => (1 : ℝ)) v * v.1 / p) ∂mu := by
        apply integral_congr_ae
        filter_upwards [] with v
        change (E.indicator (fun _ => (1 : ℝ)) v / p) * ((1 / 2) * v.1) = _
        ring
      _ = _ := by rw [integral_const_mul, integral_div]
  rw [heq] at hvar
  have hlog := Real.log_le_sub_one_of_pos (by norm_num : (0 : ℝ) < 4 / 3)
  have hm := mul_le_mul_of_nonneg_left hvar hp.le
  have hp' : p ≠ 0 := hp.ne'
  have hcancel : p * ((1 / 2 : ℝ) * ((∫ v : ℝ × B, E.indicator (fun _ => (1 : ℝ)) v * v.1 ∂mu) / p)) =
      (1 / 2 : ℝ) * (∫ v : ℝ × B, E.indicator (fun _ => (1 : ℝ)) v * v.1 ∂mu) := by field_simp
  rw [hcancel] at hm
  change _ ≤ 2 * p * (1 - Real.log p)
  change _ ≤ p * (-Real.log p + Real.log (4 / 3)) at hm
  nlinarith

theorem laplace_event_mean_le_all {B : Type*} [MeasurableSpace B]
    (nu : Measure B) [IsProbabilityMeasure nu] (E : Set (ℝ × B)) (hE : MeasurableSet E) :
    (∫ v : ℝ × B, E.indicator (fun _ => (1 : ℝ)) v * v.1 ∂realLaplace.prod nu) ≤
      2 * (realLaplace.prod nu E).toReal * (1 - Real.log (realLaplace.prod nu E).toReal) := by
  let mu := realLaplace.prod nu
  let p := (mu E).toReal
  change (∫ v : ℝ × B, E.indicator (fun _ => (1 : ℝ)) v * v.1 ∂mu) ≤ 2 * p * (1 - Real.log p)
  by_cases hp0 : p = 0
  · have hE0 : mu E = 0 := by
      by_contra hne
      have hp : 0 < p := ENNReal.toReal_pos hne (measure_ne_top _ _)
      linarith
    have ha : ∀ᵐ v ∂mu, v ∉ E := by
      rw [ae_iff]
      have hs : {v : ℝ × B | ¬v ∉ E} = E := by ext v; simp
      rw [hs]
      exact hE0
    have hz : (∫ v : ℝ × B, E.indicator (fun _ => (1 : ℝ)) v * v.1 ∂mu) = 0 := by
      apply integral_eq_zero_of_ae
      filter_upwards [ha] with v hv
      simp [hv]
    rw [hz, hp0]
    simp
  · have hp : 0 < p := lt_of_le_of_ne ENNReal.toReal_nonneg (Ne.symm hp0)
    exact laplace_event_mean_le nu E hE hp

theorem laplace_event_probability_charge {B : Type*} [MeasurableSpace B]
    (nu : Measure B) [IsProbabilityMeasure nu] (E : Set (ℝ × B)) (hE : MeasurableSet E)
    (q ell : ℝ) (hq : 0 < q) (hpq : (realLaplace.prod nu E).toReal ≤ 2 * q)
    (hell1 : 1 ≤ ell) (hellq : 1 - Real.log q ≤ ell) :
    (∫ v : ℝ × B, E.indicator (fun _ => (1 : ℝ)) v * v.1 ∂realLaplace.prod nu) ≤ 4 * q * ell := by
  have hp1 : (realLaplace.prod nu E).toReal ≤ 1 := by
    have h := ENNReal.toReal_mono (by simp : (1 : ENNReal) ≠ ∞)
      (show realLaplace.prod nu E ≤ 1 from prob_le_one)
    simpa only [ENNReal.toReal_one] using h
  exact weak_tail_probability_charge ENNReal.toReal_nonneg hp1 hq hpq hell1 hellq
    (laplace_event_mean_le_all nu E hE)

end

end PoissonAudit
