module

public import PoissonAudit.Hellinger

public section

open scoped BigOperators

namespace PoissonAudit

noncomputable section

@[expose] def finiteEntropy {P : Type*} [Fintype P] (w : P → ℝ) : ℝ :=
  -(∑ p, w p * Real.log (w p))

theorem finiteEntropy_nonneg {P : Type*} [Fintype P]
    (w : P → ℝ) (hw0 : ∀ p, 0 ≤ w p) (hw1 : ∀ p, w p ≤ 1) : 0 ≤ finiteEntropy w := by
  unfold finiteEntropy
  have h : ∑ p, w p * Real.log (w p) ≤ 0 := by
    apply Finset.sum_nonpos
    intro p _
    exact mul_nonpos_of_nonneg_of_nonpos (hw0 p) (Real.log_nonpos (hw0 p) (hw1 p))
  linarith

theorem finiteEntropy_le_log_card {P : Type*} [Fintype P] [Nonempty P]
    (w : P → ℝ) (hw0 : ∀ p, 0 ≤ w p) (hsum : ∑ p, w p = 1) :
    finiteEntropy w ≤ Real.log (Fintype.card P) := by
  classical
  have hN : 0 < (Fintype.card P : ℝ) := by exact_mod_cast Fintype.card_pos
  let u : P → ℝ := fun _ => 1 / (Fintype.card P : ℝ)
  have hu : ∀ p, 0 < u p := fun _ => div_pos zero_lt_one hN
  have husum : ∑ p, u p = 1 := by
    simp only [u, Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
    field_simp
  have hkl := finite_hellinger_le_kl w u hw0 (fun p => (hu p).le) hsum husum
    (fun p hp => False.elim ((hu p).ne' hp))
  have hnonneg : 0 ≤ ∑ p, w p * Real.log (w p / u p) :=
    (Finset.sum_nonneg fun p _ => sq_nonneg _).trans hkl
  have hterm : ∀ p, w p * Real.log (w p / u p) =
      w p * Real.log (w p) + w p * Real.log (Fintype.card P) := by
    intro p
    by_cases hp : w p = 0
    · simp [hp]
    · rw [Real.log_div hp (hu p).ne']
      simp only [u, one_div, Real.log_inv]
      ring
  simp_rw [hterm] at hnonneg
  rw [Finset.sum_add_distrib, ← Finset.sum_mul, hsum, one_mul] at hnonneg
  unfold finiteEntropy
  linarith

end

end PoissonAudit
