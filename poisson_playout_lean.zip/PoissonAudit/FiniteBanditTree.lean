module

public import PoissonAudit.ActionSampling
public import PoissonAudit.ConditionalRelaxation

public section
open MeasureTheory
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X A P : Type*} [Fintype X] [Fintype A] [Fintype P] [Nonempty P]

@[expose] def treeBestScore (S : P → ℝ) : ℝ := Finset.univ.sup' Finset.univ_nonempty S

theorem treeBestScore_le {S : P → ℝ} {b : ℝ} (h : ∀ p, S p ≤ b) : treeBestScore S ≤ b :=
  Finset.sup'_le _ _ (fun p _ => h p)

@[expose] def treeEstimatedPolicyLoss (q c : A → ℝ) (predict : P → A) (a : A) (p : P) : ℝ := by
  classical
  exact if predict p = a then c a / q a else 0

@[expose] def treeUpdatedScore (S : P → ℝ) (q c : A → ℝ) (predict : P → A) (a : A) : P → ℝ :=
  fun p => S p - treeEstimatedPolicyLoss q c predict a p

@[expose] def trueScoreStep (predict : P → X → A) (S : P → ℝ) (c : X → A → ℝ) (x : X) : P → ℝ :=
  fun p => S p - c x (predict p x)

@[expose] def contextBestScore (d : X → ℝ) (predict : P → X → A) :
    List (X → A → ℝ) → (P → ℝ) → ℝ
  | [], S => treeBestScore S
  | c :: cs, S => ∑ x, d x * contextBestScore d predict cs (trueScoreStep predict S c x)

@[expose] def finiteBanditTerminal (d : X → ℝ) (predict : P → X → A)
    (q : (P → ℝ) → X → A → ℝ) (f : (P → ℝ) → ℝ) :
    List (X → A → ℝ) → (P → ℝ) → ℝ
  | [], S => f S
  | c :: cs, S => ∑ x, d x * ∑ a, q S x a * finiteBanditTerminal d predict q f cs
      (treeUpdatedScore S (q S x) (c x) (fun p => predict p x) a)

@[expose] def finiteBanditLoss (d : X → ℝ) (predict : P → X → A)
    (q : (P → ℝ) → X → A → ℝ) : List (X → A → ℝ) → (P → ℝ) → ℝ
  | [], _ => 0
  | c :: cs, S => ∑ x, d x * ∑ a, q S x a * (c x a + finiteBanditLoss d predict q cs
      (treeUpdatedScore S (q S x) (c x) (fun p => predict p x) a))

theorem treeBestScore_weighted_le (w : A → ℝ) (hw : ∀ a, 0 ≤ w a) (v : A → P → ℝ) :
    treeBestScore (fun p => ∑ a, w a * v a p) ≤ ∑ a, w a * treeBestScore (v a) := by
  classical
  apply treeBestScore_le
  intro p
  exact Finset.sum_le_sum fun a _ => mul_le_mul_of_nonneg_left
    (Finset.le_sup' (s := Finset.univ) (f := v a) (Finset.mem_univ p)) (hw a)

theorem contextBestScore_weighted_le (d : X → ℝ) (hd : ∀ x, 0 ≤ d x)
    (predict : P → X → A) (costs : List (X → A → ℝ))
    (w : A → ℝ) (hw : ∀ a, 0 ≤ w a) (hsum : ∑ a, w a = 1) (v : A → P → ℝ) :
    contextBestScore d predict costs (fun p => ∑ a, w a * v a p) ≤
      ∑ a, w a * contextBestScore d predict costs (v a) := by
  classical
  induction costs generalizing v with
  | nil => exact treeBestScore_weighted_le w hw v
  | cons c cs ih =>
    have heq (x : X) : trueScoreStep predict (fun p => ∑ a, w a * v a p) c x =
        fun p => ∑ a, w a * trueScoreStep predict (v a) c x p := by
      funext p
      simp only [trueScoreStep, mul_sub, Finset.sum_sub_distrib, ← Finset.sum_mul, hsum, one_mul]
    simp only [contextBestScore]
    have h := Finset.sum_le_sum (s := Finset.univ) (fun x _ =>
      mul_le_mul_of_nonneg_left (ih (fun a => trueScoreStep predict (v a) c x)) (hd x))
    simp only [← heq] at h
    calc
      _ ≤ ∑ x, d x * ∑ a, w a * contextBestScore d predict cs (trueScoreStep predict (v a) c x) := h
      _ = _ := by
        simp_rw [Finset.mul_sum]
        rw [Finset.sum_comm]
        apply Finset.sum_congr rfl
        intro a _
        apply Finset.sum_congr rfl
        intro x _
        ring

theorem weighted_treeUpdatedScore (predict : P → X → A) (S : P → ℝ) (x : X)
    (c q : A → ℝ) (hq : ∀ a, 0 < q a) (hsum : ∑ a, q a = 1) :
    (fun p => ∑ a, q a * treeUpdatedScore S q c (fun p => predict p x) a p) =
      fun p => S p - c (predict p x) := by
  classical
  funext p
  simp only [treeUpdatedScore, mul_sub, Finset.sum_sub_distrib, ← Finset.sum_mul, hsum, one_mul]
  congr 1
  simp only [treeEstimatedPolicyLoss, mul_ite, mul_zero]
  rw [Finset.sum_eq_single (predict p x)]
  · simp only [ite_true]
    exact mul_div_cancel₀ _ (hq _).ne'
  · intro a _ ha
    simp [Ne.symm ha]
  · simp

theorem finiteBandit_comparator (d : X → ℝ) (hd : ∀ x, 0 ≤ d x)
    (predict : P → X → A) (q : (P → ℝ) → X → A → ℝ)
    (hq : ∀ S x a, 0 < q S x a) (hsum : ∀ S x, ∑ a, q S x a = 1)
    (costs : List (X → A → ℝ)) (S : P → ℝ) :
    contextBestScore d predict costs S ≤ finiteBanditTerminal d predict q treeBestScore costs S := by
  classical
  induction costs generalizing S with
  | nil => rfl
  | cons c cs ih =>
    apply Finset.sum_le_sum
    intro x _
    apply mul_le_mul_of_nonneg_left _ (hd x)
    have hj := contextBestScore_weighted_le d hd predict cs (q S x) (fun a => (hq S x a).le)
      (hsum S x) (fun a => treeUpdatedScore S (q S x) (c x) (fun p => predict p x) a)
    rw [weighted_treeUpdatedScore predict S x (c x) (q S x) (hq S x) (hsum S x)] at hj
    exact hj.trans (Finset.sum_le_sum fun a _ => mul_le_mul_of_nonneg_left (ih _) (hq S x a).le)

end
end PoissonAudit
