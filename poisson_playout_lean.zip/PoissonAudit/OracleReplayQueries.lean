module
public import PoissonAudit.OracleReplayTape
public section
open scoped BigOperators
namespace PoissonAudit
noncomputable section

@[expose] def replayQueries {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K) :
    List (ReplayRecord X K) → X → List (List (CostExample X K))
  | [], _ => []
  | record :: records, x =>
    replayQueries r lam B eta history oracle fallback records x ++
      actionValueQueries (history ++ record.2) x
        (fun a => (replayAt r lam B eta history oracle fallback records x).1 a * record.1 a)

theorem replayQueries_count {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (records : List (ReplayRecord X K)) (x : X) :
    (replayQueries r lam B eta history oracle fallback records x).length = records.length * (K + 1) := by
  induction records with
  | nil => simp [replayQueries]
  | cons record records ih => simp only [replayQueries, List.length_append, actionValueQueries_count, ih, List.length_cons]; ring

theorem replayQueries_input_length {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (cap : ℕ) (records : List (ReplayRecord X K)) (hc : ∀ record ∈ records, record.2.length ≤ cap)
    (x : X) (Q : List (CostExample X K)) (hQ : Q ∈ replayQueries r lam B eta history oracle fallback records x) :
    Q.length ≤ history.length + cap + 1 := by
  induction records with
  | nil => simp [replayQueries] at hQ
  | cons record records ih =>
    rcases List.mem_append.mp hQ with hQ | hQ
    · exact ih (fun rec hr => hc rec (List.mem_cons_of_mem _ hr)) hQ
    · have hlen := actionValueQueries_length (history ++ record.2) x
        (fun a => (replayAt r lam B eta history oracle fallback records x).1 a * record.1 a) Q hQ
      rw [hlen, List.length_append]
      have hrec := hc record List.mem_cons_self
      omega

@[expose] def nativeTapeCountsBounded {X : Type*} {K : ℕ} (cap : ℕ) :
    (j : ℕ) → NativeNoiseTape X K j → Prop
  | 0, _ => True
  | j + 1, tape => nativeTapeCountsBounded cap j tape.1 ∧ tape.2.2.1 ≤ cap

theorem buildReplayRecords_capped {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (cap j : ℕ) (tape : NativeNoiseTape X K j) (hc : nativeTapeCountsBounded cap j tape) :
    ∀ record ∈ buildReplayRecords r lam B eta history oracle fallback j tape, record.2.length ≤ cap := by
  induction j with
  | zero => simp [buildReplayRecords]
  | succ j ih =>
    intro record hr
    rcases List.mem_cons.mp hr with hr | hr
    · rw [hr, makeReplayRecord_length]
      exact hc.2
    · exact ih tape.1 hc.1 record hr

@[expose] def buildReplayQueries {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K) :
    (j : ℕ) → NativeNoiseTape X K j → List (List (CostExample X K))
  | 0, _ => []
  | j + 1, tape =>
    buildReplayQueries r lam B eta history oracle fallback j tape.1 ++
      (List.ofFn (fun i : Fin tape.2.2.1 =>
        replayQueries r lam B eta history oracle fallback
          (buildReplayRecords r lam B eta history oracle fallback j tape.1) (tape.2.2.2 i).1)).flatten

theorem buildReplayQueries_count {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (cap j : ℕ) (tape : NativeNoiseTape X K j) (hc : nativeTapeCountsBounded cap j tape) :
    (buildReplayQueries r lam B eta history oracle fallback j tape).length ≤ cap * j ^ 2 * (K + 1) := by
  induction j with
  | zero => simp [buildReplayQueries]
  | succ j ih =>
    have hprev := ih tape.1 hc.1
    change (buildReplayQueries r lam B eta history oracle fallback j tape.1 ++ _).length ≤ _
    simp only [List.length_append, List.length_flatten, List.map_ofFn, List.sum_ofFn, Function.comp_apply, replayQueries_count, buildReplayRecords_length,
      Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
    have hterm : tape.2.2.1 * (j * (K + 1)) ≤ cap * (j * (K + 1)) := Nat.mul_le_mul_right _ hc.2
    have hj : j ^ 2 + j ≤ (j + 1) ^ 2 := by nlinarith
    have hmul := Nat.mul_le_mul_right (K + 1) (Nat.mul_le_mul_left cap hj)
    calc
      _ ≤ cap * j ^ 2 * (K + 1) + cap * (j * (K + 1)) := add_le_add hprev hterm
      _ = cap * (j ^ 2 + j) * (K + 1) := by ring
      _ ≤ cap * (j + 1) ^ 2 * (K + 1) := hmul

@[expose] def replayRecordExampleCount {X : Type*} {K : ℕ} (records : List (ReplayRecord X K)) : ℕ :=
  (records.map (fun record => record.2.length)).sum

theorem replayRecordExampleCount_bound {X : Type*} {K : ℕ} (cap : ℕ) (records : List (ReplayRecord X K))
    (hc : ∀ record ∈ records, record.2.length ≤ cap) : replayRecordExampleCount records ≤ records.length * cap := by
  induction records with
  | nil => simp [replayRecordExampleCount]
  | cons record records ih =>
    have hr := hc record List.mem_cons_self
    have hi := ih (fun rec hm => hc rec (List.mem_cons_of_mem _ hm))
    simp only [replayRecordExampleCount, List.map_cons, List.sum_cons, List.length_cons]
    change _ + replayRecordExampleCount records ≤ _
    nlinarith
end
end PoissonAudit
