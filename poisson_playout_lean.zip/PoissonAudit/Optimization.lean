module
public import PoissonAudit.NativeSGDConvergence
public import PoissonAudit.GradientBound
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem paper_SGD_expected_descent (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ)
    (hlam : 0 ≤ lam) (hB : 1 ≤ B) (heta : 0 ≤ eta)
    (sigma s : X × Fin K → ℝ) (hsigma : sigma ∈ scaleBox (X × Fin K) B) (hs : s ∈ scaleBox (X × Fin K) B) :
    2 * eta * (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun j => (D {j.1}).toReal) lam B sigma -
        scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
          (fun j => (D {j.1}).toReal) lam B s) ≤
      weightedSquareDistance (fun j => (D {j.1}).toReal) sigma s -
        (∫ v, weightedSquareDistance (fun j => (D {j.1}).toReal)
          (nativeSGDNext r predict S lam B eta sigma v) s ∂insertedExperimentLaw r D K) +
            eta ^ 2 * (K * (4 * (r : ℝ) ^ 2 + 2 * lam ^ 2)) := by
  let w : X × Fin K → ℝ := fun j => (D {j.1}).toReal
  let mu := insertedExperimentLaw r D K
  let inner := fun v => nativeGradientInner D sigma s (nativeSampledGradient r predict sigma S lam v)
  let norm := fun v => nativeGradientSquaredNorm D (nativeSampledGradient r predict sigma S lam v)
  have hi : Integrable inner mu := integrable_nativeGradientInner r D predict sigma s S lam
  have hn : Integrable norm mu := integrable_nativeGradientSquaredNorm r D predict sigma S lam hsigma.1
  have hp (v) := boxGradientStep_descent w sigma (nativeSampledGradient r predict sigma S lam v) s
    (fun _ => ENNReal.toReal_nonneg) B eta hs
  have heq (v) : (∑ j, w j * nativeSampledGradient r predict sigma S lam v j * (sigma j - s j)) = inner v := by
    apply Finset.sum_congr rfl
    intro j _
    change _ = (sigma j - s j) * (w j * nativeSampledGradient r predict sigma S lam v j)
    ring
  have hpoint (v) : weightedSquareDistance w (nativeSGDNext r predict S lam B eta sigma v) s ≤
      weightedSquareDistance w sigma s - 2 * eta * inner v + eta ^ 2 * norm v := by
    have h := hp v
    rw [heq v] at h
    exact h
  have h := integral_mono (integrable_nativeSGDNext_distance r D predict S lam B eta hB sigma s hs)
    (((integrable_const _).sub (hi.const_mul (2 * eta))).add (hn.const_mul (eta ^ 2))) hpoint
  change _ ≤ ∫ v, weightedSquareDistance w sigma s - 2 * eta * inner v + eta ^ 2 * norm v ∂mu at h
  rw [integral_add (f := fun v => weightedSquareDistance w sigma s - 2 * eta * inner v)
      (g := fun v => eta ^ 2 * norm v) ((integrable_const _).sub (hi.const_mul _)) (hn.const_mul _),
    integral_sub (integrable_const _) (hi.const_mul _), integral_const, probReal_univ, one_smul,
    integral_const_mul, integral_const_mul] at h
  have hsupport := native_stochastic_supporting r D predict S sigma s lam B hlam (by linarith)
    (fun j => by have h : (1 : ℝ) ≤ sigma j := hsigma.1 j; linarith)
    (fun j => by have h : (1 : ℝ) ≤ s j := hs.1 j; linarith)
  have hsup := mul_le_mul_of_nonneg_left hsupport (show 0 ≤ 2 * eta from mul_nonneg (by norm_num) heta)
  have hnorm := mul_le_mul_of_nonneg_left (paper_gradient_bound r D predict sigma S lam hsigma.1) (sq_nonneg eta)
  change _ ≤ 2 * eta * (∫ v, inner v ∂mu) at hsup
  change eta ^ 2 * (∫ v, norm v ∂mu) ≤ _ at hnorm
  linarith

theorem paper_SGD_lyapunov_drift (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ)
    (hlam : 0 ≤ lam) (hB : 1 ≤ B) (heta : 0 ≤ eta) (s : NativeScaleBox X K B)
    (j : ℕ) (state : NativeSGDState X K B) :
    (∫ v, nativeSGDLyapunov r D predict S lam B eta s (j + 1)
      (nativeSGDTransition r predict S lam B eta hB j state v) ∂insertedExperimentLaw r D K) ≤
      nativeSGDLyapunov r D predict S lam B eta s j state + eta ^ 2 * (K * (4 * (r : ℝ) ^ 2 + 2 * lam ^ 2)) := by
  let J := nativeBoxObjective r D predict S lam B
  have hd := paper_SGD_expected_descent r D predict S lam B eta hlam hB heta state.1.val s.val state.1.property s.property
  have hj := nativeBoxAverage_jensen r D predict S lam B hlam hB j state.2 state.1
  have hm := mul_le_mul_of_nonneg_left hj (show 0 ≤ 2 * eta from mul_nonneg (by norm_num) heta)
  change (∫ v, 2 * eta * (j + 1 : ℕ) * (J (nativeBoxAverage B j state.2 state.1) - J s) +
      weightedSquareDistance (fun q => (D {q.1}).toReal) (nativeSGDNext r predict S lam B eta state.1.val v) s.val
      ∂insertedExperimentLaw r D K) ≤ _
  rw [integral_add (integrable_const _) (integrable_nativeSGDNext_distance r D predict S lam B eta hB state.1.val s.val s.property),
    integral_const, probReal_univ, one_smul]
  change 2 * eta * (J state.1 - J s) ≤ _ at hd
  change 2 * eta * (((j : ℝ) + 1) * J (nativeBoxAverage B j state.2 state.1)) ≤
    2 * eta * ((j : ℝ) * J state.2 + J state.1) at hm
  change _ ≤ 2 * eta * j * (J state.2 - J s) + weightedSquareDistance _ state.1.val s.val + _
  simp only [Nat.cast_add, Nat.cast_one]
  nlinarith

theorem paper_SGD_expected_lyapunov (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ)
    (hlam : 0 ≤ lam) (hB : 1 ≤ B) (heta : 0 ≤ eta) (s : NativeScaleBox X K B) (J : ℕ) :
    (∫ state, nativeSGDLyapunov r D predict S lam B eta s J state
      ∂nativeSGDStateLaw r D predict S lam B eta hB J) ≤
        B ^ 2 * K + J * eta ^ 2 * (K * (4 * (r : ℝ) ^ 2 + 2 * lam ^ 2)) := by
  induction J with
  | zero =>
    change (∫ state, nativeSGDLyapunov r D predict S lam B eta s 0 state
      ∂Measure.dirac (nativeUnitScale B hB, nativeUnitScale B hB)) ≤ _
    rw [integral_dirac]
    simp only [nativeSGDLyapunov, Nat.cast_zero, mul_zero, zero_mul, zero_add]
    have hb := weightedSquareDistance_box_bound (fun q : X × Fin K => (D {q.1}).toReal)
      (nativeUnitScale (X := X) (K := K) B hB).val s.val (fun _ => ENNReal.toReal_nonneg) B
      (nativeUnitScale B hB).property s.property
    rw [context_action_mass_sum D] at hb
    simpa only [add_zero] using hb
  | succ j ih =>
    let mu := nativeSGDStateLaw r D predict S lam B eta hB j
    let noise := insertedExperimentLaw r D K
    let next := fun v : NativeSGDState X K B × NativeNoise X K => nativeSGDTransition r predict S lam B eta hB j v.1 v.2
    let Lnext := nativeSGDLyapunov r D predict S lam B eta s (j + 1)
    let Lold := nativeSGDLyapunov r D predict S lam B eta s j
    have hm : Measurable next := measurable_nativeSGDTransition r predict S lam B eta hB j
    have hc : Continuous Lnext := continuous_nativeSGDLyapunov r D predict S lam B eta hB s (j + 1)
    have ho : Integrable Lold mu := integrable_continuous_nativeSGDState B mu _
      (continuous_nativeSGDLyapunov r D predict S lam B eta hB s j)
    have hmap : Integrable Lnext ((mu.prod noise).map next) := integrable_continuous_nativeSGDState B _ _ hc
    have hi : Integrable (fun v => Lnext (next v)) (mu.prod noise) := hmap.comp_measurable hm
    change (∫ state, Lnext state ∂(mu.prod noise).map next) ≤ _
    rw [integral_map hm.aemeasurable hc.measurable.aestronglyMeasurable, integral_prod _ hi]
    have h := integral_mono hi.integral_prod_left
      (ho.add (integrable_const (eta ^ 2 * (K * (4 * (r : ℝ) ^ 2 + 2 * lam ^ 2)))))
      (fun state => paper_SGD_lyapunov_drift r D predict S lam B eta hlam hB heta s j state)
    change (∫ state, ∫ v, Lnext (next (state, v)) ∂noise ∂mu) ≤
      ∫ state, Lold state + eta ^ 2 * (K * (4 * (r : ℝ) ^ 2 + 2 * lam ^ 2)) ∂mu at h
    rw [integral_add ho (integrable_const _), integral_const, probReal_univ, one_smul] at h
    change (∫ state, Lold state ∂mu) ≤ _ at ih
    simp only [Nat.cast_add, Nat.cast_one]
    nlinarith

theorem paper_SGD_expected_objective_error (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ)
    (hlam : 0 ≤ lam) (hB : 1 ≤ B) (heta : 0 < eta) (s : NativeScaleBox X K B) (J : ℕ) (hJ : 0 < J) :
    (∫ state, nativeBoxObjective r D predict S lam B state.2 - nativeBoxObjective r D predict S lam B s
      ∂nativeSGDStateLaw r D predict S lam B eta hB J) ≤
        B ^ 2 * K / (2 * eta * J) + eta * (K * (4 * (r : ℝ) ^ 2 + 2 * lam ^ 2)) / 2 := by
  let mu := nativeSGDStateLaw r D predict S lam B eta hB J
  let gap := fun state : NativeSGDState X K B => nativeBoxObjective r D predict S lam B state.2 - nativeBoxObjective r D predict S lam B s
  let L := nativeSGDLyapunov r D predict S lam B eta s J
  have hg : Continuous gap := ((continuous_nativeBoxObjective r D predict S lam B hB).comp continuous_snd).sub continuous_const
  have hi : Integrable gap mu := integrable_continuous_nativeSGDState B mu _ hg
  have hLi : Integrable L mu := integrable_continuous_nativeSGDState B mu _ (continuous_nativeSGDLyapunov r D predict S lam B eta hB s J)
  have hp (state : NativeSGDState X K B) : 2 * eta * J * gap state ≤ L state := by
    have hn := weightedSquareDistance_nonneg (fun q : X × Fin K => (D {q.1}).toReal) state.1.val s.val
      (fun _ => ENNReal.toReal_nonneg)
    change _ ≤ 2 * eta * J * gap state + _
    linarith
  have h := integral_mono (hi.const_mul (2 * eta * J)) hLi hp
  change (∫ state, 2 * eta * J * gap state ∂mu) ≤ _ at h
  rw [integral_const_mul] at h
  have hL := paper_SGD_expected_lyapunov r D predict S lam B eta hlam hB heta.le s J
  change (∫ state, L state ∂mu) ≤ _ at hL
  have hpos : 0 < 2 * eta * (J : ℝ) := by positivity
  have hh := h.trans hL
  have hdiv : (∫ state, gap state ∂mu) ≤ (B ^ 2 * K + (J : ℝ) * eta ^ 2 * (K * (4 * (r : ℝ) ^ 2 + 2 * lam ^ 2))) / (2 * eta * J) :=
    (le_div_iff₀ hpos).mpr (by nlinarith only [hh])
  have heq : (B ^ 2 * K + (J : ℝ) * eta ^ 2 * (K * (4 * (r : ℝ) ^ 2 + 2 * lam ^ 2))) /
      (2 * eta * J) = B ^ 2 * K / (2 * eta * J) + eta * (K * (4 * (r : ℝ) ^ 2 + 2 * lam ^ 2)) / 2 := by
    field_simp <;> ring
  rw [heq] at hdiv
  exact hdiv

theorem paper_sgd_step_size {d g ε : ℝ} {J : ℕ} (hd : 0 < d) (hg : 0 < g) (he : 0 < ε)
    (hJ : 0 < J) (hbudget : d ^ 2 * g ^ 2 / ε ^ 2 ≤ J) :
    let η := d / (g * Real.sqrt J)
    d ^ 2 / (2 * η * J) + η * g ^ 2 / 2 ≤ ε := by
  have hj : (0 : ℝ) < J := by exact_mod_cast hJ
  have hs := Real.sqrt_pos.mpr hj
  have hsq := Real.sq_sqrt hj.le
  have hb := (div_le_iff₀ (sq_pos_of_pos he)).mp hbudget
  have hprod : d * g ≤ ε * Real.sqrt J := by
    have hsq' : (d * g) ^ 2 ≤ (ε * Real.sqrt J) ^ 2 := by
      rw [mul_pow, mul_pow, hsq]
      linarith
    nlinarith [mul_pos he hs]
  dsimp only
  calc
    _ = d * g / Real.sqrt J := by
      field_simp
      nlinarith only [hsq]
    _ ≤ ε := (div_le_iff₀ hs).mpr hprod

theorem paper_sgd_objective_accuracy (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B ε : ℝ)
    (hlam : 0 < lam) (hB : 1 ≤ B) (he : 0 < ε) (hK : 0 < K)
    (s : NativeScaleBox X K B) :
    let d := B * Real.sqrt K
    let g := Real.sqrt (K * (4 * (r : ℝ) ^ 2 + 2 * lam ^ 2))
    let J := max 1 ⌈d ^ 2 * g ^ 2 / ε ^ 2⌉₊
    let η := d / (g * Real.sqrt J)
    (∫ state, nativeBoxObjective r D predict S lam B state.2 - nativeBoxObjective r D predict S lam B s
      ∂nativeSGDStateLaw r D predict S lam B η hB J) ≤ ε := by
  intro d g J η
  have hb : 0 < B := by linarith
  have hk : (0 : ℝ) < K := by exact_mod_cast hK
  have hd : 0 < d := mul_pos hb (Real.sqrt_pos.mpr hk)
  have hg0 : 0 < (K : ℝ) * (4 * (r : ℝ) ^ 2 + 2 * lam ^ 2) := by positivity
  have hg : 0 < g := Real.sqrt_pos.mpr hg0
  have hj : 0 < J := lt_of_lt_of_le Nat.zero_lt_one (le_max_left ..)
  have heta : 0 < η := div_pos hd (mul_pos hg (Real.sqrt_pos.mpr (by exact_mod_cast hj)))
  have h := paper_SGD_expected_objective_error r D predict S lam B η hlam.le hB heta s J hj
  have hd2 : d ^ 2 = B ^ 2 * K := by simp [d, mul_pow, Real.sq_sqrt hk.le]
  have hg2 : g ^ 2 = _ := Real.sq_sqrt hg0.le
  rw [← hd2, ← hg2] at h
  exact h.trans (paper_sgd_step_size hd hg he hj ((Nat.le_ceil _).trans (Nat.cast_le.mpr (le_max_right ..))))

end
end PoissonAudit
