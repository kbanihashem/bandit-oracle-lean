module
public import PoissonAudit.FiniteOutcomeRegret
public section
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {A C P : Type*} [Fintype A] [Fintype C] [Fintype P] [Nonempty P]

@[expose] def choiceActionWeight (nu : C → ℝ) (q : C → A → ℝ) (o : C × A) : ℝ := nu o.1 * q o.1 o.2

theorem choiceActionWeight_nonneg (nu : C → ℝ) (q : C → A → ℝ)
    (hnu : ∀ c, 0 ≤ nu c) (hq : ∀ c a, 0 ≤ q c a) (o : C × A) : 0 ≤ choiceActionWeight nu q o :=
  mul_nonneg (hnu o.1) (hq o.1 o.2)

theorem choiceActionWeight_sum (nu : C → ℝ) (q : C → A → ℝ)
    (hnu : ∑ c, nu c = 1) (hq : ∀ c, ∑ a, q c a = 1) : (∑ o, choiceActionWeight nu q o) = 1 := by
  classical
  simp only [Fintype.sum_prod_type, choiceActionWeight, ← Finset.mul_sum, hq, mul_one, hnu]

theorem choiceActionWeight_mean_update (nu : C → ℝ) (q : C → A → ℝ)
    (hnu : ∑ c, nu c = 1) (hq : ∀ c a, 0 < q c a) (hqs : ∀ c, ∑ a, q c a = 1)
    (S : P → ℝ) (cost : A → ℝ) (predict : P → A) :
    (fun p => ∑ o, choiceActionWeight nu q o * treeUpdatedScore S (q o.1) cost predict o.2 p) =
      fun p => S p - cost (predict p) := by
  classical
  funext p
  simp only [Fintype.sum_prod_type, choiceActionWeight, mul_assoc, ← Finset.mul_sum]
  have h (c : C) : (∑ a, q c a * treeUpdatedScore S (q c) cost predict a p) = S p - cost (predict p) := by
    have hu := weighted_treeUpdatedScore (fun p (_ : Unit) => predict p) S () cost (q c) (hq c) (hqs c)
    exact congrFun hu p
  simp only [h, ← Finset.sum_mul, hnu, one_mul]
end
end PoissonAudit
