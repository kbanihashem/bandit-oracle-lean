module
public import PoissonAudit.NativeWinnerActionTies
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section

@[expose] def valueOracleAction {X : Type*} {K : ℕ} (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (Q : List (CostExample X K)) (x : X) (v : Fin K → ℝ) : Fin K := by
  classical
  exact if h : ∃ a, oracle (boostedDesignatedQuery Q x v a) = oracle (Q ++ [(x, v)]) + 1 then
    actionFromValueTable (oracle (Q ++ [(x, v)])) (fun a => oracle (boostedDesignatedQuery Q x v a)) h else fallback

@[expose] abbrev ReplayRecord (X : Type*) (K : ℕ) := (Fin K → ℝ) × List (CostExample X K)
@[expose] abbrev ReplayLocalState (K : ℕ) := (Fin K → ℝ) × (Fin K → ℝ)

@[expose] def replayLocalStep {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (j : ℕ) (record : ReplayRecord X K) (x : X) (state : ReplayLocalState K) : ReplayLocalState K := by
  classical
  let action := valueOracleAction oracle fallback (history ++ record.2) x (fun a => state.1 a * record.1 a)
  exact (fun a => boxClip B (state.1 a - eta * ((r : ℝ) * ((if action = a then 1 else 0) * record.1 a) - lam / state.1 a)),
    fun a => (j : ℝ) / ((j : ℝ) + 1) * state.2 a + 1 / ((j : ℝ) + 1) * state.1 a)

@[expose] def replayAt {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K) :
    List (ReplayRecord X K) → X → ReplayLocalState K
  | [], _ => (fun _ => 1, fun _ => 1)
  | record :: records, x => replayLocalStep r lam B eta history oracle fallback records.length record x
      (replayAt r lam B eta history oracle fallback records x)

@[expose] def makeReplayRecord {X : Type*} {K : ℕ} (current : X → Fin K → ℝ)
    (v : (Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ)))) : ReplayRecord X K :=
  (v.1, scaledPoolExamples (fun q => current q.1 q.2) (poolPrefix v.2.1 v.2.2))

theorem makeReplayRecord_length {X : Type*} {K : ℕ} (current : X → Fin K → ℝ)
    (v : (Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ)))) :
    (makeReplayRecord current v).2.length = v.2.1 := by simp [makeReplayRecord, scaledPoolExamples]

variable {X P : Type*} {K : ℕ} [Fintype P] [Nonempty P] [LinearOrder P]

theorem valueOracleAction_maximizes (predict : P → X → Fin K) (oracle : List (CostExample X K) → ℝ)
    (horacle : ∀ Q, oracle Q = treeBestScore (queryScore predict Q)) (fallback : Fin K)
    (Q : List (CostExample X K)) (x : X) (v : Fin K → ℝ) :
    ∃ p, queryScore predict (Q ++ [(x, v)]) p = treeBestScore (queryScore predict (Q ++ [(x, v)])) ∧
      predict p x = valueOracleAction oracle fallback Q x v := by
  obtain ⟨hgood, p, hp, ha⟩ := cost_sensitive_value_action predict Q x v oracle horacle
  refine ⟨p, hp, ?_⟩
  simpa only [valueOracleAction, dif_pos hgood] using ha

variable [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X]
    [MeasurableSpace P] [MeasurableSingletonClass P]

theorem native_valueOracleAction_eq (predict : P → X → Fin K) (history : List (CostExample X K))
    (oracle : List (CostExample X K) → ℝ) (horacle : ∀ Q, oracle Q = treeBestScore (queryScore predict Q))
    (fallback : Fin K) (sigma : X × Fin K → ℝ) (v : NativeNoise X K)
    (hunique : ∀ x p, experimentScore predict sigma (queryScore predict history) x v p =
      treeBestScore (experimentScore predict sigma (queryScore predict history) x v) →
        predict p x = experimentAction predict sigma (queryScore predict history) x v) (x : X) :
    valueOracleAction oracle fallback (history ++ (makeReplayRecord (fun x a => sigma (x, a)) v).2) x
      (fun a => sigma (x, a) * v.1 a) = experimentAction predict sigma (queryScore predict history) x v := by
  have heq : (history ++ (makeReplayRecord (fun x a => sigma (x, a)) v).2) ++ [(x, fun a => sigma (x, a) * v.1 a)] =
      nativeNoiseQuery history sigma x v := rfl
  obtain ⟨p, hp, ha⟩ := valueOracleAction_maximizes predict oracle horacle fallback
    (history ++ (makeReplayRecord (fun x a => sigma (x, a)) v).2) x (fun a => sigma (x, a) * v.1 a)
  rw [heq] at hp
  have hs : queryScore predict (nativeNoiseQuery history sigma x v) = experimentScore predict sigma (queryScore predict history) x v :=
    funext (queryScore_nativeNoiseQuery predict history sigma x v)
  rw [hs] at hp
  exact ha.symm.trans (hunique x p hp)

theorem replayLocalStep_native (r : NNReal) (predict : P → X → Fin K)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ)
    (horacle : ∀ Q, oracle Q = treeBestScore (queryScore predict Q)) (fallback : Fin K)
    (lam B eta : ℝ) (hB : 1 ≤ B) (j : ℕ) (state : NativeSGDState X K B) (v : NativeNoise X K)
    (hunique : ∀ x p, experimentScore predict state.1.val (queryScore predict history) x v p =
      treeBestScore (experimentScore predict state.1.val (queryScore predict history) x v) →
        predict p x = experimentAction predict state.1.val (queryScore predict history) x v) (x : X) :
    replayLocalStep r lam B eta history oracle fallback j (makeReplayRecord (fun x a => state.1.val (x, a)) v) x
      (fun a => state.1.val (x, a), fun a => state.2.val (x, a)) =
        (fun a => (nativeSGDTransition r predict (queryScore predict history) lam B eta hB j state v).1.val (x, a),
         fun a => (nativeSGDTransition r predict (queryScore predict history) lam B eta hB j state v).2.val (x, a)) := by
  classical
  have ha := native_valueOracleAction_eq predict history oracle horacle fallback state.1.val v hunique x
  apply Prod.ext
  · funext a
    change boxClip B (state.1.val (x, a) - eta * ((r : ℝ) *
      ((if valueOracleAction oracle fallback (history ++ (makeReplayRecord (fun x a => state.1.val (x, a)) v).2) x
        (fun a => state.1.val (x, a) * v.1 a) = a then 1 else 0) * v.1 a) - lam / state.1.val (x, a))) = _
    rw [ha]
    unfold nativeSGDTransition nativeSGDNext boxGradientStep nativeSampledGradient
    simp only [experimentActionEvent, outcomeEvent, Set.indicator_apply, Set.mem_setOf_eq]
  · funext a
    rfl
end
end PoissonAudit
