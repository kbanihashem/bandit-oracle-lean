module

public import PoissonAudit.RealLaplaceMoments
public import PoissonAudit.CorrelationAlgebra

public section

open MeasureTheory InformationTheory
open scoped ENNReal

namespace PoissonAudit

noncomputable section

theorem laplace_density_mean_variational (f : ℝ → ℝ)
    (hf0 : ∀ z, 0 ≤ f z) (hfi : Integrable f realLaplace)
    (hnorm : (∫ z, f z ∂realLaplace) = 1)
    (hki : Integrable (fun z => klFun (f z)) realLaplace)
    (hfzi : Integrable (fun z => f z * z) realLaplace)
    {t : ℝ} (ht : |t| < 1) :
    t * (∫ z, f z * z ∂realLaplace) ≤
      (∫ z, klFun (f z) ∂realLaplace) - Real.log (1 - t ^ 2) := by
  have ht2 : 0 < 1 - t ^ 2 := by nlinarith [(sq_lt_one_iff_abs_lt_one t).mpr ht]
  have h := density_entropy_variational realLaplace f (fun z => t * z) hf0 hfi hnorm hki
    (by convert hfzi.const_mul t using 1; funext z; ring)
    (integrable_realLaplace_exp ht)
    (by rw [integral_realLaplace_exp ht]; exact div_pos (by norm_num) ht2)
  have heq : (∫ z, f z * (t * z) ∂realLaplace) =
      t * ∫ z, f z * z ∂realLaplace := by
    rw [← integral_const_mul]
    apply integral_congr_ae
    filter_upwards [] with z
    ring
  rw [heq, integral_realLaplace_exp ht, Real.log_div (by norm_num) ht2.ne', Real.log_one] at h
  linarith

theorem laplace_density_sign_sq (f : ℝ → ℝ)
    (hf0 : ∀ z, 0 ≤ f z) (hfi : Integrable f realLaplace)
    (hnorm : (∫ z, f z ∂realLaplace) = 1)
    (hki : Integrable (fun z => klFun (f z)) realLaplace)
    (hfsi : Integrable (fun z => f z * laplaceSign z) realLaplace) :
    (∫ z, f z * laplaceSign z ∂realLaplace) ^ 2 ≤
      2 * ∫ z, klFun (f z) ∂realLaplace := by
  let b := ∫ z, f z * laplaceSign z ∂realLaplace
  have hegi : Integrable (fun z => Real.exp (b * laplaceSign z)) realLaplace := by
    apply Integrable.of_bound (by fun_prop) (Real.exp |b|)
    filter_upwards [] with z
    rw [Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)]
    apply Real.exp_le_exp.mpr
    calc
      _ ≤ |b * laplaceSign z| := le_abs_self _
      _ = |b| := by rw [abs_mul, abs_laplaceSign, mul_one]
  have h := density_entropy_variational realLaplace f (fun z => b * laplaceSign z)
    hf0 hfi hnorm hki
    (by convert hfsi.const_mul b using 1; funext z; ring) hegi
    (by rw [integral_realLaplace_exp_sign]; exact Real.cosh_pos b)
  have heq : (∫ z, f z * (b * laplaceSign z) ∂realLaplace) = b ^ 2 := by
    calc
      _ = b * ∫ z, f z * laplaceSign z ∂realLaplace := by
        rw [← integral_const_mul]
        apply integral_congr_ae
        filter_upwards [] with z
        ring
      _ = _ := by change b * b = b ^ 2; ring
  rw [heq, integral_realLaplace_exp_sign] at h
  have hlog : Real.log (Real.cosh b) ≤ b ^ 2 / 2 :=
    (Real.log_le_iff_le_exp (Real.cosh_pos b)).mpr (Real.cosh_le_exp_half_sq b)
  change b ^ 2 ≤ _
  linarith

theorem laplace_density_two_means (f : ℝ → ℝ) (hf : Measurable f)
    (hf0 : ∀ z, 0 ≤ f z) {C : ℝ} (hfC : ∀ z, f z ≤ C)
    (hnorm : (∫ z, f z ∂realLaplace) = 1) :
    |(∫ z, f z * z ∂realLaplace) *
      (∫ z, f z * laplaceSign z ∂realLaplace)| ≤
      4 * (klDiv (realLaplace.withDensity (fun z => ENNReal.ofReal (f z))) realLaplace).toReal := by
  have hfi : Integrable f realLaplace := by
    apply Integrable.of_bound hf.aestronglyMeasurable C
    filter_upwards [] with z
    simpa only [Real.norm_eq_abs, abs_of_nonneg (hf0 z)] using hfC z
  have hki := integrable_klFun_bounded realLaplace f hf hf0 hfC
  have hfzi : Integrable (fun z => f z * z) realLaplace := by
    apply integrable_realLaplace_id.bdd_mul hf.aestronglyMeasurable
    filter_upwards [] with z
    simpa only [Real.norm_eq_abs, abs_of_nonneg (hf0 z)] using hfC z
  have hfsi : Integrable (fun z => f z * laplaceSign z) realLaplace := by
    convert hfi.bdd_mul (c := 1) measurable_laplaceSign.aestronglyMeasurable
      (Filter.Eventually.of_forall fun z => by simp [Real.norm_eq_abs, abs_laplaceSign]) using 1
    funext z
    ring
  rw [density_kl_toReal realLaplace f hf hf0 hfi hnorm]
  apply two_correlation_product
  · exact integral_nonneg fun z => klFun_nonneg (hf0 z)
  · calc
      _ ≤ ∫ z, |f z * laplaceSign z| ∂realLaplace := abs_integral_le_integral_abs
      _ = ∫ z, f z ∂realLaplace := by
        apply integral_congr_ae
        filter_upwards [] with z
        rw [abs_mul, abs_of_nonneg (hf0 z), abs_laplaceSign, mul_one]
      _ = 1 := hnorm
  · exact laplace_density_sign_sq f hf0 hfi hnorm hki hfsi
  · intro t ht0 ht
    have htt : |t| < 1 := by rw [abs_of_pos ht0]; linarith
    have hntt : |-t| < 1 := by simpa only [abs_neg] using htt
    have hp := laplace_density_mean_variational f hf0 hfi hnorm hki hfzi htt
    have hn := laplace_density_mean_variational f hf0 hfi hnorm hki hfzi hntt
    rw [neg_sq] at hn
    have hlog := neg_log_one_sub_sq_le ht0.le ht
    have hboth : |t * ∫ z, f z * z ∂realLaplace| ≤
        (∫ z, klFun (f z) ∂realLaplace) + (4 / 3 : ℝ) * t ^ 2 := by
      rw [abs_le]
      constructor <;> nlinarith
    simpa only [abs_mul, abs_of_pos ht0] using hboth

end

end PoissonAudit
