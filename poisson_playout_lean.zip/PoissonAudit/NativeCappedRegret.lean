module
public import PoissonAudit.NativeCappedOneRound
public import PoissonAudit.FiniteChoiceMixture
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] abbrev NativeFiniteOutcome (K : ℕ) (delta : ℝ) := EmpiricalChoice K (nativeEmpiricalTrials K delta) × Fin K

@[expose] def nativeFiniteChoiceLaw (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta : ℝ) (hB : 1 ≤ B) (S : P → ℝ) (x : X) : PMF (EmpiricalChoice K (nativeEmpiricalTrials K delta)) :=
  let J := nativeSGDIterations r K lam B eps
  let m := nativeEmpiricalTrials K delta
  nativeCappedChoiceLaw r D predict S lam B (eps / (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2))) hB
    (nativeCountCap r (J + m) delta) J m x

@[expose] def nativeFiniteChoiceWeight (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta : ℝ) (hB : 1 ≤ B) (S : P → ℝ) (x : X)
    (choice : EmpiricalChoice K (nativeEmpiricalTrials K delta)) : ℝ :=
  let J := nativeSGDIterations r K lam B eps
  let m := nativeEmpiricalTrials K delta
  nativeCappedChoiceWeight r D predict S lam B (eps / (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2))) hB
    (nativeCountCap r (J + m) delta) J m x choice

theorem nativeFiniteChoiceWeight_nonneg (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta : ℝ) (hB : 1 ≤ B) (S : P → ℝ) (x : X)
    (choice : EmpiricalChoice K (nativeEmpiricalTrials K delta)) :
    0 ≤ nativeFiniteChoiceWeight r D predict lam B eps delta hB S x choice := outcomeMass_nonneg _ _ _

theorem nativeFiniteChoiceWeight_sum (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta : ℝ) (hB : 1 ≤ B) (S : P → ℝ) (x : X) :
    (∑ choice, nativeFiniteChoiceWeight r D predict lam B eps delta hB S x choice) = 1 :=
  sum_outcomeMass _ _ (measurable_of_finite _)

theorem integral_nativeFiniteChoiceLaw (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta : ℝ) (hB : 1 ≤ B) (S : P → ℝ) (x : X)
    (f : EmpiricalChoice K (nativeEmpiricalTrials K delta) → ℝ) :
    (∫ choice, f choice ∂(nativeFiniteChoiceLaw r D predict lam B eps delta hB S x).toMeasure) =
      ∑ choice, nativeFiniteChoiceWeight r D predict lam B eps delta hB S x choice * f choice := by
  exact integral_actionPMF (nativeFiniteChoiceWeight r D predict lam B eps delta hB S x)
    (nativeFiniteChoiceWeight_nonneg r D predict lam B eps delta hB S x)
    (nativeFiniteChoiceWeight_sum r D predict lam B eps delta hB S x) f

@[expose] def nativeFiniteOutcomeWeight (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta gamma : ℝ) (hB : 1 ≤ B) (S : P → ℝ) (x : X)
    (o : NativeFiniteOutcome K delta) : ℝ :=
  choiceActionWeight (nativeFiniteChoiceWeight r D predict lam B eps delta hB S x)
    (choiceProbability K gamma (nativeEmpiricalTrials K delta)) o

@[expose] def nativeFiniteOutcomeUpdate (predict : P → X → Fin K) (delta gamma : ℝ)
    (S : P → ℝ) (x : X) (c : Fin K → ℝ) (o : NativeFiniteOutcome K delta) : P → ℝ :=
  treeUpdatedScore S (choiceProbability K gamma (nativeEmpiricalTrials K delta) o.1) c (fun p => predict p x) o.2

theorem nativeFiniteOutcomeWeight_nonneg (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta gamma : ℝ) (hB : 1 ≤ B) (hg0 : 0 ≤ gamma) (hg1 : gamma ≤ 1)
    (S : P → ℝ) (x : X) (o : NativeFiniteOutcome K delta) :
    0 ≤ nativeFiniteOutcomeWeight r D predict lam B eps delta gamma hB S x o :=
  choiceActionWeight_nonneg _ _ (nativeFiniteChoiceWeight_nonneg r D predict lam B eps delta hB S x)
    (choiceProbability_nonneg gamma hg0 hg1 _ (nativeEmpiricalTrials_pos K delta)) o

theorem nativeFiniteOutcomeWeight_sum (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta gamma : ℝ) (hB : 1 ≤ B) (hK : 0 < K) (S : P → ℝ) (x : X) :
    (∑ o, nativeFiniteOutcomeWeight r D predict lam B eps delta gamma hB S x o) = 1 :=
  choiceActionWeight_sum _ _ (nativeFiniteChoiceWeight_sum r D predict lam B eps delta hB S x)
    (choiceProbability_sum hK gamma _ (nativeEmpiricalTrials_pos K delta))

theorem nativeFiniteOutcome_mean_update (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta gamma : ℝ) (hB : 1 ≤ B) (hK : 0 < K)
    (hg0 : 0 < gamma) (hg1 : gamma ≤ 1) (S : P → ℝ) (x : X) (c : Fin K → ℝ) :
    (fun p => ∑ o, nativeFiniteOutcomeWeight r D predict lam B eps delta gamma hB S x o *
      nativeFiniteOutcomeUpdate predict delta gamma S x c o p) = fun p => S p - c (predict p x) :=
  choiceActionWeight_mean_update _ _ (nativeFiniteChoiceWeight_sum r D predict lam B eps delta hB S x)
    (choiceProbability_pos hK gamma hg0 hg1 _ (nativeEmpiricalTrials_pos K delta))
    (choiceProbability_sum hK gamma _ (nativeEmpiricalTrials_pos K delta)) S c (fun p => predict p x)

theorem nativeRoundFunctional_add_value (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B : ℝ) (hB : 1 ≤ B) (S : P → ℝ) (x : X)
    (c q : Fin K → ℝ) (hqs : ∑ a, q a = 1) :
    (∑ a, q a * (c a + nativeVariationalValue r D predict lam B hB (treeUpdatedScore S q c (fun p => predict p x) a))) =
      nativeRoundFunctional r D predict lam B hB S x c q + nativeVariationalValue r D predict lam B hB S := by
  simp only [treeUpdatedScore_eq_actionPenalty, nativeRoundFunctional, mul_add, mul_sub,
    Finset.sum_add_distrib, Finset.sum_sub_distrib, ← Finset.sum_mul, hqs, one_mul]
  ring

theorem native_finite_sum_round_bound (r : NNReal) (hr : 0 < (r : ℝ)) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta gamma : ℝ)
    (hlam : 0 < lam) (hB : 1 ≤ B) (heps : 0 < eps) (hd : 0 < delta) (hK : 0 < K)
    (hg : 0 < gamma) (hgsmall : gamma ≤ 1 / 2) (hcap : (K : ℝ) / gamma ≤ B)
    (hlamBudget : 4 * (r : ℝ) * explorationLog K gamma ≤ lam)
    (hepsBudget : eps ≤ lam * delta ^ 2 / (32 * B ^ 2 * ((r : ℝ) + 1) ^ 2 * K))
    (c : X → Fin K → ℝ) (hc0 : ∀ x a, 0 ≤ c x a) (hc1 : ∀ x a, c x a ≤ 1) (S : P → ℝ) :
    (∑ x, (D {x}).toReal * ∑ o, nativeFiniteOutcomeWeight r D predict lam B eps delta gamma hB S x o *
      (c x o.2 + nativeVariationalValue r D predict lam B hB (nativeFiniteOutcomeUpdate predict delta gamma S x (c x) o))) ≤
        nativeVariationalValue r D predict lam B hB S + nativeRoundSlack P r K lam B gamma + (1 + K / gamma) * delta := by
  let s : NativeScaleBox X K B := ⟨nativeOptimalScale r D predict lam B hB S,
    (optimalScale_spec (markedPoolLaw r (contextLaplaceLaw D K)) (poissonCoefficient predict)
      (integrable_poissonCoefficient r D predict) (fun j => (D {j.1}).toReal) lam B hB S).1⟩
  have hmin := (optimalScale_spec (markedPoolLaw r (contextLaplaceLaw D K)) (poissonCoefficient predict)
    (integrable_poissonCoefficient r D predict) (fun j => (D {j.1}).toReal) lam B hB S).2
  have h := native_capped_one_round_bound r hr D predict S lam B eps delta gamma hlam hB heps hd hK hg hgsmall hcap hlamBudget s hmin hepsBudget c hc0 hc1
  change (∫ x, ∫ choice, nativeRoundFunctional r D predict lam B hB S x (c x) (choiceProbability K gamma (nativeEmpiricalTrials K delta) choice)
    ∂(nativeFiniteChoiceLaw r D predict lam B eps delta hB S x).toMeasure ∂D) ≤ _ at h
  simp_rw [integral_nativeFiniteChoiceLaw] at h
  rw [integral_fintype Integrable.of_finite] at h
  simp only [Measure.real, smul_eq_mul] at h
  have heq : (∑ x, (D {x}).toReal * ∑ o, nativeFiniteOutcomeWeight r D predict lam B eps delta gamma hB S x o *
      (c x o.2 + nativeVariationalValue r D predict lam B hB (nativeFiniteOutcomeUpdate predict delta gamma S x (c x) o))) =
    (∑ x, (D {x}).toReal * ∑ choice, nativeFiniteChoiceWeight r D predict lam B eps delta hB S x choice *
      nativeRoundFunctional r D predict lam B hB S x (c x) (choiceProbability K gamma (nativeEmpiricalTrials K delta) choice)) +
        nativeVariationalValue r D predict lam B hB S := by
    simp only [Fintype.sum_prod_type, nativeFiniteOutcomeWeight, choiceActionWeight, nativeFiniteOutcomeUpdate,
      mul_assoc, ← Finset.mul_sum]
    simp_rw [nativeRoundFunctional_add_value r D predict lam B hB S _ _ _
      (choiceProbability_sum hK gamma _ (nativeEmpiricalTrials_pos K delta) _)]
    exact finite_weighted_add_const _ (nativeFiniteChoiceWeight r D predict lam B eps delta hB S)
      (context_mass_sum D) (nativeFiniteChoiceWeight_sum r D predict lam B eps delta hB S) _ _
  rw [heq]
  linarith

theorem native_capped_finite_context_regret (r : NNReal) (hr : 0 < (r : ℝ)) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (lam B eps delta gamma : ℝ)
    (hlam : 0 < lam) (hB : 1 ≤ B) (heps : 0 < eps) (hd : 0 < delta) (hK : 0 < K)
    (hg : 0 < gamma) (hgsmall : gamma ≤ 1 / 2) (hcap : (K : ℝ) / gamma ≤ B)
    (hlamBudget : 4 * (r : ℝ) * explorationLog K gamma ≤ lam)
    (hepsBudget : eps ≤ lam * delta ^ 2 / (32 * B ^ 2 * ((r : ℝ) + 1) ^ 2 * K))
    (costs : List (X → Fin K → ℝ)) (hc0 : ∀ c ∈ costs, ∀ x a, 0 ≤ c x a)
    (hc1 : ∀ c ∈ costs, ∀ x a, c x a ≤ 1) :
    finiteOutcomeLoss (fun x => (D {x}).toReal) Prod.snd
      (nativeFiniteOutcomeWeight r D predict lam B eps delta gamma hB) (nativeFiniteOutcomeUpdate predict delta gamma) costs (fun _ => 0) +
        contextBestScore (fun x => (D {x}).toReal) predict costs (fun _ => 0) ≤
          6 * (r : ℝ) * K + lam * K * Real.log B + costs.length * (nativeRoundSlack P r K lam B gamma + (1 + K / gamma) * delta) := by
  have hgm : gamma ≤ 1 := by linarith
  have h := finiteOutcome_regret (fun x => (D {x}).toReal) (fun _ => ENNReal.toReal_nonneg) (context_mass_sum D)
    predict Prod.snd (nativeFiniteOutcomeWeight r D predict lam B eps delta gamma hB)
    (nativeFiniteOutcomeWeight_nonneg r D predict lam B eps delta gamma hB hg.le hgm)
    (nativeFiniteOutcomeWeight_sum r D predict lam B eps delta gamma hB hK)
    (nativeFiniteOutcomeUpdate predict delta gamma)
    (nativeFiniteOutcome_mean_update r D predict lam B eps delta gamma hB hK hg hgm)
    (nativeVariationalValue r D predict lam B hB)
    (fun S p => poisson_variationalValue_ge_score r D predict S lam B hlam.le hB p)
    (nativeRoundSlack P r K lam B gamma + (1 + K / gamma) * delta) costs
    (fun c hc S => by
      have hrnd := native_finite_sum_round_bound r hr D predict lam B eps delta gamma hlam hB heps hd hK hg hgsmall hcap hlamBudget hepsBudget c (hc0 c hc) (hc1 c hc) S
      linarith) (fun _ => 0)
  have hi := native_initial_value_bound r D predict lam B hB
  linarith
end
end PoissonAudit
