module

public import Mathlib.Probability.Distributions.Poisson.Basic
public import Mathlib.Tactic

public section

open MeasureTheory ProbabilityTheory

namespace PoissonAudit

noncomputable section

private theorem poisson_weighted_exp_sum (r : NNReal) :
    HasSum (fun n : ℕ => Real.exp (-(r : ℝ)) * (r : ℝ) ^ n / n.factorial * Real.exp n)
      (Real.exp ((Real.exp 1 - 1) * r)) := by
  have h := (NormedSpace.expSeries_div_hasSum_exp ((r : ℝ) * Real.exp 1)).mul_left (Real.exp (-(r : ℝ)))
  rw [← Real.exp_eq_exp_ℝ, ← Real.exp_add] at h
  convert h using 1
  · funext n
    rw [mul_pow, ← Real.exp_nat_mul]
    simp only [mul_one]
    ring
  · congr 1
    ring

theorem poisson_exp_tail (r : NNReal) (M : ℕ) :
    (poissonMeasure r).real {n : ℕ | M < n} ≤ Real.exp ((Real.exp 1 - 1) * r - M) := by
  let μ := poissonMeasure r
  let E := {n : ℕ | M < n}
  have hE : MeasurableSet E := .of_discrete
  have h := poisson_weighted_exp_sum r
  have hi : Integrable (fun n : ℕ => Real.exp n) μ := by
    apply integrable_poissonMeasure_iff.mpr
    simpa only [Real.norm_eq_abs, abs_of_pos (Real.exp_pos _)] using h.summable
  have hmean : (∫ n : ℕ, Real.exp n ∂μ) = Real.exp ((Real.exp 1 - 1) * r) := by
    rw [integral_poissonMeasure]
    exact h.tsum_eq
  have hmajor (n : ℕ) : E.indicator (fun _ => Real.exp (M : ℝ)) n ≤ Real.exp n := by
    by_cases hn : n ∈ E
    · rw [Set.indicator_of_mem hn]
      exact Real.exp_le_exp.mpr (by exact_mod_cast (le_of_lt (show M < n from hn)))
    · rw [Set.indicator_of_notMem hn]
      exact (Real.exp_pos _).le
  have hb := integral_mono ((integrable_const (Real.exp (M : ℝ))).indicator hE) hi hmajor
  rw [integral_indicator_const _ hE, smul_eq_mul, hmean] at hb
  rw [Real.exp_sub]
  exact (le_div_iff₀ (Real.exp_pos _)).mpr hb

theorem paper_count_cap (r : NNReal) (count : ℕ) (hc : 0 < count) (δ : ℝ) (hd : 0 < δ) :
    let M := ⌈(Real.exp 1 - 1) * (r : ℝ) + Real.log (4 * count / δ)⌉₊
    (count : ℝ) * (poissonMeasure r).real {n : ℕ | M < n} ≤ δ / 4 := by
  dsimp only
  have hpos : 0 < 4 * (count : ℝ) / δ := by positivity
  have hcap := Nat.le_ceil ((Real.exp 1 - 1) * (r : ℝ) + Real.log (4 * count / δ))
  have h := (poisson_exp_tail r _).trans (Real.exp_le_exp.mpr
    (show _ ≤ -Real.log (4 * count / δ) by linarith only [hcap]))
  rw [Real.exp_neg, Real.exp_log hpos] at h
  calc
    _ ≤ (count : ℝ) * (4 * count / δ)⁻¹ := mul_le_mul_of_nonneg_left h (by positivity)
    _ = _ := by field_simp

end
end PoissonAudit
