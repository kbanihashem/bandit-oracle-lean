module

public import PoissonAudit.ScaleUniqueness
public import Mathlib.Analysis.Convex.Deriv
public import Mathlib.Analysis.SpecialFunctions.Log.Deriv
public import Mathlib.Analysis.Calculus.Deriv.Inv

public section

open Set

namespace PoissonAudit

theorem convex_neg_log_sub_quadratic (B : ℝ) (hB : 1 ≤ B) :
    ConvexOn ℝ (Icc 1 B) (fun x => -Real.log x - x ^ 2 / (2 * B ^ 2)) := by
  have hB0 : 0 < B := by linarith
  have hpos : ∀ x ∈ Icc (1 : ℝ) B, 0 < x := by intro x hx; linarith [hx.1]
  have hd (x : ℝ) (hx : x ≠ 0) :
      HasDerivAt (fun x => -Real.log x - x ^ 2 / (2 * B ^ 2))
        (-x⁻¹ - x / B ^ 2) x := by
    convert! ((Real.hasDerivAt_log hx).neg.sub (((hasDerivAt_id x).pow 2).div_const (2 * B ^ 2))) using 1 <;>
      simp only [id_eq, Nat.reduceSub, pow_one, mul_one] <;> field_simp <;> ring
  have hdd (x : ℝ) (hx : x ≠ 0) :
      HasDerivAt (fun x => -x⁻¹ - x / B ^ 2) ((x ^ 2)⁻¹ - (B ^ 2)⁻¹) x := by
    convert! (hasDerivAt_inv hx).neg.sub ((hasDerivAt_id x).div_const (B ^ 2)) using 1 <;> simp
  apply convexOn_of_hasDerivWithinAt2_nonneg (f' := fun x => -x⁻¹ - x / B ^ 2)
    (f'' := fun x => (x ^ 2)⁻¹ - (B ^ 2)⁻¹) (convex_Icc 1 B)
  · exact ((continuousOn_id.log (fun x hx => (hpos x hx).ne')).neg).sub
      ((continuousOn_id.pow 2).div_const _)
  · intro x hx
    exact (hd x (hpos x (interior_subset hx)).ne').hasDerivWithinAt
  · intro x hx
    exact (hdd x (hpos x (interior_subset hx)).ne').hasDerivWithinAt
  · intro x hx
    have hx' := interior_subset hx
    apply sub_nonneg.mpr
    simpa only [one_div] using
      (one_div_le_one_div_of_le (sq_pos_of_pos (hpos x hx'))
        ((sq_le_sq₀ (hpos x hx').le hB0.le).mpr hx'.2))

theorem log_ratio_strong_jensen {B s t a b : ℝ} (hB : 1 ≤ B)
    (hs : s ∈ Icc 1 B) (ht : t ∈ Icc 1 B)
    (ha : 0 ≤ a) (hb : 0 ≤ b) (hab : a + b = 1) :
    Real.log (B / (a * s + b * t)) ≤
      a * Real.log (B / s) + b * Real.log (B / t) -
        a * b / (2 * B ^ 2) * (s - t) ^ 2 := by
  have hB0 : 0 < B := by linarith
  have hs0 : 0 < s := by linarith [hs.1]
  have ht0 : 0 < t := by linarith [ht.1]
  have hm0 : 0 < a * s + b * t := (convex_Ioi (0 : ℝ)) hs0 ht0 ha hb hab
  have h := (convex_neg_log_sub_quadratic B hB).2 hs ht ha hb hab
  simp only [smul_eq_mul] at h
  rw [Real.log_div hB0.ne' hm0.ne', Real.log_div hB0.ne' hs0.ne', Real.log_div hB0.ne' ht0.ne']
  have hBsum : (a + b) * Real.log B = Real.log B := by rw [hab, one_mul]
  have hsq : a * s ^ 2 + b * t ^ 2 - (a * s + b * t) ^ 2 = a * b * (s - t) ^ 2 := by
    have hbb : b = 1 - a := by linarith
    rw [hbb]
    ring
  have hsqd := congrArg (fun x : ℝ => x / (2 * B ^ 2)) hsq
  simp only [add_div, sub_div, mul_div_assoc] at hsqd
  ring_nf at h hBsum hsqd ⊢
  linarith

end PoissonAudit
