module
public import PoissonAudit.OracleContextMap
public section
open MeasureTheory Set
namespace PoissonAudit
noncomputable section
variable {X Y : Type*} [MeasurableSpace X] [MeasurableSpace Y] {K : ℕ}

theorem mapNativeNoise_measurePreserving (f : X → Y) (hf : Measurable f) (r : NNReal)
    (D : Measure X) [IsProbabilityMeasure D] :
    MeasurePreserving (mapNativeNoise (K := K) f) (insertedExperimentLaw r D K)
      (insertedExperimentLaw r (D.map f) K) := by
  have hcontext : MeasurePreserving f D (D.map f) := ⟨hf, rfl⟩
  have hmark : MeasurePreserving (Prod.map f id) (contextLaplaceLaw D K) (contextLaplaceLaw (D.map f) K) :=
    hcontext.prod (MeasurePreserving.id (laplaceMeasure K))
  have hseq : MeasurePreserving (fun v : ℕ → X × (Fin K → ℝ) => fun i => Prod.map f id (v i))
      (markSequence (contextLaplaceLaw D K)) (markSequence (contextLaplaceLaw (D.map f) K)) := by
    refine ⟨Measurable.of_eval fun i => hmark.measurable.comp (measurable_pi_apply i), ?_⟩
    change (Measure.infinitePi (fun _ : ℕ => contextLaplaceLaw D K)).map _ = _
    rw [Measure.infinitePi_map_pi _ (fun _ => hmark.measurable)]
    simp only [hmark.map_eq]
    rfl
  exact (MeasurePreserving.id (laplaceMeasure K)).prod
    ((MeasurePreserving.id (ProbabilityTheory.poissonMeasure r)).prod hseq)

theorem mapNativeNoiseTape_measurePreserving (f : X → Y) (hf : Measurable f) (r : NNReal)
    (D : Measure X) [IsProbabilityMeasure D] (j : ℕ) :
    MeasurePreserving (mapNativeNoiseTape (K := K) f j) (nativeNoiseTapeLaw r D j)
      (nativeNoiseTapeLaw r (D.map f) j) := by
  haveI : IsProbabilityMeasure (D.map f) := (Measure.isProbabilityMeasure_map_iff hf.aemeasurable).mpr inferInstance
  induction j with
  | zero =>
    refine ⟨measurable_const, ?_⟩
    change (nativeNoiseTapeLaw (K := K) r D 0).map (fun _ => ULift.up ()) = Measure.dirac (ULift.up ())
    rw [Measure.map_const, measure_univ, one_smul]
  | succ j ih => exact ih.prod (mapNativeNoise_measurePreserving f hf r D)
end
end PoissonAudit
