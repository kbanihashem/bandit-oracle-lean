module

public import PoissonAudit.MaxLineIntegration
public import Mathlib.MeasureTheory.Integral.Prod

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {Omega P : Type*} [MeasurableSpace Omega]
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem measurable_sampled_winner_slope (A : P → Omega → ℝ) (B : P → ℝ)
    (hAm : ∀ p, Measurable (A p)) :
    Measurable (fun v : ℝ × Omega => B (lineWinner (fun p => A p v.2) B v.1)) := by
  apply (measurable_of_finite B).comp
  exact measurable_winner (fun p (v : ℝ × Omega) => A p v.2 + v.1 * B p)
    (fun p => ((hAm p).comp measurable_snd).add (measurable_fst.mul measurable_const))

theorem integrable_sampled_winner_slope (mu : Measure Omega) [IsProbabilityMeasure mu]
    (A : P → Omega → ℝ) (B : P → ℝ) (hAm : ∀ p, Measurable (A p)) (a b : ℝ) :
    Integrable (fun v : ℝ × Omega => B (lineWinner (fun p => A p v.2) B v.1))
      ((volume.restrict (uIoc a b)).prod mu) := by
  haveI : IsFiniteMeasure (volume.restrict (uIoc a b)) := by
    unfold uIoc
    infer_instance
  apply Integrable.of_bound (measurable_sampled_winner_slope A B hAm).aestronglyMeasurable
    (∑ p, |B p|)
  filter_upwards [] with v
  rw [Real.norm_eq_abs]
  exact Finset.single_le_sum (f := fun p : P => |B p|) (fun _ _ => abs_nonneg _)
    (Finset.mem_univ (lineWinner (fun p => A p v.2) B v.1))

theorem expected_lineMax_change (mu : Measure Omega) [IsProbabilityMeasure mu]
    (A : P → Omega → ℝ) (B : P → ℝ)
    (hAm : ∀ p, Measurable (A p)) (hAi : ∀ p, Integrable (A p) mu) (a b : ℝ) :
    (∫ omega, lineMax (fun p => A p omega) B b ∂mu) -
      (∫ omega, lineMax (fun p => A p omega) B a ∂mu) =
    ∫ t in a..b, ∫ omega, B (lineWinner (fun p => A p omega) B t) ∂mu := by
  classical
  have hFi (t : ℝ) : Integrable (fun omega => lineMax (fun p => A p omega) B t) mu := by
    apply integrable_finset_max mu Finset.univ Finset.univ_nonempty
    intro p _
    exact (hAi p).add (integrable_const (t * B p))
  calc
    _ = ∫ omega, lineMax (fun p => A p omega) B b - lineMax (fun p => A p omega) B a ∂mu :=
      (integral_sub (hFi b) (hFi a)).symm
    _ = ∫ omega, (∫ t in a..b, B (lineWinner (fun p => A p omega) B t)) ∂mu := by
      apply integral_congr_ae
      filter_upwards [] with omega
      exact (integral_winner_slope (fun p => A p omega) B a b).symm
    _ = _ := (intervalIntegral_integral_swap (integrable_sampled_winner_slope mu A B hAm a b)).symm

end

end PoissonAudit
