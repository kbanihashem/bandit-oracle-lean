module

public import Mathlib.Analysis.SpecialFunctions.Log.Basic
public import Mathlib.Tactic

public section

open scoped BigOperators

namespace PoissonAudit

theorem sqrt_discrepancy_le_kl_term {u w : ℝ}
    (hu : 0 ≤ u) (hw : 0 < w) :
    (Real.sqrt u - Real.sqrt w) ^ 2 ≤ u * Real.log (u / w) - u + w := by
  by_cases hz : u = 0
  · rw [hz]
    simp only [Real.sqrt_zero, zero_sub, neg_sq, zero_div, zero_mul, sub_zero, zero_add]
    exact (Real.sq_sqrt hw.le).le
  · have hu0 : 0 < u := lt_of_le_of_ne hu (Ne.symm hz)
    have hsu : 0 < Real.sqrt u := Real.sqrt_pos.mpr hu0
    have hsw : 0 < Real.sqrt w := Real.sqrt_pos.mpr hw
    have hlog := Real.log_le_sub_one_of_pos (div_pos hsw hsu)
    rw [Real.log_div hsw.ne' hsu.ne', Real.log_sqrt hw.le, Real.log_sqrt hu] at hlog
    have hmul := mul_le_mul_of_nonneg_left hlog (show 0 ≤ 2 * u by positivity)
    have hid : u * (Real.sqrt w / Real.sqrt u) = Real.sqrt u * Real.sqrt w := by
      rw [← mul_div_assoc]
      apply (div_eq_iff hsu.ne').2
      calc
        _ = (Real.sqrt u) ^ 2 * Real.sqrt w := by rw [Real.sq_sqrt hu]
        _ = _ := by ring
    have hmul' : u * (Real.log w - Real.log u) ≤
        2 * Real.sqrt u * Real.sqrt w - 2 * u := by
      calc
        _ = (2 * u) * (Real.log w / 2 - Real.log u / 2) := by ring
        _ ≤ (2 * u) * (Real.sqrt w / Real.sqrt u - 1) := hmul
        _ = _ := by linear_combination 2 * hid
    rw [Real.log_div hu0.ne' hw.ne']
    nlinarith [Real.sq_sqrt hu, Real.sq_sqrt hw.le, hmul']

theorem finite_hellinger_le_kl {A : Type*} [Fintype A]
    (u w : A → ℝ) (hu : ∀ a, 0 ≤ u a) (hw : ∀ a, 0 ≤ w a)
    (husum : ∑ a, u a = 1) (hwsum : ∑ a, w a = 1)
    (hsupport : ∀ a, w a = 0 → u a = 0) :
    ∑ a, (Real.sqrt (u a) - Real.sqrt (w a)) ^ 2 ≤
      ∑ a, u a * Real.log (u a / w a) := by
  have hp : ∀ a,
      (Real.sqrt (u a) - Real.sqrt (w a)) ^ 2 ≤
        u a * Real.log (u a / w a) - u a + w a := by
    intro a
    by_cases hz : w a = 0
    · simp [hz, hsupport a hz]
    · exact sqrt_discrepancy_le_kl_term (hu a) (lt_of_le_of_ne (hw a) (Ne.symm hz))
  calc
    _ ≤ ∑ a, (u a * Real.log (u a / w a) - u a + w a) :=
      Finset.sum_le_sum fun a _ => hp a
    _ = _ := by
      rw [Finset.sum_add_distrib, Finset.sum_sub_distrib, husum, hwsum]
      ring

end PoissonAudit
