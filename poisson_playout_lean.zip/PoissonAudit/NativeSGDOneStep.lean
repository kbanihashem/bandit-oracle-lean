module
public import PoissonAudit.NativeGradientMoments
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section

theorem weightedSquareDistance_nonneg {Q : Type*} [Fintype Q] (w sigma s : Q → ℝ)
    (hw : ∀ j, 0 ≤ w j) : 0 ≤ weightedSquareDistance w sigma s :=
  Finset.sum_nonneg (fun j _ => mul_nonneg (hw j) (sq_nonneg _))

theorem weightedSquareDistance_box_bound {Q : Type*} [Fintype Q] (w sigma s : Q → ℝ)
    (hw : ∀ j, 0 ≤ w j) (B : ℝ) (hsigma : sigma ∈ scaleBox Q B) (hs : s ∈ scaleBox Q B) :
    weightedSquareDistance w sigma s ≤ B ^ 2 * ∑ j, w j := by
  classical
  have hp (j : Q) : (sigma j - s j) ^ 2 ≤ B ^ 2 := by
    have h1 : (1 : ℝ) ≤ sigma j := hsigma.1 j
    have h2 := hsigma.2 j
    have h3 : (1 : ℝ) ≤ s j := hs.1 j
    have h4 := hs.2 j
    nlinarith [mul_nonneg (by linarith : 0 ≤ B - (sigma j - s j)) (by linarith : 0 ≤ B + (sigma j - s j))]
  have h := Finset.sum_le_sum (s := Finset.univ) (fun j _ => mul_le_mul_of_nonneg_left (hp j) (hw j))
  simpa only [weightedSquareDistance, ← Finset.sum_mul, mul_comm] using h

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def nativeSGDNext (r : NNReal) (predict : P → X → Fin K) (S : P → ℝ)
    (lam B eta : ℝ) (sigma : X × Fin K → ℝ)
    (v : (Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ)))) : X × Fin K → ℝ :=
  boxGradientStep sigma (nativeSampledGradient r predict sigma S lam v) B eta

theorem integrable_nativeSGDNext_distance (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ) (hB : 1 ≤ B)
    (sigma s : X × Fin K → ℝ) (hs : s ∈ scaleBox (X × Fin K) B) :
    Integrable (fun v => weightedSquareDistance (fun j => (D {j.1}).toReal)
      (nativeSGDNext r predict S lam B eta sigma v) s) (insertedExperimentLaw r D K) := by
  have hm : Measurable (fun v => weightedSquareDistance (fun j => (D {j.1}).toReal)
      (nativeSGDNext r predict S lam B eta sigma v) s) := by
    apply Finset.measurable_sum
    intro j _
    have hclip : Continuous (boxClip B) := by unfold boxClip; fun_prop
    have hj : Measurable (fun v => boxClip B (sigma j - eta * nativeSampledGradient r predict sigma S lam v j)) :=
      hclip.measurable.comp (measurable_const.sub
      ((measurable_nativeSampledGradient r predict sigma S lam j).const_mul eta))
    exact measurable_const.mul ((hj.sub measurable_const).pow_const 2)
  apply Integrable.of_bound hm.aestronglyMeasurable (B ^ 2 * K)
  filter_upwards [] with v
  rw [Real.norm_eq_abs, abs_of_nonneg (weightedSquareDistance_nonneg _ _ _ (fun _ => ENNReal.toReal_nonneg))]
  have h := weightedSquareDistance_box_bound (fun j : X × Fin K => (D {j.1}).toReal) (nativeSGDNext r predict S lam B eta sigma v) s
    (fun _ => ENNReal.toReal_nonneg) B (boxGradientStep_feasible sigma (nativeSampledGradient r predict sigma S lam v) B eta hB) hs
  rw [context_action_mass_sum D] at h
  exact h

theorem native_SGD_expected_descent (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ)
    (hlam : 0 ≤ lam) (hB : 1 ≤ B) (heta : 0 ≤ eta)
    (sigma s : X × Fin K → ℝ) (hsigma : sigma ∈ scaleBox (X × Fin K) B) (hs : s ∈ scaleBox (X × Fin K) B) :
    2 * eta * (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun j => (D {j.1}).toReal) lam B sigma -
        scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
          (fun j => (D {j.1}).toReal) lam B s) ≤
      weightedSquareDistance (fun j => (D {j.1}).toReal) sigma s -
        (∫ v, weightedSquareDistance (fun j => (D {j.1}).toReal)
          (nativeSGDNext r predict S lam B eta sigma v) s ∂insertedExperimentLaw r D K) +
            eta ^ 2 * (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2)) := by
  let w : X × Fin K → ℝ := fun j => (D {j.1}).toReal
  let mu := insertedExperimentLaw r D K
  let inner := fun v => nativeGradientInner D sigma s (nativeSampledGradient r predict sigma S lam v)
  let norm := fun v => nativeGradientSquaredNorm D (nativeSampledGradient r predict sigma S lam v)
  have hi : Integrable inner mu := integrable_nativeGradientInner r D predict sigma s S lam
  have hn : Integrable norm mu := integrable_nativeGradientSquaredNorm r D predict sigma S lam hsigma.1
  have hp (v) := boxGradientStep_descent w sigma (nativeSampledGradient r predict sigma S lam v) s
    (fun _ => ENNReal.toReal_nonneg) B eta hs
  have heq (v) : (∑ j, w j * nativeSampledGradient r predict sigma S lam v j * (sigma j - s j)) = inner v := by
    apply Finset.sum_congr rfl
    intro j _
    change _ = (sigma j - s j) * (w j * nativeSampledGradient r predict sigma S lam v j)
    ring
  have hpoint (v) : weightedSquareDistance w (nativeSGDNext r predict S lam B eta sigma v) s ≤
      weightedSquareDistance w sigma s - 2 * eta * inner v + eta ^ 2 * norm v := by
    have h := hp v
    rw [heq v] at h
    exact h
  have h := integral_mono (integrable_nativeSGDNext_distance r D predict S lam B eta hB sigma s hs)
    (((integrable_const _).sub (hi.const_mul (2 * eta))).add (hn.const_mul (eta ^ 2))) hpoint
  change _ ≤ ∫ v, weightedSquareDistance w sigma s - 2 * eta * inner v + eta ^ 2 * norm v ∂mu at h
  rw [integral_add (f := fun v => weightedSquareDistance w sigma s - 2 * eta * inner v)
      (g := fun v => eta ^ 2 * norm v) ((integrable_const _).sub (hi.const_mul _)) (hn.const_mul _),
    integral_sub (integrable_const _) (hi.const_mul _), integral_const, probReal_univ, one_smul,
    integral_const_mul, integral_const_mul] at h
  have hsupport := native_stochastic_supporting r D predict S sigma s lam B hlam (by linarith)
    (fun j => by have h : (1 : ℝ) ≤ sigma j := hsigma.1 j; linarith)
    (fun j => by have h : (1 : ℝ) ≤ s j := hs.1 j; linarith)
  have hsup := mul_le_mul_of_nonneg_left hsupport (show 0 ≤ 2 * eta from mul_nonneg (by norm_num) heta)
  have hnorm := mul_le_mul_of_nonneg_left (nativeGradientSquaredNorm_expectation r D predict sigma S lam hsigma.1) (sq_nonneg eta)
  change _ ≤ 2 * eta * (∫ v, inner v ∂mu) at hsup
  change eta ^ 2 * (∫ v, norm v ∂mu) ≤ _ at hnorm
  linarith
end
end PoissonAudit
