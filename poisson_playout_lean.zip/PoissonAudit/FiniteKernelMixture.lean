module
public import PoissonAudit.FiniteProductMixture
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {Omega A : Type*} [MeasurableSpace Omega] [Fintype A] [MeasurableSpace A] [MeasurableSingletonClass A]

@[expose] def finiteKernelMixtureWeight (mu : Measure Omega) (q : Omega → A → ℝ) (a : A) : ℝ := ∫ z, q z a ∂mu

theorem integrable_finiteKernelWeight (mu : Measure Omega) [IsProbabilityMeasure mu]
    (q : Omega → A → ℝ) (hq : ∀ z a, 0 ≤ q z a) (hsum : ∀ z, ∑ a, q z a = 1)
    (hqm : ∀ a, Measurable (fun z => q z a)) (a : A) : Integrable (fun z => q z a) mu := by
  apply Integrable.of_bound (hqm a).aestronglyMeasurable 1
  filter_upwards [] with z
  rw [Real.norm_eq_abs, abs_of_nonneg (hq z a), ← hsum z]
  exact Finset.single_le_sum (fun b _ => hq z b) (Finset.mem_univ a)

theorem finiteKernelMixtureWeight_nonneg (mu : Measure Omega) (q : Omega → A → ℝ) (hq : ∀ z a, 0 ≤ q z a) (a : A) :
    0 ≤ finiteKernelMixtureWeight mu q a := integral_nonneg fun z => hq z a

theorem finiteKernelMixtureWeight_sum (mu : Measure Omega) [IsProbabilityMeasure mu]
    (q : Omega → A → ℝ) (hq : ∀ z a, 0 ≤ q z a) (hsum : ∀ z, ∑ a, q z a = 1)
    (hqm : ∀ a, Measurable (fun z => q z a)) : (∑ a, finiteKernelMixtureWeight mu q a) = 1 := by
  unfold finiteKernelMixtureWeight
  rw [← integral_finsetSum _ (fun a _ => integrable_finiteKernelWeight mu q hq hsum hqm a)]
  simp only [hsum, integral_const, probReal_univ, one_smul]

@[expose] def finiteKernelMixtureLaw (mu : Measure Omega) [IsProbabilityMeasure mu]
    (q : Omega → A → ℝ) (hq : ∀ z a, 0 ≤ q z a) (hsum : ∀ z, ∑ a, q z a = 1)
    (hqm : ∀ a, Measurable (fun z => q z a)) : PMF A :=
  actionPMF (finiteKernelMixtureWeight mu q) (finiteKernelMixtureWeight_nonneg mu q hq)
    (finiteKernelMixtureWeight_sum mu q hq hsum hqm)

theorem integral_finiteKernelMixtureLaw (mu : Measure Omega) [IsProbabilityMeasure mu]
    (q : Omega → A → ℝ) (hq : ∀ z a, 0 ≤ q z a) (hsum : ∀ z, ∑ a, q z a = 1)
    (hqm : ∀ a, Measurable (fun z => q z a)) (f : A → ℝ) :
    (∫ a, f a ∂(finiteKernelMixtureLaw mu q hq hsum hqm).toMeasure) = ∫ z, ∑ a, q z a * f a ∂mu := by
  unfold finiteKernelMixtureLaw
  rw [integral_actionPMF, integral_finsetSum _ (fun a _ => (integrable_finiteKernelWeight mu q hq hsum hqm a).mul_const (f a))]
  apply Finset.sum_congr rfl
  intro a _
  exact (integral_mul_const _ _).symm

theorem measurable_outcomeMass_parameter {Lambda : Type*} [MeasurableSpace Lambda]
    (mu : Measure Omega) [IsProbabilityMeasure mu] (W : Lambda × Omega → A) (hW : Measurable W) (a : A) :
    Measurable (fun z : Lambda => outcomeMass mu (fun v => W (z, v)) a) := by
  classical
  have hE : MeasurableSet {v : Lambda × Omega | W v = a} := hW (measurableSet_singleton a)
  have hm : Measurable (fun v : Lambda × Omega => if W v = a then (1 : ℝ) else 0) := measurable_const.ite hE measurable_const
  have hi := hm.stronglyMeasurable.integral_prod_right' (ν := mu)
  have heq : (fun z : Lambda => outcomeMass mu (fun v => W (z, v)) a) =
      fun z => ∫ v, (if W (z, v) = a then (1 : ℝ) else 0) ∂mu := by
    funext z
    exact (integral_if_outcome mu _ (hW.comp (measurable_const.prodMk measurable_id)) a).symm
  rw [heq]
  exact hi.measurable
end
end PoissonAudit
