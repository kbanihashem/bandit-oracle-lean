module

public import PoissonAudit.ScaleUniqueness

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {Omega P Q : Type*} [MeasurableSpace Omega]
    [Fintype P] [Nonempty P] [Fintype Q]

@[expose] def optimalScale (mu : Measure Omega) [IsFiniteMeasure mu]
    (V : Omega → P → Q → ℝ) (hV : ∀ p j, Integrable (fun omega => V omega p j) mu)
    (w : Q → ℝ) (lam B : ℝ) (hB : 1 ≤ B) (S : P → ℝ) : Q → ℝ :=
  Classical.choose (exists_scale_minimizer mu S V hV w lam B hB)

theorem optimalScale_spec (mu : Measure Omega) [IsFiniteMeasure mu]
    (V : Omega → P → Q → ℝ) (hV : ∀ p j, Integrable (fun omega => V omega p j) mu)
    (w : Q → ℝ) (lam B : ℝ) (hB : 1 ≤ B) (S : P → ℝ) :
    optimalScale mu V hV w lam B hB S ∈ scaleBox Q B ∧
      IsMinOn (scaleObjective mu S V w lam B) (scaleBox Q B) (optimalScale mu V hV w lam B hB S) :=
  Classical.choose_spec (exists_scale_minimizer mu S V hV w lam B hB)

@[expose] def variationalValue (mu : Measure Omega) [IsFiniteMeasure mu]
    (V : Omega → P → Q → ℝ) (hV : ∀ p j, Integrable (fun omega => V omega p j) mu)
    (w : Q → ℝ) (lam B : ℝ) (hB : 1 ≤ B) (S : P → ℝ) : ℝ :=
  scaleObjective mu S V w lam B (optimalScale mu V hV w lam B hB S)

theorem variationalValue_le (mu : Measure Omega) [IsFiniteMeasure mu]
    (V : Omega → P → Q → ℝ) (hV : ∀ p j, Integrable (fun omega => V omega p j) mu)
    (w : Q → ℝ) (lam B : ℝ) (hB : 1 ≤ B) (S : P → ℝ)
    (sigma : Q → ℝ) (hsigma : sigma ∈ scaleBox Q B) :
    variationalValue mu V hV w lam B hB S ≤ scaleObjective mu S V w lam B sigma :=
  (optimalScale_spec mu V hV w lam B hB S).2 hsigma

theorem affinePoolPotential_mono_score (mu : Measure Omega) [IsFiniteMeasure mu]
    (V : Omega → P → Q → ℝ) (hV : ∀ p j, Integrable (fun omega => V omega p j) mu)
    (sigma : Q → ℝ) (S T : P → ℝ) (hST : S ≤ T) :
    affinePoolPotential mu S V sigma ≤ affinePoolPotential mu T V sigma := by
  classical
  apply integral_mono (integrable_affinePoolMax mu S V hV sigma)
    (integrable_affinePoolMax mu T V hV sigma)
  intro omega
  apply Finset.sup'_le
  intro p _
  exact (add_le_add (hST p) le_rfl).trans
    (Finset.le_sup' (s := Finset.univ) (f := fun p => T p + ∑ j, sigma j * V omega p j) (Finset.mem_univ p))

theorem variationalValue_mono (mu : Measure Omega) [IsFiniteMeasure mu]
    (V : Omega → P → Q → ℝ) (hV : ∀ p j, Integrable (fun omega => V omega p j) mu)
    (w : Q → ℝ) (lam B : ℝ) (hB : 1 ≤ B) :
    Monotone (variationalValue mu V hV w lam B hB) := by
  intro S T hST
  let sigma := optimalScale mu V hV w lam B hB T
  calc
    _ ≤ scaleObjective mu S V w lam B sigma :=
      variationalValue_le mu V hV w lam B hB S sigma (optimalScale_spec mu V hV w lam B hB T).1
    _ ≤ scaleObjective mu T V w lam B sigma :=
      add_le_add (affinePoolPotential_mono_score mu V hV sigma S T hST) le_rfl
    _ = _ := rfl

theorem variationalValue_envelope (mu : Measure Omega) [IsFiniteMeasure mu]
    (V : Omega → P → Q → ℝ) (hV : ∀ p j, Integrable (fun omega => V omega p j) mu)
    (w : Q → ℝ) (lam B : ℝ) (hB : 1 ≤ B) (S T : P → ℝ) :
    let sigma := optimalScale mu V hV w lam B hB S
    variationalValue mu V hV w lam B hB T - variationalValue mu V hV w lam B hB S ≤
      affinePoolPotential mu T V sigma - affinePoolPotential mu S V sigma := by
  exact minimizer_envelope mu S T V w lam B _ _
    (optimalScale_spec mu V hV w lam B hB S).1 (optimalScale_spec mu V hV w lam B hB T).2

theorem affinePoolPotential_ge_score (mu : Measure Omega) [IsProbabilityMeasure mu]
    (V : Omega → P → Q → ℝ) (hV : ∀ p j, Integrable (fun omega => V omega p j) mu)
    (hmean : ∀ p j, (∫ omega, V omega p j ∂mu) = 0)
    (S : P → ℝ) (sigma : Q → ℝ) (p : P) :
    S p ≤ affinePoolPotential mu S V sigma := by
  classical
  have hi : Integrable (fun omega => S p + ∑ j, sigma j * V omega p j) mu :=
    (integrable_const _).add (integrable_finsetSum _ fun j _ => (hV p j).const_mul _)
  have hh := integral_mono hi (integrable_affinePoolMax mu S V hV sigma)
    (fun omega => Finset.le_sup' (s := Finset.univ) (f := fun p => S p + ∑ j, sigma j * V omega p j) (Finset.mem_univ p))
  rw [integral_add (integrable_const _) (integrable_finsetSum _ fun j _ => (hV p j).const_mul _),
    integral_finsetSum _ (fun j _ => (hV p j).const_mul _)] at hh
  simp only [integral_const, probReal_univ, smul_eq_mul, one_mul, integral_const_mul, hmean,
    mul_zero, Finset.sum_const_zero, add_zero] at hh
  exact hh

theorem variationalValue_ge_score (mu : Measure Omega) [IsProbabilityMeasure mu]
    (V : Omega → P → Q → ℝ) (hV : ∀ p j, Integrable (fun omega => V omega p j) mu)
    (hmean : ∀ p j, (∫ omega, V omega p j ∂mu) = 0)
    (w : Q → ℝ) (hw : ∀ j, 0 ≤ w j) (lam B : ℝ) (hlam : 0 ≤ lam) (hB : 1 ≤ B)
    (S : P → ℝ) (p : P) : S p ≤ variationalValue mu V hV w lam B hB S := by
  let sigma := optimalScale mu V hV w lam B hB S
  have hsigma := (optimalScale_spec mu V hV w lam B hB S).1
  have hpen : 0 ≤ scalePenalty w lam B sigma := by
    apply mul_nonneg hlam
    apply Finset.sum_nonneg
    intro j _
    apply mul_nonneg (hw j)
    apply Real.log_nonneg
    have hs0 : 0 < sigma j := by have h : (1 : ℝ) ≤ sigma j := hsigma.1 j; linarith
    exact (le_div_iff₀ hs0).mpr (by simpa only [one_mul] using hsigma.2 j)
  have h := affinePoolPotential_ge_score mu V hV hmean S sigma p
  change S p ≤ affinePoolPotential mu S V sigma + scalePenalty w lam B sigma
  linarith

end

end PoissonAudit
