module
public import PoissonAudit.OracleSamplerQueries
public section
open MeasureTheory Set
namespace PoissonAudit
noncomputable section

@[expose] def vectorValues {K : ℕ} (v : Vector ℝ K) : Fin K → ℝ := v.get

theorem vectorValues_ofFn {K : ℕ} (f : Fin K → ℝ) : vectorValues (Vector.ofFn f) = f := by
  funext a
  simp [vectorValues, Vector.get, Vector.ofFn]
  congr 1

@[expose] def arrayValueOracleAction {X : Type*} {K : ℕ} (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (Q : List (CostExample X K)) (x : X) (v : Vector ℝ K) : Fin K := by
  classical
  let base := oracle (Q ++ [(x, vectorValues v)])
  let table := Vector.ofFn (fun a => oracle (boostedDesignatedQuery Q x (vectorValues v) a))
  exact if h : ∃ a, vectorValues table a = base + 1 then
    actionFromValueTable base (vectorValues table) h else fallback

theorem arrayValueOracleAction_eq {X : Type*} {K : ℕ} (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (Q : List (CostExample X K)) (x : X) (v : Vector ℝ K) :
    arrayValueOracleAction oracle fallback Q x v = valueOracleAction oracle fallback Q x (vectorValues v) := by
  unfold arrayValueOracleAction valueOracleAction
  simp only [vectorValues_ofFn]

@[expose] abbrev ArrayReplayState (K : ℕ) := Vector ℝ K × Vector ℝ K
@[expose] def arrayStateValues {K : ℕ} (state : ArrayReplayState K) : ReplayLocalState K :=
  (vectorValues state.1, vectorValues state.2)

@[expose] def arrayReplayLocalStep {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (j : ℕ) (record : ReplayRecord X K) (x : X) (state : ArrayReplayState K) : ArrayReplayState K := by
  classical
  let designated := Vector.ofFn (fun a => vectorValues state.1 a * record.1 a)
  let action := arrayValueOracleAction oracle fallback (history ++ record.2) x designated
  let next := Vector.ofFn (fun a => boxClip B (vectorValues state.1 a - eta *
    ((r : ℝ) * ((if action = a then 1 else 0) * record.1 a) - lam / vectorValues state.1 a)))
  let avg := Vector.ofFn (fun a => (j : ℝ) / ((j : ℝ) + 1) * vectorValues state.2 a +
    1 / ((j : ℝ) + 1) * vectorValues state.1 a)
  exact (next, avg)

theorem arrayReplayLocalStep_values {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (j : ℕ) (record : ReplayRecord X K) (x : X) (state : ArrayReplayState K) :
    arrayStateValues (arrayReplayLocalStep r lam B eta history oracle fallback j record x state) =
      replayLocalStep r lam B eta history oracle fallback j record x (arrayStateValues state) := by
  unfold arrayStateValues arrayReplayLocalStep replayLocalStep
  simp only [vectorValues_ofFn, arrayValueOracleAction_eq]

@[expose] def arrayReplayAt {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K) :
    List (ReplayRecord X K) → X → ArrayReplayState K
  | [], _ => (Vector.ofFn (fun _ => 1), Vector.ofFn (fun _ => 1))
  | record :: records, x => arrayReplayLocalStep r lam B eta history oracle fallback records.length record x
      (arrayReplayAt r lam B eta history oracle fallback records x)

theorem arrayReplayAt_values {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (records : List (ReplayRecord X K)) (x : X) :
    arrayStateValues (arrayReplayAt r lam B eta history oracle fallback records x) =
      replayAt r lam B eta history oracle fallback records x := by
  induction records with
  | nil => simp only [arrayReplayAt, arrayStateValues, vectorValues_ofFn, replayAt]
  | cons record records ih =>
    rw [arrayReplayAt, arrayReplayLocalStep_values, ih]
    rfl

@[expose] def arrayMakeReplayRecord {X : Type*} {K : ℕ} (current : X → Vector ℝ K) (v : NativeNoise X K) : ReplayRecord X K :=
  (v.1, List.ofFn (fun i : Fin v.2.1 =>
    let point := v.2.2 i
    let scale := current point.1
    let coeff := Vector.ofFn (fun a => vectorValues scale a * point.2 a)
    (point.1, vectorValues coeff)))

theorem arrayMakeReplayRecord_values {X : Type*} {K : ℕ} (current : X → Vector ℝ K) (v : NativeNoise X K) :
    arrayMakeReplayRecord current v = makeReplayRecord (fun x => vectorValues (current x)) v := by
  apply Prod.ext
  · rfl
  · unfold arrayMakeReplayRecord makeReplayRecord scaledPoolExamples
    simp only [vectorValues_ofFn]
    rfl

@[expose] def arrayBuildReplayRecords {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K) :
    (J : ℕ) → NativeNoiseTape X K J → List (ReplayRecord X K)
  | 0, _ => []
  | J + 1, tape =>
    let records := arrayBuildReplayRecords r lam B eta history oracle fallback J tape.1
    arrayMakeReplayRecord (fun x => (arrayReplayAt r lam B eta history oracle fallback records x).1) tape.2 :: records

theorem arrayBuildReplayRecords_eq {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (J : ℕ) (tape : NativeNoiseTape X K J) :
    arrayBuildReplayRecords r lam B eta history oracle fallback J tape = buildReplayRecords r lam B eta history oracle fallback J tape := by
  induction J with
  | zero => rfl
  | succ J ih =>
    simp only [arrayBuildReplayRecords, buildReplayRecords, ih, arrayMakeReplayRecord_values]
    congr 1
    congr 1
    funext x
    exact congrArg Prod.fst (arrayReplayAt_values r lam B eta history oracle fallback _ x)
end
end PoissonAudit
