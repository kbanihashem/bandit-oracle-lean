module
public import PoissonAudit.ContextScheduleLaw
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X Y O A P : Type*} [Fintype Y] [Fintype O] [Fintype A] [Fintype P] [Nonempty P]

@[expose] def finitePathContexts : (costs : List (Y → A → ℝ)) → outcomePaths O costs → (Fin costs.length → Y)
  | [], _ => fun i => Fin.elim0 i
  | _ :: cs, path => Fin.cons path.1 (finitePathContexts cs path.2.2)

@[expose] def finitePathOutcomes : (costs : List (Y → A → ℝ)) → outcomePaths O costs → (Fin costs.length → O)
  | [], _ => fun i => Fin.elim0 i
  | _ :: cs, path => Fin.cons path.2.1 (finitePathOutcomes cs path.2.2)

theorem transcriptToOutcomePath_contexts (f : X → Y) (costs : List (Y → A → ℝ))
    (path : ContextTranscript X O costs.length) :
    finitePathContexts costs (transcriptToOutcomePath f costs path) = fun i => f (transcriptContexts costs.length path i) := by
  induction costs with
  | nil => funext i; exact Fin.elim0 i
  | cons c cs ih =>
    funext i
    refine Fin.cases ?_ (fun j => ?_) i
    · rfl
    · exact congrFun (ih path.2.2) j

theorem transcriptToOutcomePath_outcomes (f : X → Y) (costs : List (Y → A → ℝ))
    (path : ContextTranscript X O costs.length) :
    finitePathOutcomes costs (transcriptToOutcomePath f costs path) = transcriptOutcomes costs.length path := by
  induction costs with
  | nil => funext i; exact Fin.elim0 i
  | cons c cs ih =>
    funext i
    refine Fin.cases ?_ (fun j => ?_) i
    · rfl
    · exact congrFun (ih path.2.2) j

theorem outcomePathLoss_eq_sum (action : O → A) (costs : List (Y → A → ℝ)) (path : outcomePaths O costs) :
    outcomePathLoss action costs path =
      ∑ i, costs.get i (finitePathContexts costs path i) (action (finitePathOutcomes costs path i)) := by
  induction costs with
  | nil => simp [outcomePathLoss]
  | cons c cs ih =>
    rw [outcomePathLoss, ih]
    simp only [List.length_cons]
    rw [Fin.sum_univ_succ]
    simp [finitePathContexts, finitePathOutcomes]
    rfl

theorem outcomePathTrueScore_eq_sum (predict : P → Y → A) (costs : List (Y → A → ℝ)) (S : P → ℝ)
    (path : outcomePaths O costs) :
    outcomePathTrueScore predict costs S path =
      fun p => S p - ∑ i, costs.get i (finitePathContexts costs path i) (predict p (finitePathContexts costs path i)) := by
  induction costs generalizing S with
  | nil => simp [outcomePathTrueScore]
  | cons c cs ih =>
    rw [outcomePathTrueScore, ih]
    funext p
    simp only [List.length_cons]
    rw [Fin.sum_univ_succ]
    simp only [finitePathContexts, Fin.cons_zero, Fin.cons_succ, List.get_eq_getElem, List.getElem_cons_zero, List.getElem_cons_succ, trueScoreStep]
    change S p - c path.1 (predict p path.1) -
      (∑ i, cs.get i (finitePathContexts cs path.2.2 i) (predict p (finitePathContexts cs path.2.2 i))) =
        S p - (c path.1 (predict p path.1) +
          ∑ i, cs.get i (finitePathContexts cs path.2.2 i) (predict p (finitePathContexts cs path.2.2 i)))
    ring
end
end PoissonAudit
