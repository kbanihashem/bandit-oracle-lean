module
public import PoissonAudit.NativeEnrichedTrial
public import PoissonAudit.FiniteProbabilityL1
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section

theorem integral_iid_eval {A : Type*} [MeasurableSpace A] (mu : Measure A) [IsProbabilityMeasure mu]
    (m : ℕ) (i : Fin m) (f : A → ℝ) (hfm : Measurable f) :
    (∫ u : Fin m → A, f (u i) ∂iidPool mu m) = ∫ a, f a ∂mu := by
  have he := measurePreserving_eval (fun _ : Fin m => mu) i
  have h := integral_map he.measurable.aemeasurable (f := f) (by rw [he.map_eq]; exact hfm.aestronglyMeasurable)
  rw [he.map_eq] at h
  exact h.symm

@[expose] def trialAnyOverflow {K m : ℕ} (u : Fin m → Fin K × Bool) : Bool := decide (∃ i, (u i).2 = true)

theorem trialAnyOverflow_bound {K m : ℕ} (u : Fin m → Fin K × Bool) :
    boolStatistic (trialAnyOverflow u) ≤ ∑ i, boolStatistic (u i).2 := by
  classical
  by_cases h : ∃ i, (u i).2 = true
  · obtain ⟨i, hi⟩ := h
    have hs := Finset.single_le_sum (f := fun j => boolStatistic (u j).2)
      (fun j _ => (boolStatistic_mem _).1) (Finset.mem_univ i)
    have hflag : trialAnyOverflow u = true := by simp [trialAnyOverflow, show ∃ i, (u i).2 = true from ⟨i, hi⟩]
    rw [hflag]
    simpa only [boolStatistic, hi, ite_true] using hs
  · have hflag : trialAnyOverflow u = false := by simp [trialAnyOverflow, h]
    rw [hflag]
    change 0 ≤ ∑ i, boolStatistic (u i).2
    exact Finset.sum_nonneg fun i _ => (boolStatistic_mem _).1

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem nativeEnrichedPool_action_projection (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (cap m : ℕ) :
    MeasurePreserving (fun u : Fin m → Fin K × Bool => fun i => (u i).1)
      (iidPool (nativeEnrichedLaw r D predict sigma S x cap).toMeasure m)
      (iidPool (nativeActionLaw r D predict sigma S x).toMeasure m) :=
  measurePreserving_pi (fun _ : Fin m => (nativeEnrichedLaw r D predict sigma S x cap).toMeasure)
    (fun _ => (nativeActionLaw r D predict sigma S x).toMeasure)
    (fun _ => nativeEnrichedLaw_action_projection r D predict sigma S x cap)

theorem native_enriched_reference_error (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (gamma : ℝ)
    (hg0 : 0 ≤ gamma) (hg1 : gamma ≤ 1) (x : X) (cap m : ℕ) (hm : 0 < m) (ref : Fin K → ℝ) :
    (∫ u, ∑ a, |empiricalMixture K gamma m (fun i => (u i).1) a - ref a|
      ∂iidPool (nativeEnrichedLaw r D predict sigma S x cap).toMeasure m) ≤
        K * Real.sqrt (1 / m) + ∑ a, |nativeBanditProbability r D predict sigma S gamma x a - ref a| := by
  let f := fun u : Fin m → Fin K => ∑ a, |empiricalMixture K gamma m u a - ref a|
  have he := nativeEnrichedPool_action_projection r D predict sigma S x cap m
  have h := integral_map he.measurable.aemeasurable (f := f)
    (by rw [he.map_eq]; exact (measurable_of_finite f).aestronglyMeasurable)
  rw [he.map_eq] at h
  change (∫ u, f u ∂iidPool (nativeActionLaw r D predict sigma S x).toMeasure m) = _ at h
  rw [← h]
  exact empiricalMixture_reference_error (experimentProbability r D predict sigma S x) ref
    (experimentProbability_nonneg r D predict sigma S x) (sum_experimentProbability r D predict sigma S x) gamma hg0 hg1 m hm

theorem native_enriched_trial_overflow_budget (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (cap m : ℕ) (hc : 0 < cap) :
    (∫ u, boolStatistic (trialAnyOverflow u) ∂iidPool (nativeEnrichedLaw r D predict sigma S x cap).toMeasure m) ≤
      m * ((r : ℝ) / cap) := by
  have h := integral_mono (μ := iidPool (nativeEnrichedLaw r D predict sigma S x cap).toMeasure m)
    Integrable.of_finite Integrable.of_finite trialAnyOverflow_bound
  rw [integral_finsetSum _ (fun _ _ => Integrable.of_finite)] at h
  have he (i : Fin m) : (∫ u : Fin m → Fin K × Bool, boolStatistic (u i).2 ∂iidPool (nativeEnrichedLaw r D predict sigma S x cap).toMeasure m) =
      (insertedExperimentLaw r D K).real (nativeOverflowEvent cap) := by
    rw [integral_iid_eval _ m i (fun b : Fin K × Bool => boolStatistic b.2) (measurable_of_finite _),
      nativeEnrichedLaw_overflow_mean r D predict sigma S x cap]
  simp only [he, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul] at h
  exact h.trans (mul_le_mul_of_nonneg_left (native_noise_overflow_bound (K := K) r D cap hc) (Nat.cast_nonneg m))
end
end PoissonAudit
