module

public import PoissonAudit.Algebra
public import PoissonAudit.EntropyVariational

public section

open InformationTheory

namespace PoissonAudit

theorem entropy_perspective_mono {p u : ℝ} (hp0 : 0 ≤ p) (hpu : p ≤ u) (hu1 : u ≤ 1) :
    p * (1 - Real.log p) ≤ u * (1 - Real.log u) := by
  have hu0 : 0 ≤ u := hp0.trans hpu
  have hlu : Real.log u ≤ 0 := Real.log_nonpos hu0 hu1
  by_cases hpz : p = 0
  · simp only [hpz, zero_mul]
    exact mul_nonneg hu0 (by linarith)
  have hp : 0 < p := lt_of_le_of_ne hp0 (Ne.symm hpz)
  have hu : 0 < u := hp.trans_le hpu
  have hkl := mul_nonneg hu.le (klFun_nonneg (div_nonneg hp0 hu.le))
  have heq : u * klFun (p / u) = p * Real.log p - p * Real.log u + u - p := by
    rw [klFun_apply, Real.log_div hp.ne' hu.ne']
    field_simp
  rw [heq] at hkl
  have hm := mul_le_mul_of_nonpos_right hpu hlu
  nlinarith

theorem weak_tail_probability_charge {alpha p q ell : ℝ}
    (hp0 : 0 ≤ p) (hp1 : p ≤ 1) (hq : 0 < q) (hpq : p ≤ 2 * q)
    (hell1 : 1 ≤ ell) (hellq : 1 - Real.log q ≤ ell)
    (htail : alpha ≤ 2 * p * (1 - Real.log p)) : alpha ≤ 4 * q * ell := by
  by_cases hqsmall : 2 * q ≤ 1
  · have hm := entropy_perspective_mono hp0 hpq hqsmall
    have hlog : Real.log (2 * q) = Real.log 2 + Real.log q :=
      Real.log_mul (by norm_num) hq.ne'
    have hlog2 : 0 ≤ Real.log 2 := Real.log_nonneg (by norm_num)
    have hb : 1 - Real.log (2 * q) ≤ ell := by rw [hlog]; linarith
    have hprod := mul_le_mul_of_nonneg_left hb (by positivity : 0 ≤ 4 * q)
    nlinarith
  · have hm := entropy_perspective_mono hp0 hp1 (by norm_num : (1 : ℝ) ≤ 1)
    simp only [Real.log_one] at hm
    have hprod := mul_le_mul_of_nonneg_left hell1 hq.le
    nlinarith

theorem scale_controls_update_weak {n ell lam q sigma B : ℝ}
    (hn : 0 < n) (hell : 0 < ell) (hq : 0 < q)
    (hsigma : 0 ≤ sigma) (hsigmaB : sigma ≤ B)
    (hlam : 4 * n * ell ≤ lam)
    (hinterior : sigma < B → ∃ alpha : ℝ,
      alpha ≤ 4 * q * ell ∧ lam ≤ n * sigma * alpha)
    (hcap : 1 ≤ q * B) : 1 / q ≤ sigma := by
  apply (div_le_iff₀ hq).mpr
  by_cases hb : sigma = B
  · simpa only [hb, mul_comm] using hcap
  · obtain ⟨alpha, halpha, hfo⟩ := hinterior (lt_of_le_of_ne hsigmaB hb)
    have hprod := mul_le_mul_of_nonneg_left halpha (mul_nonneg hn.le hsigma)
    have hpos : 0 < 4 * n * ell := by positivity
    have hh : (4 * n * ell) * 1 ≤ (4 * n * ell) * (q * sigma) := by nlinarith
    have hc := (mul_le_mul_iff_of_pos_left hpos).mp hh
    simpa only [mul_comm] using hc

end PoissonAudit
