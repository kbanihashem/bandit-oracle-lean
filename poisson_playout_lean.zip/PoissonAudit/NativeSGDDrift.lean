module
public import PoissonAudit.NativeSGDProcess
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem nativeBoxAverage_jensen (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B : ℝ) (hlam : 0 ≤ lam) (hB : 1 ≤ B)
    (j : ℕ) (avg curr : NativeScaleBox X K B) :
    ((j : ℝ) + 1) * nativeBoxObjective r D predict S lam B (nativeBoxAverage B j avg curr) ≤
      (j : ℝ) * nativeBoxObjective r D predict S lam B avg + nativeBoxObjective r D predict S lam B curr := by
  let a : ℝ := j / ((j : ℝ) + 1)
  let b : ℝ := 1 / ((j : ℝ) + 1)
  have hd : 0 < (j : ℝ) + 1 := by positivity
  have ha : 0 ≤ a := div_nonneg (Nat.cast_nonneg _) hd.le
  have hb : 0 ≤ b := one_div_nonneg.mpr hd.le
  have hab : a + b = 1 := by dsimp [a, b]; field_simp
  have hF := (convex_affinePoolPotential (markedPoolLaw r (contextLaplaceLaw D K)) S
    (poissonCoefficient predict) (integrable_poissonCoefficient r D predict)).2
      (Set.mem_univ avg.val) (Set.mem_univ curr.val) ha hb hab
  have hC := (convex_scalePenalty (fun q : X × Fin K => (D {q.1}).toReal)
    (fun _ => ENNReal.toReal_nonneg) lam B hlam hB).2 avg.property curr.property ha hb hab
  have hJ : nativeBoxObjective r D predict S lam B (nativeBoxAverage B j avg curr) ≤
      a * nativeBoxObjective r D predict S lam B avg + b * nativeBoxObjective r D predict S lam B curr := by
    change affinePoolPotential _ _ _ _ + scalePenalty _ _ _ _ ≤ _
    simp only [nativeBoxObjective, scaleObjective, smul_eq_mul] at hF hC ⊢
    change affinePoolPotential _ _ _ (a • avg.val + b • curr.val) +
      scalePenalty _ _ _ (a • avg.val + b • curr.val) ≤ _
    nlinarith
  have hmul := mul_le_mul_of_nonneg_left hJ hd.le
  have haeq : ((j : ℝ) + 1) * a = j := by dsimp [a]; field_simp
  have hbeq : ((j : ℝ) + 1) * b = 1 := by dsimp [b]; field_simp
  have heq : ((j : ℝ) + 1) * (a * nativeBoxObjective r D predict S lam B avg +
      b * nativeBoxObjective r D predict S lam B curr) =
        (j : ℝ) * nativeBoxObjective r D predict S lam B avg + nativeBoxObjective r D predict S lam B curr := by
    rw [mul_add, ← mul_assoc, haeq, ← mul_assoc, hbeq, one_mul]
  rw [heq] at hmul
  exact hmul

theorem native_SGD_lyapunov_drift (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ)
    (hlam : 0 ≤ lam) (hB : 1 ≤ B) (heta : 0 ≤ eta) (s : NativeScaleBox X K B)
    (j : ℕ) (state : NativeSGDState X K B) :
    (∫ v, nativeSGDLyapunov r D predict S lam B eta s (j + 1)
      (nativeSGDTransition r predict S lam B eta hB j state v) ∂insertedExperimentLaw r D K) ≤
      nativeSGDLyapunov r D predict S lam B eta s j state + eta ^ 2 * (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2)) := by
  let J := nativeBoxObjective r D predict S lam B
  have hd := native_SGD_expected_descent r D predict S lam B eta hlam hB heta state.1.val s.val state.1.property s.property
  have hj := nativeBoxAverage_jensen r D predict S lam B hlam hB j state.2 state.1
  have hm := mul_le_mul_of_nonneg_left hj (show 0 ≤ 2 * eta from mul_nonneg (by norm_num) heta)
  change (∫ v, 2 * eta * (j + 1 : ℕ) * (J (nativeBoxAverage B j state.2 state.1) - J s) +
      weightedSquareDistance (fun q => (D {q.1}).toReal) (nativeSGDNext r predict S lam B eta state.1.val v) s.val
      ∂insertedExperimentLaw r D K) ≤ _
  rw [integral_add (integrable_const _) (integrable_nativeSGDNext_distance r D predict S lam B eta hB state.1.val s.val s.property),
    integral_const, probReal_univ, one_smul]
  change 2 * eta * (J state.1 - J s) ≤ _ at hd
  change 2 * eta * (((j : ℝ) + 1) * J (nativeBoxAverage B j state.2 state.1)) ≤
    2 * eta * ((j : ℝ) * J state.2 + J state.1) at hm
  change _ ≤ 2 * eta * j * (J state.2 - J s) + weightedSquareDistance _ state.1.val s.val + _
  simp only [Nat.cast_add, Nat.cast_one]
  nlinarith
end
end PoissonAudit
