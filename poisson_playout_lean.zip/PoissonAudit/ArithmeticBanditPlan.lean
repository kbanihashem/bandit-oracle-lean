module
public import PoissonAudit.ArithmeticPolynomialTuning
public import PoissonAudit.ExecutionPolynomial
public import PoissonAudit.NativeCappedLaw
public section
namespace PoissonAudit
noncomputable section

structure BanditParameters where
  r : NNReal
  lam : ℝ
  B : ℝ
  gamma : ℝ
  eps : ℝ
  delta : ℝ

@[expose] def arithmeticBanditPlan (K T : ℕ) (L : ℝ) : BanditParameters :=
  let k : ℝ := K
  let t : ℝ := T
  let A := arithmeticTuningA (k * t * L)
  let B := k * (t + 1)
  let ell := arithmeticTuningLog B
  let r : NNReal := Real.toNNReal (A / (k * ell))
  let lam := 4 * A / k
  let gamma := 1 / (t + 1)
  let delta := gamma / (t * (gamma + k))
  let eps := lam * delta ^ 2 / (32 * B ^ 2 * ((r : ℝ) + 1) ^ 2 * k)
  ⟨r, lam, B, gamma, eps, delta⟩

@[expose] def BanditParameters.iterations (p : BanditParameters) (K : ℕ) : ℕ := nativeSGDIterations p.r K p.lam p.B p.eps
@[expose] def BanditParameters.trials (p : BanditParameters) (K : ℕ) : ℕ := nativeEmpiricalTrials K p.delta
@[expose] def BanditParameters.cap (p : BanditParameters) (K : ℕ) : ℕ := nativeCountCap p.r (p.iterations K + p.trials K) p.delta
@[expose] def BanditParameters.eta (p : BanditParameters) (K : ℕ) : ℝ := p.eps / (K * (64 * (p.r : ℝ) ^ 2 + 2 * p.lam ^ 2))

structure ValidBanditParameters (K : ℕ) (p : BanditParameters) : Prop where
  r_pos : 0 < (p.r : ℝ)
  lam_pos : 0 < p.lam
  B_one : 1 ≤ p.B
  gamma_pos : 0 < p.gamma
  gamma_small : p.gamma ≤ 1 / 2
  eps_pos : 0 < p.eps
  delta_pos : 0 < p.delta
  floor_bound : (K : ℝ) / p.gamma ≤ p.B
  stability : 4 * (p.r : ℝ) * explorationLog K p.gamma ≤ p.lam
  eps_budget : p.eps ≤ p.lam * p.delta ^ 2 / (32 * p.B ^ 2 * ((p.r : ℝ) + 1) ^ 2 * K)

theorem arithmeticBanditPlan_valid (K T : ℕ) (hK : 0 < K) (hT : 0 < T) (L : ℝ) (hL : 1 ≤ L) :
    ValidBanditParameters K (arithmeticBanditPlan K T L) := by
  have hk : (1 : ℝ) ≤ K := by exact_mod_cast hK
  have ht : (1 : ℝ) ≤ T := by exact_mod_cast hT
  have hs := arithmetic_tuning_charges hk ht hL (z := 0) (le_refl _) (by linarith)
  dsimp only at hs
  rcases hs with ⟨hr, hlam, hB, hg, hgs, hfloor, hstable, _⟩
  have hrval := Real.coe_toNNReal _ hr.le
  unfold arithmeticBanditPlan
  dsimp only
  constructor
  · simpa only [hrval] using hr
  · exact hlam
  · exact hB
  · exact hg
  · exact hgs
  · positivity
  · positivity
  · exact hfloor.le
  · rw [hrval, explorationLog_tuned hK ht]
    exact hstable
  · exact le_refl _

theorem arithmeticBanditPlan_charges (K T : ℕ) (hK : 0 < K) (hT : 0 < T) (L z : ℝ)
    (hL : 1 ≤ L) (hz : 0 ≤ z) (hzL : z ≤ L) :
    let p := arithmeticBanditPlan K T L
    6 * (p.r : ℝ) * K + p.lam * K * Real.log p.B +
      T * (p.gamma + (Real.exp 1 - 2) / (1 - p.gamma) * (4 * z / p.lam + K / p.B) +
        2 * Real.exp 1 * z / (p.r : ℝ)) ≤
          10 * Real.exp 1 * arithmeticTuningA ((K : ℝ) * T * L) * arithmeticTuningLog ((K : ℝ) * (T + 1)) := by
  have hk : (1 : ℝ) ≤ K := by exact_mod_cast hK
  have ht : (1 : ℝ) ≤ T := by exact_mod_cast hT
  have hs := arithmetic_tuning_charges hk ht hL hz hzL
  dsimp only at hs
  have hrval := Real.coe_toNNReal _ hs.1.le
  dsimp only [arithmeticBanditPlan]
  simpa only [hrval] using hs.2.2.2.2.2.2.2

theorem arithmeticBanditPlan_delta_charge (K T : ℕ) (hK : 0 < K) (hT : 0 < T) (L : ℝ) :
    let p := arithmeticBanditPlan K T L
    (T : ℝ) * ((1 + K / p.gamma) * p.delta) = 1 := by
  dsimp only [arithmeticBanditPlan]
  have ht : (T : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (by omega)
  have hden : 1 / ((T : ℝ) + 1) + K ≠ 0 := by positivity
  field_simp
  <;> ring

theorem arithmeticBanditPlan_resources (K T : ℕ) (hK : 0 < K) (hT : 0 < T) (L : ℝ) (hL : 1 ≤ L) :
    let p := arithmeticBanditPlan K T L
    let H := 2 + (K : ℝ) + T + L
    PowerBound H 82 (p.iterations K) ∧ PowerBound H 15 (p.trials K) ∧ PowerBound H 94 (p.cap K) ∧
      PowerBound H 353 (samplerInternalBudget K (p.cap K) (p.iterations K) (p.trials K)) := by
  have hk : (1 : ℝ) ≤ K := by exact_mod_cast hK
  have ht : (1 : ℝ) ≤ T := by exact_mod_cast hT
  have hprod : 1 ≤ (K : ℝ) * T * L := by nlinarith [mul_le_mul hk ht (by linarith) (by linarith)]
  have hA := arithmeticTuningA_bounds _ hprod
  have hB : 1 ≤ (K : ℝ) * (T + 1) := by nlinarith
  have hel := arithmeticTuningLog_bounds _ hB
  have hp := arithmetic_tuning_power_bounds K T L _ _ hk ht hL hA.1 hA.2.2 hel.1
  dsimp only at hp
  rcases hp with ⟨hH, hn, hlam0, hd0, heps0, hrP, hkP, hlamP, hBP, hepsP, hdP⟩
  have hrval := Real.coe_toNNReal _ hn.le
  let p := arithmeticBanditPlan K T L
  have hb := native_finite_budgets_power_bound (2 + (K : ℝ) + T + L) hH p.r K p.lam p.B p.eps p.delta
    (by simpa only [p, arithmeticBanditPlan, hrval] using hrP) hkP hlamP hBP
    (by simpa only [p, arithmeticBanditPlan, hrval] using hepsP) hdP
  rcases hb with ⟨hJ, hm, hc⟩
  exact ⟨hJ, hm, hc, samplerInternalBudget_power_bound _ hH K _ _ _ hkP hc hJ hm⟩
end
end PoissonAudit
