module
public import PoissonAudit.OracleReplay
public section
open MeasureTheory Set
namespace PoissonAudit
noncomputable section
universe u

@[expose] def NativeNoiseTape (X : Type u) (K : ℕ) : ℕ → Type u
  | 0 => ULift.{u} Unit
  | j + 1 => NativeNoiseTape X K j × NativeNoise X K

instance nativeNoiseTape_measurableSpace (X : Type u) [MeasurableSpace X] (K j : ℕ) : MeasurableSpace (NativeNoiseTape X K j) := by
  induction j with
  | zero => exact inferInstanceAs (MeasurableSpace (ULift.{u} Unit))
  | succ j ih => letI := ih; exact inferInstanceAs (MeasurableSpace (NativeNoiseTape X K j × NativeNoise X K))

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def nativeNoiseTapeLaw (r : NNReal) (D : Measure X) [IsProbabilityMeasure D] :
    (j : ℕ) → Measure (NativeNoiseTape X K j)
  | 0 => Measure.dirac (ULift.up ())
  | j + 1 => (nativeNoiseTapeLaw r D j).prod (insertedExperimentLaw r D K)

instance nativeNoiseTapeLaw_isProbability (r : NNReal) (D : Measure X) [IsProbabilityMeasure D] (j : ℕ) :
    IsProbabilityMeasure (nativeNoiseTapeLaw (K := K) r D j) := by
  induction j with
  | zero => exact inferInstanceAs (IsProbabilityMeasure (Measure.dirac (ULift.up () : ULift.{_} Unit)))
  | succ j ih => letI := ih; exact inferInstanceAs (IsProbabilityMeasure ((nativeNoiseTapeLaw r D j).prod (insertedExperimentLaw r D K)))

@[expose] def nativeTapeState (r : NNReal) (predict : P → X → Fin K) (S : P → ℝ)
    (lam B eta : ℝ) (hB : 1 ≤ B) : (j : ℕ) → NativeNoiseTape X K j → NativeSGDState X K B
  | 0, _ => (nativeUnitScale B hB, nativeUnitScale B hB)
  | j + 1, v => nativeSGDTransition r predict S lam B eta hB j (nativeTapeState r predict S lam B eta hB j v.1) v.2

theorem measurable_nativeTapeState (r : NNReal) (predict : P → X → Fin K) (S : P → ℝ)
    (lam B eta : ℝ) (hB : 1 ≤ B) (j : ℕ) : Measurable (nativeTapeState r predict S lam B eta hB j) := by
  induction j with
  | zero => exact measurable_const
  | succ j ih => exact (measurable_nativeSGDTransition r predict S lam B eta hB j).comp ((ih.comp measurable_fst).prodMk measurable_snd)

theorem nativeTapeState_measurePreserving (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ) (hB : 1 ≤ B) (j : ℕ) :
    MeasurePreserving (nativeTapeState r predict S lam B eta hB j) (nativeNoiseTapeLaw r D j)
      (nativeSGDStateLaw r D predict S lam B eta hB j) := by
  induction j with
  | zero =>
    refine ⟨measurable_const, ?_⟩
    change (nativeNoiseTapeLaw (K := K) r D 0).map
      (fun _ => (nativeUnitScale B hB, nativeUnitScale B hB)) = Measure.dirac (nativeUnitScale B hB, nativeUnitScale B hB)
    rw [Measure.map_const, measure_univ, one_smul]
  | succ j ih =>
    have hT : MeasurePreserving
        (fun v : NativeSGDState X K B × NativeNoise X K => nativeSGDTransition r predict S lam B eta hB j v.1 v.2)
        ((nativeSGDStateLaw r D predict S lam B eta hB j).prod (insertedExperimentLaw r D K))
        (nativeSGDStateLaw r D predict S lam B eta hB (j + 1)) :=
      ⟨measurable_nativeSGDTransition r predict S lam B eta hB j, rfl⟩
    exact hT.comp (ih.prod (MeasurePreserving.id (insertedExperimentLaw r D K)))

@[expose] def nativeStateTieGood (predict : P → X → Fin K) (S : P → ℝ) (B : ℝ)
    (state : NativeSGDState X K B) (v : NativeNoise X K) : Prop :=
  ∀ x p q, experimentScore predict state.1.val S x v p = experimentScore predict state.1.val S x v q → predict p x = predict q x

theorem measurableSet_nativeStateTieGood (predict : P → X → Fin K) (S : P → ℝ) (B : ℝ) :
    MeasurableSet {v : NativeSGDState X K B × NativeNoise X K | nativeStateTieGood predict S B v.1 v.2} := by
  have hs (x : X) (p : P) : Measurable (fun v : NativeSGDState X K B × NativeNoise X K => experimentScore predict v.1.1.val S x v.2 p) :=
    (measurable_joint_experimentScore predict S x p).comp
      ((measurable_subtype_coe.comp (measurable_fst.comp measurable_fst)).prodMk measurable_snd)
  simp only [nativeStateTieGood, Set.setOf_forall]
  apply MeasurableSet.iInter
  intro x
  apply MeasurableSet.iInter
  intro p
  apply MeasurableSet.iInter
  intro q
  by_cases h : predict p x = predict q x
  · simp only [h, implies_true, Set.setOf_true, MeasurableSet.univ]
  · have hc := (measurableSet_eq_fun (hs x p) (hs x q)).compl
    change MeasurableSet {v : NativeSGDState X K B × NativeNoise X K | ¬experimentScore predict v.1.1.val S x v.2 p = experimentScore predict v.1.1.val S x v.2 q} at hc
    simpa only [h, imp_false] using hc

@[expose] def nativeTapeGood (r : NNReal) (predict : P → X → Fin K) (S : P → ℝ)
    (lam B eta : ℝ) (hB : 1 ≤ B) : (j : ℕ) → NativeNoiseTape X K j → Prop
  | 0, _ => True
  | j + 1, v => nativeTapeGood r predict S lam B eta hB j v.1 ∧
      nativeStateTieGood predict S B (nativeTapeState r predict S lam B eta hB j v.1) v.2

theorem measurableSet_nativeTapeGood (r : NNReal) (predict : P → X → Fin K) (S : P → ℝ)
    (lam B eta : ℝ) (hB : 1 ≤ B) (j : ℕ) :
    MeasurableSet {v | nativeTapeGood r predict S lam B eta hB j v} := by
  induction j with
  | zero => exact MeasurableSet.univ
  | succ j ih =>
    exact (measurable_fst ih).inter
      (((measurable_nativeTapeState r predict S lam B eta hB j).comp measurable_fst).prodMk measurable_snd
        (measurableSet_nativeStateTieGood predict S B))

theorem nativeTapeGood_ae (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ) (hB : 1 ≤ B) (j : ℕ) :
    ∀ᵐ v ∂nativeNoiseTapeLaw r D j, nativeTapeGood r predict S lam B eta hB j v := by
  induction j with
  | zero => exact Filter.Eventually.of_forall fun _ => trivial
  | succ j ih =>
    have hE := measurableSet_nativeTapeGood r predict S lam B eta hB (j + 1)
    apply (Measure.ae_prod_iff_ae_ae hE).mpr
    filter_upwards [ih] with tape htape
    have hpos (q : X × Fin K) : 0 < (nativeTapeState r predict S lam B eta hB j tape).1.val q :=
      lt_of_lt_of_le zero_lt_one ((nativeTapeState r predict S lam B eta hB j tape).1.property.1 q)
    filter_upwards [native_inserted_all_context_ties r D predict (nativeTapeState r predict S lam B eta hB j tape).1.val S hpos] with v hv
    exact ⟨htape, hv⟩
end
end PoissonAudit
