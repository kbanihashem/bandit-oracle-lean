module

public import PoissonAudit.ShiftedMidpoint
public import Mathlib.Analysis.SpecialFunctions.ImproperIntegrals
public import Mathlib.MeasureTheory.Integral.Pi

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

theorem integrable_exp_neg_abs : Integrable (fun x : ℝ => Real.exp (-|x|)) := by
  have hl : IntegrableOn (fun x : ℝ => Real.exp (-|x|)) (Iic 0) :=
    (integrableOn_exp_Iic 0).congr_fun (by
      intro x hx
      simp only [mem_Iic] at hx
      simp only [abs_of_nonpos hx, neg_neg]) measurableSet_Iic
  have hr : IntegrableOn (fun x : ℝ => Real.exp (-|x|)) (Ioi 0) :=
    (integrableOn_exp_neg_Ioi 0).congr_fun (by
      intro x hx
      simp only [mem_Ioi] at hx
      simp only [abs_of_pos hx]) measurableSet_Ioi
  have hu : Iic (0 : ℝ) ∪ Ioi 0 = Set.univ := Iic_union_Ioi
  rw [← integrableOn_univ, ← hu, integrableOn_union]
  exact ⟨hl, hr⟩

theorem integral_exp_neg_abs : (∫ x : ℝ, Real.exp (-|x|)) = 2 := by
  have hl : (∫ x : ℝ in Iic 0, Real.exp (-|x|)) = 1 := by
    rw [← integral_exp_Iic_zero]
    apply setIntegral_congr_fun measurableSet_Iic
    intro x hx
    change Real.exp (-|x|) = Real.exp x
    rw [abs_of_nonpos hx, neg_neg]
  have hr : (∫ x : ℝ in Ioi 0, Real.exp (-|x|)) = 1 := by
    rw [← integral_exp_neg_Ioi_zero]
    apply setIntegral_congr_fun measurableSet_Ioi
    intro x hx
    change Real.exp (-|x|) = Real.exp (-x)
    rw [abs_of_pos hx]
  have h := integral_add_compl (s := Iic (0 : ℝ)) measurableSet_Iic integrable_exp_neg_abs
  rw [compl_Iic, hl, hr] at h
  linarith

theorem laplaceKernel_eq_prod {K : ℕ} (z : Fin K → ℝ) :
    laplaceKernel z = ∏ a, Real.exp (-|z a|) := by
  unfold laplaceKernel l1
  rw [← Finset.sum_neg_distrib, Real.exp_sum]

theorem integrable_laplaceKernel (K : ℕ) : Integrable (@laplaceKernel K) := by
  change Integrable (fun z : Fin K → ℝ => laplaceKernel z)
  simp_rw [laplaceKernel_eq_prod]
  exact Integrable.fintype_prod_dep (fun _ => integrable_exp_neg_abs)

theorem integral_laplaceKernel (K : ℕ) : (∫ z : Fin K → ℝ, laplaceKernel z) = 2 ^ K := by
  simp_rw [laplaceKernel_eq_prod]
  rw [integral_fintype_prod_volume_eq_prod (ι := Fin K) (E := fun _ => ℝ)
    (fun _ x => Real.exp (-|x|))]
  simp only [integral_exp_neg_abs, Finset.prod_const, Finset.card_univ, Fintype.card_fin]

theorem bounded_mul_laplaceKernel_integrable {K : ℕ}
    (f : (Fin K → ℝ) → ℝ) (hf : Measurable f) {C : ℝ} (hb : ∀ z, |f z| ≤ C) :
    Integrable (fun z => f z * laplaceKernel z) := by
  apply (integrable_laplaceKernel K).bdd_mul hf.aestronglyMeasurable
  exact Filter.Eventually.of_forall (fun z => by simpa only [Real.norm_eq_abs] using hb z)

theorem sqrt_square_bounded {u w : ℝ} (_hu0 : 0 ≤ u) (hu1 : u ≤ 1)
    (_hw0 : 0 ≤ w) (hw1 : w ≤ 1) : |(Real.sqrt u - Real.sqrt w) ^ 2| ≤ 1 := by
  have hu' : 0 ≤ Real.sqrt u := Real.sqrt_nonneg u
  have hw' : 0 ≤ Real.sqrt w := Real.sqrt_nonneg w
  have hu'' : Real.sqrt u ≤ 1 := Real.sqrt_le_one.mpr hu1
  have hw'' : Real.sqrt w ≤ 1 := Real.sqrt_le_one.mpr hw1
  rw [abs_of_nonneg (sq_nonneg _)]
  nlinarith

theorem bounded_channel_shifted_midpoint {K : ℕ}
    (r : (Fin K → ℝ) → ℝ) (hr : Measurable r)
    (hr0 : ∀ z, 0 ≤ r z) (hr1 : ∀ z, r z ≤ 1)
    (v : Fin K → ℝ) (w : ℝ) (hw0 : 0 ≤ w) (hw1 : w ≤ 1)
    (hmid : ∀ z,
      Real.sqrt (r (z - v)) * Real.sqrt (r (-z - v)) ≤ r (-v)) :
    (∫ z, (r (z - v) - r (-v)) * laplaceKernel z) ≤
      2 * Real.exp (l1 v) *
        ∫ z, (Real.sqrt (r z) - Real.sqrt w) ^ 2 * laplaceKernel z := by
  apply shifted_midpoint_comparison r v w hr0 hw0 hmid
  · apply bounded_mul_laplaceKernel_integrable _
      ((hr.comp (measurable_id.sub measurable_const)).sub_const _) (C := 1)
    intro z
    change |r (z - v) - r (-v)| ≤ 1
    rw [abs_le]
    constructor <;> linarith [hr0 (z - v), hr1 (z - v), hr0 (-v), hr1 (-v)]
  · apply bounded_mul_laplaceKernel_integrable _ (by fun_prop) (C := 1)
    intro z
    exact sqrt_square_bounded (hr0 _) (hr1 _) hw0 hw1
  · apply bounded_mul_laplaceKernel_integrable _ (by fun_prop) (C := 1)
    intro z
    exact sqrt_square_bounded (hr0 _) (hr1 _) hw0 hw1

end

end PoissonAudit
