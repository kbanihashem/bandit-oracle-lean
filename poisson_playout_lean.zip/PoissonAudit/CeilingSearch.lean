module
public import Mathlib.Tactic
public section
namespace PoissonAudit
noncomputable section

def ceilingSearch (x : ℝ) (i : ℕ) : ℕ × ℕ :=
  if x ≤ i then (i,1)
  else
    let tail := ceilingSearch x (i+1)
    (tail.1,2+tail.2)
termination_by ⌈x⌉₊ - i
decreasing_by
  have h : i < ⌈x⌉₊ := Nat.lt_ceil.mpr (lt_of_not_ge (by assumption))
  omega

theorem ceilingSearch_spec (x : ℝ) (i : ℕ) (hi : i ≤ ⌈x⌉₊) :
    ceilingSearch x i = (⌈x⌉₊,2*(⌈x⌉₊-i)+1) := by
  rw [ceilingSearch]
  split_ifs with h
  · have := Nat.ceil_le.mpr h
    congr 1 <;> omega
  · have hlt := Nat.lt_ceil.mpr (lt_of_not_ge h)
    rw [ceilingSearch_spec x (i+1) (by omega)]
    simp only [Prod.mk.injEq,true_and]
    omega
termination_by ⌈x⌉₊ - i
decreasing_by
  have := Nat.lt_ceil.mpr (lt_of_not_ge (by assumption : ¬x ≤ i))
  omega

end
end PoissonAudit
