module
public import PoissonAudit.ExponentialCounts
public import PoissonAudit.ManuscriptOracle
public section
open MeasureTheory ProbabilityTheory Set
namespace PoissonAudit
noncomputable section

variable {X : Type*} {K : ℕ}
def clipNoise (cap : ℕ) (v : NativeNoise X K) : NativeNoise X K :=
  (v.1,min v.2.1 (cap+1),v.2.2)

def clipTape (cap : ℕ) : (J : ℕ) → NativeNoiseTape X K J → NativeNoiseTape X K J
  | 0, t => t
  | j+1, t => (clipTape cap j t.1,clipNoise cap t.2)

def clipInputs (cap J m : ℕ) (v : NativeNoiseTape X K J × (Fin m → NativeNoise X K)) :=
  (clipTape cap J v.1,fun i => clipNoise cap (v.2 i))

private theorem clip_tape_ok (cap J : ℕ) (t : NativeNoiseTape X K J) :
    nativeTapeCountsBounded cap J (clipTape cap J t) ↔ nativeTapeCountsBounded cap J t := by
  induction J with
  | zero => rfl
  | succ j ih =>
    change (nativeTapeCountsBounded cap j (clipTape cap j t.1) ∧ min t.2.2.1 (cap+1) ≤ cap) ↔ (_ ∧ t.2.2.1 ≤ cap)
    rw [ih]
    exact and_congr_right fun _ => by omega

private theorem clip_tape_id (cap J : ℕ) (t : NativeNoiseTape X K J) (h : nativeTapeCountsBounded cap J t) :
    clipTape cap J t = t := by
  induction J with
  | zero => rfl
  | succ j ih =>
    have he : clipNoise cap t.2 = t.2 := by
      unfold clipNoise
      rw [min_eq_left (by have := h.2; omega)]
    simp [clipTape,ih _ h.1,he]
    rfl

private def ok (cap J m : ℕ) (v : NativeNoiseTape X K J × (Fin m → NativeNoise X K)) :=
  nativeTapeCountsBounded cap J v.1 ∧ ∀ i, (v.2 i).2.1 ≤ cap

private theorem clip_ok (cap J m : ℕ) (v : NativeNoiseTape X K J × (Fin m → NativeNoise X K)) :
    ok cap J m (clipInputs cap J m v) ↔ ok cap J m v := by
  simp only [ok,clipInputs,clip_tape_ok,clipNoise]
  exact and_congr_right fun _ => forall_congr' fun i => by omega

private theorem clip_id (cap J m : ℕ) (v : NativeNoiseTape X K J × (Fin m → NativeNoise X K)) (hv : ok cap J m v) :
    clipInputs cap J m v = v := by
  apply Prod.ext
  · exact clip_tape_id cap J v.1 hv.1
  · funext i
    simp [clipInputs,clipNoise,min_eq_left ((hv.2 i).trans (Nat.le_succ _))]

theorem sampler_clipping (r : NNReal) (lam B eta : ℝ) (H : List (CostExample X K))
    (val : List (CostExample X K) → ℝ) (fallback : Fin K) (cap J m : ℕ)
    (v : NativeNoiseTape X K J × (Fin m → NativeNoise X K)) (x : X) :
    let f := fun w : NativeNoiseTape X K J × (Fin m → NativeNoise X K) =>
      (executeArraySampler r lam B eta H val fallback cap J m w.1 w.2 x).choice
    f (clipInputs cap J m v) = f v := by
  intro f
  by_cases h : ok cap J m v
  · rw [clip_id cap J m v h]
  · have hc := (clip_ok cap J m v).not.mpr h
    dsimp only [f]
    simp only [(executeArraySampler_correct r lam B eta H val fallback cap J m _ _ x).1,cappedOracleChoice]
    exact (if_neg hc).trans (if_neg h).symm

variable [MeasurableSpace X]

def waitNoiseLaw (cap : ℕ) (r : NNReal) (D : Measure X) (K : ℕ) : Measure (NativeNoise X K) :=
  (laplaceMeasure K).prod (((waitLaw (cap+1)).map (fun tape => (runWaits (cap+1) r tape).count)).prod (markSequence (contextLaplaceLaw D K)))

instance waitNoiseProb (cap : ℕ) (r : NNReal) (D : Measure X) [IsProbabilityMeasure D] (K : ℕ) :
    IsProbabilityMeasure (waitNoiseLaw cap r D K) := by
  unfold waitNoiseLaw
  rw [runWaits_law]
  haveI : IsProbabilityMeasure ((poissonMeasure r).map (fun j => min j (cap+1))) :=
    (Measure.isProbabilityMeasure_map_iff (Measurable.of_discrete.aemeasurable)).mpr inferInstance
  infer_instance

private theorem clipNoise_mp (cap : ℕ) (r : NNReal) (D : Measure X) [IsProbabilityMeasure D] :
    MeasurePreserving (clipNoise (K := K) cap) (insertedExperimentLaw r D K) (waitNoiseLaw cap r D K) := by
  unfold waitNoiseLaw
  rw [runWaits_law]
  have hm : Measurable (fun j : ℕ => min j (cap+1)) := .of_discrete
  have hc : MeasurePreserving (fun j : ℕ => min j (cap+1)) (poissonMeasure r) _ := ⟨hm,rfl⟩
  haveI : IsProbabilityMeasure ((poissonMeasure r).map (fun j => min j (cap+1))) :=
    (Measure.isProbabilityMeasure_map_iff hm.aemeasurable).mpr inferInstance
  exact (MeasurePreserving.id (laplaceMeasure K)).prod (hc.prod (MeasurePreserving.id _))

def waitTrainingLaw (cap : ℕ) (r : NNReal) (D : Measure X) (K : ℕ) :
    (j : ℕ) → Measure (NativeNoiseTape X K j)
  | 0 => Measure.dirac (ULift.up ())
  | j+1 => (waitTrainingLaw cap r D K j).prod (waitNoiseLaw cap r D K)

private theorem clipTape_mp (cap : ℕ) (r : NNReal) (D : Measure X) [IsProbabilityMeasure D] (J : ℕ) :
    MeasurePreserving (clipTape (K := K) cap J) (nativeNoiseTapeLaw r D J) (waitTrainingLaw cap r D K J) := by
  induction J with
  | zero => exact MeasurePreserving.id _
  | succ j ih => exact ih.prod (clipNoise_mp cap r D)

theorem waiting_inputs (cap J m : ℕ) (r : NNReal) (D : Measure X) [IsProbabilityMeasure D] :
    MeasurePreserving (clipInputs (K := K) cap J m)
      ((nativeNoiseTapeLaw r D J).prod (iidPool (insertedExperimentLaw r D K) m))
      ((waitTrainingLaw cap r D K J).prod (iidPool (waitNoiseLaw cap r D K) m)) :=
  (clipTape_mp cap r D J).prod (measurePreserving_pi _ _ (fun _ => clipNoise_mp cap r D))

private theorem measurable_tape_ok (cap J : ℕ) :
    MeasurableSet {v : NativeNoiseTape X K J | nativeTapeCountsBounded cap J v} := by
  induction J with
  | zero => exact MeasurableSet.univ
  | succ j ih =>
    exact (measurable_fst ih).inter ((measurable_fst.comp (measurable_snd.comp measurable_snd)) (show MeasurableSet (Iic cap) from .of_discrete))

private theorem measurable_ok (cap J m : ℕ) :
    MeasurableSet {v : NativeNoiseTape X K J × (Fin m → NativeNoise X K) | ok cap J m v} := by
  change MeasurableSet ((Prod.fst ⁻¹' {v : NativeNoiseTape X K J | nativeTapeCountsBounded cap J v}) ∩ {v : NativeNoiseTape X K J × (Fin m → NativeNoise X K) | ∀ i, (v.2 i).2.1 ≤ cap})
  apply (measurable_fst (measurable_tape_ok cap J)).inter
  simp only [Set.setOf_forall]
  exact MeasurableSet.iInter fun i =>
    (measurable_fst.comp (measurable_snd.comp ((measurable_pi_apply i).comp measurable_snd))) (show MeasurableSet (Iic cap) from .of_discrete)

private theorem projection_map {A B : Type*} [MeasurableSpace A] [MeasurableSpace B]
    {μ ν : Measure A} {F : A → A} (hp : MeasurePreserving F μ ν) (s : Set A) (hs : MeasurableSet s)
    (hinv : F ⁻¹' s = s) (hid : ∀ a ∈ s, F a = a)
    (f : A → B) (hf : AEMeasurable f μ) (b : B) (hout : ∀ x ∉ s, f x = b)
    (hsame : ∀ a, f (F a) = f a) : ν.map f = μ.map f := by
  have hr : ν.restrict s = μ.restrict s := by
    rw [← hp.map_eq,Measure.restrict_map hp.measurable hs,hinv]
    calc
      _ = (μ.restrict s).map id := Measure.map_congr <| (ae_restrict_mem hs).mono fun a ha => hid a ha
      _ = _ := Measure.map_id
  have hgood : AEMeasurable f (ν.restrict s) := hr ▸ hf.restrict
  have hbad : AEMeasurable f (ν.restrict sᶜ) :=
    aemeasurable_const.congr ((ae_restrict_mem hs.compl).mono fun a ha => (hout a ha).symm)
  have hall := aemeasurable_union_iff.mpr ⟨hgood,hbad⟩
  rw [union_compl_self,Measure.restrict_univ] at hall
  rw [← hp.map_eq] at hall ⊢
  rw [AEMeasurable.map_map_of_aemeasurable hall hp.measurable.aemeasurable]
  exact Measure.map_congr (Filter.Eventually.of_forall hsame)

theorem waiting_sampler_law (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (lam B eta : ℝ) (H : List (CostExample X K)) (val : List (CostExample X K) → ℝ)
    (fallback : Fin K) (cap J m : ℕ) (x : X) :
    let f := fun w : NativeNoiseTape X K J × (Fin m → NativeNoise X K) =>
      (executeArraySampler r lam B eta H val fallback cap J m w.1 w.2 x).choice
    let μ := (nativeNoiseTapeLaw (K := K) r D J).prod (iidPool (insertedExperimentLaw r D K) m)
    AEMeasurable f μ →
      ((waitTrainingLaw cap r D K J).prod (iidPool (waitNoiseLaw cap r D K) m)).map f = μ.map f := by
  intro f μ hf
  apply projection_map (waiting_inputs cap J m r D) {v | ok cap J m v} (measurable_ok cap J m)
    (Set.ext (clip_ok cap J m)) (clip_id cap J m) f hf none
  · intro v hv
    dsimp only [f]
    rw [(executeArraySampler_correct r lam B eta H val fallback cap J m _ _ x).1]
    exact if_neg hv
  · exact fun v => sampler_clipping r lam B eta H val fallback cap J m v x


theorem waiting_round_resources (r : NNReal) (lam B eta gamma : ℝ)
    (H : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (T cap J m : ℕ) (hK : 0 < K) (ht : H.length ≤ T)
    (tape : NativeNoiseTape X K J) (trials : Fin m → NativeNoise X K) (x : X)
    (waits : Fin (J+m) → WaitTape (cap+1)) :
    let run := executeArraySampler r lam B eta H oracle fallback cap J m tape trials x
    let waitWork := ∑ i, ((runWaits (cap+1) r (waits i)).draws + (runWaits (cap+1) r (waits i)).operations)
    let update := (executeProbabilityTable K gamma m run.choice).2 + 4*K + K*H.length + 16
    let bound := onlineWorkBudget T K cap J m + 8*((J+m)*(cap+1))
    run.internalWork + 4*queryCoefficientCount K run.queries + 4*elementaryDrawBudget K cap J m + update + waitWork ≤ bound ∧
    run.allocatedWords + probabilityTableAllocation K m run.choice + 3*K + K*H.length + 16 + (J+m)*(cap+1) ≤ bound := by
  intro run waitWork update bound
  have hw : waitWork ≤ ∑ _ : Fin (J+m), 4*(cap+1) := by
    apply Finset.sum_le_sum
    intro i _
    have h := runWaits_spec (cap+1) r (waits i)
    omega
  simp only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul] at hw
  have h := manuscript_round_budget r lam B eta gamma H oracle fallback T cap J m hK ht tape trials x
  change _ + update ≤ onlineWorkBudget T K cap J m ∧ _ ≤ onlineWorkBudget T K cap J m at h
  dsimp only [bound]
  constructor <;> nlinarith only [hw,h.1,h.2]

end
end PoissonAudit
