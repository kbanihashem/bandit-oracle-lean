module
public import PoissonAudit.ArraySampler
public import PoissonAudit.NativeGeneralContextRegret
public section
open MeasureTheory Set
namespace PoissonAudit
noncomputable section

@[expose] abbrev ObservedBanditRound (X : Type*) (K : ℕ) (delta : ℝ) := X × NativeFiniteOutcome K delta × ℝ

@[expose] def observedHistoryStep {X : Type*} {K : ℕ} (L : ℕ) (delta gamma : ℝ)
    (history : List (CostExample X K)) (round : ObservedBanditRound X K delta) : List (CostExample X K) :=
  appendBanditObservation history round.1 round.2.1.2
    (roundedLossValue L round.2.2 / choiceProbability K gamma (nativeEmpiricalTrials K delta) round.2.1.1 round.2.1.2)

@[expose] def observedScoreStep {X P : Type*} {K : ℕ} (predict : P → X → Fin K) (L : ℕ) (delta gamma : ℝ)
    (S : P → ℝ) (round : ObservedBanditRound X K delta) : P → ℝ :=
  actionPenaltyScore predict S round.1 round.2.1.2
    (roundedLossValue L round.2.2 / choiceProbability K gamma (nativeEmpiricalTrials K delta) round.2.1.1 round.2.1.2)

@[expose] def runObservedHistory {X : Type*} {K : ℕ} (L : ℕ) (delta gamma : ℝ)
    (history : List (CostExample X K)) (rounds : List (ObservedBanditRound X K delta)) : List (CostExample X K) :=
  rounds.foldl (observedHistoryStep L delta gamma) history

@[expose] def runObservedScore {X P : Type*} {K : ℕ} (predict : P → X → Fin K) (L : ℕ) (delta gamma : ℝ)
    (S : P → ℝ) (rounds : List (ObservedBanditRound X K delta)) : P → ℝ :=
  rounds.foldl (observedScoreStep predict L delta gamma) S

theorem observedHistoryStep_score {X P : Type*} {K : ℕ} (predict : P → X → Fin K)
    (L : ℕ) (delta gamma : ℝ) (history : List (CostExample X K)) (round : ObservedBanditRound X K delta) :
    queryScore predict (observedHistoryStep L delta gamma history round) =
      observedScoreStep predict L delta gamma (queryScore predict history) round :=
  queryScore_appendBanditObservation predict history _ _ _

theorem runObservedHistory_score {X P : Type*} {K : ℕ} (predict : P → X → Fin K)
    (L : ℕ) (delta gamma : ℝ) (history : List (CostExample X K)) (rounds : List (ObservedBanditRound X K delta)) :
    queryScore predict (runObservedHistory L delta gamma history rounds) =
      runObservedScore predict L delta gamma (queryScore predict history) rounds := by
  induction rounds generalizing history with
  | nil => rfl
  | cons round rounds ih =>
    change queryScore predict (runObservedHistory L delta gamma (observedHistoryStep L delta gamma history round) rounds) = _
    rw [ih, observedHistoryStep_score]
    rfl

theorem runObservedHistory_length {X : Type*} {K : ℕ} (L : ℕ) (delta gamma : ℝ)
    (history : List (CostExample X K)) (rounds : List (ObservedBanditRound X K delta)) :
    (runObservedHistory L delta gamma history rounds).length = history.length + rounds.length := by
  induction rounds generalizing history with
  | nil => simp [runObservedHistory]
  | cons round rounds ih =>
    change (runObservedHistory L delta gamma (observedHistoryStep L delta gamma history round) rounds).length = _
    rw [ih]
    simp only [observedHistoryStep, appendBanditObservation_length, List.length_cons]
    omega

theorem mapCostQuery_observedUpdate {X Y : Type*} {K : ℕ} (f : X → Y) (history : List (CostExample X K))
    (x : X) (a : Fin K) (b : ℝ) :
    mapCostQuery f (appendBanditObservation history x a b) = appendBanditObservation (mapCostQuery f history) (f x) a b := by
  simp [mapCostQuery, appendBanditObservation]

theorem observed_update_quotient_score {X Y P : Type*} [MeasurableSpace Y] [MeasurableSingletonClass Y] [Fintype Y]
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P] {K : ℕ} (f : X → Y) (predict : P → Y → Fin K)
    (L : ℕ) (delta gamma : ℝ) (history : List (CostExample X K)) (x : X) (o : NativeFiniteOutcome K delta)
    (observed : ℝ) (cost : Fin K → ℝ) (halign : cost o.2 = roundedLossValue L observed) :
    queryScore predict (mapCostQuery f (observedHistoryStep L delta gamma history (x, o, observed))) =
      nativeFiniteOutcomeUpdate predict delta gamma (queryScore predict (mapCostQuery f history)) (f x) cost o := by
  unfold observedHistoryStep nativeFiniteOutcomeUpdate
  rw [mapCostQuery_observedUpdate, queryScore_appendBanditObservation, treeUpdatedScore_eq_actionPenalty]
  rw [halign]
end
end PoissonAudit
