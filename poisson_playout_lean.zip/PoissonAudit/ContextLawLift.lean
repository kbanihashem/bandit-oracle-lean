module
public import PoissonAudit.OutcomePathRecursion
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section

theorem probability_on_subsingleton {A : Type*} [MeasurableSpace A] [Subsingleton A]
    (mu : Measure A) [IsProbabilityMeasure mu] (a : A) : mu = Measure.dirac a := by
  have hconst : (fun _ : A => a) = id := funext fun b => Subsingleton.elim _ _
  have h := Measure.map_const mu a
  rw [hconst, Measure.map_id, measure_univ, one_smul] at h
  exact h

variable {X Y O A P : Type*} [MeasurableSpace X] [MeasurableSpace Y] [MeasurableSingletonClass Y] [Fintype Y]
    [MeasurableSpace O] [MeasurableSingletonClass O] [Fintype O]
    [Fintype A] [Fintype P] [Nonempty P]

theorem liftedContextLaw_certificate (D : Measure X) [IsProbabilityMeasure D] (f : X → Y) (hf : Measurable f)
    (w : (P → ℝ) → Y → O → ℝ) (hw : ∀ S y o, 0 ≤ w S y o) (hwsum : ∀ S y, ∑ o, w S y o = 1)
    (U : (P → ℝ) → Y → (A → ℝ) → O → P → ℝ) (costs : List (Y → A → ℝ)) :
    ∀ S, IsProbabilityMeasure (liftedContextLaw D f w U costs S) ∧
      (liftedContextLaw D f w U costs S).map (transcriptToOutcomePath f costs) =
        (outcomePathLaw (fun y => ((D.map f) {y}).toReal) (fun _ => ENNReal.toReal_nonneg)
          (context_mass_sum (D.map f)) w U hw hwsum costs S).toMeasure := by
  classical
  haveI : IsProbabilityMeasure (D.map f) := (Measure.isProbabilityMeasure_map_iff hf.aemeasurable).mpr inferInstance
  let d := fun y => ((D.map f) {y}).toReal
  let hd := fun y => show 0 ≤ d y from ENNReal.toReal_nonneg
  have hds : ∑ y, d y = 1 := context_mass_sum (D.map f)
  induction costs with
  | nil =>
    intro S
    haveI : IsProbabilityMeasure (liftedContextLaw D f w U [] S) := by
      change IsProbabilityMeasure (Measure.dirac (ULift.up ()))
      infer_instance
    refine ⟨inferInstance, ?_⟩
    haveI : Subsingleton (outcomePaths (X := Y) (A := A) O []) := by
      change Subsingleton (Fin 0 → Y × O)
      infer_instance
    have ht := probability_on_subsingleton (outcomePathLaw d hd hds w U hw hwsum [] S).toMeasure
      (emptyOutcomePath Y O A)
    change (liftedContextLaw D f w U [] S).map (fun _ => emptyOutcomePath Y O A) = _
    rw [Measure.map_const, measure_univ, one_smul]
    exact ht.symm
  | cons c cs ih =>
    intro S
    haveI (S' : P → ℝ) : IsProbabilityMeasure (liftedContextLaw D f w U cs S') := (ih S').1
    let phi := transcriptToOutcomePath (O := O) f (c :: cs)
    have hphi : Measurable phi := measurable_transcriptToOutcomePath f hf (c :: cs)
    have htail : Measurable (transcriptToOutcomePath (O := O) f cs) := measurable_transcriptToOutcomePath f hf cs
    have hbranch (y : Y) (o : O) :
        Measure.map phi (Measure.map (contextTranscriptBranch cs.length o)
          ((D.restrict (f ⁻¹' {y})).prod (liftedContextLaw D f w U cs (U S y (c y) o)))) =
            (D.map f) {y} • (outcomePathLaw d hd hds w U hw hwsum cs (U S y (c y) o)).toMeasure.map
              (outcomePathCons c cs y o) := by
      let mu := liftedContextLaw D f w U cs (U S y (c y) o)
      let g := transcriptToOutcomePath (O := O) f cs
      let pack : Y × O × outcomePaths O cs → outcomePaths O (c :: cs) := fun z => z
      have hpack : Measurable pack := measurable_of_finite pack
      have hembed : Measurable (contextTranscriptBranch (X := X) cs.length o) := measurable_contextTranscriptBranch cs.length o
      have hraw : Measurable (fun z : X × ContextTranscript X O cs.length => (f z.1, o, g z.2)) :=
        (hf.comp measurable_fst).prodMk (measurable_const.prodMk (htail.comp measurable_snd))
      rw [Measure.map_map hphi hembed]
      change ((D.restrict (f ⁻¹' {y})).prod mu).map (pack ∘ (fun z => (f z.1, o, g z.2))) = _
      rw [← Measure.map_map hpack hraw, quotient_branch_map D f hf y o mu g htail,
        Measure.map_smul _ hpack.aemeasurable]
      have hi := (ih (U S y (c y) o)).2
      change mu.map g = _ at hi
      rw [hi]
      rw [Measure.map_map hpack (measurable_of_finite (fun z : outcomePaths O cs => (y, o, z)))]
      rfl
    have hmap : (liftedContextLaw D f w U (c :: cs) S).map phi =
        (outcomePathLaw d hd hds w U hw hwsum (c :: cs) S).toMeasure := by
      rw [outcomePathLaw_cons]
      unfold liftedContextLaw
      rw [Measure.map_finset_sum' hphi.aemeasurable]
      apply Finset.sum_congr rfl
      intro y _
      rw [Measure.map_finset_sum' hphi.aemeasurable]
      apply Finset.sum_congr rfl
      intro o _
      rw [Measure.map_smul _ hphi.aemeasurable, hbranch, smul_smul]
      have hscalar : ENNReal.ofReal (w S y o) * (D.map f) {y} = ENNReal.ofReal (d y * w S y o) := by
        rw [ENNReal.ofReal_mul ENNReal.toReal_nonneg, ENNReal.ofReal_toReal (measure_ne_top _ _)]
        exact mul_comm _ _
      rw [hscalar]
    have hprobMap : IsProbabilityMeasure ((liftedContextLaw D f w U (c :: cs) S).map phi) := by
      rw [hmap]
      infer_instance
    have hprob : IsProbabilityMeasure (liftedContextLaw D f w U (c :: cs) S) :=
      (Measure.isProbabilityMeasure_map_iff hphi.aemeasurable).mp hprobMap
    exact ⟨hprob, hmap⟩
end
end PoissonAudit
