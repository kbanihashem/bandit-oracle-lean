module
public import PoissonAudit.NativeNoiseTape
public import PoissonAudit.NativeOverflowProcess
public import PoissonAudit.OracleReplayQueries
public section
open MeasureTheory Set
namespace PoissonAudit
noncomputable section

@[expose] def nativeTapeFlag {X : Type*} {K : ℕ} (cap : ℕ) : (j : ℕ) → NativeNoiseTape X K j → Bool
  | 0, _ => false
  | j + 1, tape => nativeTapeFlag cap j tape.1 || nativeOverflowBool cap tape.2

theorem nativeTapeFlag_false_iff {X : Type*} {K : ℕ} (cap j : ℕ) (tape : NativeNoiseTape X K j) :
    nativeTapeFlag cap j tape = false ↔ nativeTapeCountsBounded cap j tape := by
  induction j with
  | zero => simp [nativeTapeFlag, nativeTapeCountsBounded]
  | succ j ih => simp only [nativeTapeFlag, Bool.or_eq_false_iff, ih, nativeOverflowBool, nativeTapeCountsBounded]; split_ifs <;> simp_all

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def nativeTapeFlaggedState (r : NNReal) (predict : P → X → Fin K) (S : P → ℝ)
    (lam B eta : ℝ) (hB : 1 ≤ B) (cap j : ℕ) (tape : NativeNoiseTape X K j) : NativeFlaggedState X K B :=
  (nativeTapeState r predict S lam B eta hB j tape, nativeTapeFlag cap j tape)

theorem measurable_nativeTapeFlaggedState (r : NNReal) (predict : P → X → Fin K) (S : P → ℝ)
    (lam B eta : ℝ) (hB : 1 ≤ B) (cap j : ℕ) : Measurable (nativeTapeFlaggedState r predict S lam B eta hB cap j) := by
  induction j with
  | zero =>
    change Measurable (fun _ : NativeNoiseTape X K 0 => ((nativeUnitScale B hB, nativeUnitScale B hB), false))
    exact measurable_const
  | succ j ih => exact (measurable_nativeFlaggedTransition r predict S lam B eta hB cap j).comp ((ih.comp measurable_fst).prodMk measurable_snd)

theorem nativeTapeFlaggedState_measurePreserving (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ) (hB : 1 ≤ B) (cap j : ℕ) :
    MeasurePreserving (nativeTapeFlaggedState r predict S lam B eta hB cap j) (nativeNoiseTapeLaw r D j)
      (nativeFlaggedStateLaw r D predict S lam B eta hB cap j) := by
  induction j with
  | zero =>
    refine ⟨measurable_nativeTapeFlaggedState r predict S lam B eta hB cap 0, ?_⟩
    change (nativeNoiseTapeLaw (K := K) r D 0).map
      (fun _ => ((nativeUnitScale B hB, nativeUnitScale B hB), false)) = Measure.dirac ((nativeUnitScale B hB, nativeUnitScale B hB), false)
    rw [Measure.map_const, measure_univ, one_smul]
  | succ j ih =>
    have hT : MeasurePreserving
        (fun v : NativeFlaggedState X K B × NativeNoise X K => nativeFlaggedTransition r predict S lam B eta hB cap j v.1 v.2)
        ((nativeFlaggedStateLaw r D predict S lam B eta hB cap j).prod (insertedExperimentLaw r D K))
        (nativeFlaggedStateLaw r D predict S lam B eta hB cap (j + 1)) :=
      ⟨measurable_nativeFlaggedTransition r predict S lam B eta hB cap j, rfl⟩
    exact hT.comp (ih.prod (MeasurePreserving.id (insertedExperimentLaw r D K)))
end
end PoissonAudit
