module

public import PoissonAudit.CurvatureEntropyAlgebra

public section

namespace PoissonAudit

theorem importance_quadratic_charge {C sigma beta p q c R gamma : ℝ}
    (hC : 0 ≤ C) (hsigma : 0 < sigma) (hbeta : 0 ≤ beta) (hbetap : beta ≤ p)
    (hp0 : 0 ≤ p) (hq : 0 < q) (hgamma : gamma < 1)
    (hqmix : (1 - gamma) * p ≤ q) (hc0 : 0 ≤ c) (hc1 : c ≤ 1)
    (hquad : R ≤ C * (beta / sigma) * (c / q) ^ 2) :
    q * R ≤ C / (1 - gamma) * (if 0 < p then beta / (sigma * p) else 0) := by
  split_ifs with hp
  · have hden : 0 < (1 - gamma) * p := mul_pos (by linarith) hp
    have hCb : 0 ≤ C * (beta / sigma) := mul_nonneg hC (div_nonneg hbeta hsigma.le)
    have hcb : q * (c / q) ^ 2 ≤ 1 / q := by
      have heq : q * (c / q) ^ 2 = c ^ 2 / q := by field_simp <;> ring
      rw [heq]
      apply div_le_div_of_nonneg_right _ hq.le
      nlinarith
    have hrec : 1 / q ≤ 1 / ((1 - gamma) * p) := one_div_le_one_div_of_le hden hqmix
    calc
      _ ≤ q * (C * (beta / sigma) * (c / q) ^ 2) := mul_le_mul_of_nonneg_left hquad hq.le
      _ = C * (beta / sigma) * (q * (c / q) ^ 2) := by ring
      _ ≤ C * (beta / sigma) * (1 / q) := mul_le_mul_of_nonneg_left hcb hCb
      _ ≤ C * (beta / sigma) * (1 / ((1 - gamma) * p)) := mul_le_mul_of_nonneg_left hrec hCb
      _ = _ := by field_simp <;> ring
  · have hpz : p = 0 := le_antisymm (le_of_not_gt hp) hp0
    have hbz : beta = 0 := by linarith
    rw [hbz, zero_div, mul_zero, zero_mul] at hquad
    simpa using mul_nonpos_of_nonneg_of_nonpos hq.le hquad

end PoissonAudit
