module

public import PoissonAudit.LaplaceProductLaw
public import Mathlib.MeasureTheory.Measure.Lebesgue.EqHaar
public import Mathlib.LinearAlgebra.AffineSpace.AffineSubspace.Basic

public section

open MeasureTheory MeasureTheory.Measure Set

namespace PoissonAudit

noncomputable section

theorem iidPool_absolutelyContinuous {U : Type*} [MeasurableSpace U]
    (mu nu : Measure U) [SigmaFinite mu] [SigmaFinite nu] (hac : mu ≪ nu) (n : ℕ) :
    iidPool mu n ≪ iidPool nu n := by
  induction n with
  | zero =>
    have heq : iidPool mu 0 = iidPool nu 0 := by
      unfold iidPool
      rw [Measure.pi_of_empty (fun _ : Fin 0 => mu), Measure.pi_of_empty (fun _ : Fin 0 => nu)]
    rw [heq]
  | succ n ih =>
    let e : (Fin (n + 1) → U) ≃ᵐ U × (Fin n → U) :=
      MeasurableEquiv.piFinSuccAbove (fun _ => U) 0
    have hm : MeasurePreserving e (iidPool mu (n + 1)) (mu.prod (iidPool mu n)) :=
      splitMark_measurePreserving mu 0
    have hn : MeasurePreserving e (iidPool nu (n + 1)) (nu.prod (iidPool nu n)) :=
      splitMark_measurePreserving nu 0
    have h := (hac.prod ih).map e.symm.measurable
    rw [(hm.symm e).map_eq, (hn.symm e).map_eq] at h
    exact h

theorem linear_fiber_haar_zero {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [MeasurableSpace E] [BorelSpace E] [FiniteDimensional ℝ E]
    (mu : Measure E) [IsAddHaarMeasure mu] (L : E →ₗ[ℝ] ℝ) (hL : L ≠ 0) (c : ℝ) :
    mu {z | L z = c} = 0 := by
  let s : AffineSubspace ℝ E := ({c} : AffineSubspace ℝ ℝ).comap L.toAffineMap
  have hmem (z : E) : z ∈ s ↔ L z = c := by simp [s, AffineSubspace.mem_singleton_iff]
  have hs : s ≠ ⊤ := by
    intro hs
    have hall (z : E) : L z = c := (hmem z).mp (by rw [hs]; trivial)
    have hc : c = 0 := by simpa only [map_zero] using (hall 0).symm
    apply hL
    ext z
    change L z = 0
    rw [hall z, hc]
  have heq : {z | L z = c} = (s : Set E) := by ext z; exact (hmem z).symm
  rw [heq]
  exact addHaar_affineSubspace mu s hs

theorem laplace_pool_absolutelyContinuous (m K : ℕ) :
    iidPool (laplaceMeasure K) m ≪ (volume : Measure (Fin m → Fin K → ℝ)) := by
  have hac : laplaceMeasure K ≪ (volume : Measure (Fin K → ℝ)) :=
    withDensity_absolutelyContinuous _ _
  exact iidPool_absolutelyContinuous _ _ hac m

theorem laplace_pool_ae_linear_ne (m K : ℕ)
    (L : (Fin m → Fin K → ℝ) →ₗ[ℝ] ℝ) (hL : L ≠ 0) (c : ℝ) :
    ∀ᵐ z ∂iidPool (laplaceMeasure K) m, L z ≠ c := by
  have hz := (laplace_pool_absolutelyContinuous m K)
    (linear_fiber_haar_zero volume L hL c)
  rw [ae_iff]
  simpa only [not_not] using hz

end

end PoissonAudit
