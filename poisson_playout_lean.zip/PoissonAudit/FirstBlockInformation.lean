module

public import PoissonAudit.WinnerInformation

public section

open MeasureTheory ProbabilityTheory InformationTheory
open scoped BigOperators ENNReal

namespace PoissonAudit

noncomputable section

@[expose] def firstBlockInformation {U V P : Type*} [MeasurableSpace U] [MeasurableSpace V]
    [Fintype P] (mu : Measure U) (nu : Measure V) (W : U × V → P) : ENNReal :=
  ∑ p, mu.prod nu (outcomeEvent W p) *
    klDiv (eventPosterior (mu.prod nu) (outcomeEvent W p)).fst mu

theorem firstBlockInformation_le_log_card {U V P : Type*} [MeasurableSpace U] [MeasurableSpace V]
    [MeasurableSpace P] [MeasurableSingletonClass P] [Fintype P] [Nonempty P]
    (mu : Measure U) (nu : Measure V) [IsProbabilityMeasure mu] [IsProbabilityMeasure nu]
    (W : U × V → P) (hW : Measurable W) :
    firstBlockInformation mu nu W ≤ ENNReal.ofReal (Real.log (Fintype.card P)) := by
  have hp (p : P) : klDiv (eventPosterior (mu.prod nu) (outcomeEvent W p)).fst mu ≤
      klDiv (eventPosterior (mu.prod nu) (outcomeEvent W p)) (mu.prod nu) := by
    have h := klDiv_map_le (eventPosterior (mu.prod nu) (outcomeEvent W p)) (mu.prod nu) measurable_fst
    change klDiv (eventPosterior (mu.prod nu) (outcomeEvent W p)).fst (mu.prod nu).fst ≤ _ at h
    rwa [Measure.fst_prod] at h
  calc
    _ ≤ ∑ p, mu.prod nu (outcomeEvent W p) *
        klDiv (eventPosterior (mu.prod nu) (outcomeEvent W p)) (mu.prod nu) :=
      Finset.sum_le_sum fun p _ => mul_le_mul_right (hp p) _
    _ = ENNReal.ofReal (finiteEntropy (outcomeMass (mu.prod nu) W)) :=
      sum_weighted_winnerPosterior_kl (mu.prod nu) W hW
    _ ≤ _ := ENNReal.ofReal_le_ofReal (finiteEntropy_le_log_card _
      (outcomeMass_nonneg (mu.prod nu) W) (sum_outcomeMass (mu.prod nu) W hW))

theorem firstBlockInformation_eq_coordinateInformation {U P : Type*} [MeasurableSpace U]
    [MeasurableSpace P] [MeasurableSingletonClass P] [Fintype P]
    (mu : Measure U) [IsProbabilityMeasure mu] (n : ℕ) (i : Fin (n + 1))
    (W : U × (Fin n → U) → P) (hW : Measurable W) :
    firstBlockInformation mu (iidPool mu n) W =
      coordinateInformation mu (n + 1) (fun u => W (splitMark i u)) i := by
  classical
  have hmp := splitMark_measurePreserving mu i
  unfold firstBlockInformation coordinateInformation
  apply Finset.sum_congr rfl
  intro p _
  let E := outcomeEvent W p
  have hE : MeasurableSet E := hW (measurableSet_singleton p)
  have hmass : iidPool mu (n + 1) (splitMark i ⁻¹' E) = (mu.prod (iidPool mu n)) E :=
    hmp.measure_preimage hE.nullMeasurableSet
  have hpost := map_eventPosterior (iidPool mu (n + 1)) (splitMark i) hmp.measurable E hE
  rw [hmp.map_eq] at hpost
  have hcoord : (eventPosterior (iidPool mu (n + 1)) (splitMark i ⁻¹' E)).map (fun u => u i) =
      (eventPosterior (mu.prod (iidPool mu n)) E).fst := by
    rw [← hpost]
    change _ = ((eventPosterior (iidPool mu (n + 1)) (splitMark i ⁻¹' E)).map (splitMark i)).map Prod.fst
    rw [Measure.map_map measurable_fst hmp.measurable]
    rfl
  change (mu.prod (iidPool mu n)) E * klDiv (eventPosterior (mu.prod (iidPool mu n)) E).fst mu =
    iidPool mu (n + 1) (splitMark i ⁻¹' E) *
      klDiv ((eventPosterior (iidPool mu (n + 1)) (splitMark i ⁻¹' E)).map (fun u => u i)) mu
  rw [hmass, hcoord]

end

end PoissonAudit
