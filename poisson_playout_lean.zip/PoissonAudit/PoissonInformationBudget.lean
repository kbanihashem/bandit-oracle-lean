module

public import PoissonAudit.LocationInformation
public import PoissonAudit.MarkedPoolLaw

public section

open MeasureTheory ProbabilityTheory InformationTheory
open scoped BigOperators ENNReal

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem information_deletionSum_bounds (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (m : ℕ) (C : Fin m → X) :
    0 ≤ deletionSum (insertedLocationInformationReal predict sigma S) m C ∧
      deletionSum (insertedLocationInformationReal predict sigma S) m C ≤ Real.log (Fintype.card P) := by
  cases m with
  | zero => simpa only [deletionSum, le_refl, true_and] using (log_policy_card_nonneg (P := P))
  | succ n =>
    constructor
    · exact Finset.sum_nonneg fun i _ => ENNReal.toReal_nonneg
    · change (∑ i, (insertedLocationInformation predict sigma S n (splitMark i C)).toReal) ≤ _
      simp_rw [insertedLocationInformation_delete]
      exact locationInformation_budget predict sigma S (n + 1) C

theorem integrable_insertedLocationInformationReal (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (n : ℕ) :
    Integrable (insertedLocationInformationReal predict sigma S n) (D.prod (iidPool D n)) :=
  Integrable.of_finite

theorem abs_information_insertionMean_le (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (n : ℕ) :
    |insertionMean D (insertedLocationInformationReal predict sigma S) n| ≤ Real.log (Fintype.card P) := by
  have hi := integrable_insertedLocationInformationReal D predict sigma S n
  have hnon : 0 ≤ insertionMean D (insertedLocationInformationReal predict sigma S) n :=
    integral_nonneg fun v => (insertedLocationInformationReal_bounds predict sigma S n v).1
  rw [abs_of_nonneg hnon]
  calc
    _ ≤ ∫ _ : X × (Fin n → X), Real.log (Fintype.card P) ∂D.prod (iidPool D n) :=
      integral_mono hi (integrable_const _) fun v => (insertedLocationInformationReal_bounds predict sigma S n v).2
    _ = _ := by simp

theorem integrable_information_insertionMean (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) :
    Integrable (insertionMean D (insertedLocationInformationReal predict sigma S)) (poissonMeasure r) := by
  apply Integrable.of_bound (measurable_of_countable _).aestronglyMeasurable (Real.log (Fintype.card P))
  filter_upwards [] with n
  exact abs_information_insertionMean_le D predict sigma S n

@[expose] def insertedConditionalInformation (r : NNReal) (D : Measure X)
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) : ℝ :=
  ∫ n, (∫ C, insertedLocationInformationReal predict sigma S n (x, C) ∂iidPool D n) ∂poissonMeasure r

theorem information_context_mean_bounds (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (n : ℕ) (x : X) :
    0 ≤ (∫ C, insertedLocationInformationReal predict sigma S n (x, C) ∂iidPool D n) ∧
      (∫ C, insertedLocationInformationReal predict sigma S n (x, C) ∂iidPool D n) ≤ Real.log (Fintype.card P) := by
  constructor
  · exact integral_nonneg fun C => (insertedLocationInformationReal_bounds predict sigma S n (x, C)).1
  · calc
      _ ≤ ∫ _ : Fin n → X, Real.log (Fintype.card P) ∂iidPool D n :=
        integral_mono Integrable.of_finite (integrable_const _) fun C =>
          (insertedLocationInformationReal_bounds predict sigma S n (x, C)).2
      _ = _ := by simp

theorem poisson_inserted_information_budget (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) :
    (r : ℝ) * (∫ x, insertedConditionalInformation r D predict sigma S x ∂D) ≤ Real.log (Fintype.card P) := by
  have hins := marked_poisson_insertion r D (insertedLocationInformationReal predict sigma S)
    (integrable_insertedLocationInformationReal D predict sigma S)
    (integrable_information_insertionMean r D predict sigma S)
  have hswap : (∫ n, (∫ x, ∫ C, insertedLocationInformationReal predict sigma S n (x, C)
      ∂iidPool D n ∂D) ∂poissonMeasure r) = ∫ x, insertedConditionalInformation r D predict sigma S x ∂D := by
    have hi : Integrable (fun v : ℕ × X => ∫ C, insertedLocationInformationReal predict sigma S v.1 (v.2, C)
        ∂iidPool D v.1) ((poissonMeasure r).prod D) := by
      apply Integrable.of_bound (measurable_of_countable _).aestronglyMeasurable (Real.log (Fintype.card P))
      filter_upwards [] with v
      rw [Real.norm_eq_abs, abs_of_nonneg (information_context_mean_bounds D predict sigma S v.1 v.2).1]
      exact (information_context_mean_bounds D predict sigma S v.1 v.2).2
    exact integral_integral_swap hi
  rw [hswap] at hins
  rw [← hins]
  have hinner (m : ℕ) : 0 ≤ (∫ C, deletionSum (insertedLocationInformationReal predict sigma S) m C ∂iidPool D m) ∧
      (∫ C, deletionSum (insertedLocationInformationReal predict sigma S) m C ∂iidPool D m) ≤
        Real.log (Fintype.card P) := by
    constructor
    · exact integral_nonneg fun C => (information_deletionSum_bounds predict sigma S m C).1
    · calc
        _ ≤ ∫ _ : Fin m → X, Real.log (Fintype.card P) ∂iidPool D m :=
          integral_mono Integrable.of_finite (integrable_const _) fun C =>
            (information_deletionSum_bounds predict sigma S m C).2
        _ = _ := by simp
  have hi : Integrable (fun m => ∫ C, deletionSum (insertedLocationInformationReal predict sigma S) m C ∂iidPool D m)
      (poissonMeasure r) := by
    apply Integrable.of_bound (measurable_of_countable _).aestronglyMeasurable (Real.log (Fintype.card P))
    filter_upwards [] with m
    rw [Real.norm_eq_abs, abs_of_nonneg (hinner m).1]
    exact (hinner m).2
  calc
    _ ≤ ∫ _ : ℕ, Real.log (Fintype.card P) ∂poissonMeasure r := integral_mono hi (integrable_const _) fun m => (hinner m).2
    _ = _ := by simp

end

end PoissonAudit
