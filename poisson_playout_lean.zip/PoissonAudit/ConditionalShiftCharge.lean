module

public import PoissonAudit.FlatConditionalWinner
public import PoissonAudit.ConditionalLocationMoments

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K m : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem conditional_policy_shift_charge (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (C : Fin m → X) (p : P) (v : Fin K → ℝ) :
    let nu := iidPool (laplaceMeasure K) m
    let E := outcomeEvent (insertedLocationWinner predict sigma S x C) p
    let r := eventChannel nu E
    (∫ z, r (z - v) - r (-v) ∂laplaceMeasure K) ≤
      2 * Real.exp (l1 v) * eventInformationCharge (laplaceMeasure K) nu E := by
  dsimp only
  let W := insertedLocationWinner predict sigma S x C
  let nu := iidPool (laplaceMeasure K) m
  let mu := laplaceMeasure K
  let w := outcomeMass (mu.prod nu) W p
  have hs := conditional_winner_shift_comparison (flatInsertedScore predict sigma S x C)
    (measurable_flatInsertedScore predict sigma S x C)
    (affine_flatInsertedScore predict sigma S x C) p v w
    (outcomeMass_nonneg (mu.prod nu) W p) (outcomeMass_le_one (mu.prod nu) W p)
  dsimp only at hs
  rw [← native_conditional_channel_eq_flat predict sigma S x C p] at hs
  have hE : MeasurableSet (outcomeEvent W p) :=
    measurable_insertedLocationWinner predict sigma S x C (measurableSet_singleton p)
  have hh := eventChannel_discrepancy_le_charge mu nu (outcomeEvent W p) hE
  exact hs.trans (mul_le_mul_of_nonneg_left hh (by positivity))

@[expose] def conditionalShiftDifference (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (a : Fin K) (C : Fin m → X) (v : Fin K → ℝ) : ℝ :=
  ∑ p, if predict p x = a then
    ∫ z, eventChannel (iidPool (laplaceMeasure K) m) (outcomeEvent (insertedLocationWinner predict sigma S x C) p) (z - v) -
      eventChannel (iidPool (laplaceMeasure K) m) (outcomeEvent (insertedLocationWinner predict sigma S x C) p) (-v)
      ∂laplaceMeasure K else 0

theorem conditional_action_shift_charge (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (a : Fin K) (C : Fin m → X) (v : Fin K → ℝ) :
    conditionalShiftDifference predict sigma S x a C v ≤
      2 * Real.exp (l1 v) * locationActionEntropy predict sigma S x a m C := by
  unfold conditionalShiftDifference locationActionEntropy winnerActionEntropy
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro p _
  by_cases hp : predict p x = a
  · simp only [hp, ite_true]
    exact conditional_policy_shift_charge predict sigma S x C p v
  · simp [hp]

end

end PoissonAudit
