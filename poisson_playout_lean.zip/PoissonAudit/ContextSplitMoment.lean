module

public import PoissonAudit.ConditionalLocationMoments

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem finiteInsertedMoment_context_split (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (g : ℝ → ℝ) (hg : Integrable g realLaplace) (n : ℕ) :
    (∫ z0, ∫ pool, finiteInsertedMoment predict sigma S x a g n (z0, pool)
      ∂iidPool (contextLaplaceLaw D K) n ∂laplaceMeasure K) =
      ∫ C, locationActionMoment predict sigma S x a g n C ∂iidPool D n := by
  let e := MeasurableEquiv.arrowProdEquivProdArrow X (Fin K → ℝ) (Fin n)
  have hmp : MeasurePreserving e (iidPool (contextLaplaceLaw D K) n)
      ((iidPool D n).prod (iidPool (laplaceMeasure K) n)) :=
    measurePreserving_arrowProdEquivProdArrow X (Fin K → ℝ) (Fin n) (fun _ => D) (fun _ => laplaceMeasure K)
  let eall := MeasurableEquiv.prodCongr (MeasurableEquiv.refl (Fin K → ℝ)) e
  have hid : MeasurePreserving (fun z : Fin K → ℝ => z) (laplaceMeasure K) (laplaceMeasure K) :=
    ⟨measurable_id, Measure.map_id⟩
  have hmpall : MeasurePreserving eall
      ((laplaceMeasure K).prod (iidPool (contextLaplaceLaw D K) n))
      ((laplaceMeasure K).prod ((iidPool D n).prod (iidPool (laplaceMeasure K) n))) := hid.prod hmp
  have hback := MeasurePreserving.symm eall hmpall
  let F := fun v : (Fin K → ℝ) × ((Fin n → X) × (Fin n → Fin K → ℝ)) =>
    finiteInsertedMoment predict sigma S x a g n (v.1, e.symm v.2)
  have hi := integrable_finiteInsertedMoment D predict sigma S x a g hg n
  have hFi : Integrable F ((laplaceMeasure K).prod ((iidPool D n).prod (iidPool (laplaceMeasure K) n))) :=
    hback.integrable_comp_of_integrable hi
  calc
    _ = ∫ v, finiteInsertedMoment predict sigma S x a g n v
        ∂(laplaceMeasure K).prod (iidPool (contextLaplaceLaw D K) n) := (integral_prod _ hi).symm
    _ = ∫ v, F v ∂(laplaceMeasure K).prod ((iidPool D n).prod (iidPool (laplaceMeasure K) n)) :=
      (hback.integral_comp' (finiteInsertedMoment predict sigma S x a g n)).symm
    _ = ∫ C, ∫ z0, ∫ Z, F (z0, (C, Z)) ∂iidPool (laplaceMeasure K) n ∂laplaceMeasure K ∂iidPool D n :=
      integral_fresh_count_marks _ _ _ F hFi
    _ = _ := by
      apply integral_congr_ae
      filter_upwards [] with C
      rw [locationActionMoment_eq_iterated predict sigma S x a g hg n C]
      rfl

theorem experimentMoment_eq_contexts (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (g : ℝ → ℝ) (hgm : Measurable g) (hgi : Integrable g realLaplace) :
    experimentMoment r D predict sigma S x a g =
      ∫ n, (∫ C, locationActionMoment predict sigma S x a g n C ∂iidPool D n) ∂ProbabilityTheory.poissonMeasure r := by
  rw [experimentMoment_eq_finite r D predict sigma S x a g hgm hgi]
  apply integral_congr_ae
  filter_upwards [] with n
  exact finiteInsertedMoment_context_split D predict sigma S x a g hgi n

end

end PoissonAudit
