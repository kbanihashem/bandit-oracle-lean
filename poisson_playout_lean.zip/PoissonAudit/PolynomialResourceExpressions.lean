module
public import PoissonAudit.PolynomialTuning
public section
namespace PoissonAudit
noncomputable section

theorem powerBound_pow {H x : ℝ} {a : ℕ} (hH : 0 ≤ H) (hx : PowerBound H a x) (n : ℕ) :
    PowerBound H (a * n) (x ^ n) := by
  refine ⟨pow_nonneg hx.1 n, ?_⟩
  rw [pow_mul]
  exact pow_le_pow_left₀ hx.1 hx.2 n

@[expose] def finiteQueryBudget (K J m cap : ℝ) : ℝ := (cap * J ^ 2 + m * ((cap + 1) * J + 1)) * (K + 1)

@[expose] def finiteWorkEnvelope (T K J m cap : ℝ) : ℝ :=
  T * (100 * (K + 1) * (T + cap + J + m + 2) ^ 5 * (finiteQueryBudget K J m cap + 1))

theorem finite_resource_expressions_power_bound (H : ℝ) (hH : 2 ≤ H) (T K J m cap : ℝ)
    (hT : PowerBound H 1 T) (hK : PowerBound H 1 K) (hJ : PowerBound H 82 J)
    (hm : PowerBound H 15 m) (hcap : PowerBound H 94 cap) :
    PowerBound H 261 (finiteQueryBudget K J m cap) ∧
      PowerBound H 359 (T * finiteQueryBudget K J m cap * K * (T + cap + 1)) ∧
      PowerBound H 180 (T * K * (J + m) * (cap + 1)) ∧
      PowerBound H 1024 (finiteWorkEnvelope T K J m cap) := by
  have hH0 : 0 ≤ H := by linarith
  have hH1 : 1 ≤ H := by linarith
  have hcap1 : PowerBound H 95 (cap + 1) := powerBound_add hH hcap (powerBound_one H)
  have hK1 : PowerBound H 2 (K + 1) := powerBound_add hH hK (powerBound_one H)
  have hfirst : PowerBound H 258 (cap * J ^ 2) := powerBound_mul hH0 hcap (powerBound_sq hH0 hJ)
  have hsecond : PowerBound H 193 (m * ((cap + 1) * J + 1)) := powerBound_mul hH0 hm
    (powerBound_add hH (powerBound_mul hH0 hcap1 hJ) (powerBound_one H))
  have hQ : PowerBound H 261 (finiteQueryBudget K J m cap) := powerBound_mul hH0 (powerBound_add hH hfirst hsecond) hK1
  have hinput : PowerBound H 96 (T + cap + 1) := powerBound_add hH (powerBound_add hH hT hcap) (powerBound_one H)
  have hwords : PowerBound H 359 (T * finiteQueryBudget K J m cap * K * (T + cap + 1)) :=
    powerBound_mul hH0 (powerBound_mul hH0 (powerBound_mul hH0 hT hQ) hK) hinput
  have hsam : PowerBound H 180 (T * K * (J + m) * (cap + 1)) :=
    powerBound_mul hH0 (powerBound_mul hH0 (powerBound_mul hH0 hT hK) (powerBound_add hH hJ hm)) hcap1
  have htwo : PowerBound H 1 2 := by convert! powerBound_const hH 1 using 1 <;> norm_num
  have hsum : PowerBound H 98 (T + cap + J + m + 2) :=
    powerBound_add hH (powerBound_add hH (powerBound_add hH (powerBound_add hH hT hcap) hJ) hm) htwo
  have h100 : PowerBound H 7 100 := by
    have h := powerBound_const hH 7
    exact ⟨by norm_num, (by norm_num : (100 : ℝ) ≤ 2 ^ 7).trans h.2⟩
  have hwork : PowerBound H 762 (finiteWorkEnvelope T K J m cap) :=
    powerBound_mul hH0 hT (powerBound_mul hH0
      (powerBound_mul hH0 (powerBound_mul hH0 h100 hK1) (powerBound_pow hH0 hsum 5))
      (powerBound_add hH hQ (powerBound_one H)))
  exact ⟨hQ, hwords, hsam, powerBound_mono hH1 hwork (by norm_num)⟩
end
end PoissonAudit
