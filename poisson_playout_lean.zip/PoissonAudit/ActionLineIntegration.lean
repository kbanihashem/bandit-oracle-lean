module

public import PoissonAudit.ExpectedLineIntegration

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

@[expose] def actionSlope {P A : Type*} [DecidableEq A] (pick : P → A) (a : A) (p : P) : ℝ :=
  if pick p = a then -1 else 0

theorem integral_negative_action_indicator {Omega A : Type*} [MeasurableSpace Omega]
    [MeasurableSpace A] [MeasurableSingletonClass A] [DecidableEq A]
    (mu : Measure Omega) (f : Omega → A) (hf : Measurable f) (a : A) :
    (∫ omega, (if f omega = a then (-1 : ℝ) else 0) ∂mu) = -(mu {omega | f omega = a}).toReal := by
  have hE : MeasurableSet {omega | f omega = a} := hf (measurableSet_singleton a)
  have heq : (fun omega => if f omega = a then (-1 : ℝ) else 0) =
      fun omega => -({omega | f omega = a}.indicator (fun _ => (1 : ℝ)) omega) := by
    funext omega
    by_cases h : f omega = a <;> simp [h]
  rw [heq, integral_neg]
  congr 1
  exact integral_indicator_const (1 : ℝ) hE |>.trans (by simp only [smul_eq_mul, mul_one]; rfl)

variable {Omega P A : Type*} [MeasurableSpace Omega]
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]
    [MeasurableSpace A] [MeasurableSingletonClass A] [DecidableEq A]

@[expose] def lineActionMass (mu : Measure Omega) (score : P → Omega → ℝ)
    (pick : P → A) (a : A) (t : ℝ) : ℝ :=
  (mu {omega | pick (lineWinner (fun p => score p omega) (actionSlope pick a) t) = a}).toReal

theorem integral_action_line_slope (mu : Measure Omega) (score : P → Omega → ℝ)
    (hs : ∀ p, Measurable (score p)) (pick : P → A) (a : A) (t : ℝ) :
    (∫ omega, actionSlope pick a (lineWinner (fun p => score p omega) (actionSlope pick a) t) ∂mu) =
      -lineActionMass mu score pick a t := by
  apply integral_negative_action_indicator
  exact (measurable_of_finite pick).comp
    (measurable_winner (fun p omega => score p omega + t * actionSlope pick a p)
      (fun p => (hs p).add measurable_const))

theorem intervalIntegrable_lineActionMass (mu : Measure Omega) [IsProbabilityMeasure mu]
    (score : P → Omega → ℝ) (hs : ∀ p, Measurable (score p))
    (pick : P → A) (a : A) (u v : ℝ) :
    IntervalIntegrable (lineActionMass mu score pick a) volume u v := by
  have hi := integrable_sampled_winner_slope mu score (actionSlope pick a) hs u v
  have hh : IntervalIntegrable
      (fun t => ∫ omega, actionSlope pick a (lineWinner (fun p => score p omega) (actionSlope pick a) t) ∂mu)
      volume u v := intervalIntegrable_iff.mpr hi.integral_prod_left
  simp_rw [integral_action_line_slope mu score hs pick a] at hh
  convert! hh.neg using 1
  funext t
  change _ = -(-lineActionMass mu score pick a t)
  ring

theorem expected_action_line_change (mu : Measure Omega) [IsProbabilityMeasure mu]
    (score : P → Omega → ℝ) (hs : ∀ p, Measurable (score p))
    (hi : ∀ p, Integrable (score p) mu) (pick : P → A) (a : A) (u v : ℝ) :
    (∫ omega, lineMax (fun p => score p omega) (actionSlope pick a) v ∂mu) -
      (∫ omega, lineMax (fun p => score p omega) (actionSlope pick a) u ∂mu) =
      -(∫ t in u..v, lineActionMass mu score pick a t) := by
  rw [expected_lineMax_change mu score (actionSlope pick a) hs hi u v]
  simp_rw [integral_action_line_slope mu score hs pick a]
  exact intervalIntegral.integral_neg

end

end PoissonAudit
