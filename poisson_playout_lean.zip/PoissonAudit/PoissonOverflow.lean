module
public import PoissonAudit.NativeEmpiricalRule
public section
open MeasureTheory Set
namespace PoissonAudit
noncomputable section

theorem real_markov_tail {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) [IsProbabilityMeasure mu] (f : Omega → ℝ)
    (hfm : Measurable f) (hfi : Integrable f mu) (hf0 : ∀ z, 0 ≤ f z)
    (cap : ℝ) (hcap : 0 < cap) :
    mu.real {z | cap < f z} ≤ (∫ z, f z ∂mu) / cap := by
  let E := {z | cap < f z}
  have hE : MeasurableSet E := measurableSet_lt measurable_const hfm
  have hp (z : Omega) : E.indicator (fun _ => (1 : ℝ)) z ≤ f z / cap := by
    by_cases hz : z ∈ E
    · rw [Set.indicator_of_mem hz]
      exact (one_le_div hcap).mpr (le_of_lt hz)
    · rw [Set.indicator_of_notMem hz]
      exact div_nonneg (hf0 z) hcap.le
  have h := integral_mono ((integrable_const (1 : ℝ)).indicator hE) (hfi.div_const cap) hp
  rw [integral_indicator_const 1 hE, smul_eq_mul, mul_one, integral_div] at h
  exact h

variable {X : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}

theorem integrable_nativeNoise_count (r : NNReal) (D : Measure X) [IsProbabilityMeasure D] :
    Integrable (fun v : NativeNoise X K => (v.2.1 : ℝ)) (insertedExperimentLaw r D K) :=
  ((integrable_poisson_count r).comp_fst (markSequence (contextLaplaceLaw D K))).comp_snd (laplaceMeasure K)

theorem integral_nativeNoise_count (r : NNReal) (D : Measure X) [IsProbabilityMeasure D] :
    (∫ v : NativeNoise X K, (v.2.1 : ℝ) ∂insertedExperimentLaw r D K) = r := by
  have hin := (integrable_poisson_count r).comp_fst (markSequence (contextLaplaceLaw D K))
  change (∫ v : NativeNoise X K, (v.2.1 : ℝ) ∂(laplaceMeasure K).prod (markedPoolLaw r (contextLaplaceLaw D K))) = _
  rw [integral_prod _ (integrable_nativeNoise_count r D)]
  simp only [integral_const, probReal_univ, one_smul]
  change (∫ pool, (pool.1 : ℝ) ∂(ProbabilityTheory.poissonMeasure r).prod (markSequence (contextLaplaceLaw D K))) = _
  rw [integral_prod _ hin]
  simp only [integral_const, probReal_univ, one_smul]
  exact integral_poisson_count r

@[expose] def nativeOverflowEvent {X : Type*} {K : ℕ} (cap : ℕ) : Set (NativeNoise X K) := {v | cap < v.2.1}

theorem native_noise_overflow_bound (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (cap : ℕ) (hc : 0 < cap) :
    (insertedExperimentLaw r D K).real (nativeOverflowEvent (X := X) (K := K) cap) ≤ (r : ℝ) / cap := by
  have h := real_markov_tail (insertedExperimentLaw r D K) (fun v : NativeNoise X K => (v.2.1 : ℝ))
    (by fun_prop) (integrable_nativeNoise_count r D)
    (fun v => Nat.cast_nonneg _) cap (by exact_mod_cast hc)
  rw [integral_nativeNoise_count r D] at h
  have heq : {v : NativeNoise X K | (cap : ℝ) < v.2.1} = nativeOverflowEvent cap := by
    ext v
    simp only [nativeOverflowEvent, Set.mem_setOf_eq, Nat.cast_lt]
  rw [heq] at h
  exact h

@[expose] def nativeCountCap (r : NNReal) (count : ℕ) (delta : ℝ) : ℕ :=
  max 1 ⌈8 * (r : ℝ) * count / delta⌉₊

theorem nativeCountCap_pos (r : NNReal) (count : ℕ) (delta : ℝ) : 0 < nativeCountCap r count delta :=
  lt_of_lt_of_le Nat.zero_lt_one (le_max_left _ _)

theorem nativeCountCap_budget (r : NNReal) (count : ℕ) (delta : ℝ) :
    8 * (r : ℝ) * count / delta ≤ nativeCountCap r count delta :=
  (Nat.le_ceil _).trans (Nat.cast_le.mpr (le_max_right _ _))

theorem nativeCountCap_total_tail_budget (r : NNReal) (count : ℕ) (delta : ℝ) (hd : 0 < delta) :
    (count : ℝ) * ((r : ℝ) / nativeCountCap r count delta) ≤ delta / 8 := by
  have hc : (0 : ℝ) < nativeCountCap r count delta := by exact_mod_cast nativeCountCap_pos r count delta
  have hb := (div_le_iff₀ hd).mp (nativeCountCap_budget r count delta)
  calc
    _ = (count : ℝ) * r / nativeCountCap r count delta := by ring
    _ ≤ delta / 8 := (div_le_iff₀ hc).mpr (by nlinarith only [hb])
end
end PoissonAudit
