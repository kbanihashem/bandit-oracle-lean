module

public import PoissonAudit.FiniteMaxIntegral

public section

open MeasureTheory
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {Omega P Q : Type*} [MeasurableSpace Omega]
    [Fintype P] [Nonempty P] [Fintype Q]

@[expose] def scaleBox (Q : Type*) (B : ℝ) : Set (Q → ℝ) := Set.Icc 1 (fun _ => B)

@[expose] def scalePenalty (w : Q → ℝ) (lam B : ℝ) (sigma : Q → ℝ) : ℝ :=
  lam * ∑ j, w j * Real.log (B / sigma j)

@[expose] def scaleObjective (mu : Measure Omega) (S : P → ℝ)
    (V : Omega → P → Q → ℝ) (w : Q → ℝ) (lam B : ℝ) (sigma : Q → ℝ) : ℝ :=
  affinePoolPotential mu S V sigma + scalePenalty w lam B sigma

omit [MeasurableSpace Omega] in
theorem affinePoolMax_box_bound (S : P → ℝ) (V : Omega → P → Q → ℝ)
    (B : ℝ) (hB : 1 ≤ B) (sigma : Q → ℝ) (hsigma : sigma ∈ scaleBox Q B)
    (omega : Omega) :
    ‖affinePoolMax S V sigma omega‖ ≤ ∑ p, (|S p| + B * ∑ j, |V omega p j|) := by
  classical
  obtain ⟨p, _, hp⟩ := Finset.exists_mem_eq_sup' (s := Finset.univ) Finset.univ_nonempty
    (fun p => S p + ∑ j, sigma j * V omega p j)
  unfold affinePoolMax
  rw [hp, Real.norm_eq_abs]
  calc
    _ ≤ |S p| + |∑ j, sigma j * V omega p j| := abs_add_le _ _
    _ ≤ |S p| + ∑ j, |sigma j * V omega p j| :=
      add_le_add le_rfl (Finset.abs_sum_le_sum_abs _ _)
    _ ≤ |S p| + B * ∑ j, |V omega p j| := by
      gcongr
      rw [Finset.mul_sum]
      apply Finset.sum_le_sum
      intro j _
      rw [abs_mul, abs_of_nonneg (show 0 ≤ sigma j by have hh : (1 : ℝ) ≤ sigma j := hsigma.1 j; linarith)]
      exact mul_le_mul_of_nonneg_right (hsigma.2 j) (abs_nonneg _)
    _ ≤ _ := Finset.single_le_sum (f := fun q : P => |S q| + B * ∑ j, |V omega q j|) (fun q _ => add_nonneg (abs_nonneg _) (mul_nonneg (by linarith) (Finset.sum_nonneg fun _ _ => abs_nonneg _))) (Finset.mem_univ p)

theorem continuousOn_affinePoolPotential (mu : Measure Omega) [IsFiniteMeasure mu]
    (S : P → ℝ) (V : Omega → P → Q → ℝ)
    (hV : ∀ p j, Integrable (fun omega => V omega p j) mu)
    (B : ℝ) (hB : 1 ≤ B) :
    ContinuousOn (affinePoolPotential mu S V) (scaleBox Q B) := by
  apply continuousOn_of_dominated
    (fun sigma _ => (integrable_affinePoolMax mu S V hV sigma).aestronglyMeasurable)
    (fun sigma hsigma => Filter.Eventually.of_forall (affinePoolMax_box_bound S V B hB sigma hsigma))
  · exact integrable_finsetSum _ fun p _ => (integrable_const _).add
      ((integrable_finsetSum _ fun j _ => (hV p j).abs).const_mul B)
  · exact Filter.Eventually.of_forall fun omega => (continuous_affinePoolMax S V omega).continuousOn

theorem continuousOn_scalePenalty (w : Q → ℝ) (lam B : ℝ) (hB : 1 ≤ B) :
    ContinuousOn (scalePenalty w lam B) (scaleBox Q B) := by
  apply continuousOn_const.mul
  apply continuousOn_finsetSum
  intro j _
  apply continuousOn_const.mul
  have hs : ∀ sigma ∈ scaleBox Q B, sigma j ≠ 0 := by
    intro sigma hsigma
    have hh : (1 : ℝ) ≤ sigma j := hsigma.1 j
    linarith
  apply ContinuousOn.log
  · exact continuousOn_const.div (continuous_apply j).continuousOn hs
  · intro sigma hsigma
    exact div_ne_zero (by linarith) (hs sigma hsigma)

theorem exists_scale_minimizer (mu : Measure Omega) [IsFiniteMeasure mu]
    (S : P → ℝ) (V : Omega → P → Q → ℝ)
    (hV : ∀ p j, Integrable (fun omega => V omega p j) mu)
    (w : Q → ℝ) (lam B : ℝ) (hB : 1 ≤ B) :
    ∃ sigma ∈ scaleBox Q B, IsMinOn (scaleObjective mu S V w lam B) (scaleBox Q B) sigma := by
  apply isCompact_Icc.exists_isMinOn
  · exact ⟨1, fun _ => le_rfl, fun _ => hB⟩
  · exact (continuousOn_affinePoolPotential mu S V hV B hB).add
      (continuousOn_scalePenalty w lam B hB)

theorem minimizer_envelope (mu : Measure Omega) (S S' : P → ℝ)
    (V : Omega → P → Q → ℝ) (w : Q → ℝ) (lam B : ℝ)
    (sigma sigma' : Q → ℝ)
    (hsigma : sigma ∈ scaleBox Q B)
    (hnew : IsMinOn (scaleObjective mu S' V w lam B) (scaleBox Q B) sigma') :
    scaleObjective mu S' V w lam B sigma' - scaleObjective mu S V w lam B sigma ≤
      affinePoolPotential mu S' V sigma - affinePoolPotential mu S V sigma := by
  have h := hnew hsigma
  unfold scaleObjective
  change affinePoolPotential mu S' V sigma' + scalePenalty w lam B sigma' ≤
    affinePoolPotential mu S' V sigma + scalePenalty w lam B sigma at h
  linarith

end

end PoissonAudit
