module
public import PoissonAudit.ArrayReplay
public section
namespace PoissonAudit
noncomputable section

@[expose] def executeFilter {A : Type*} (p : A → Bool) : List A → List A × ℕ
  | [] => ([], 0)
  | a :: xs => let tail := executeFilter p xs; (if p a then a :: tail.1 else tail.1, tail.2 + 4)

theorem executeFilter_correct {A : Type*} (p : A → Bool) (xs : List A) :
    executeFilter p xs = (xs.filter p, 4 * xs.length) := by
  induction xs with
  | nil => rfl
  | cons a xs ih => simp [executeFilter, ih, List.filter_cons]; omega

@[expose] def executeMinimum {A : Type*} [Min A] : List A → Option A × ℕ
  | [] => (none, 0)
  | a :: xs => let tail := executeMinimum xs; (some (tail.1.elim a (Min.min a)), tail.2 + 4)

theorem executeMinimum_correct {A : Type*} [LinearOrder A] (xs : List A) :
    executeMinimum xs = (xs.min?, 4 * xs.length) := by
  induction xs with
  | nil => rfl
  | cons a xs ih => simp [executeMinimum, ih]; omega

@[expose] def executeCachedSelection {K : ℕ} (base : ℝ) (table : Vector ℝ K) (fallback : Fin K) : Fin K × ℕ := by
  classical
  let eligible := executeFilter (fun a => decide (vectorValues table a = base + 1)) (List.ofFn id)
  let selected := executeMinimum eligible.1
  exact (selected.1.getD fallback, eligible.2 + selected.2)

theorem executeCachedSelection_steps {K : ℕ} (base : ℝ) (table : Vector ℝ K) (fallback : Fin K) :
    (executeCachedSelection base table fallback).2 ≤ 8 * K := by
  classical
  dsimp only [executeCachedSelection]
  rw [executeFilter_correct, executeMinimum_correct]
  simp only [List.length_ofFn]
  have h := List.length_filter_le (fun a => decide (vectorValues table a = base + 1)) (List.ofFn (id : Fin K → Fin K))
  simp only [List.length_ofFn] at h
  omega

theorem cachedSelection_min {K : ℕ} (base : ℝ) (table : Fin K → ℝ) (hgood : ∃ a, table a = base + 1) :
    ((List.ofFn (id : Fin K → Fin K)).filter (fun a => decide (table a = base + 1))).min? =
      some (actionFromValueTable base table hgood) := by
  classical
  apply List.min?_eq_some_iff.mpr
  constructor
  · simp only [List.mem_filter, List.mem_ofFn, decide_eq_true_eq]
    exact ⟨⟨actionFromValueTable base table hgood, rfl⟩, actionFromValueTable_spec base table hgood⟩
  · intro a ha
    have hp := (List.mem_filter.mp ha).2
    have htable : table a = base + 1 := of_decide_eq_true hp
    unfold actionFromValueTable
    exact Finset.min'_le _ a (by simp [htable])

theorem executeCachedSelection_value {K : ℕ} (base : ℝ) (table : Vector ℝ K) (fallback : Fin K) :
    (executeCachedSelection base table fallback).1 =
      if h : ∃ a, vectorValues table a = base + 1 then actionFromValueTable base (vectorValues table) h else fallback := by
  classical
  dsimp only [executeCachedSelection]
  rw [executeFilter_correct, executeMinimum_correct]
  split_ifs with hg
  · rw [cachedSelection_min base (vectorValues table) hg]
    rfl
  · have he : (List.ofFn (id : Fin K → Fin K)).filter (fun a => decide (vectorValues table a = base + 1)) = [] := by
      apply List.filter_eq_nil_iff.mpr
      intro a _
      exact fun ha => hg ⟨a, of_decide_eq_true ha⟩
    rw [he]
    rfl
end
end PoissonAudit
