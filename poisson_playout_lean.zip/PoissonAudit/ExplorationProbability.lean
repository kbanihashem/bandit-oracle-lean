module

public import PoissonAudit.ScalarProbabilityControl

public section

namespace PoissonAudit

noncomputable section

@[expose] def explorationProbability (K : ℕ) (gamma p : ℝ) : ℝ :=
  (1 - gamma) * p + gamma / K

@[expose] def explorationLog (K : ℕ) (gamma : ℝ) : ℝ :=
  1 - Real.log (gamma / K)

theorem exploration_floor {K : ℕ} {gamma p : ℝ}
    (hp : 0 ≤ p) (hgamma : gamma ≤ 1) :
    gamma / K ≤ explorationProbability K gamma p := by
  unfold explorationProbability
  have h := mul_nonneg (by linarith : 0 ≤ 1 - gamma) hp
  linarith

theorem exploration_positive {K : ℕ} {gamma p : ℝ}
    (hK : 0 < K) (hg : 0 < gamma) (hp : 0 ≤ p) (hgamma : gamma ≤ 1) :
    0 < explorationProbability K gamma p :=
  (div_pos hg (by exact_mod_cast hK)).trans_le (exploration_floor hp hgamma)

theorem exploration_dominates_half {K : ℕ} {gamma p : ℝ}
    (hg : 0 ≤ gamma) (hp : 0 ≤ p) (hgamma : gamma ≤ 1 / 2) :
    p ≤ 2 * explorationProbability K gamma p := by
  have ht := mul_nonneg (by linarith : 0 ≤ 1 / 2 - gamma) hp
  have hf : 0 ≤ gamma / (K : ℝ) := div_nonneg hg (Nat.cast_nonneg _)
  unfold explorationProbability
  nlinarith

theorem exploration_log_ge_one {K : ℕ} {gamma : ℝ}
    (hK : 0 < K) (hg : 0 < gamma) (hgamma : gamma ≤ 1) :
    1 ≤ explorationLog K gamma := by
  have hKr : (1 : ℝ) ≤ K := by exact_mod_cast hK
  have hf : 0 ≤ gamma / (K : ℝ) := div_nonneg hg.le (Nat.cast_nonneg _)
  have hf1 : gamma / (K : ℝ) ≤ 1 := (div_le_one (by positivity)).mpr (hgamma.trans hKr)
  have hl := Real.log_nonpos hf hf1
  unfold explorationLog
  linarith

theorem exploration_log_controls {K : ℕ} {gamma p : ℝ}
    (hK : 0 < K) (hg : 0 < gamma) (hp : 0 ≤ p) (hgamma : gamma ≤ 1) :
    1 - Real.log (explorationProbability K gamma p) ≤ explorationLog K gamma := by
  have hl := Real.log_le_log (div_pos hg (by exact_mod_cast hK)) (exploration_floor hp hgamma)
  unfold explorationLog
  linarith

theorem exploration_cap {K : ℕ} {gamma p B : ℝ}
    (hK : 0 < K) (hg : 0 < gamma) (hp : 0 ≤ p) (hgamma : gamma ≤ 1)
    (hB : (K : ℝ) / gamma ≤ B) :
    1 ≤ explorationProbability K gamma p * B := by
  have hKr : (0 : ℝ) < K := by exact_mod_cast hK
  have hBp : 0 ≤ B := (div_pos hKr hg).le.trans hB
  have hfloor := exploration_floor (K := K) hp hgamma
  have hprod := mul_le_mul_of_nonneg_left hB (div_nonneg hg.le hKr.le)
  have heq : gamma / (K : ℝ) * ((K : ℝ) / gamma) = 1 := by field_simp
  rw [heq] at hprod
  exact hprod.trans (mul_le_mul_of_nonneg_right hfloor hBp)

end

end PoissonAudit
