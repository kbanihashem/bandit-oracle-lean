module

public import Mathlib.InformationTheory.KullbackLeibler.ChainRule
public import Mathlib.InformationTheory.KullbackLeibler.DataProcessing
public import Mathlib.Probability.Kernel.Disintegration.StandardBorel
public import PoissonAudit.MarkedPoisson

public section

open MeasureTheory ProbabilityTheory InformationTheory
open scoped BigOperators ENNReal

namespace PoissonAudit

theorem klDiv_marginals_le {A B : Type*} [MeasurableSpace A] [MeasurableSpace B]
    [StandardBorelSpace B] [Nonempty B]
    (rho : Measure (A × B)) [IsProbabilityMeasure rho]
    (mu : Measure A) [IsProbabilityMeasure mu]
    (nu : Measure B) [IsProbabilityMeasure nu] :
    klDiv rho.fst mu + klDiv rho.snd nu ≤ klDiv rho (mu.prod nu) := by
  have hchain := klDiv_compProd_eq_add rho.fst mu rho.condKernel (Kernel.const A nu)
  rw [rho.disintegrate rho.condKernel, Measure.compProd_const, Measure.compProd_const] at hchain
  have hdp := klDiv_map_le rho (rho.fst.prod nu) measurable_snd
  change klDiv rho.snd (rho.fst.prod nu).snd ≤ _ at hdp
  rw [Measure.snd_prod] at hdp
  calc
    _ ≤ klDiv rho.fst mu + klDiv rho (rho.fst.prod nu) := add_le_add le_rfl hdp
    _ = _ := hchain.symm

theorem klDiv_sum_coordinates_le {U : Type*} [MeasurableSpace U]
    [StandardBorelSpace U] [Nonempty U]
    (mu : Measure U) [IsProbabilityMeasure mu]
    (n : ℕ) (rho : Measure (Fin n → U)) [IsProbabilityMeasure rho] :
    (∑ i : Fin n, klDiv (rho.map (fun u => u i)) mu) ≤ klDiv rho (iidPool mu n) := by
  induction n with
  | zero => simp
  | succ n ih =>
    let e : (Fin (n + 1) → U) ≃ᵐ U × (Fin n → U) :=
      MeasurableEquiv.piFinSuccAbove (fun _ => U) 0
    let rhoPair : Measure (U × (Fin n → U)) := rho.map e
    have hbase : (iidPool mu (n + 1)).map e = mu.prod (iidPool mu n) :=
      (measurePreserving_piFinSuccAbove (fun _ : Fin (n + 1) => mu) 0).map_eq
    have hdp := klDiv_map_le rho (iidPool mu (n + 1)) e.measurable
    rw [hbase] at hdp
    have hp := klDiv_marginals_le rhoPair mu (iidPool mu n)
    have hi := ih rhoPair.snd
    have hfst : rhoPair.fst = rho.map (fun u => u 0) := by
      change (rho.map e).map Prod.fst = _
      rw [Measure.map_map measurable_fst e.measurable]
      rfl
    have hsnd : ∀ i : Fin n,
        rhoPair.snd.map (fun u => u i) = rho.map (fun u => u i.succ) := by
      intro i
      change ((rho.map e).map Prod.snd).map (fun u => u i) = _
      rw [Measure.map_map (measurable_pi_apply i) measurable_snd,
        Measure.map_map ((measurable_pi_apply i).comp measurable_snd) e.measurable]
      congr 1
    rw [Fin.sum_univ_succ]
    rw [← hfst]
    simp_rw [← hsnd]
    calc
      _ ≤ klDiv rhoPair.fst mu + klDiv rhoPair.snd (iidPool mu n) := add_le_add le_rfl hi
      _ ≤ klDiv rhoPair (mu.prod (iidPool mu n)) := hp
      _ ≤ _ := hdp

end PoissonAudit
