module

public import PoissonAudit.FixedPoolDerivative
public import PoissonAudit.PoissonPotential
public import Mathlib.MeasureTheory.Measure.Prod

public section

open MeasureTheory MeasureTheory.Measure Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {m K : ℕ}

theorem measurable_context_linear_score (predict : P → X → Fin K)
    (sigma : X × Fin K → ℝ) (p : P) :
    Measurable (fun v : (Fin m → X) × (Fin m → Fin K → ℝ) => poolLinearScore predict sigma v.1 p v.2) :=
  measurable_from_prod_countable_right fun C => measurable_poolLinearScore predict sigma C p

theorem context_pool_tie_slopes (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma h : X × Fin K → ℝ)
    (hsigma : ∀ j, 0 < sigma j) (S : P → ℝ) (p q : P) :
    ∀ᵐ u ∂iidPool (contextLaplaceLaw D K) m,
      S p + poolLinearScore predict sigma (fun i => (u i).1) p (fun i => (u i).2) =
        S q + poolLinearScore predict sigma (fun i => (u i).1) q (fun i => (u i).2) →
      poolLinearScore predict h (fun i => (u i).1) p (fun i => (u i).2) =
        poolLinearScore predict h (fun i => (u i).1) q (fun i => (u i).2) := by
  let e := MeasurableEquiv.arrowProdEquivProdArrow X (Fin K → ℝ) (Fin m)
  have hmp : MeasurePreserving e (iidPool (contextLaplaceLaw D K) m)
      ((iidPool D m).prod (iidPool (laplaceMeasure K) m)) :=
    measurePreserving_arrowProdEquivProdArrow X (Fin K → ℝ) (Fin m) (fun _ => D) (fun _ => laplaceMeasure K)
  let A (v : (Fin m → X) × (Fin m → Fin K → ℝ)) (p : P) := S p + poolLinearScore predict sigma v.1 p v.2
  let B (v : (Fin m → X) × (Fin m → Fin K → ℝ)) (p : P) := poolLinearScore predict h v.1 p v.2
  have hAm (p : P) : Measurable (fun v => A v p) :=
    measurable_const.add (measurable_context_linear_score predict sigma p)
  have hBm (p : P) : Measurable (fun v => B v p) := measurable_context_linear_score predict h p
  have hm : MeasurableSet {v | A v p = A v q → B v p = B v q} :=
    (measurableSet_eq_fun (hAm p) (hAm q)).imp (measurableSet_eq_fun (hBm p) (hBm q))
  have hprod : ∀ᵐ v ∂(iidPool D m).prod (iidPool (laplaceMeasure K) m), A v p = A v q → B v p = B v q := by
    apply (ae_prod_iff_ae_ae hm).mpr
    exact Filter.Eventually.of_forall fun C => by
      filter_upwards [laplace_pool_tie_forces_agreement predict sigma hsigma C S p q] with z hz hA
      exact congrArg (fun L : (Fin m → Fin K → ℝ) →ₗ[ℝ] ℝ => L z)
        (poolLinearScore_eq_of_agree predict h C p q (hz hA))
  exact hmp.quasiMeasurePreserving.ae hprod

theorem poisson_score_eq_prefix (predict : P → X → Fin K)
    (sigma : X × Fin K → ℝ) (pool : ℕ × (ℕ → X × (Fin K → ℝ))) (p : P) :
    (∑ j, sigma j * poissonCoefficient predict pool p j) =
      poolLinearScore predict sigma (fun i : Fin pool.1 => (pool.2 i).1) p (fun i => (pool.2 i).2) :=
  poissonCoefficient_expansion predict p sigma pool

theorem measurable_poisson_linear_score (predict : P → X → Fin K)
    (sigma : X × Fin K → ℝ) (p : P) :
    Measurable (fun pool => ∑ j, sigma j * poissonCoefficient predict pool p j) := by
  apply Finset.measurable_sum
  intro j _
  exact measurable_const.mul (measurable_poolSum _ (measurable_singleMarkCoefficient predict p j))

theorem poisson_pool_tie_slopes (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma h : X × Fin K → ℝ)
    (hsigma : ∀ j, 0 < sigma j) (S : P → ℝ) (p q : P) :
    ∀ᵐ pool ∂markedPoolLaw r (contextLaplaceLaw D K),
      S p + (∑ j, sigma j * poissonCoefficient predict pool p j) =
        S q + (∑ j, sigma j * poissonCoefficient predict pool q j) →
      (∑ j, h j * poissonCoefficient predict pool p j) =
        ∑ j, h j * poissonCoefficient predict pool q j := by
  have hm : MeasurableSet {pool | S p + (∑ j, sigma j * poissonCoefficient predict pool p j) =
      S q + (∑ j, sigma j * poissonCoefficient predict pool q j) →
      (∑ j, h j * poissonCoefficient predict pool p j) = ∑ j, h j * poissonCoefficient predict pool q j} :=
    (measurableSet_eq_fun (measurable_const.add (measurable_poisson_linear_score predict sigma p))
      (measurable_const.add (measurable_poisson_linear_score predict sigma q))).imp
      (measurableSet_eq_fun (measurable_poisson_linear_score predict h p) (measurable_poisson_linear_score predict h q))
  apply (ae_prod_iff_ae_ae hm).mpr
  apply Filter.Eventually.of_forall
  intro n
  have hn := (poolPrefix_measurePreserving (contextLaplaceLaw D K) n).quasiMeasurePreserving.ae
    (context_pool_tie_slopes (m := n) D predict sigma h hsigma S p q)
  simpa only [poisson_score_eq_prefix, poolPrefix] using hn

end

end PoissonAudit
