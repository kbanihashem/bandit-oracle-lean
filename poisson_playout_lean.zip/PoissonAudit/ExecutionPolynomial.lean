module
public import PoissonAudit.CostedArraySampler
public import PoissonAudit.PolynomialResourceExpressions
public section
namespace PoissonAudit
noncomputable section

theorem powerBound_le {H x y : ℝ} {a : ℕ} (hy : PowerBound H a y) (hx : 0 ≤ x) (hxy : x ≤ y) : PowerBound H a x :=
  ⟨hx, hxy.trans hy.2⟩

theorem powerBound_small {H : ℝ} (hH : 2 ≤ H) (n e : ℕ) (h : (n : ℝ) ≤ 2 ^ e) : PowerBound H e n :=
  powerBound_le (powerBound_const hH e) (Nat.cast_nonneg _) h

theorem samplerInternalBudget_power_bound (H : ℝ) (hH : 2 ≤ H) (K cap J m : ℕ)
    (hK : PowerBound H 1 K) (hc : PowerBound H 94 cap) (hJ : PowerBound H 82 J) (hm : PowerBound H 15 m) :
    PowerBound H 353 (samplerInternalBudget K cap J m) := by
  have hH0 : 0 ≤ H := by linarith
  have hH1 : 1 ≤ H := by linarith
  have h1 := powerBound_one H
  have h2 := powerBound_small hH 2 1 (by norm_num)
  have h4 := powerBound_small hH 4 2 (by norm_num)
  have h12 := powerBound_small hH 12 4 (by norm_num)
  have h60 := powerBound_small hH 60 6 (by norm_num)
  have hK1 : PowerBound H 2 ((K : ℝ) + 1) := powerBound_add hH hK h1
  have hK2 : PowerBound H 2 ((K : ℝ) + 2) := powerBound_add hH hK h2
  have h4K : PowerBound H 3 (4 * (K : ℝ)) := powerBound_mul hH0 h4 hK
  have hrep : PowerBound H 168 (replayInternalBudget K J) := by
    unfold replayInternalBudget
    push_cast
    exact powerBound_add hH (powerBound_mul hH0 h2 hK)
      (powerBound_mul hH0 hJ (powerBound_add hH
        (powerBound_mul hH0 h60 (powerBound_sq hH0 hK1)) (powerBound_mul hH0 hJ hK2)))
  have hrecord : PowerBound H 264 ((cap : ℝ) * (replayInternalBudget K J + 4 * K + 1)) :=
    powerBound_mul hH0 hc (powerBound_add hH (powerBound_add hH hrep h4K) h1)
  have hquery : PowerBound H 260 ((cap : ℝ) * J ^ 2 * (K + 1)) :=
    powerBound_mul hH0 (powerBound_mul hH0 hc (powerBound_sq hH0 hJ)) hK1
  have hpool : PowerBound H 178 ((cap : ℝ) * (J * (K + 1))) :=
    powerBound_mul hH0 hc (powerBound_mul hH0 hJ hK1)
  have hstep : PowerBound H 267 (constructionStepBudget K cap J) := by
    unfold constructionStepBudget
    push_cast
    exact powerBound_add hH (powerBound_add hH (powerBound_add hH hrecord hquery) hpool) h1
  have hcall : PowerBound H 8 (4 * (K : ℝ) ^ 2 + 12 * K + 1) := by
    have h := powerBound_add hH (powerBound_add hH (powerBound_mul hH0 h4 (powerBound_sq hH0 hK))
      (powerBound_mul hH0 h12 hK)) h1
    exact powerBound_mono hH1 h (by norm_num)
  have htail : PowerBound H 179 (((cap : ℝ) + 2) * J * (K + 1)) :=
    powerBound_mul hH0 (powerBound_mul hH0 (powerBound_add hH hc h2) hJ) hK1
  have htrial : PowerBound H 268 (trialInternalBudget K cap J) := by
    unfold trialInternalBudget
    push_cast
    exact powerBound_add hH (powerBound_add hH (powerBound_add hH (powerBound_add hH hrep hrecord) hcall) h4K) htail
  have hbuild : PowerBound H 349 ((J : ℝ) * constructionStepBudget K cap J) := powerBound_mul hH0 hJ hstep
  have htrials : PowerBound H 284 ((m : ℝ) * (trialInternalBudget K cap J + 1)) :=
    powerBound_mul hH0 hm (powerBound_add hH htrial h1)
  have htrialQ : PowerBound H 195 ((m : ℝ) * (((cap + 1) * J + 1) * (K + 1))) :=
    powerBound_mul hH0 hm (powerBound_mul hH0
      (powerBound_add hH (powerBound_mul hH0 (powerBound_add hH hc h1) hJ) h1) hK1)
  have hchecks : PowerBound H 86 (4 * ((J : ℝ) + m + 1)) :=
    powerBound_mul hH0 h4 (powerBound_add hH (powerBound_add hH hJ hm) h1)
  unfold samplerInternalBudget
  push_cast
  exact powerBound_add hH (powerBound_add hH (powerBound_add hH (powerBound_add hH hbuild htrials) hquery) htrialQ) hchecks
end
end PoissonAudit
