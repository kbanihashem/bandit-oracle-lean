module

public import PoissonAudit.EventInformationCharge

public section

open MeasureTheory InformationTheory
open scoped ENNReal

namespace PoissonAudit

noncomputable section

theorem eventChannel_discrepancy_le_charge {U V : Type*} [MeasurableSpace U] [MeasurableSpace V]
    (mu : Measure U) (nu : Measure V) [IsProbabilityMeasure mu] [IsProbabilityMeasure nu]
    (E : Set (U × V)) (hE : MeasurableSet E) :
    (∫ z, (Real.sqrt (eventChannel nu E z) - Real.sqrt (mu.prod nu E).toReal) ^ 2 ∂mu) ≤
      eventInformationCharge mu nu E := by
  have hdp := klDiv_map_le (eventPosterior (mu.prod nu) E) (mu.prod nu) measurable_fst
  change klDiv (eventPosterior (mu.prod nu) E).fst (mu.prod nu).fst ≤ _ at hdp
  rw [Measure.fst_prod] at hdp
  have hw := mul_le_mul_right hdp (mu.prod nu E)
  rw [weighted_eventPosterior_kl (mu.prod nu) E hE] at hw
  have hfinite : mu.prod nu E * klDiv (eventPosterior (mu.prod nu) E).fst mu ≠ ∞ :=
    ne_top_of_le_ne_top ENNReal.ofReal_ne_top hw
  have hh := eventChannel_discrepancy_le_posterior mu nu E hE
  have hr := ENNReal.toReal_mono hfinite hh
  rw [ENNReal.toReal_ofReal (integral_nonneg fun _ => sq_nonneg _), ENNReal.toReal_mul] at hr
  exact hr

end

end PoissonAudit
