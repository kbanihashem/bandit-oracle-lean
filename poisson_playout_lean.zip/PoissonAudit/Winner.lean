module

public import Mathlib.Analysis.Convex.Basic
public import Mathlib.MeasureTheory.MeasurableSpace.Constructions
public import Mathlib.MeasureTheory.Constructions.BorelSpace.Basic
public import Mathlib.MeasureTheory.Constructions.BorelSpace.Order
public import Mathlib.Tactic

public section

open scoped BigOperators
open MeasureTheory

namespace PoissonAudit

noncomputable section

variable {P : Type*} [Fintype P] [Nonempty P] [LinearOrder P]

@[expose] def IsWinner (S : P → ℝ) (p : P) : Prop :=
  (∀ q, S q ≤ S p) ∧ ∀ q, q < p → S q < S p

theorem exists_isWinner (S : P → ℝ) : ∃ p, IsWinner S p := by
  classical
  obtain ⟨p, _, hp⟩ := Finset.exists_max_image Finset.univ S Finset.univ_nonempty
  let maxima := Finset.univ.filter (fun p => ∀ q, S q ≤ S p)
  have hne : maxima.Nonempty := ⟨p, by simp [maxima, hp]⟩
  let i := maxima.min' hne
  have him : i ∈ maxima := Finset.min'_mem maxima hne
  have hi : ∀ q, S q ≤ S i := (Finset.mem_filter.mp him).2
  refine ⟨i, hi, ?_⟩
  intro q hqi
  apply lt_of_le_of_ne (hi q)
  intro heq
  have hqm : q ∈ maxima := by
    apply Finset.mem_filter.mpr
    refine ⟨Finset.mem_univ _, ?_⟩
    intro j
    rw [heq]
    exact hi j
  have hmin : i ≤ q := Finset.min'_le maxima q hqm
  exact (not_le_of_gt hqi) hmin

omit [Fintype P] [Nonempty P] in
theorem isWinner_unique {S : P → ℝ} {p q : P}
    (hp : IsWinner S p) (hq : IsWinner S q) : p = q := by
  rcases lt_trichotomy p q with h | h | h
  · exact False.elim ((not_lt_of_ge (hp.1 q)) (hq.2 p h))
  · exact h
  · exact False.elim ((not_lt_of_ge (hq.1 p)) (hp.2 q h))

@[expose] def winner (S : P → ℝ) : P := Classical.choose (exists_isWinner S)

theorem winner_spec (S : P → ℝ) : IsWinner S (winner S) :=
  Classical.choose_spec (exists_isWinner S)

theorem winner_eq_iff (S : P → ℝ) (p : P) : winner S = p ↔ IsWinner S p := by
  constructor
  · intro h
    rw [← h]
    exact winner_spec S
  · exact fun h => isWinner_unique (winner_spec S) h

theorem winner_maximizes (S : P → ℝ) (p : P) : S p ≤ S (winner S) :=
  (winner_spec S).1 p

omit [Nonempty P] in
theorem measurable_winner_event {Omega : Type*} [MeasurableSpace Omega]
    (score : P → Omega → ℝ) (hscore : ∀ p, Measurable (score p)) (p : P) :
    MeasurableSet {omega | IsWinner (fun q => score q omega) p} := by
  classical
  have hle : MeasurableSet {omega | ∀ q, score q omega ≤ score p omega} := by
    simp only [Set.ofPred_forall]
    exact MeasurableSet.iInter (fun q => measurableSet_le (hscore q) (hscore p))
  have hlt : MeasurableSet {omega | ∀ q, q < p → score q omega < score p omega} := by
    rw [Set.ofPred_forall]
    apply MeasurableSet.iInter
    intro q
    by_cases h : q < p
    · simpa only [h, true_implies] using measurableSet_lt (hscore q) (hscore p)
    · simp [h]
  exact hle.inter hlt

theorem measurable_winner {Omega : Type*} [MeasurableSpace Omega]
    [MeasurableSpace P] (score : P → Omega → ℝ) (hscore : ∀ p, Measurable (score p)) :
    Measurable (fun omega => winner (fun p => score p omega)) := by
  apply measurable_to_countable'
  intro p
  have heq : (fun omega => winner (fun p => score p omega)) ⁻¹' {p} =
      {omega | IsWinner (fun q => score q omega) p} := by
    ext omega
    exact winner_eq_iff _ _
  rw [heq]
  exact measurable_winner_event score hscore p

omit [Fintype P] [Nonempty P] in

theorem convex_winner_region {E : Type*} [AddCommGroup E] [Module ℝ E]
    (score : P → E → ℝ)
    (haffine : ∀ p x y a b, a + b = 1 →
      score p (a • x + b • y) = a * score p x + b * score p y) (p : P) :
    Convex ℝ {x | IsWinner (fun q => score q x) p} := by
  intro x hx y hy a b ha hb hab
  constructor
  · intro q
    change score q (a • x + b • y) ≤ score p (a • x + b • y)
    rw [haffine q x y a b hab, haffine p x y a b hab]
    exact add_le_add (mul_le_mul_of_nonneg_left (hx.1 q) ha)
      (mul_le_mul_of_nonneg_left (hy.1 q) hb)
  · intro q hqp
    change score q (a • x + b • y) < score p (a • x + b • y)
    rw [haffine q x y a b hab, haffine p x y a b hab]
    by_cases hbp : 0 < b
    · exact add_lt_add_of_le_of_lt (mul_le_mul_of_nonneg_left (hx.2 q hqp).le ha)
        (mul_lt_mul_of_pos_left (hy.2 q hqp) hbp)
    · have hb0 : b = 0 := le_antisymm (le_of_not_gt hbp) hb
      have ha1 : a = 1 := by linarith
      simpa [hb0, ha1] using hx.2 q hqp

end

end PoissonAudit
