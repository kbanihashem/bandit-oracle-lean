module
public import PoissonAudit.ScoreMeasurability
public section

open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section

variable {Y P A O : Type*} [Fintype P] [Nonempty P] [Fintype O]

@[expose] def schedulePayoff (w : (P → ℝ) → Y → O → ℝ)
    (U : (P → ℝ) → Y → (A → ℝ) → O → P → ℝ) (act : O → A) (pred : P → Y → A) :
    (n : ℕ) → (Fin n → Y × (A → ℝ)) → (P → ℝ) → (P → ℝ) → ℝ
  | 0, _, _, Q => treeBestScore Q
  | n+1, v, S, Q =>
    let y := (v 0).1
    let c := (v 0).2
    ∑ o, w S y o * (c (act o) +
      schedulePayoff w U act pred n (fun t => v t.succ) (U S y c o) (fun p => Q p - c (pred p y)))

theorem measurable_schedulePayoff {Ω : Type*} [MeasurableSpace Ω]
    [Fintype Y] [MeasurableSpace Y] [MeasurableSingletonClass Y] [Fintype A]
    (w : (P → ℝ) → Y → O → ℝ) (hw : ∀ y o, Measurable (fun S => w S y o))
    (U : (P → ℝ) → Y → (A → ℝ) → O → P → ℝ)
    (hU : ∀ y o, Measurable (fun z : (P → ℝ) × (A → ℝ) => U z.1 y z.2 o))
    (act : O → A) (pred : P → Y → A) (n : ℕ)
    (v : Ω → Fin n → Y × (A → ℝ)) (hv : Measurable v)
    (S Q : Ω → P → ℝ) (hS : Measurable S) (hQ : Measurable Q) :
    Measurable (fun z => schedulePayoff w U act pred n (v z) (S z) (Q z)) := by
  induction n generalizing S Q with
  | zero =>
    have h := Finset.measurable_sup' Finset.univ_nonempty (fun p _ => (measurable_pi_apply p).comp hQ)
    convert h using 1
    funext z
    simp [schedulePayoff, treeBestScore, Finset.sup'_apply, Function.comp_def]
  | succ n ih =>
    have h0 := (measurable_pi_apply (0 : Fin (n+1))).comp hv
    have hy := measurable_fst.comp h0
    have hc := measurable_snd.comp h0
    have ht : Measurable (fun z t => v z (Fin.succ t)) :=
      Measurable.of_eval (fun t => (measurable_pi_apply t.succ).comp hv)
    apply Finset.measurable_sum
    intro o _
    have hW : Measurable (fun z : (P → ℝ) × Y => w z.1 z.2 o) :=
      measurable_from_prod_countable_left (fun y => hw y o)
    have hV : Measurable (fun z : ((P → ℝ) × (A → ℝ)) × Y => U z.1.1 z.2 z.1.2 o) :=
      measurable_from_prod_countable_left (fun y => hU y o)
    apply ((hW.comp (hS.prodMk hy))).mul
    apply ((measurable_pi_apply (act o)).comp hc).add
    apply ih _ ht _ _ (hV.comp ((hS.prodMk hc).prodMk hy))
    apply Measurable.of_eval
    intro p
    have hsel : Measurable (fun z : (A → ℝ) × Y => z.1 (pred p z.2)) :=
      measurable_from_prod_countable_left (fun y => measurable_pi_apply (pred p y))
    exact ((measurable_pi_apply p).comp hQ).sub (hsel.comp (hc.prodMk hy))

theorem schedulePayoff_bound (w : (P → ℝ) → Y → O → ℝ)
    (hw : ∀ S y o, 0 ≤ w S y o) (hs : ∀ S y, ∑ o, w S y o = 1)
    (U : (P → ℝ) → Y → (A → ℝ) → O → P → ℝ) (act : O → A) (pred : P → Y → A)
    (n : ℕ) (v : Fin n → Y × (A → ℝ))
    (hv : ∀ t a, (v t).2 a ∈ Icc (0 : ℝ) 1) (S Q : P → ℝ) (b : ℝ)
    (hQ : ∀ p, |Q p| ≤ b) : |schedulePayoff w U act pred n v S Q| ≤ b + 2*n := by
  classical
  induction n generalizing S Q b with
  | zero =>
    simp only [schedulePayoff, Nat.cast_zero, mul_zero, add_zero]
    obtain ⟨p, _, hp⟩ := Finset.exists_mem_eq_sup' Finset.univ_nonempty Q
    simpa only [treeBestScore, hp] using hQ p
  | succ n ih =>
    let y := (v 0).1
    let c := (v 0).2
    have hb (o : O) := ih (fun i => v i.succ) (fun i => hv i.succ) (U S y c o)
      (fun p => Q p - c (pred p y)) (b+1) (fun p => by
        have h := abs_sub (Q p) (c (pred p y))
        have hc := hv 0 (pred p y)
        change 0 ≤ c (pred p y) ∧ c (pred p y) ≤ 1 at hc
        rw [abs_of_nonneg hc.1] at h
        linarith [hQ p])
    unfold schedulePayoff
    apply (Finset.abs_sum_le_sum_abs _ _).trans
    calc
      _ ≤ ∑ o, w S y o * (1+(b+1+2*n)) := by
        apply Finset.sum_le_sum
        intro o _
        rw [abs_mul, abs_of_nonneg (hw ..)]
        apply mul_le_mul_of_nonneg_left _ (hw ..)
        apply (abs_add_le ..).trans
        exact add_le_add (by simpa [abs_of_nonneg (hv 0 (act o)).1] using (hv 0 (act o)).2) (hb o)
      _ = _ := by rw [← Finset.sum_mul, hs]; push_cast; ring

theorem integral_schedulePayoff_finite [Fintype Y] [MeasurableSpace Y] [MeasurableSingletonClass Y] [Fintype A]
    (D : Measure Y) [IsProbabilityMeasure D] (w : (P → ℝ) → Y → O → ℝ)
    (hs : ∀ S y, ∑ o, w S y o = 1)
    (U : (P → ℝ) → Y → (A → ℝ) → O → P → ℝ) (act : O → A) (pred : P → Y → A)
    (cs : List (Y → A → ℝ)) (S Q : P → ℝ) :
    (∫ ys, schedulePayoff w U act pred cs.length (fun t => (ys t,cs.get t (ys t))) S Q ∂iidPool D cs.length) =
      finiteOutcomeLoss (fun y => (D {y}).toReal) act w U cs S +
      contextBestScore (fun y => (D {y}).toReal) pred cs Q := by
  induction cs generalizing S Q with
  | nil => simp [schedulePayoff,finiteOutcomeLoss,contextBestScore]
  | cons c cs ih =>
    let F := fun (p : Y × (Fin cs.length → Y)) =>
      ∑ o, w S p.1 o * (c p.1 (act o) +
        schedulePayoff w U act pred cs.length (fun t => (p.2 t,cs.get t (p.2 t)))
          (U S p.1 (c p.1) o) (trueScoreStep pred Q c p.1))
    have h := iid_split_integral D (0 : Fin (cs.length+1)) F
    convert_to (∫ z, F (splitMark 0 z) ∂iidPool D (cs.length+1)) = _

    · congr 1
    rw [h, integral_prod _ Integrable.of_finite, integral_fintype Integrable.of_finite]
    simp only [Measure.real, smul_eq_mul, F, finiteOutcomeLoss, contextBestScore, ← Finset.sum_add_distrib, ← mul_add]
    apply Finset.sum_congr rfl
    intro y _
    congr 1
    rw [integral_finsetSum _ (fun _ _ => Integrable.of_finite)]
    simp_rw [integral_const_mul, integral_add (integrable_const _) Integrable.of_finite, integral_const, probReal_univ, one_smul, ih]
    simp only [← add_assoc, mul_add, Finset.sum_add_distrib, ← Finset.sum_mul, hs, one_mul]

end
end PoissonAudit
