module

public import PoissonAudit.RealLaplaceMoments
public import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus

public section

open MeasureTheory Set Filter
open scoped Topology

namespace PoissonAudit

noncomputable section

@[expose] def laplaceSurvival (t : ℝ) : ℝ := ∫ z in Ioi t, realLaplaceDensity z

theorem continuous_realLaplaceDensity : Continuous realLaplaceDensity := by
  unfold realLaplaceDensity
  fun_prop

theorem setIntegral_realLaplace (f : ℝ → ℝ) (E : Set ℝ) (hE : MeasurableSet E) :
    (∫ z in E, f z ∂realLaplace) = (∫ z in E, f z * Real.exp (-|z|)) / 2 := by
  rw [← integral_indicator hE, integral_realLaplace]
  congr 1
  rw [← integral_indicator hE]
  apply integral_congr_ae
  filter_upwards [] with z
  by_cases h : z ∈ E <;> simp [h]

theorem laplaceSurvival_eq_probability (t : ℝ) :
    laplaceSurvival t = (realLaplace (Ioi t)).toReal := by
  have h := setIntegral_realLaplace (fun _ => (1 : ℝ)) (Ioi t) measurableSet_Ioi
  simp only [one_mul] at h
  unfold laplaceSurvival realLaplaceDensity
  rw [integral_div]
  rw [← h, setIntegral_const]
  change (realLaplace (Ioi t)).toReal * 1 = _
  ring

theorem hasDerivAt_laplaceSurvival (t : ℝ) :
    HasDerivAt laplaceSurvival (-realLaplaceDensity t) t := by
  have heq (u : ℝ) : laplaceSurvival u = laplaceSurvival t - ∫ z in t..u, realLaplaceDensity z := by
    have h := intervalIntegral.integral_Ioi_sub_Ioi' (a := t) (b := u)
      integrable_realLaplaceDensity.integrableOn integrable_realLaplaceDensity.integrableOn
    change laplaceSurvival t - laplaceSurvival u = _ at h
    linarith
  have hd := (intervalIntegral.integral_hasDerivAt_right
    (continuous_realLaplaceDensity.intervalIntegrable t t)
    continuous_realLaplaceDensity.aestronglyMeasurable.stronglyMeasurableAtFilter
    continuous_realLaplaceDensity.continuousAt).const_sub (laplaceSurvival t)
  convert! hd using 1
  funext u
  exact heq u

theorem integral_laplaceSign_tail (t : ℝ) :
    (∫ z in Ioi t, laplaceSign z ∂realLaplace) = realLaplaceDensity t := by
  by_cases ht : 0 ≤ t
  · rw [setIntegral_realLaplace _ _ measurableSet_Ioi]
    have heq : (∫ z : ℝ in Ioi t, laplaceSign z * Real.exp (-|z|)) = Real.exp (-t) := by
      calc
        _ = ∫ z : ℝ in Ioi t, Real.exp (-z) := by
          apply setIntegral_congr_fun measurableSet_Ioi
          intro z hz
          have hz0 : 0 < z := lt_of_le_of_lt ht hz
          simp [laplaceSign, hz0, abs_of_pos hz0]
        _ = _ := integral_exp_neg_Ioi t
    rw [heq]
    simp [realLaplaceDensity, abs_of_nonneg ht]
  · have ht0 : t ≤ 0 := le_of_lt (lt_of_not_ge ht)
    have hl : (∫ z in Iic t, laplaceSign z ∂realLaplace) = -Real.exp t / 2 := by
      rw [setIntegral_realLaplace _ _ measurableSet_Iic]
      congr 1
      calc
        _ = ∫ z : ℝ in Iic t, -Real.exp z := by
          apply setIntegral_congr_fun measurableSet_Iic
          intro z hz
          have hz0 : z ≤ 0 := hz.trans ht0
          simp [laplaceSign, not_lt.mpr hz0, abs_of_nonpos hz0]
        _ = _ := by rw [integral_neg, integral_exp_Iic]
    have h := integral_add_compl (s := Iic t) measurableSet_Iic integrable_realLaplace_sign
    rw [compl_Iic, hl, integral_realLaplace_sign] at h
    simp only [realLaplaceDensity, abs_of_nonpos ht0, neg_neg]
    linarith

theorem realLaplaceDensity_shift_le (t u : ℝ) :
    realLaplaceDensity (t + u) ≤ Real.exp |u| * realLaplaceDensity t := by
  unfold realLaplaceDensity
  have ht : |t| ≤ |t + u| + |u| := by
    simpa only [add_neg_cancel_right, abs_neg] using abs_add_le (t + u) (-u)
  have he : Real.exp (-|t + u|) ≤ Real.exp |u| * Real.exp (-|t|) := by
    rw [← Real.exp_add]
    apply Real.exp_le_exp.mpr
    linarith
  nlinarith

end

end PoissonAudit
