module
public import PoissonAudit.RealLaplaceMoments
public import Mathlib.MeasureTheory.Measure.Haar.NormedSpace
public section
open MeasureTheory Set
namespace PoissonAudit
noncomputable section

@[expose] def scaledLaplaceDensity (u y : ℝ) : ℝ := realLaplaceDensity (y / u) / u

theorem scaledLaplaceDensity_pos {u : ℝ} (hu : 0 < u) (y : ℝ) : 0 < scaledLaplaceDensity u y :=
  div_pos (realLaplaceDensity_pos _) hu

theorem integrable_scaledLaplaceDensity {u : ℝ} (hu : 0 < u) : Integrable (scaledLaplaceDensity u) := by
  have h := integrable_realLaplaceDensity.comp_mul_left' (inv_ne_zero hu.ne')
  convert! h.div_const u using 1
  funext y
  change realLaplaceDensity (y / u) / u = realLaplaceDensity (u⁻¹ * y) / u
  congr 2
  ring

theorem integral_scaledLaplaceDensity {u : ℝ} (hu : 0 < u) : (∫ y, scaledLaplaceDensity u y) = 1 := by
  have heq : (∫ y, realLaplaceDensity (y / u)) = u := by
    calc
      _ = ∫ y, realLaplaceDensity (u⁻¹ * y) := by
        apply integral_congr_ae
        filter_upwards [] with y
        congr 1
        ring
      _ = _ := by rw [Measure.integral_comp_inv_mul_left, abs_of_pos hu, integral_realLaplaceDensity, smul_eq_mul, mul_one]
  change (∫ y, realLaplaceDensity (y / u) / u) = _
  rw [integral_div, heq, div_self hu.ne']

theorem scaledLaplaceDensity_ordered {u v : ℝ} (hu : 0 < u) (hv : 0 < v) (huv : u ≤ v) (y : ℝ) :
    scaledLaplaceDensity u y ≤ (v / u) * scaledLaplaceDensity v y := by
  have hdiv := div_le_div_of_nonneg_left (abs_nonneg y) hu huv
  have he := Real.exp_le_exp.mpr (neg_le_neg hdiv)
  have heq (s : ℝ) (hs : 0 < s) : scaledLaplaceDensity s y = Real.exp (- (|y| / s)) / (2 * s) := by
    unfold scaledLaplaceDensity realLaplaceDensity
    rw [abs_div, abs_of_pos hs]
    ring
  rw [heq u hu, heq v hv]
  calc
    _ ≤ Real.exp (- (|y| / v)) / (2 * u) := div_le_div_of_nonneg_right he (by positivity)
    _ = _ := by field_simp <;> ring

theorem normalized_density_l1_domination {Omega : Type*} [MeasurableSpace Omega]
    (mu : Measure Omega) (f g : Omega → ℝ) (hfi : Integrable f mu) (hgi : Integrable g mu)
    (hfn : ∫ x, f x ∂mu = 1) (hgn : ∫ x, g x ∂mu = 1)
    (hg : ∀ x, 0 ≤ g x) (C : ℝ) (hC : 1 ≤ C) (hfg : ∀ x, f x ≤ C * g x) :
    (∫ x, |f x - g x| ∂mu) ≤ 2 * (C - 1) := by
  have hp (x : Omega) : |f x - g x| ≤ 2 * (C - 1) * g x - (f x - g x) := by
    rcases le_total (f x) (g x) with h | h
    · rw [abs_of_nonpos (sub_nonpos.mpr h)]
      nlinarith [mul_nonneg (by linarith : 0 ≤ C - 1) (hg x)]
    · rw [abs_of_nonneg (sub_nonneg.mpr h)]
      nlinarith [hfg x]
  have hi := integral_mono (hfi.sub hgi).abs ((hgi.const_mul (2 * (C - 1))).sub (hfi.sub hgi)) hp
  change (∫ x, |f x - g x| ∂mu) ≤ ∫ x, 2 * (C - 1) * g x - (f x - g x) ∂mu at hi
  rw [integral_sub (f := fun x => 2 * (C - 1) * g x) (g := fun x => f x - g x)
      (hgi.const_mul _) (hfi.sub hgi), integral_const_mul, integral_sub hfi hgi, hfn, hgn] at hi
  simpa only [sub_self, sub_zero, mul_one] using hi

theorem scaledLaplaceDensity_l1_ordered {u v : ℝ} (hu : 1 ≤ u) (hv : 1 ≤ v) (huv : u ≤ v) :
    (∫ y, |scaledLaplaceDensity u y - scaledLaplaceDensity v y|) ≤ 2 * (v - u) := by
  have hu0 : 0 < u := by linarith
  have hv0 : 0 < v := by linarith
  have h := normalized_density_l1_domination volume (scaledLaplaceDensity u) (scaledLaplaceDensity v)
    (integrable_scaledLaplaceDensity hu0) (integrable_scaledLaplaceDensity hv0)
    (integral_scaledLaplaceDensity hu0) (integral_scaledLaplaceDensity hv0)
    (fun y => (scaledLaplaceDensity_pos hv0 y).le) (v / u) ((one_le_div hu0).mpr huv)
    (scaledLaplaceDensity_ordered hu0 hv0 huv)
  have heq : v / u - 1 = (v - u) / u := by field_simp
  rw [heq] at h
  have hdiv := div_le_self (sub_nonneg.mpr huv) hu
  linarith

theorem scaledLaplaceDensity_l1 {u v : ℝ} (hu : 1 ≤ u) (hv : 1 ≤ v) :
    (∫ y, |scaledLaplaceDensity u y - scaledLaplaceDensity v y|) ≤ 2 * |u - v| := by
  rcases le_total u v with huv | hvu
  · have h := scaledLaplaceDensity_l1_ordered hu hv huv
    rw [abs_of_nonpos (sub_nonpos.mpr huv)]
    linarith
  · have h := scaledLaplaceDensity_l1_ordered hv hu hvu
    simp_rw [abs_sub_comm (scaledLaplaceDensity v _) (scaledLaplaceDensity u _)] at h
    rw [abs_of_nonneg (sub_nonneg.mpr hvu)]
    exact h

theorem integral_scaled_laplace_test {u : ℝ} (hu : 0 < u) (F : ℝ → ℝ) :
    (∫ z, F (u * z) ∂realLaplace) = ∫ y, F y * scaledLaplaceDensity u y := by
  let g := fun y => F y * realLaplaceDensity (y / u)
  calc
    _ = ∫ z, F (u * z) * realLaplaceDensity z := by
      rw [integral_realLaplace]
      change _ = ∫ z, F (u * z) * (Real.exp (-|z|) / 2)
      simp_rw [← mul_div_assoc]
      rw [integral_div]
    _ = ∫ z, g (u * z) := by
      apply integral_congr_ae
      filter_upwards [] with z
      simp [g, hu.ne']
    _ = |u⁻¹| * ∫ y, g y := by rw [Measure.integral_comp_mul_left, smul_eq_mul]
    _ = _ := by
      rw [abs_of_pos (inv_pos.mpr hu)]
      unfold g scaledLaplaceDensity
      simp_rw [← mul_div_assoc]
      rw [integral_div]
      ring
end
end PoissonAudit
