module

public import PoissonAudit.ThresholdPotential
public import PoissonAudit.Winner

public section

open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {P : Type*} [Fintype P] [Nonempty P] [DecidableEq P]

@[expose] def groupMaximum (A : P → ℝ) (E : Finset P) (hE : E.Nonempty) : ℝ := E.sup' hE A

@[expose] def sampledGroupMaximum (A : P → ℝ) (E : Finset P) (d : ℝ) : ℝ :=
  Finset.univ.sup' Finset.univ_nonempty (fun p => A p + if p ∈ E then d else 0)

theorem sampledGroupMaximum_eq (A : P → ℝ) (E : Finset P)
    (hE : E.Nonempty) (hEc : Eᶜ.Nonempty) (d : ℝ) :
    sampledGroupMaximum A E d = max (groupMaximum A E hE + d) (groupMaximum A Eᶜ hEc) := by
  apply le_antisymm
  · apply Finset.sup'_le
    intro p _
    by_cases hp : p ∈ E
    · have h := Finset.le_sup' (s := E) (f := A) hp
      simp only [if_pos hp]
      exact le_max_of_le_left (add_le_add h le_rfl)
    · have h := Finset.le_sup' (s := Eᶜ) (f := A) (Finset.mem_compl.mpr hp)
      simp only [if_neg hp, add_zero]
      exact le_max_of_le_right h
  · apply max_le
    · obtain ⟨p, hp, heq⟩ := Finset.exists_mem_eq_sup' (s := E) hE A
      have h := Finset.le_sup' (s := Finset.univ)
        (f := fun p => A p + if p ∈ E then d else 0) (Finset.mem_univ p)
      simpa only [if_pos hp, groupMaximum, ← heq] using! h
    · obtain ⟨p, hp, heq⟩ := Finset.exists_mem_eq_sup' (s := Eᶜ) hEc A
      have h := Finset.le_sup' (s := Finset.univ)
        (f := fun p => A p + if p ∈ E then d else 0) (Finset.mem_univ p)
      simpa only [if_neg (Finset.mem_compl.mp hp), add_zero, groupMaximum, ← heq] using! h

@[expose] def groupThreshold (A : P → ℝ) (E : Finset P)
    (hE : E.Nonempty) (hEc : Eᶜ.Nonempty) (sigma : ℝ) : ℝ :=
  (groupMaximum A Eᶜ hEc - groupMaximum A E hE) / sigma

theorem sampledGroupMaximum_threshold (A : P → ℝ) (E : Finset P)
    (hE : E.Nonempty) (hEc : Eᶜ.Nonempty) (sigma z s : ℝ) (hsigma : sigma ≠ 0) :
    sampledGroupMaximum A E (sigma * z - s) =
      groupMaximum A Eᶜ hEc + max (sigma * (z - groupThreshold A E hE hEc sigma) - s) 0 := by
  rw [sampledGroupMaximum_eq A E hE hEc, add_max]
  congr 1
  · unfold groupThreshold
    field_simp
    ring
  · ring

theorem sampledGroupMaximum_increment (A : P → ℝ) (E : Finset P)
    (hE : E.Nonempty) (hEc : Eᶜ.Nonempty) (sigma z s : ℝ) (hsigma : sigma ≠ 0) :
    sampledGroupMaximum A E (sigma * z - s) - sampledGroupMaximum A E (sigma * z) =
      thresholdIncrement (groupThreshold A E hE hEc sigma) sigma z s := by
  have h0 := sampledGroupMaximum_threshold A E hE hEc sigma z 0 hsigma
  simp only [sub_zero] at h0
  rw [sampledGroupMaximum_threshold A E hE hEc sigma z s hsigma, h0]
  unfold thresholdIncrement
  ring

theorem measurable_groupMaximum {Omega : Type*} [MeasurableSpace Omega]
    (A : P → Omega → ℝ) (hA : ∀ p, Measurable (A p)) (E : Finset P) (hE : E.Nonempty) :
    Measurable (fun omega => groupMaximum (fun p => A p omega) E hE) := by
  have h := Finset.measurable_sup' hE (fun p _ => hA p)
  convert! h using 1
  funext omega
  exact (Finset.sup'_apply hE A omega).symm

variable [LinearOrder P]

theorem winner_group_iff (A : P → ℝ) (E : Finset P)
    (hE : E.Nonempty) (hEc : Eᶜ.Nonempty) (d : ℝ)
    (hne : groupMaximum A E hE + d ≠ groupMaximum A Eᶜ hEc) :
    winner (fun p => A p + if p ∈ E then d else 0) ∈ E ↔
      groupMaximum A Eᶜ hEc < groupMaximum A E hE + d := by
  let w := winner (fun p => A p + if p ∈ E then d else 0)
  have hw : sampledGroupMaximum A E d = A w + if w ∈ E then d else 0 := by
    apply le_antisymm
    · apply Finset.sup'_le
      intro p _
      simpa only [w] using! winner_maximizes (fun q => A q + if q ∈ E then d else 0) p
    · exact Finset.le_sup' (s := Finset.univ)
        (f := fun p => A p + if p ∈ E then d else 0) (Finset.mem_univ w)
  rw [sampledGroupMaximum_eq A E hE hEc] at hw
  constructor
  · intro hmem
    change w ∈ E at hmem
    rw [if_pos hmem] at hw
    have hA : A w ≤ groupMaximum A E hE := Finset.le_sup' (s := E) (f := A) hmem
    have hV := le_max_right (groupMaximum A E hE + d) (groupMaximum A Eᶜ hEc)
    rw [hw] at hV
    exact lt_of_le_of_ne (by linarith) (Ne.symm hne)
  · intro hpos
    change w ∈ E
    by_contra hmem
    rw [if_neg hmem, add_zero] at hw
    have hA : A w ≤ groupMaximum A Eᶜ hEc := Finset.le_sup' (s := Eᶜ) (f := A) (Finset.mem_compl.mpr hmem)
    have hU := le_max_left (groupMaximum A E hE + d) (groupMaximum A Eᶜ hEc)
    rw [hw] at hU
    linarith

theorem winner_group_threshold (A : P → ℝ) (E : Finset P)
    (hE : E.Nonempty) (hEc : Eᶜ.Nonempty) (sigma z s : ℝ) (hsigma : 0 < sigma)
    (hz : z ≠ groupThreshold A E hE hEc sigma + s / sigma) :
    winner (fun p => A p + if p ∈ E then sigma * z - s else 0) ∈ E ↔
      groupThreshold A E hE hEc sigma + s / sigma < z := by
  let U := groupMaximum A E hE
  let V := groupMaximum A Eᶜ hEc
  let t := groupThreshold A E hE hEc sigma
  have heq : sigma * (z - t) - s = U + (sigma * z - s) - V := by
    unfold t groupThreshold U V
    field_simp
    ring
  have hne : U + (sigma * z - s) ≠ V := by
    intro hh
    have hzero : sigma * (z - t) - s = 0 := by rw [heq]; linarith
    have hd : z - t = s / sigma := (eq_div_iff hsigma.ne').mpr (by nlinarith)
    exact hz (by change z = t + s / sigma; linarith)
  rw [winner_group_iff A E hE hEc _ hne, ← threshold_positive_iff t sigma z s hsigma, heq]
  change V < U + (sigma * z - s) ↔ 0 < U + (sigma * z - s) - V
  constructor <;> intro h <;> linarith

end

end PoissonAudit
