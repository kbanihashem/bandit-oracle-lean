module
public import PoissonAudit.NativeEmpiricalRule
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section

theorem finite_probability_l1_le_two {A : Type*} [Fintype A] (q r : A → ℝ)
    (hq : ∀ a, 0 ≤ q a) (hr : ∀ a, 0 ≤ r a) (hqs : ∑ a, q a = 1) (hrs : ∑ a, r a = 1) :
    (∑ a, |q a - r a|) ≤ 2 := by
  have h := Finset.sum_le_sum (s := Finset.univ) (fun a _ =>
    show |q a - r a| ≤ q a + r a from abs_le.mpr ⟨by linarith [hq a], by linarith [hr a]⟩)
  rw [Finset.sum_add_distrib, hqs, hrs] at h
  norm_num at h ⊢
  exact h

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem nativeBanditProbability_nonneg (r : NNReal) (D : Measure X) (predict : P → X → Fin K)
    (sigma : X × Fin K → ℝ) (S : P → ℝ) (gamma : ℝ) (hg0 : 0 ≤ gamma) (hg1 : gamma ≤ 1) (x : X) (a : Fin K) :
    0 ≤ nativeBanditProbability r D predict sigma S gamma x a :=
  add_nonneg (mul_nonneg (sub_nonneg.mpr hg1) (experimentProbability_nonneg r D predict sigma S x a))
    (div_nonneg hg0 (Nat.cast_nonneg _))

theorem nativeBanditProbability_le_one (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (gamma : ℝ)
    (hK : 0 < K) (hg0 : 0 ≤ gamma) (hg1 : gamma ≤ 1) (x : X) (a : Fin K) :
    nativeBanditProbability r D predict sigma S gamma x a ≤ 1 := by
  rw [← nativeBanditProbability_sum r D predict sigma S gamma hK x]
  exact Finset.single_le_sum (fun b _ => nativeBanditProbability_nonneg r D predict sigma S gamma hg0 hg1 x b) (Finset.mem_univ a)

theorem empiricalMixture_reference_error {K : ℕ} (p ref : Fin K → ℝ) (hp : ∀ a, 0 ≤ p a)
    (hsum : ∑ a, p a = 1) (gamma : ℝ) (hg0 : 0 ≤ gamma) (hg1 : gamma ≤ 1) (m : ℕ) (hm : 0 < m) :
    (∫ u, ∑ a, |empiricalMixture K gamma m u a - ref a| ∂iidPool (actionPMF p hp hsum).toMeasure m) ≤
      K * Real.sqrt (1 / m) + ∑ a, |explorationProbability K gamma (p a) - ref a| := by
  let mu := iidPool (actionPMF p hp hsum).toMeasure m
  have hfirst := integral_mono (μ := mu)
    (f := fun u => ∑ a, |empiricalMixture K gamma m u a - explorationProbability K gamma (p a)|)
    (g := fun u => ∑ a, |empiricalFrequency m a u - p a|) Integrable.of_finite Integrable.of_finite
    (fun u => empiricalMixture_l1_contract gamma hg0 hg1 m u p)
  have he := empiricalFrequency_l1_error p hp hsum m hm
  simp only [Fintype.card_fin] at he
  have hb := hfirst.trans he
  have hpoint (u : Fin m → Fin K) : (∑ a, |empiricalMixture K gamma m u a - ref a|) ≤
      (∑ a, |empiricalMixture K gamma m u a - explorationProbability K gamma (p a)|) +
        ∑ a, |explorationProbability K gamma (p a) - ref a| := by
    rw [← Finset.sum_add_distrib]
    exact Finset.sum_le_sum fun a _ => abs_sub_le _ _ _
  have h := integral_mono (μ := mu) Integrable.of_finite Integrable.of_finite hpoint
  rw [integral_add Integrable.of_finite (integrable_const _), integral_const, probReal_univ, one_smul] at h
  linarith
end
end PoissonAudit
