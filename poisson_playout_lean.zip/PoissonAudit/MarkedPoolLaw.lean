module

public import PoissonAudit.MarkedPoisson
public import Mathlib.Probability.ProductMeasure

public section

open MeasureTheory ProbabilityTheory
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {U : Type*} [MeasurableSpace U]

@[expose] def markSequence (mu : Measure U) : Measure (ℕ → U) :=
  Measure.infinitePi (fun _ : ℕ => mu)

instance markSequence_isProbability (mu : Measure U) [IsProbabilityMeasure mu] :
    IsProbabilityMeasure (markSequence mu) := by unfold markSequence; infer_instance

@[expose] def markedPoolLaw (r : NNReal) (mu : Measure U) : Measure (ℕ × (ℕ → U)) :=
  (poissonMeasure r).prod (markSequence mu)

instance markedPoolLaw_isProbability (r : NNReal) (mu : Measure U) [IsProbabilityMeasure mu] :
    IsProbabilityMeasure (markedPoolLaw r mu) := by unfold markedPoolLaw; infer_instance

@[expose] def poolPrefix (m : ℕ) (u : ℕ → U) : Fin m → U := fun i => u i

theorem measurable_poolPrefix (m : ℕ) : Measurable (@poolPrefix U m) := by
  change Measurable (fun u : ℕ → U => fun i : Fin m => u i)
  exact Measurable.of_eval fun i => measurable_pi_apply (i : ℕ)

theorem poolPrefix_measurePreserving (mu : Measure U) [IsProbabilityMeasure mu] (m : ℕ) :
    MeasurePreserving (poolPrefix m) (markSequence mu) (iidPool mu m) := by
  let e : (Finset.range m) ≃ Fin m :=
    { toFun := fun i => ⟨i, Finset.mem_range.mp i.property⟩
      invFun := fun i => ⟨i, Finset.mem_range.mpr i.isLt⟩
      left_inv := by intro i; rfl
      right_inv := by intro i; rfl }
  have hrestrict : MeasurePreserving ((Finset.range m).restrict : (ℕ → U) → (Finset.range m → U))
      (markSequence mu) (Measure.pi fun _ : Finset.range m => mu) :=
    ⟨(by exact Measurable.of_eval fun i => measurable_pi_apply (i : ℕ)),
      Measure.infinitePi_map_restrict (fun _ : ℕ => mu)⟩
  have hreindex := measurePreserving_piCongrLeft (fun _ : Fin m => mu) e
  convert hreindex.comp hrestrict using 1
  · funext u i; rfl
  · rfl

theorem integral_poisson_count (r : NNReal) :
    (∫ m : ℕ, (m : ℝ) ∂poissonMeasure r) = r := by
  have h := poisson_integral_insertion r (fun _ => (1 : ℝ)) (integrable_const _)
  simpa only [mul_one, integral_const, probReal_univ, smul_eq_mul, one_mul] using h

theorem integrable_poisson_count (r : NNReal) :
    Integrable (fun m : ℕ => (m : ℝ)) (poissonMeasure r) := by
  by_cases hr : r = 0
  · subst r
    rw [integrable_poissonMeasure_iff]
    convert (summable_zero : Summable (fun _ : ℕ => (0 : ℝ))) using 1
    funext n
    cases n <;> simp
  · apply Integrable.of_integral_ne_zero
    rw [integral_poisson_count]
    exact_mod_cast hr

end

end PoissonAudit
