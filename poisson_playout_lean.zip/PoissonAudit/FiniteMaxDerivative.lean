module

public import PoissonAudit.FiniteMaxIntegral
public import Mathlib.Analysis.Calculus.ParametricIntegral

public section

open MeasureTheory Set Filter
open scoped BigOperators Topology

namespace PoissonAudit

noncomputable section

variable {P : Type*} [Fintype P] [Nonempty P]

@[expose] def lineMax (A B : P → ℝ) (t : ℝ) : ℝ :=
  Finset.univ.sup' Finset.univ_nonempty (fun p => A p + t * B p)

theorem lineMax_eq_w_near (A B : P → ℝ) (w : P)
    (hw : ∀ p, A p ≤ A w) (hties : ∀ p, A p = A w → B p = B w) :
    (fun t => lineMax A B t) =ᶠ[𝓝 0] fun t => A w + t * B w := by
  classical
  have hp : ∀ p, ∀ᶠ t : ℝ in 𝓝 0, A p + t * B p ≤ A w + t * B w := by
    intro p
    by_cases h : A p = A w
    · exact Filter.Eventually.of_forall fun t => by rw [h, hties p h]
    · have hlt : A p < A w := lt_of_le_of_ne (hw p) h
      have hc1 : ContinuousAt (fun t : ℝ => A p + t * B p) 0 := by fun_prop
      have hc2 : ContinuousAt (fun t : ℝ => A w + t * B w) 0 := by fun_prop
      have hh := hc1.eventually_lt hc2 (by simpa only [zero_mul, add_zero] using hlt)
      exact hh.mono fun _ h => h.le
  have hall : ∀ᶠ t : ℝ in 𝓝 0, ∀ p, A p + t * B p ≤ A w + t * B w :=
    Filter.eventually_all.mpr hp
  filter_upwards [hall] with t ht
  apply le_antisymm
  · exact Finset.sup'_le _ _ fun p _ => ht p
  · exact Finset.le_sup' (s := Finset.univ) (f := fun p => A p + t * B p) (Finset.mem_univ w)

theorem hasDerivAt_lineMax (A B : P → ℝ) (w : P)
    (hw : ∀ p, A p ≤ A w) (hties : ∀ p, A p = A w → B p = B w) :
    HasDerivAt (lineMax A B) (B w) 0 := by
  have hd : HasDerivAt (fun t : ℝ => A w + t * B w) (B w) 0 := by
    convert! (hasDerivAt_const 0 (A w)).add ((hasDerivAt_id 0).mul_const (B w)) using 1 <;> simp
  exact hd.congr_of_eventuallyEq (lineMax_eq_w_near A B w hw hties)

theorem lineMax_sub_le (A B : P → ℝ) (t u : ℝ) :
    lineMax A B t - lineMax A B u ≤ (∑ p, |B p|) * |t - u| := by
  classical
  obtain ⟨p, _, hp⟩ := Finset.exists_mem_eq_sup' (s := Finset.univ) Finset.univ_nonempty
    (fun p => A p + t * B p)
  have hpu := Finset.le_sup' (s := Finset.univ) (f := fun p => A p + u * B p) (Finset.mem_univ p)
  have hB : |B p| ≤ ∑ q, |B q| :=
    Finset.single_le_sum (f := fun q : P => |B q|) (fun _ _ => abs_nonneg _) (Finset.mem_univ p)
  have hmul : (t - u) * B p ≤ (∑ p, |B p|) * |t - u| := by
    calc
      _ ≤ |(t - u) * B p| := le_abs_self _
      _ = |B p| * |t - u| := by rw [abs_mul, mul_comm]
      _ ≤ _ := mul_le_mul_of_nonneg_right hB (abs_nonneg _)
  change _ ≤ lineMax A B u at hpu
  change (Finset.univ.sup' _ _) - _ ≤ _
  rw [hp]
  nlinarith

theorem lineMax_abs_sub_le (A B : P → ℝ) (t u : ℝ) :
    |lineMax A B t - lineMax A B u| ≤ (∑ p, |B p|) * |t - u| := by
  rw [abs_le]
  constructor
  · have h := lineMax_sub_le A B u t
    rw [abs_sub_comm u t] at h
    linarith
  · exact lineMax_sub_le A B t u

theorem lineMax_lipschitz (A B : P → ℝ) :
    LipschitzWith (Real.nnabs (∑ p, |B p|)) (lineMax A B) := by
  apply LipschitzWith.of_dist_le_mul
  intro t u
  have hC : 0 ≤ ∑ p, |B p| := Finset.sum_nonneg fun _ _ => abs_nonneg _
  simpa only [Real.dist_eq, Real.coe_nnabs, abs_of_nonneg hC]
    using lineMax_abs_sub_le A B t u

end

end PoissonAudit
