module

public import Mathlib.Analysis.SpecialFunctions.Exponential
public import Mathlib.Tactic

public section

open scoped BigOperators

namespace PoissonAudit

theorem exp_series_tail (x : ℝ) :
    (∑' n : ℕ, x ^ (n + 2) / ((n + 2).factorial : ℝ)) = Real.exp x - 1 - x := by
  have hs := (NormedSpace.expSeries_div_hasSum_exp x).summable
  have he := hs.sum_add_tsum_nat_add 2
  rw [(NormedSpace.expSeries_div_hasSum_exp x).tsum_eq,
    ← Real.exp_eq_exp_ℝ] at he
  norm_num [Finset.sum_range_succ] at he
  linarith

theorem exp_quadratic_remainder {x : ℝ} (hx0 : 0 ≤ x) (hx1 : x ≤ 1) :
    Real.exp x - 1 - x ≤ (Real.exp 1 - 2) * x ^ 2 := by
  have hsx : Summable (fun n : ℕ => x ^ (n + 2) / ((n + 2).factorial : ℝ)) :=
    (summable_nat_add_iff 2).2 (NormedSpace.expSeries_div_summable x)
  have hs1 : Summable (fun n : ℕ =>
      (1 : ℝ) ^ (n + 2) / ((n + 2).factorial : ℝ)) :=
    (summable_nat_add_iff 2).2 (NormedSpace.expSeries_div_summable (1 : ℝ))
  have hp : ∀ n : ℕ,
      x ^ (n + 2) / ((n + 2).factorial : ℝ) ≤
        x ^ 2 * ((1 : ℝ) ^ (n + 2) / ((n + 2).factorial : ℝ)) := by
    intro n
    have hn : x ^ n ≤ 1 := pow_le_one₀ hx0 hx1
    have hmul := mul_le_mul_of_nonneg_right hn (sq_nonneg x)
    have hfact : 0 ≤ ((n + 2).factorial : ℝ) := by positivity
    calc
      _ = (x ^ n * x ^ 2) / ((n + 2).factorial : ℝ) := by rw [pow_add]
      _ ≤ (1 * x ^ 2) / ((n + 2).factorial : ℝ) := div_le_div_of_nonneg_right hmul hfact
      _ = _ := by simp [div_eq_mul_inv]
  have hsum := hsx.tsum_le_tsum hp (hs1.mul_left (x ^ 2))
  rw [tsum_mul_left, exp_series_tail x, exp_series_tail 1] at hsum
  nlinarith only [hsum]

end PoissonAudit
