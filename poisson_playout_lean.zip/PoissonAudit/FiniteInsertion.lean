module

public import PoissonAudit.PoissonOptimality

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}

@[expose] def markValue (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (p : P) (u : X × (Fin K → ℝ)) : ℝ :=
  sigma (u.1, predict p u.1) * u.2 (predict p u.1)

theorem measurable_markValue (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (p : P) :
    Measurable (markValue predict sigma p) := by
  have heq : markValue predict sigma p = fun u => ∑ j, sigma j * singleMarkCoefficient predict p j u := by
    funext u
    exact (singleMark_expansion predict p sigma u).symm
  rw [heq]
  apply Finset.measurable_sum
  intro j _
  exact measurable_const.mul (measurable_singleMarkCoefficient predict p j)

@[expose] def finitePoolScore (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) {m : ℕ} (u : Fin m → X × (Fin K → ℝ)) (p : P) : ℝ :=
  S p + ∑ i, markValue predict sigma p (u i)

@[expose] def insertedPoolScore (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) {m : ℕ} (v : (X × (Fin K → ℝ)) × (Fin m → X × (Fin K → ℝ))) (p : P) : ℝ :=
  S p + markValue predict sigma p v.1 + ∑ i, markValue predict sigma p (v.2 i)

theorem measurable_finitePoolScore (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (m : ℕ) (p : P) :
    Measurable (fun u : Fin m → X × (Fin K → ℝ) => finitePoolScore predict sigma S u p) := by
  apply measurable_const.add
  apply Finset.measurable_sum
  intro i _
  exact (measurable_markValue predict sigma p).comp (measurable_pi_apply i)

theorem measurable_insertedPoolScore (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (m : ℕ) (p : P) :
    Measurable (fun v : (X × (Fin K → ℝ)) × (Fin m → X × (Fin K → ℝ)) => insertedPoolScore predict sigma S v p) := by
  apply Measurable.add
  · exact measurable_const.add ((measurable_markValue predict sigma p).comp measurable_fst)
  · apply Finset.measurable_sum
    intro i _
    exact (measurable_markValue predict sigma p).comp ((measurable_pi_apply i).comp measurable_snd)

variable [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def finiteMarkWinner (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) {m : ℕ} (u : Fin m → X × (Fin K → ℝ)) : P :=
  winner (finitePoolScore predict sigma S u)

@[expose] def insertedMarkWinner (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) {m : ℕ} (v : (X × (Fin K → ℝ)) × (Fin m → X × (Fin K → ℝ))) : P :=
  winner (insertedPoolScore predict sigma S v)

theorem measurable_finiteMarkWinner (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (m : ℕ) : Measurable (fun u : Fin m → X × (Fin K → ℝ) => finiteMarkWinner predict sigma S u) :=
  measurable_winner (fun p u => finitePoolScore predict sigma S u p)
    (measurable_finitePoolScore predict sigma S m)

theorem measurable_insertedMarkWinner (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (m : ℕ) : Measurable (fun v : (X × (Fin K → ℝ)) × (Fin m → X × (Fin K → ℝ)) => insertedMarkWinner predict sigma S v) :=
  measurable_winner (fun p v => insertedPoolScore predict sigma S v p)
    (measurable_insertedPoolScore predict sigma S m)

theorem insertedMarkWinner_delete (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) {n : ℕ} (u : Fin (n + 1) → X × (Fin K → ℝ)) (i : Fin (n + 1)) :
    insertedMarkWinner predict sigma S (splitMark i u) = finiteMarkWinner predict sigma S u := by
  have heq : insertedPoolScore predict sigma S (splitMark i u) = finitePoolScore predict sigma S u := by
    funext p
    change S p + markValue predict sigma p (u i) + (∑ j : Fin n, markValue predict sigma p (u (i.succAbove j))) =
      S p + ∑ j : Fin (n + 1), markValue predict sigma p (u j)
    rw [Fin.sum_univ_succAbove (fun j => markValue predict sigma p (u j)) i]
    ring
  exact congrArg winner heq

@[expose] def insertedContribution (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (j : X × Fin K) (n : ℕ)
    (v : (X × (Fin K → ℝ)) × (Fin n → X × (Fin K → ℝ))) : ℝ :=
  singleMarkCoefficient predict (insertedMarkWinner predict sigma S v) j v.1

@[expose] def finitePoolGradient (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (j : X × Fin K) {n : ℕ} (u : Fin n → X × (Fin K → ℝ)) : ℝ :=
  ∑ i, singleMarkCoefficient predict (finiteMarkWinner predict sigma S u) j (u i)

theorem deletion_insertedContribution (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (j : X × Fin K) (n : ℕ) (u : Fin (n + 1) → X × (Fin K → ℝ)) :
    deletionSum (insertedContribution predict sigma S j) (n + 1) u = finitePoolGradient predict sigma S j u := by
  apply Finset.sum_congr rfl
  intro i _
  change singleMarkCoefficient predict (insertedMarkWinner predict sigma S (splitMark i u)) j (u i) = _
  rw [insertedMarkWinner_delete]

theorem poissonScore_eq_finitePoolScore (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (pool : ℕ × (ℕ → X × (Fin K → ℝ))) (p : P) :
    poissonScore predict sigma S pool p = finitePoolScore predict sigma S (poolPrefix pool.1 pool.2) p := by
  unfold poissonScore
  rw [poissonCoefficient_expansion]
  rfl

theorem poissonWinner_eq_finiteMarkWinner (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (pool : ℕ × (ℕ → X × (Fin K → ℝ))) :
    poissonWinner predict sigma S pool = finiteMarkWinner predict sigma S (poolPrefix pool.1 pool.2) := by
  apply congrArg winner
  funext p
  exact poissonScore_eq_finitePoolScore predict sigma S pool p

theorem poissonCoefficient_winner_eq_finiteGradient (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (j : X × Fin K) (pool : ℕ × (ℕ → X × (Fin K → ℝ))) :
    poissonCoefficient predict pool (poissonWinner predict sigma S pool) j =
      finitePoolGradient predict sigma S j (poolPrefix pool.1 pool.2) := by
  rw [poissonWinner_eq_finiteMarkWinner]
  rfl

end

end PoissonAudit
