module

public import PoissonAudit.InsertedCorrelations
public import PoissonAudit.EventTail
public import PoissonAudit.WinnerInformation

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}

@[expose] def insertedExperimentLaw (r : NNReal) (D : Measure X) (K : ℕ) :
    Measure ((Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ)))) :=
  (laplaceMeasure K).prod (markedPoolLaw r (contextLaplaceLaw D K))

instance insertedExperimentLaw_isProbability (r : NNReal) (D : Measure X) [IsProbabilityMeasure D] :
    IsProbabilityMeasure (insertedExperimentLaw r D K) := by unfold insertedExperimentLaw; infer_instance

@[expose] def experimentScore (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (v : (Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ)))) (p : P) : ℝ :=
  S p + markValue predict sigma p (x, v.1) + ∑ j, sigma j * poissonCoefficient predict v.2 p j

theorem measurable_experimentScore (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (p : P) : Measurable (fun v => experimentScore predict sigma S x v p) :=
  (measurable_const.add ((measurable_markValue predict sigma p).comp
    (measurable_const.prodMk measurable_fst))).add
      ((measurable_poisson_linear_score predict sigma p).comp measurable_snd)

variable [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def experimentWinner (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (v : (Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ)))) : P :=
  winner (experimentScore predict sigma S x v)

theorem measurable_experimentWinner (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) : Measurable (experimentWinner predict sigma S x) :=
  measurable_winner (fun p v => experimentScore predict sigma S x v p)
    (measurable_experimentScore predict sigma S x)

@[expose] def experimentAction (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (v : (Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ)))) : Fin K :=
  predict (experimentWinner predict sigma S x v) x

theorem measurable_experimentAction (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) : Measurable (experimentAction predict sigma S x) :=
  (measurable_of_finite (fun p => predict p x)).comp (measurable_experimentWinner predict sigma S x)

@[expose] def experimentActionEvent (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (a : Fin K) : Set ((Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ)))) :=
  outcomeEvent (experimentAction predict sigma S x) a

theorem measurable_experimentActionEvent (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (a : Fin K) : MeasurableSet (experimentActionEvent predict sigma S x a) :=
  (measurable_experimentAction predict sigma S x) (measurableSet_singleton a)

@[expose] def experimentProbability (r : NNReal) (D : Measure X)
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) : ℝ :=
  outcomeMass (insertedExperimentLaw r D K) (experimentAction predict sigma S x) a

theorem experimentProbability_nonneg (r : NNReal) (D : Measure X)
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) :
    0 ≤ experimentProbability r D predict sigma S x a := ENNReal.toReal_nonneg

theorem experimentProbability_le_one (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) :
    experimentProbability r D predict sigma S x a ≤ 1 :=
  outcomeMass_le_one _ _ _

theorem sum_experimentProbability (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) :
    (∑ a, experimentProbability r D predict sigma S x a) = 1 :=
  sum_outcomeMass _ _ (measurable_experimentAction predict sigma S x)

@[expose] def experimentAlpha (r : NNReal) (D : Measure X)
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) : ℝ :=
  ∫ v, (experimentActionEvent predict sigma S x a).indicator (fun _ => (1 : ℝ)) v * v.1 a
    ∂insertedExperimentLaw r D K

theorem integrable_experiment_correlation (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) :
    Integrable (fun v => (experimentActionEvent predict sigma S x a).indicator (fun _ => (1 : ℝ)) v * v.1 a)
      (insertedExperimentLaw r D K) := by
  classical
  have hz : Integrable (fun v : (Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ))) => v.1 a)
      (insertedExperimentLaw r D K) := by
    change Integrable _ ((laplaceMeasure K).prod (markedPoolLaw r (contextLaplaceLaw D K)))
    simpa only [mul_one] using (integrable_laplace_coordinate K a).mul_prod
      (integrable_const (1 : ℝ) (μ := markedPoolLaw r (contextLaplaceLaw D K)))
  convert! hz.indicator (measurable_experimentActionEvent predict sigma S x a) using 1
  funext v
  by_cases h : v ∈ experimentActionEvent predict sigma S x a <;> simp [h]

theorem experimentWinner_eq_insertedMarkWinner (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (x : X) (v : (Fin K → ℝ) × (ℕ × (ℕ → X × (Fin K → ℝ)))) :
    experimentWinner predict sigma S x v =
      insertedMarkWinner predict sigma S ((x, v.1), poolPrefix v.2.1 v.2.2) := by
  apply congrArg winner
  funext p
  unfold experimentScore insertedPoolScore
  rw [poissonCoefficient_expansion]
  rfl

end

end PoissonAudit
