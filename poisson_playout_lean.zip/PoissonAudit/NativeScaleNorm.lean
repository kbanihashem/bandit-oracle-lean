module
public import PoissonAudit.NativeScaleStability
public import PoissonAudit.NativeSGDAccuracy
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem integral_scaleActionDifference_eq (D : Measure X) [IsProbabilityMeasure D]
    (sigma tau : X × Fin K → ℝ) :
    (∫ x, scaleActionDifference sigma tau x ∂D) =
      ∑ j : X × Fin K, (D {j.1}).toReal * |sigma j - tau j| := by
  rw [integral_fintype Integrable.of_finite]
  simp only [Measure.real, smul_eq_mul, scaleActionDifference, Fintype.sum_prod_type, Finset.mul_sum]

theorem integral_scaleActionDifference_square (D : Measure X) [IsProbabilityMeasure D]
    (sigma tau : X × Fin K → ℝ) :
    (∫ x, scaleActionDifference sigma tau x ∂D) ^ 2 ≤
      K * weightedSquareDistance (fun j => (D {j.1}).toReal) sigma tau := by
  let w : X × Fin K → ℝ := fun j => (D {j.1}).toReal
  have hmul (j : X × Fin K) : Real.sqrt (w j) * (Real.sqrt (w j) * |sigma j - tau j|) = w j * |sigma j - tau j| := by
    rw [← mul_assoc, ← pow_two, Real.sq_sqrt ENNReal.toReal_nonneg]
  have hf (j : X × Fin K) : (Real.sqrt (w j)) ^ 2 = w j := Real.sq_sqrt ENNReal.toReal_nonneg
  have hg (j : X × Fin K) : (Real.sqrt (w j) * |sigma j - tau j|) ^ 2 = w j * (sigma j - tau j) ^ 2 := by
    rw [mul_pow, hf j, sq_abs]
  have h := Finset.sum_mul_sq_le_sq_mul_sq Finset.univ (fun j : X × Fin K => Real.sqrt (w j))
    (fun j => Real.sqrt (w j) * |sigma j - tau j|)
  simp only [hmul, hf, hg] at h
  rw [context_action_mass_sum D, ← integral_scaleActionDifference_eq D sigma tau] at h
  exact h

@[expose] def nativeMeanActionError (r : NNReal) (D : Measure X) (predict : P → X → Fin K)
    (S : P → ℝ) (sigma tau : X × Fin K → ℝ) : ℝ :=
  ∫ x, ∑ a, |experimentProbability r D predict sigma S x a - experimentProbability r D predict tau S x a| ∂D

theorem native_action_error_young (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (sigma tau : X × Fin K → ℝ)
    (hsigma : ∀ j, 1 ≤ sigma j) (htau : ∀ j, 1 ≤ tau j) (delta : ℝ) (hd : 0 < delta) :
    nativeMeanActionError r D predict S sigma tau ≤
      delta / 4 + (4 * ((r : ℝ) + 1) ^ 2 * K / delta) * weightedSquareDistance (fun j => (D {j.1}).toReal) sigma tau := by
  let L := ∫ x, scaleActionDifference sigma tau x ∂D
  let V := weightedSquareDistance (fun j => (D {j.1}).toReal) sigma tau
  let c : ℝ := r + 1
  have hs := native_mean_scale_stability r D predict sigma tau S hsigma htau
  have hcs := integral_scaleActionDifference_square D sigma tau
  change L ^ 2 ≤ K * V at hcs
  change nativeMeanActionError r D predict S sigma tau ≤ 2 * c * L at hs
  have h4 := mul_le_mul_of_nonneg_left hcs (show 0 ≤ 4 * c ^ 2 from mul_nonneg (by norm_num) (sq_nonneg c))
  have hy : delta * (2 * c * L) ≤ delta ^ 2 / 4 + 4 * c ^ 2 * K * V := by
    nlinarith [sq_nonneg (2 * c * L - delta / 2)]
  have heq : delta * (delta / 4 + (4 * c ^ 2 * K / delta) * V) = delta ^ 2 / 4 + 4 * c ^ 2 * K * V := by field_simp <;> ring
  have hb : 2 * c * L ≤ delta / 4 + (4 * c ^ 2 * K / delta) * V := by
    apply (mul_le_mul_iff_left₀ hd).mp
    nlinarith only [heq, hy]
  exact hs.trans hb
end
end PoissonAudit
