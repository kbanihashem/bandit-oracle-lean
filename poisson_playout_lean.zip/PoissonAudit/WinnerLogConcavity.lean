module

public import PoissonAudit.PrekopaMidpoint
public import PoissonAudit.LaplaceLaw
public import PoissonAudit.WinnerChannel

public section

open MeasureTheory

namespace PoissonAudit

noncomputable section

@[expose] def MidpointLogConcave {E : Type*} [AddCommGroup E] [Module ℝ E]
    (f : E → ℝ) : Prop :=
  (∀ x, 0 ≤ f x) ∧ ∀ x y,
    Real.sqrt (f x) * Real.sqrt (f y) ≤ f ((1 / 2 : ℝ) • (x + y))

theorem midpointLogConcave_scale {E : Type*} [AddCommGroup E] [Module ℝ E]
    {f : E → ℝ} (hf : MidpointLogConcave f) {c : ℝ} (hc : 0 ≤ c) :
    MidpointLogConcave (fun x => c * f x) := by
  refine ⟨fun x => mul_nonneg hc (hf.1 x), ?_⟩
  intro x y
  rw [Real.sqrt_mul hc, Real.sqrt_mul hc]
  have h := mul_le_mul_of_nonneg_left (hf.2 x y) hc
  calc
    _ = (Real.sqrt c) ^ 2 * (Real.sqrt (f x) * Real.sqrt (f y)) := by ring
    _ = c * (Real.sqrt (f x) * Real.sqrt (f y)) := by rw [Real.sq_sqrt hc]
    _ ≤ _ := h

theorem midpointLogConcave_laplaceDensity (K : ℕ) : MidpointLogConcave (@laplaceDensity K) := by
  have hk : MidpointLogConcave (@laplaceKernel K) :=
    ⟨fun x => (laplaceKernel_pos x).le, laplaceKernel_midpoint⟩
  have h := midpointLogConcave_scale hk (c := (2 ^ K : ℝ)⁻¹) (by positivity)
  have heq : (@laplaceDensity K) = (fun x => (2 ^ K : ℝ)⁻¹ * laplaceKernel x) := by
    funext x
    unfold laplaceDensity
    ring
  rw [heq]
  exact h

theorem midpointLogConcave_marginal {K d : ℕ}
    (f : (Fin K → ℝ) × (Fin (d + 1) → ℝ) → ℝ)
    (hf : Measurable f) (hlc : MidpointLogConcave f)
    (hfi : ∀ z, Integrable (fun y => f (z, y))) :
    MidpointLogConcave (fun z => ∫ y, f (z, y)) := by
  refine ⟨fun z => integral_nonneg (fun y => hlc.1 (z, y)), ?_⟩
  intro x z
  apply prekopa_leindler_midpoint
    (fun y => f (x, y)) (fun y => f (z, y))
    (fun y => f ((1 / 2 : ℝ) • (x + z), y))
    (hf.comp (measurable_const.prodMk measurable_id))
    (hf.comp (measurable_const.prodMk measurable_id))
    (hf.comp (measurable_const.prodMk measurable_id))
    (fun y => hlc.1 _) (fun y => hlc.1 _) (fun y => hlc.1 _)
    (hfi x) (hfi z) (hfi _)
  intro y w
  simpa only [Prod.mk_add_mk, Prod.smul_mk] using hlc.2 (x, y) (z, w)

variable {P : Type*} [Fintype P] [Nonempty P] [LinearOrder P]

@[expose] def winnerDensity {K m : ℕ}
    (score : P → (Fin K → ℝ) × (Fin m → ℝ) → ℝ) (p : P)
    (v : (Fin K → ℝ) × (Fin m → ℝ)) : ℝ :=
  winningIndicator score p v * laplaceDensity v.2

omit [Nonempty P] in
theorem measurable_winnerDensity {K m : ℕ}
    (score : P → (Fin K → ℝ) × (Fin m → ℝ) → ℝ)
    (hs : ∀ p, Measurable (score p)) (p : P) : Measurable (winnerDensity score p) :=
  (measurable_winningIndicator score hs p).mul ((measurable_laplaceDensity m).comp measurable_snd)

omit [Nonempty P] in
theorem integrable_winnerDensity_section {K m : ℕ}
    (score : P → (Fin K → ℝ) × (Fin m → ℝ) → ℝ)
    (hs : ∀ p, Measurable (score p)) (p : P) (z : Fin K → ℝ) :
    Integrable (fun y => winnerDensity score p (z, y)) := by
  apply (integrable_laplaceDensity m).bdd_mul
  · exact ((measurable_winningIndicator score hs p).comp
      (measurable_const.prodMk measurable_id)).aestronglyMeasurable
  · filter_upwards [] with y
    rw [Real.norm_eq_abs, abs_of_nonneg (winningIndicator_mem_Icc score p (z, y)).1]
    exact (winningIndicator_mem_Icc score p (z, y)).2

omit [Fintype P] [Nonempty P] in
theorem midpointLogConcave_winnerDensity {K m : ℕ}
    (score : P → (Fin K → ℝ) × (Fin m → ℝ) → ℝ)
    (haffine : ∀ p x y a b, a + b = 1 →
      score p (a • x + b • y) = a * score p x + b * score p y) (p : P) :
    MidpointLogConcave (winnerDensity score p) := by
  classical
  refine ⟨fun v => mul_nonneg (winningIndicator_mem_Icc score p v).1 (laplaceDensity_pos _).le, ?_⟩
  intro x y
  by_cases hx : IsWinner (fun q => score q x) p
  · by_cases hy : IsWinner (fun q => score q y) p
    · have hm : IsWinner (fun q => score q ((1 / 2 : ℝ) • (x + y))) p := by
        have hc := convex_winner_region score haffine p
        have h := hc hx hy (by norm_num : 0 ≤ (1 / 2 : ℝ))
          (by norm_num : 0 ≤ (1 / 2 : ℝ)) (by norm_num : (1 / 2 : ℝ) + 1 / 2 = 1)
        change IsWinner (fun q => score q ((1 / 2 : ℝ) • x + (1 / 2 : ℝ) • y)) p at h
        simpa only [smul_add] using h
      simp only [winnerDensity, winningIndicator, hx, hy, hm, ite_true, one_mul]
      exact (midpointLogConcave_laplaceDensity m).2 x.2 y.2
    · simp only [winnerDensity, winningIndicator, hy, ite_false, zero_mul, Real.sqrt_zero,
        mul_zero]
      exact mul_nonneg (winningIndicator_mem_Icc score p _).1 (laplaceDensity_pos _).le
  · simp only [winnerDensity, winningIndicator, hx, ite_false, zero_mul, Real.sqrt_zero,
      zero_mul]
    exact mul_nonneg (winningIndicator_mem_Icc score p _).1 (laplaceDensity_pos _).le

omit [Nonempty P] in

theorem conditional_winner_midpointLogConcave {K d : ℕ}
    (score : P → (Fin K → ℝ) × (Fin (d + 1) → ℝ) → ℝ)
    (hs : ∀ p, Measurable (score p))
    (haffine : ∀ p x y a b, a + b = 1 →
      score p (a • x + b • y) = a * score p x + b * score p y) (p : P) :
    MidpointLogConcave (winnerChannel (laplaceMeasure (d + 1)) score p) := by
  have h := midpointLogConcave_marginal (winnerDensity score p)
    (measurable_winnerDensity score hs p) (midpointLogConcave_winnerDensity score haffine p)
    (integrable_winnerDensity_section score hs p)
  have heq : winnerChannel (laplaceMeasure (d + 1)) score p =
      (fun z => ∫ y, winnerDensity score p (z, y)) := by
    funext z
    exact integral_laplaceMeasure (fun y => winningIndicator score p (z, y))
  rwa [heq]

omit [Nonempty P] in
theorem conditional_winner_midpointLogConcave_all {K m : ℕ}
    (score : P → (Fin K → ℝ) × (Fin m → ℝ) → ℝ)
    (hs : ∀ p, Measurable (score p))
    (haffine : ∀ p x y a b, a + b = 1 →
      score p (a • x + b • y) = a * score p x + b * score p y) (p : P) :
    MidpointLogConcave (winnerChannel (laplaceMeasure m) score p) := by
  cases m with
  | succ d => exact conditional_winner_midpointLogConcave score hs haffine p
  | zero =>
    have heq : ∀ z, winnerChannel (laplaceMeasure 0) score p z = winnerDensity score p (z, 0) := by
      intro z
      rw [winnerChannel, integral_laplaceMeasure_zero]
      simp [winnerDensity, laplaceDensity, laplaceKernel, l1]
    have h := midpointLogConcave_winnerDensity score haffine p
    constructor
    · intro z
      rw [heq]
      exact h.1 _
    · intro x y
      rw [heq, heq, heq]
      have hm := h.2 (x, 0) (y, 0)
      simpa only [Prod.mk_add_mk, zero_add, Prod.smul_mk, smul_zero] using hm

theorem midpoint_shift_identity {K : ℕ} (z v : Fin K → ℝ) :
    (1 / 2 : ℝ) • ((z - v) + (-z - v)) = -v := by
  funext a
  simp only [Pi.smul_apply, Pi.add_apply, Pi.sub_apply, Pi.neg_apply, smul_eq_mul]
  ring

omit [Nonempty P] in

theorem conditional_winner_shift_comparison {K m : ℕ}
    (score : P → (Fin K → ℝ) × (Fin m → ℝ) → ℝ)
    (hs : ∀ p, Measurable (score p))
    (haffine : ∀ p x y a b, a + b = 1 →
      score p (a • x + b • y) = a * score p x + b * score p y) (p : P)
    (v : Fin K → ℝ) (w : ℝ) (hw0 : 0 ≤ w) (hw1 : w ≤ 1) :
    let r := winnerChannel (laplaceMeasure m) score p
    (∫ z, r (z - v) - r (-v) ∂laplaceMeasure K) ≤
      2 * Real.exp (l1 v) *
        ∫ z, (Real.sqrt (r z) - Real.sqrt w) ^ 2 ∂laplaceMeasure K := by
  let r := winnerChannel (laplaceMeasure m) score p
  have hr := measurable_winnerChannel (laplaceMeasure m) score hs p
  have hrange := winnerChannel_mem_Icc (laplaceMeasure m) score hs p
  have hlc := conditional_winner_midpointLogConcave_all score hs haffine p
  have hmid : ∀ z, Real.sqrt (r (z - v)) * Real.sqrt (r (-z - v)) ≤ r (-v) := by
    intro z
    have h := hlc.2 (z - v) (-z - v)
    rwa [midpoint_shift_identity] at h
  have hraw := bounded_channel_shifted_midpoint r hr (fun z => (hrange z).1)
    (fun z => (hrange z).2) v w hw0 hw1 hmid
  change (∫ z, r (z - v) - r (-v) ∂laplaceMeasure K) ≤ _
  rw [integral_laplaceMeasure_kernel, integral_laplaceMeasure_kernel]
  have hscaled := mul_le_mul_of_nonneg_left hraw (show 0 ≤ (2 ^ K : ℝ)⁻¹ by positivity)
  nlinarith only [hscaled]

end

end PoissonAudit
