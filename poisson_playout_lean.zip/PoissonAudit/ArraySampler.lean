module
public import PoissonAudit.ArrayReplay
public section
open MeasureTheory Set
namespace PoissonAudit
noncomputable section

@[expose] def arrayTrialAction {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (records : List (ReplayRecord X K)) (x : X) (v : NativeNoise X K) : Fin K :=
  let current := fun y => (arrayReplayAt r lam B eta history oracle fallback records y).2
  let record := arrayMakeReplayRecord current v
  let atX := current x
  let designated := Vector.ofFn (fun a => vectorValues atX a * v.1 a)
  arrayValueOracleAction oracle fallback (history ++ record.2) x designated

theorem arrayTrialAction_eq {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (records : List (ReplayRecord X K)) (x : X) (v : NativeNoise X K) :
    arrayTrialAction r lam B eta history oracle fallback records x v =
      replayTrialAction r lam B eta history oracle fallback records x v := by
  have hs : (fun y => vectorValues (arrayReplayAt r lam B eta history oracle fallback records y).2) =
      fun y => (replayAt r lam B eta history oracle fallback records y).2 := by
    funext y
    exact congrArg Prod.snd (arrayReplayAt_values r lam B eta history oracle fallback records y)
  unfold arrayTrialAction replayTrialAction
  simp only [arrayValueOracleAction_eq, vectorValues_ofFn, arrayMakeReplayRecord_values]
  rw [hs, congrFun hs x]

@[expose] def arrayCappedChoice {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (cap J m : ℕ) (tape : NativeNoiseTape X K J) (trials : Fin m → NativeNoise X K) (x : X) : EmpiricalChoice K m := by
  classical
  exact if nativeTapeCountsBounded cap J tape ∧ ∀ i, (trials i).2.1 ≤ cap then
    let records := arrayBuildReplayRecords r lam B eta history oracle fallback J tape
    let actions := Vector.ofFn (fun i => arrayTrialAction r lam B eta history oracle fallback records x (trials i))
    some actions.get else none

theorem arrayCappedChoice_eq {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (cap J m : ℕ) (tape : NativeNoiseTape X K J) (trials : Fin m → NativeNoise X K) (x : X) :
    arrayCappedChoice r lam B eta history oracle fallback cap J m tape trials x =
      cappedOracleChoice r lam B eta history oracle fallback cap J m tape trials x := by
  classical
  unfold arrayCappedChoice cappedOracleChoice
  split_ifs
  · simp only [arrayBuildReplayRecords_eq, arrayTrialAction_eq]
    congr 1
    funext i
    simp [Vector.get, Vector.ofFn]
    congr 1
  · rfl
end
end PoissonAudit
