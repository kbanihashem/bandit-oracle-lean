module

public import PoissonAudit.LaplaceLaw
public import PoissonAudit.EntropyVariational

public section

open MeasureTheory Set
open scoped ENNReal

namespace PoissonAudit

noncomputable section

@[expose] def realLaplaceDensity (z : ℝ) : ℝ := Real.exp (-|z|) / 2
@[expose] def realLaplace : Measure ℝ :=
  volume.withDensity (fun z => ENNReal.ofReal (realLaplaceDensity z))

theorem realLaplaceDensity_pos (z : ℝ) : 0 < realLaplaceDensity z := by
  exact div_pos (Real.exp_pos _) (by norm_num)

theorem integrable_realLaplaceDensity : Integrable realLaplaceDensity :=
  integrable_exp_neg_abs.div_const 2

theorem integral_realLaplaceDensity : (∫ z, realLaplaceDensity z) = 1 := by
  change (∫ z : ℝ, Real.exp (-|z|) / 2) = 1
  rw [integral_div, integral_exp_neg_abs]
  norm_num

instance realLaplace_isProbability : IsProbabilityMeasure realLaplace := by
  refine ⟨?_⟩
  unfold realLaplace
  rw [withDensity_apply _ MeasurableSet.univ, Measure.restrict_univ,
    ← ofReal_integral_eq_lintegral_ofReal integrable_realLaplaceDensity
      (Filter.Eventually.of_forall fun z => (realLaplaceDensity_pos z).le),
    integral_realLaplaceDensity]
  simp

theorem measurable_realLaplaceDensity : Measurable realLaplaceDensity := by
  unfold realLaplaceDensity
  fun_prop

theorem integral_realLaplace (f : ℝ → ℝ) :
    (∫ z, f z ∂realLaplace) = (∫ z, f z * Real.exp (-|z|)) / 2 := by
  unfold realLaplace
  rw [integral_withDensity_eq_integral_toReal_smul
    measurable_realLaplaceDensity.ennreal_ofReal
    (Filter.Eventually.of_forall fun _ => ENNReal.ofReal_lt_top) f]
  simp only [ENNReal.toReal_ofReal (realLaplaceDensity_pos _).le, smul_eq_mul]
  change (∫ z, (Real.exp (-|z|) / 2) * f z) = _
  calc
    _ = ∫ z, (f z * Real.exp (-|z|)) / 2 := by
      apply integral_congr_ae
      filter_upwards [] with z
      ring
    _ = _ := integral_div _ _

theorem integrable_tilted_laplace {t : ℝ} (ht : |t| < 1) :
    Integrable (fun z : ℝ => Real.exp (t * z) * Real.exp (-|z|)) := by
  have hl : IntegrableOn (fun z : ℝ => Real.exp (t * z) * Real.exp (-|z|)) (Iic 0) := by
    apply (integrableOn_exp_mul_Iic (a := t + 1) (by have := (abs_lt.mp ht).1; linarith) 0).congr_fun
    · intro z hz
      change Real.exp ((t + 1) * z) = Real.exp (t * z) * Real.exp (-|z|)
      rw [← Real.exp_add, abs_of_nonpos hz, neg_neg]
      congr 1
      ring
    · exact measurableSet_Iic
  have hr : IntegrableOn (fun z : ℝ => Real.exp (t * z) * Real.exp (-|z|)) (Ioi 0) := by
    apply (integrableOn_exp_mul_Ioi (a := t - 1) (by have := (abs_lt.mp ht).2; linarith) 0).congr_fun
    · intro z hz
      change Real.exp ((t - 1) * z) = Real.exp (t * z) * Real.exp (-|z|)
      rw [← Real.exp_add, abs_of_pos hz]
      congr 1
      ring
    · exact measurableSet_Ioi
  rw [← integrableOn_univ, ← Iic_union_Ioi (a := (0 : ℝ)), integrableOn_union]
  exact ⟨hl, hr⟩

theorem integral_realLaplace_exp {t : ℝ} (ht : |t| < 1) :
    (∫ z, Real.exp (t * z) ∂realLaplace) = 1 / (1 - t ^ 2) := by
  rw [integral_realLaplace]
  have hl : (∫ z : ℝ in Iic 0, Real.exp (t * z) * Real.exp (-|z|)) = 1 / (t + 1) := by
    calc
      _ = ∫ z : ℝ in Iic 0, Real.exp ((t + 1) * z) := by
        apply setIntegral_congr_fun measurableSet_Iic
        intro z hz
        change Real.exp (t * z) * Real.exp (-|z|) = Real.exp ((t + 1) * z)
        rw [← Real.exp_add, abs_of_nonpos hz, neg_neg]
        congr 1
        ring
      _ = _ := by
        rw [integral_exp_mul_Iic (by have := (abs_lt.mp ht).1; linarith)]
        simp
  have hr : (∫ z : ℝ in Ioi 0, Real.exp (t * z) * Real.exp (-|z|)) = 1 / (1 - t) := by
    calc
      _ = ∫ z : ℝ in Ioi 0, Real.exp ((t - 1) * z) := by
        apply setIntegral_congr_fun measurableSet_Ioi
        intro z hz
        change Real.exp (t * z) * Real.exp (-|z|) = Real.exp ((t - 1) * z)
        rw [← Real.exp_add, abs_of_pos hz]
        congr 1
        ring
      _ = _ := by
        rw [integral_exp_mul_Ioi (by have := (abs_lt.mp ht).2; linarith)]
        simp only [mul_zero, Real.exp_zero]
        rw [show t - 1 = -(1 - t) by ring, div_neg]
        ring
  have hh := integral_add_compl (s := Iic (0 : ℝ)) measurableSet_Iic (integrable_tilted_laplace ht)
  rw [compl_Iic, hl, hr] at hh
  rw [← hh]
  have ht0 : t + 1 ≠ 0 := by have := (abs_lt.mp ht).1; linarith
  have ht1 : 1 - t ≠ 0 := by have := (abs_lt.mp ht).2; linarith
  have ht2 : 1 - t ^ 2 ≠ 0 := by nlinarith [(sq_lt_one_iff_abs_lt_one t).mpr ht]
  field_simp [ht0, ht1, ht2]
  ring

end

end PoissonAudit
