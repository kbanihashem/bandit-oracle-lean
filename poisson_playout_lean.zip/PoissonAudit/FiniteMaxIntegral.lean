module

public import PoissonAudit.ConditionalRelaxation
public import Mathlib.MeasureTheory.Integral.Bochner.Basic
public import Mathlib.Topology.Order.Compact

public section

open MeasureTheory
open scoped BigOperators

namespace PoissonAudit

variable {Omega P Q : Type*} [MeasurableSpace Omega]

theorem integrable_finset_max [DecidableEq P] (mu : Measure Omega)
    (s : Finset P) (hs : s.Nonempty) (f : P → Omega → ℝ)
    (hf : ∀ p ∈ s, Integrable (f p) mu) :
    Integrable (fun omega => s.sup' hs (fun p => f p omega)) mu := by
  induction s using Finset.induction_on with
  | empty => simp at hs
  | @insert p s hps ih =>
    by_cases hsn : s.Nonempty
    · simp_rw [Finset.sup'_insert hsn]
      exact (hf p (Finset.mem_insert_self _ _)).sup
        (ih hsn (fun q hq => hf q (Finset.mem_insert_of_mem hq)))
    · have he : s = ∅ := Finset.not_nonempty_iff_eq_empty.mp hsn
      subst s
      simpa using hf p (Finset.mem_insert_self _ _)

noncomputable section

variable [Fintype P] [Nonempty P] [Fintype Q]

@[expose] def affinePoolMax (S : P → ℝ) (V : Omega → P → Q → ℝ)
    (sigma : Q → ℝ) (omega : Omega) : ℝ :=
  Finset.univ.sup' Finset.univ_nonempty (fun p => S p + ∑ j, sigma j * V omega p j)

@[expose] def affinePoolPotential (mu : Measure Omega) (S : P → ℝ)
    (V : Omega → P → Q → ℝ) (sigma : Q → ℝ) : ℝ :=
  ∫ omega, affinePoolMax S V sigma omega ∂mu

theorem integrable_affinePoolMax (mu : Measure Omega) [IsFiniteMeasure mu]
    (S : P → ℝ) (V : Omega → P → Q → ℝ)
    (hV : ∀ p j, Integrable (fun omega => V omega p j) mu) (sigma : Q → ℝ) :
    Integrable (affinePoolMax S V sigma) mu := by
  classical
  apply integrable_finset_max mu Finset.univ Finset.univ_nonempty
  intro p _
  exact (integrable_const _).add
    (integrable_finsetSum _ (fun j _ => (hV p j).const_mul (sigma j)))

omit [MeasurableSpace Omega] in
theorem continuous_affinePoolMax (S : P → ℝ) (V : Omega → P → Q → ℝ)
    (omega : Omega) : Continuous (fun sigma => affinePoolMax S V sigma omega) := by
  classical
  apply Continuous.finset_sup'_apply Finset.univ_nonempty
  intro p _
  fun_prop

omit [MeasurableSpace Omega] in

theorem convex_affinePoolMax (S : P → ℝ) (V : Omega → P → Q → ℝ)
    (omega : Omega) : ConvexOn ℝ Set.univ (fun sigma => affinePoolMax S V sigma omega) := by
  classical
  refine ⟨convex_univ, ?_⟩
  intro s _ t _ a b ha hb hab
  unfold affinePoolMax
  apply Finset.sup'_le
  intro p _
  have hs := Finset.le_sup' (s := Finset.univ) (f := fun p => S p + ∑ j, s j * V omega p j)
    (Finset.mem_univ p)
  have ht := Finset.le_sup' (s := Finset.univ) (f := fun p => S p + ∑ j, t j * V omega p j)
    (Finset.mem_univ p)
  have h := add_le_add (mul_le_mul_of_nonneg_left hs ha) (mul_le_mul_of_nonneg_left ht hb)
  convert h using 1
  · simp only [Pi.add_apply, Pi.smul_apply, smul_eq_mul, add_mul, Finset.sum_add_distrib,
      mul_assoc, ← Finset.mul_sum]
    linear_combination -(S p) * hab

theorem convex_affinePoolPotential (mu : Measure Omega) [IsFiniteMeasure mu]
    (S : P → ℝ) (V : Omega → P → Q → ℝ)
    (hV : ∀ p j, Integrable (fun omega => V omega p j) mu) :
    ConvexOn ℝ Set.univ (affinePoolPotential mu S V) := by
  exact integral_convexOn_of_integrand_ae convex_univ
    (Filter.Eventually.of_forall (convex_affinePoolMax S V))
    (fun sigma _ => integrable_affinePoolMax mu S V hV sigma)

end

end PoissonAudit
