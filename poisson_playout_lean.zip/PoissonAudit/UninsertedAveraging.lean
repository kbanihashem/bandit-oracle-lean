module

public import PoissonAudit.ConditionalActionDifference
public import PoissonAudit.ContextPrefixAverage

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

theorem integral_if_outcome {Omega A : Type*} [MeasurableSpace Omega]
    [MeasurableSpace A] [MeasurableSingletonClass A] [DecidableEq A]
    (mu : Measure Omega) (W : Omega → A) (hW : Measurable W) (a : A) :
    (∫ omega, (if W omega = a then (1 : ℝ) else 0) ∂mu) = outcomeMass mu W a := by
  classical
  have heq : (fun omega => if W omega = a then (1 : ℝ) else 0) =
      (outcomeEvent W a).indicator (fun _ => (1 : ℝ)) := by
    funext omega
    by_cases h : W omega = a <;> simp [outcomeEvent, h]
  rw [heq]
  exact integral_outcomeIndicator mu W hW a

theorem integrable_if_outcome {Omega A : Type*} [MeasurableSpace Omega]
    [MeasurableSpace A] [MeasurableSingletonClass A] [DecidableEq A]
    (mu : Measure Omega) [IsProbabilityMeasure mu] (W : Omega → A) (hW : Measurable W) (a : A) :
    Integrable (fun omega => if W omega = a then (1 : ℝ) else 0) mu := by
  have hE : MeasurableSet {omega | W omega = a} := hW (measurableSet_singleton a)
  have hm : Measurable (fun omega => if W omega = a then (1 : ℝ) else 0) :=
    measurable_const.ite hE measurable_const
  apply Integrable.of_bound hm.aestronglyMeasurable 1
  filter_upwards [] with omega
  split <;> norm_num

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem finite_uninserted_context_split (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) (a : Fin K) (n : ℕ) :
    (∫ u : Fin n → X × (Fin K → ℝ), (if predict (finiteMarkWinner predict sigma S u) x = a then (1 : ℝ) else 0)
      ∂iidPool (contextLaplaceLaw D K) n) =
      ∫ C, locationUninsertedProbability predict sigma S x a n C ∂iidPool D n := by
  let e := MeasurableEquiv.arrowProdEquivProdArrow X (Fin K → ℝ) (Fin n)
  have hmp : MeasurePreserving e (iidPool (contextLaplaceLaw D K) n)
      ((iidPool D n).prod (iidPool (laplaceMeasure K) n)) :=
    measurePreserving_arrowProdEquivProdArrow X (Fin K → ℝ) (Fin n) (fun _ => D) (fun _ => laplaceMeasure K)
  let f := fun u : Fin n → X × (Fin K → ℝ) =>
    if predict (finiteMarkWinner predict sigma S u) x = a then (1 : ℝ) else 0
  have hi : Integrable f (iidPool (contextLaplaceLaw D K) n) :=
    integrable_if_outcome _ _ ((measurable_of_finite (fun p => predict p x)).comp (measurable_finiteMarkWinner predict sigma S n)) a
  have hback := MeasurePreserving.symm e hmp
  have hFi := hback.integrable_comp_of_integrable hi
  calc
    _ = ∫ v, f (e.symm v) ∂(iidPool D n).prod (iidPool (laplaceMeasure K) n) := (hback.integral_comp' f).symm
    _ = ∫ C, ∫ Z, (if predict (locationWinner predict sigma S C Z) x = a then (1 : ℝ) else 0)
        ∂iidPool (laplaceMeasure K) n ∂iidPool D n := integral_prod _ hFi
    _ = _ := by
      apply integral_congr_ae
      filter_upwards [] with C
      exact integral_if_outcome _ _ ((measurable_of_finite (fun p => predict p x)).comp (measurable_locationWinner predict sigma S C)) a

theorem uninsertedActionProbability_eq_contexts (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) :
    uninsertedActionProbability r D predict sigma S x a =
      ∫ n, (∫ C, locationUninsertedProbability predict sigma S x a n C ∂iidPool D n) ∂ProbabilityTheory.poissonMeasure r := by
  have hA : Measurable (fun pool => predict (poissonWinner predict sigma S pool) x) :=
    (measurable_of_finite (fun p => predict p x)).comp (measurable_poissonWinner predict sigma S)
  have hi := integrable_if_outcome (markedPoolLaw r (contextLaplaceLaw D K)) _ hA a
  change outcomeMass (markedPoolLaw r (contextLaplaceLaw D K)) (fun pool => predict (poissonWinner predict sigma S pool) x) a = _
  rw [← integral_if_outcome _ _ hA a]
  change (∫ pool, (if predict (poissonWinner predict sigma S pool) x = a then (1 : ℝ) else 0)
    ∂(ProbabilityTheory.poissonMeasure r).prod (markSequence (contextLaplaceLaw D K))) = _
  rw [integral_prod _ hi]
  apply integral_congr_ae
  filter_upwards [] with n
  have hmp := poolPrefix_measurePreserving (contextLaplaceLaw D K) n
  let f := fun u : Fin n → X × (Fin K → ℝ) =>
    if predict (finiteMarkWinner predict sigma S u) x = a then (1 : ℝ) else 0
  have hm : Measurable f := by
    apply Measurable.ite _ measurable_const measurable_const
    exact ((measurable_of_finite (fun p => predict p x)).comp (measurable_finiteMarkWinner predict sigma S n)) (measurableSet_singleton a)
  have hmap := integral_map hmp.measurable.aemeasurable (f := f)
    (by rw [hmp.map_eq]; exact hm.aestronglyMeasurable)
  rw [hmp.map_eq] at hmap
  calc
    _ = ∫ u, f (poolPrefix n u) ∂markSequence (contextLaplaceLaw D K) := by
      apply integral_congr_ae
      filter_upwards [] with u
      simp only [poissonWinner_eq_finiteMarkWinner]
      rfl
    _ = ∫ u, f u ∂iidPool (contextLaplaceLaw D K) n := hmap.symm
    _ = _ := finite_uninserted_context_split D predict sigma S x a n

theorem integrable_locationUninserted_field (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) :
    Integrable (contextPrefixField (locationUninsertedProbability predict sigma S x a)) (markedPoolLaw r D) := by
  apply integrable_contextPrefixField r D _ 1
  intro n C
  rw [abs_of_nonneg (locationUninsertedProbability_bounds predict sigma S x a n C).1]
  exact (locationUninsertedProbability_bounds predict sigma S x a n C).2

theorem integral_locationUninserted_field (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) :
    (∫ pool, contextPrefixField (locationUninsertedProbability predict sigma S x a) pool ∂markedPoolLaw r D) =
      uninsertedActionProbability r D predict sigma S x a := by
  rw [integral_contextPrefixField r D _ 1 (fun n C => by
    rw [abs_of_nonneg (locationUninsertedProbability_bounds predict sigma S x a n C).1]
    exact (locationUninsertedProbability_bounds predict sigma S x a n C).2)]
  exact (uninsertedActionProbability_eq_contexts r D predict sigma S x a).symm

end

end PoissonAudit
