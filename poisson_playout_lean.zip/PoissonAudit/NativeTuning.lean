module
public import PoissonAudit.NativeIdealRegret
public section
open scoped BigOperators
namespace PoissonAudit
noncomputable section

theorem tuned_regret_charges {t k z A ell r lam B gamma : ℝ}
    (ht : 0 ≤ t) (hk : 0 < k) (hz : 0 ≤ z) (hA : 1 ≤ A) (hell : 1 ≤ ell)
    (hr : 0 < r) (hlam : 0 < lam) (hB : 0 < B)
    (hg : gamma ≤ 1 / 2) (hTg : t * gamma ≤ 1) (hTB : t * k / B ≤ 1)
    (hTL : 4 * t * z / lam ≤ A) (hTn : t * z / r ≤ A * ell)
    (hrK : r * k ≤ A) (hlamK : lam * k = 4 * A) (hlog : Real.log B ≤ ell) :
    6 * r * k + lam * k * Real.log B +
      t * (gamma + (Real.exp 1 - 2) / (1 - gamma) * (4 * z / lam + k / B) +
        2 * Real.exp 1 * z / r) ≤ 10 * Real.exp 1 * A * ell := by
  have he : 2 ≤ Real.exp 1 := by linarith [Real.add_one_le_exp (1 : ℝ)]
  have hden : 0 < 1 - gamma := by linarith
  have hC : 0 ≤ (Real.exp 1 - 2) / (1 - gamma) := div_nonneg (by linarith) hden.le
  have hC2 : (Real.exp 1 - 2) / (1 - gamma) ≤ 2 * (Real.exp 1 - 2) := by
    apply (div_le_iff₀ hden).mpr
    nlinarith
  have hbud : t * (4 * z / lam + k / B) ≤ A + 1 := by
    calc
      _ = 4 * t * z / lam + t * k / B := by ring
      _ ≤ _ := add_le_add hTL hTB
  have hnon : 0 ≤ t * (4 * z / lam + k / B) := by positivity
  have hcurv := (mul_le_mul_of_nonneg_right hC2 hnon).trans
    (mul_le_mul_of_nonneg_left hbud (by linarith : 0 ≤ 2 * (Real.exp 1 - 2)))
  have hins := mul_le_mul_of_nonneg_left hTn (by positivity : 0 ≤ 2 * Real.exp 1)
  have hpen := mul_le_mul_of_nonneg_left hlog (by linarith : 0 ≤ 4 * A)
  have hAe : A ≤ A * ell := by nlinarith
  have hAe1 : 1 ≤ A * ell := le_trans hA hAe
  have hcurv2 : 2 * (Real.exp 1 - 2) * (A + 1) ≤ 4 * (Real.exp 1 - 2) * (A * ell) := by
    nlinarith [mul_nonneg (by linarith : 0 ≤ Real.exp 1 - 2) (by linarith : 0 ≤ 2 * A * ell - (A + 1))]
  have htotal : 6 * r * k + lam * k * Real.log B +
      t * (gamma + (Real.exp 1 - 2) / (1 - gamma) * (4 * z / lam + k / B) +
        2 * Real.exp 1 * z / r) ≤
      6 * A + 4 * A * ell + 1 + 4 * (Real.exp 1 - 2) * (A * ell) + 2 * Real.exp 1 * (A * ell) := by
    have hc := hcurv.trans hcurv2
    have hpen' : lam * k * Real.log B ≤ 4 * A * ell := by rw [hlamK]; exact hpen
    ring_nf at hrK hpen' hTg hc hins ⊢
    linarith only [hrK, hpen', hTg, hc, hins]
  have hextra : 0 ≤ (4 * Real.exp 1 - 3) * (A * ell) := mul_nonneg (by linarith) (by positivity)
  nlinarith

theorem concrete_tuning {k t L z : ℝ} (hk : 1 ≤ k) (ht : 1 ≤ t) (hL : 1 ≤ L)
    (hz : 0 ≤ z) (hzL : z ≤ L) :
    let B := k * (t + 1)
    let gamma := 1 / (t + 1)
    let ell := 1 + Real.log B
    let A := Real.sqrt (k * t * L)
    let r := A / (k * ell)
    let lam := 4 * A / k
    0 < r ∧ 0 < lam ∧ 1 ≤ B ∧ 0 < gamma ∧ gamma ≤ 1 / 2 ∧ k / gamma = B ∧
      4 * r * ell = lam ∧
      (6 * r * k + lam * k * Real.log B +
        t * (gamma + (Real.exp 1 - 2) / (1 - gamma) * (4 * z / lam + k / B) +
          2 * Real.exp 1 * z / r) ≤ 10 * Real.exp 1 * A * ell) := by
  let B := k * (t + 1)
  let gamma := 1 / (t + 1)
  let ell := 1 + Real.log B
  let A := Real.sqrt (k * t * L)
  let r := A / (k * ell)
  let lam := 4 * A / k
  have hk0 : 0 < k := by linarith
  have ht0 : 0 < t := by linarith
  have ht1 : 0 < t + 1 := by linarith
  have hB : 1 ≤ B := by dsimp [B]; nlinarith
  have hB0 : 0 < B := by linarith
  have hell : 1 ≤ ell := by dsimp [ell]; linarith [Real.log_nonneg hB]
  have hell0 : 0 < ell := by linarith
  have hprod : 1 ≤ k * t * L := by nlinarith [mul_le_mul hk ht (by linarith) (by linarith)]
  have hA0 : 0 ≤ A := Real.sqrt_nonneg _
  have hA2 : A ^ 2 = k * t * L := Real.sq_sqrt (by linarith)
  have hA : 1 ≤ A := by nlinarith
  have hAp : 0 < A := by linarith
  have hr : 0 < r := div_pos hAp (mul_pos hk0 hell0)
  have hlam : 0 < lam := div_pos (by positivity) hk0
  have hg : 0 < gamma := one_div_pos.mpr ht1
  have hgs : gamma ≤ 1 / 2 := by dsimp [gamma]; apply (div_le_iff₀ ht1).mpr; linarith
  have hcap : k / gamma = B := by dsimp [gamma, B]; field_simp
  have hrate : 4 * r * ell = lam := by dsimp [r, lam]; field_simp
  have hlamK : lam * k = 4 * A := by dsimp [lam]; field_simp
  have hrK : r * k ≤ A := by
    have heq : r * k = A / ell := by dsimp [r]; field_simp
    rw [heq]
    apply (div_le_iff₀ hell0).mpr
    nlinarith
  have hTg : t * gamma ≤ 1 := by dsimp [gamma]; rw [mul_one_div]; apply (div_le_one ht1).mpr; linarith
  have hTB : t * k / B ≤ 1 := by apply (div_le_one hB0).mpr; dsimp [B]; nlinarith
  have hTL_eq : 4 * t * L / lam = A := by
    dsimp [lam]
    field_simp
    nlinarith [hA2]
  have hTn_eq : t * L / r = A * ell := by
    dsimp [r]
    field_simp
    nlinarith [hA2]
  have hTL : 4 * t * z / lam ≤ A := by
    rw [← hTL_eq]
    exact div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left hzL (by positivity)) hlam.le
  have hTn : t * z / r ≤ A * ell := by
    rw [← hTn_eq]
    exact div_le_div_of_nonneg_right (mul_le_mul_of_nonneg_left hzL ht0.le) hr.le
  refine ⟨hr, hlam, hB, hg, hgs, hcap, hrate, ?_⟩
  exact tuned_regret_charges ht0.le hk0 hz hA hell hr hlam hB0 hgs hTg hTB hTL hTn hrK hlamK (by change Real.log B ≤ 1 + Real.log B; linarith)

theorem explorationLog_tuned {K : ℕ} (hK : 0 < K) {t : ℝ} (ht : 1 ≤ t) :
    explorationLog K (1 / (t + 1)) = 1 + Real.log ((K : ℝ) * (t + 1)) := by
  have hk : (K : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr (Nat.ne_of_gt hK)
  have ht1 : t + 1 ≠ 0 := by linarith
  have heq : (1 / (t + 1)) / (K : ℝ) = 1 / ((K : ℝ) * (t + 1)) := by field_simp
  unfold explorationLog
  rw [heq, one_div, Real.log_inv]
  ring

theorem tuning_log_bound {k t : ℝ} (hk : 1 ≤ k) (ht : 1 ≤ t) :
    1 + Real.log (k * (t + 1)) ≤ 3 * Real.log (2 * k * t) := by
  have hk0 : 0 < k := by linarith
  have ht0 : 0 < t := by linarith
  have hB0 : 0 < k * (t + 1) := by positivity
  have hdom : k * (t + 1) ≤ 2 * k * t := by nlinarith
  have hlog := Real.log_le_log hB0 hdom
  have htwo : 2 ≤ 2 * k * t := by nlinarith [mul_le_mul hk ht (by linarith) (by linarith)]
  have hlog2 := Real.log_le_log (by norm_num : (0 : ℝ) < 2) htwo
  have hhalf := Real.one_sub_inv_le_log_of_pos (by norm_num : (0 : ℝ) < 2)
  norm_num at hhalf
  linarith

end
end PoissonAudit
