module
public import PoissonAudit.NativeSGDConvergence
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem native_SGD_objective_accuracy (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eps : ℝ)
    (hlam : 0 < lam) (hB : 1 ≤ B) (heps : 0 < eps) (hK : 0 < K)
    (s : NativeScaleBox X K B) (J : ℕ) (hJ : 0 < J)
    (hbudget : B ^ 2 * K * (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2)) / eps ^ 2 ≤ J) :
    (∫ state, nativeBoxObjective r D predict S lam B state.2 - nativeBoxObjective r D predict S lam B s
      ∂nativeSGDStateLaw r D predict S lam B (eps / (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2))) hB J) ≤ eps := by
  let G : ℝ := K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2)
  have hG : 0 < G := by dsimp [G]; positivity
  have heta : 0 < eps / G := div_pos heps hG
  have h := native_SGD_expected_objective_error r D predict S lam B (eps / G) hlam.le hB heta s J hJ
  have hfirst : B ^ 2 * K / (2 * (eps / G) * J) ≤ eps / 2 := by
    apply (div_le_iff₀ (by positivity : 0 < 2 * (eps / G) * (J : ℝ))).mpr
    apply (mul_le_mul_iff_right₀ hG).mp
    have heq : G * (eps / 2 * (2 * (eps / G) * J)) = (J : ℝ) * eps ^ 2 := by field_simp
    rw [heq]
    have hb := (div_le_iff₀ (sq_pos_of_pos heps)).mp hbudget
    nlinarith only [hb]
  have hsecond : (eps / G) * G / 2 = eps / 2 := by field_simp
  rw [hsecond] at h
  linarith

theorem native_SGD_scale_accuracy (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eps : ℝ)
    (hlam : 0 < lam) (hB : 1 ≤ B) (heps : 0 < eps) (hK : 0 < K)
    (s : NativeScaleBox X K B)
    (hmin : IsMinOn (scaleObjective (markedPoolLaw r (contextLaplaceLaw D K)) S (poissonCoefficient predict)
      (fun q => (D {q.1}).toReal) lam B) (scaleBox (X × Fin K) B) s.val)
    (J : ℕ) (hJ : 0 < J)
    (hbudget : B ^ 2 * K * (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2)) / eps ^ 2 ≤ J) :
    (∫ state, weightedSquareDistance (fun q => (D {q.1}).toReal) state.2.val s.val
      ∂nativeSGDStateLaw r D predict S lam B (eps / (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2))) hB J) ≤
        2 * B ^ 2 * eps / lam := by
  let mu := nativeSGDStateLaw r D predict S lam B (eps / (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2))) hB J
  let dist := fun state : NativeSGDState X K B => weightedSquareDistance (fun q => (D {q.1}).toReal) state.2.val s.val
  let gap := fun state : NativeSGDState X K B => nativeBoxObjective r D predict S lam B state.2 - nativeBoxObjective r D predict S lam B s
  have hd : Continuous dist := by
    apply continuous_finsetSum
    intro q _
    exact continuous_const.mul ((((continuous_apply q).comp (continuous_subtype_val.comp continuous_snd)).sub continuous_const).pow 2)
  have hg : Continuous gap := ((continuous_nativeBoxObjective r D predict S lam B hB).comp continuous_snd).sub continuous_const
  have hdi : Integrable dist mu := integrable_continuous_nativeSGDState B mu _ hd
  have hgi : Integrable gap mu := integrable_continuous_nativeSGDState B mu _ hg
  have hp (state : NativeSGDState X K B) : lam / (2 * B ^ 2) * dist state ≤ gap state := by
    have h := scaleObjective_quadratic_growth (markedPoolLaw r (contextLaplaceLaw D K)) S
      (poissonCoefficient predict) (integrable_poissonCoefficient r D predict) (fun q => (D {q.1}).toReal)
      (fun _ => ENNReal.toReal_nonneg) lam B hlam.le hB s.val state.2.val s.property state.2.property hmin
    have heq : (∑ q : X × Fin K, (D {q.1}).toReal * (s.val q - state.2.val q) ^ 2) = dist state := by
      apply Finset.sum_congr rfl
      intro q _
      change (D {q.1}).toReal * (s.val q - state.2.val q) ^ 2 = (D {q.1}).toReal * (state.2.val q - s.val q) ^ 2
      ring
    rw [heq] at h
    exact h
  have h := integral_mono (hdi.const_mul (lam / (2 * B ^ 2))) hgi hp
  change (∫ state, lam / (2 * B ^ 2) * dist state ∂mu) ≤ ∫ state, gap state ∂mu at h
  rw [integral_const_mul] at h
  have he := native_SGD_objective_accuracy r D predict S lam B eps hlam hB heps hK s J hJ hbudget
  change (∫ state, gap state ∂mu) ≤ eps at he
  have ht := h.trans he
  have hB0 : 0 < B := by linarith
  apply (le_div_iff₀ hlam).mpr
  have hm := mul_le_mul_of_nonneg_left ht (by positivity : 0 ≤ 2 * B ^ 2)
  field_simp at hm
  nlinarith
@[expose] def nativeSGDIterations (r : NNReal) (K : ℕ) (lam B eps : ℝ) : ℕ :=
  max 1 ⌈B ^ 2 * K * (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2)) / eps ^ 2⌉₊

theorem nativeSGDIterations_pos (r : NNReal) (K : ℕ) (lam B eps : ℝ) :
    0 < nativeSGDIterations r K lam B eps := lt_of_lt_of_le Nat.zero_lt_one (le_max_left _ _)

theorem nativeSGDIterations_budget (r : NNReal) (K : ℕ) (lam B eps : ℝ) :
    B ^ 2 * K * (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2)) / eps ^ 2 ≤ nativeSGDIterations r K lam B eps := by
  exact (Nat.le_ceil _).trans (Nat.cast_le.mpr (le_max_right _ _))

theorem nativeSGDIterations_upper (r : NNReal) (K : ℕ) (lam B eps : ℝ) :
    (nativeSGDIterations r K lam B eps : ℝ) ≤
      1 + B ^ 2 * K * (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2)) / eps ^ 2 := by
  let v := B ^ 2 * K * (K * (64 * (r : ℝ) ^ 2 + 2 * lam ^ 2)) / eps ^ 2
  have hv : 0 ≤ v := by dsimp [v]; positivity
  have hc := Nat.ceil_lt_add_one hv
  change ((max 1 ⌈v⌉₊ : ℕ) : ℝ) ≤ 1 + v
  rw [Nat.cast_max, Nat.cast_one]
  exact max_le (by linarith) (by linarith)

end
end PoissonAudit
