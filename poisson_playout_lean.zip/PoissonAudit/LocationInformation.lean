module

public import PoissonAudit.FirstBlockInformation
public import PoissonAudit.FiniteInsertion

public section

open MeasureTheory ProbabilityTheory InformationTheory
open scoped BigOperators ENNReal

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def locationWinner (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    {m : ℕ} (C : Fin m → X) (Z : Fin m → (Fin K → ℝ)) : P :=
  finiteMarkWinner predict sigma S (fun i => (C i, Z i))

@[expose] def insertedLocationWinner (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) {n : ℕ} (C : Fin n → X) (v : (Fin K → ℝ) × (Fin n → (Fin K → ℝ))) : P :=
  insertedMarkWinner predict sigma S ((x, v.1), fun i => (C i, v.2 i))

theorem measurable_locationWinner (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    {m : ℕ} (C : Fin m → X) : Measurable (locationWinner predict sigma S C) :=
  (measurable_finiteMarkWinner predict sigma S m).comp
    (Measurable.of_eval fun i => measurable_const.prodMk (measurable_pi_apply i))

theorem measurable_insertedLocationWinner (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ)
    (x : X) {n : ℕ} (C : Fin n → X) : Measurable (insertedLocationWinner predict sigma S x C) :=
  (measurable_insertedMarkWinner predict sigma S n).comp
    ((measurable_const.prodMk measurable_fst).prodMk
      (Measurable.of_eval fun i => measurable_const.prodMk ((measurable_pi_apply i).comp measurable_snd)))

@[expose] def insertedLocationInformation (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (n : ℕ) (v : X × (Fin n → X)) : ENNReal :=
  firstBlockInformation (laplaceMeasure K) (iidPool (laplaceMeasure K) n)
    (insertedLocationWinner predict sigma S v.1 v.2)

@[expose] def insertedLocationInformationReal (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (n : ℕ) (v : X × (Fin n → X)) : ℝ :=
  (insertedLocationInformation predict sigma S n v).toReal

theorem insertedLocationInformation_le_log_card (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (n : ℕ) (v : X × (Fin n → X)) :
    insertedLocationInformation predict sigma S n v ≤ ENNReal.ofReal (Real.log (Fintype.card P)) :=
  firstBlockInformation_le_log_card _ _ _ (measurable_insertedLocationWinner predict sigma S v.1 v.2)

theorem log_policy_card_nonneg : 0 ≤ Real.log (Fintype.card P : ℝ) := by
  apply Real.log_nonneg
  exact_mod_cast (Nat.succ_le_of_lt (Fintype.card_pos : 0 < Fintype.card P))

theorem insertedLocationInformationReal_bounds (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (n : ℕ) (v : X × (Fin n → X)) :
    0 ≤ insertedLocationInformationReal predict sigma S n v ∧
      insertedLocationInformationReal predict sigma S n v ≤ Real.log (Fintype.card P) := by
  refine ⟨ENNReal.toReal_nonneg, ?_⟩
  have h := ENNReal.toReal_mono ENNReal.ofReal_ne_top (insertedLocationInformation_le_log_card predict sigma S n v)
  rwa [ENNReal.toReal_ofReal (log_policy_card_nonneg (P := P))] at h

theorem insertedLocationInformation_delete (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (n : ℕ) (C : Fin (n + 1) → X) (i : Fin (n + 1)) :
    insertedLocationInformation predict sigma S n (splitMark i C) =
      coordinateInformation (laplaceMeasure K) (n + 1) (locationWinner predict sigma S C) i := by
  have h := firstBlockInformation_eq_coordinateInformation (laplaceMeasure K) n i
    (insertedLocationWinner predict sigma S (C i) (fun j => C (i.succAbove j)))
    (measurable_insertedLocationWinner predict sigma S (C i) (fun j => C (i.succAbove j)))
  have heq : (fun Z => insertedLocationWinner predict sigma S (C i) (fun j => C (i.succAbove j)) (splitMark i Z)) =
      locationWinner predict sigma S C := by
    funext Z
    exact insertedMarkWinner_delete predict sigma S (fun j => (C j, Z j)) i
  rw [heq] at h
  exact h

theorem locationInformation_budget (predict : P → X → Fin K) (sigma : X × Fin K → ℝ)
    (S : P → ℝ) (m : ℕ) (C : Fin m → X) :
    (∑ i, (coordinateInformation (laplaceMeasure K) m (locationWinner predict sigma S C) i).toReal) ≤
      Real.log (Fintype.card P) := by
  have hsum := sum_coordinateInformation_le_log_card (laplaceMeasure K) m
    (locationWinner predict sigma S C) (measurable_locationWinner predict sigma S C)
  have hfinite (i : Fin m) : coordinateInformation (laplaceMeasure K) m (locationWinner predict sigma S C) i ≠ ∞ := by
    apply ne_top_of_le_ne_top ENNReal.ofReal_ne_top
    exact (Finset.single_le_sum (f := fun i => coordinateInformation (laplaceMeasure K) m
      (locationWinner predict sigma S C) i) (fun _ _ => zero_le) (Finset.mem_univ i)).trans hsum
  rw [← ENNReal.toReal_sum (fun i _ => hfinite i)]
  have h := ENNReal.toReal_mono ENNReal.ofReal_ne_top hsum
  rwa [ENNReal.toReal_ofReal (log_policy_card_nonneg (P := P))] at h

end

end PoissonAudit
