module
public import PoissonAudit.NativeScaleNorm
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem measurable_experimentProbability_scale (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (x : X) (a : Fin K) :
    Measurable (fun sigma : X × Fin K → ℝ => experimentProbability r D predict sigma S x a) := by
  have hW : Measurable (fun v : (X × Fin K → ℝ) × NativeNoise X K => predict (experimentWinner predict v.1 S x v.2) x) :=
    (measurable_of_finite (fun p => predict p x)).comp (measurable_joint_experimentWinner predict S x)
  have hE : MeasurableSet {v : (X × Fin K → ℝ) × NativeNoise X K |
      predict (experimentWinner predict v.1 S x v.2) x = a} := hW (measurableSet_singleton a)
  have hm : Measurable (fun v : (X × Fin K → ℝ) × NativeNoise X K =>
      if predict (experimentWinner predict v.1 S x v.2) x = a then (1 : ℝ) else 0) := measurable_const.ite hE measurable_const
  have hi := hm.stronglyMeasurable.integral_prod_right' (ν := insertedExperimentLaw r D K)
  have heq : (fun sigma : X × Fin K → ℝ => experimentProbability r D predict sigma S x a) =
      fun sigma => ∫ v, (if predict (experimentWinner predict sigma S x v) x = a then (1 : ℝ) else 0) ∂insertedExperimentLaw r D K := by
    funext sigma
    exact (integral_if_outcome _ _ (measurable_experimentAction predict sigma S x) a).symm
  rw [heq]
  exact hi.measurable

theorem measurable_nativeMeanActionError_scale (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (tau : X × Fin K → ℝ) :
    Measurable (fun sigma : X × Fin K → ℝ => nativeMeanActionError r D predict S sigma tau) := by
  have heq (sigma : X × Fin K → ℝ) : nativeMeanActionError r D predict S sigma tau =
      ∑ x, (D {x}).toReal * ∑ a, |experimentProbability r D predict sigma S x a - experimentProbability r D predict tau S x a| := by
    unfold nativeMeanActionError
    rw [integral_fintype Integrable.of_finite]
    rfl
  simp_rw [heq]
  apply Finset.measurable_sum
  intro x _
  apply measurable_const.mul
  apply Finset.measurable_sum
  intro a _
  exact continuous_abs.measurable.comp ((measurable_experimentProbability_scale r D predict S x a).sub measurable_const)

theorem nativeMeanActionError_bounds (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (sigma tau : X × Fin K → ℝ) :
    0 ≤ nativeMeanActionError r D predict S sigma tau ∧ nativeMeanActionError r D predict S sigma tau ≤ K := by
  constructor
  · exact integral_nonneg fun x => Finset.sum_nonneg fun a _ => abs_nonneg _
  · have hp (x : X) (a : Fin K) : |experimentProbability r D predict sigma S x a - experimentProbability r D predict tau S x a| ≤ 1 := by
      have hs0 := experimentProbability_nonneg r D predict sigma S x a
      have ht0 := experimentProbability_nonneg r D predict tau S x a
      have hs1 := experimentProbability_le_one r D predict sigma S x a
      have ht1 := experimentProbability_le_one r D predict tau S x a
      exact abs_le.mpr ⟨by linarith, by linarith⟩
    have h := integral_mono (μ := D) (f := fun x => ∑ a, |experimentProbability r D predict sigma S x a - experimentProbability r D predict tau S x a|)
      (g := fun _ => (K : ℝ)) Integrable.of_finite (integrable_const _) (fun x => by
        have h := Finset.sum_le_sum (s := Finset.univ) fun a _ => hp x a
        simpa using h)
    change (∫ x, ∑ a, |experimentProbability r D predict sigma S x a - experimentProbability r D predict tau S x a| ∂D) ≤ K
    simpa only [integral_const, probReal_univ, one_smul] using h
end
end PoissonAudit
