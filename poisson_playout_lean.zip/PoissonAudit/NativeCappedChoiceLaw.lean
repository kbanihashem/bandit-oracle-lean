module
public import PoissonAudit.NativeEnrichedPool
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section

@[expose] abbrev CappedRawOutcome (K m : ℕ) := Bool × (Fin m → Fin K × Bool)
@[expose] abbrev EmpiricalChoice (K m : ℕ) := Option (Fin m → Fin K)

instance (K m : ℕ) : MeasurableSpace (EmpiricalChoice K m) := ⊤
instance (K m : ℕ) : MeasurableSingletonClass (EmpiricalChoice K m) := ⟨fun _ => trivial⟩

@[expose] def cappedOutcomeChoice {K m : ℕ} (o : CappedRawOutcome K m) : EmpiricalChoice K m :=
  if o.1 || trialAnyOverflow o.2 then none else some (fun i => (o.2 i).1)

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

@[expose] def nativeCappedKernel (r : NNReal) (D : Measure X) (predict : P → X → Fin K) (S : P → ℝ)
    (B : ℝ) (x : X) (cap m : ℕ) (state : NativeFlaggedState X K B) (o : CappedRawOutcome K m) : ℝ :=
  if state.2 = o.1 then finiteProductWeight (nativeEnrichedProbability r D predict state.1.2.val S x cap) m o.2 else 0

theorem nativeCappedKernel_nonneg (r : NNReal) (D : Measure X) (predict : P → X → Fin K) (S : P → ℝ)
    (B : ℝ) (x : X) (cap m : ℕ) (state : NativeFlaggedState X K B) (o : CappedRawOutcome K m) :
    0 ≤ nativeCappedKernel r D predict S B x cap m state o := by
  unfold nativeCappedKernel
  split_ifs
  · exact finiteProductWeight_nonneg _ (nativeEnrichedProbability_nonneg r D predict state.1.2.val S x cap) m o.2
  · exact le_rfl

theorem nativeCappedKernel_test_sum (r : NNReal) (D : Measure X) (predict : P → X → Fin K) (S : P → ℝ)
    (B : ℝ) (x : X) (cap m : ℕ) (state : NativeFlaggedState X K B) (f : CappedRawOutcome K m → ℝ) :
    (∑ o, nativeCappedKernel r D predict S B x cap m state o * f o) =
      ∑ u, finiteProductWeight (nativeEnrichedProbability r D predict state.1.2.val S x cap) m u * f (state.2, u) := by
  classical
  rw [Fintype.sum_prod_type, Finset.sum_eq_single state.2]
  · simp only [nativeCappedKernel, ite_true]
  · intro b _ hb
    simp only [nativeCappedKernel, Ne.symm hb, ite_false, zero_mul, Finset.sum_const_zero]
  · simp

theorem nativeCappedKernel_sum (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (B : ℝ) (x : X) (cap m : ℕ) (state : NativeFlaggedState X K B) :
    (∑ o, nativeCappedKernel r D predict S B x cap m state o) = 1 := by
  have h := nativeCappedKernel_test_sum r D predict S B x cap m state (fun _ => 1)
  simp only [mul_one, finiteProductWeight_sum _ (nativeEnrichedProbability_sum r D predict state.1.2.val S x cap)] at h
  exact h

theorem measurable_nativeCappedKernel (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (B : ℝ) (x : X) (cap m : ℕ) (o : CappedRawOutcome K m) :
    Measurable (fun state : NativeFlaggedState X K B => nativeCappedKernel r D predict S B x cap m state o) := by
  have hp (a : Fin K × Bool) : Measurable (fun state : NativeFlaggedState X K B =>
      nativeEnrichedProbability r D predict state.1.2.val S x cap a) :=
    (measurable_nativeEnrichedProbability_scale r D predict S x cap a).comp
      (measurable_subtype_coe.comp (measurable_snd.comp measurable_fst))
  have hm : Measurable (fun state : NativeFlaggedState X K B =>
      finiteProductWeight (nativeEnrichedProbability r D predict state.1.2.val S x cap) m o.2) :=
    Finset.measurable_prod _ (fun i _ => hp (o.2 i))
  exact hm.ite (measurable_snd (measurableSet_singleton o.1)) measurable_const

@[expose] def nativeCappedRawLaw (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ) (hB : 1 ≤ B) (cap J m : ℕ) (x : X) : PMF (CappedRawOutcome K m) :=
  finiteKernelMixtureLaw (nativeFlaggedStateLaw r D predict S lam B eta hB cap J)
    (nativeCappedKernel r D predict S B x cap m) (nativeCappedKernel_nonneg r D predict S B x cap m)
    (nativeCappedKernel_sum r D predict S B x cap m) (measurable_nativeCappedKernel r D predict S B x cap m)

@[expose] def nativeCappedChoiceWeight (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ) (hB : 1 ≤ B) (cap J m : ℕ) (x : X) (choice : EmpiricalChoice K m) : ℝ :=
  outcomeMass (nativeCappedRawLaw r D predict S lam B eta hB cap J m x).toMeasure cappedOutcomeChoice choice

@[expose] def nativeCappedChoiceLaw (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ) (hB : 1 ≤ B) (cap J m : ℕ) (x : X) : PMF (EmpiricalChoice K m) :=
  actionPMF (nativeCappedChoiceWeight r D predict S lam B eta hB cap J m x)
    (outcomeMass_nonneg _ _) (sum_outcomeMass _ _ (measurable_of_finite _))

theorem integral_nativeCappedChoiceLaw (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (S : P → ℝ) (lam B eta : ℝ) (hB : 1 ≤ B) (cap J m : ℕ) (x : X)
    (f : EmpiricalChoice K m → ℝ) :
    (∫ choice, f choice ∂(nativeCappedChoiceLaw r D predict S lam B eta hB cap J m x).toMeasure) =
      ∫ state : NativeFlaggedState X K B,
        (∫ u, f (cappedOutcomeChoice (state.2, u)) ∂iidPool (nativeEnrichedLaw r D predict state.1.2.val S x cap).toMeasure m)
          ∂nativeFlaggedStateLaw r D predict S lam B eta hB cap J := by
  let mu := nativeFlaggedStateLaw r D predict S lam B eta hB cap J
  let q := nativeCappedKernel r D predict S B x cap m
  have he := integral_finite_outcome_test (nativeCappedRawLaw r D predict S lam B eta hB cap J m x).toMeasure
    cappedOutcomeChoice (measurable_of_finite _) f
  unfold nativeCappedChoiceLaw nativeCappedChoiceWeight
  rw [integral_actionPMF, ← he]
  change (∫ o, f (cappedOutcomeChoice o) ∂(finiteKernelMixtureLaw mu q _ _ _).toMeasure) = _
  rw [integral_finiteKernelMixtureLaw]
  apply integral_congr_ae
  filter_upwards [] with state
  rw [nativeCappedKernel_test_sum]
  exact (integral_iid_actionPMF (nativeEnrichedProbability r D predict state.1.2.val S x cap)
    (nativeEnrichedProbability_nonneg r D predict state.1.2.val S x cap)
    (nativeEnrichedProbability_sum r D predict state.1.2.val S x cap) m (fun u => f (cappedOutcomeChoice (state.2, u)))).symm
end
end PoissonAudit
