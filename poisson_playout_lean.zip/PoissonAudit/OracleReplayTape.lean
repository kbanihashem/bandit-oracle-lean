module
public import PoissonAudit.NativeNoiseTape
public section
open MeasureTheory Set
namespace PoissonAudit
noncomputable section

@[expose] def buildReplayRecords {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K) :
    (j : ℕ) → NativeNoiseTape X K j → List (ReplayRecord X K)
  | 0, _ => []
  | j + 1, tape =>
    let records := buildReplayRecords r lam B eta history oracle fallback j tape.1
    makeReplayRecord (fun x => (replayAt r lam B eta history oracle fallback records x).1) tape.2 :: records

theorem buildReplayRecords_length {X : Type*} {K : ℕ} (r : NNReal) (lam B eta : ℝ)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ) (fallback : Fin K)
    (j : ℕ) (tape : NativeNoiseTape X K j) :
    (buildReplayRecords r lam B eta history oracle fallback j tape).length = j := by
  induction j with
  | zero => rfl
  | succ j ih => simp only [buildReplayRecords, List.length_cons, ih]

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem replayAt_build_native (r : NNReal) (predict : P → X → Fin K)
    (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ)
    (horacle : ∀ Q, oracle Q = treeBestScore (queryScore predict Q)) (fallback : Fin K)
    (lam B eta : ℝ) (hB : 1 ≤ B) (j : ℕ) (tape : NativeNoiseTape X K j)
    (hgood : nativeTapeGood r predict (queryScore predict history) lam B eta hB j tape) (x : X) :
    replayAt r lam B eta history oracle fallback (buildReplayRecords r lam B eta history oracle fallback j tape) x =
      (fun a => (nativeTapeState r predict (queryScore predict history) lam B eta hB j tape).1.val (x, a),
       fun a => (nativeTapeState r predict (queryScore predict history) lam B eta hB j tape).2.val (x, a)) := by
  induction j generalizing x with
  | zero => rfl
  | succ j ih =>
    let records := buildReplayRecords r lam B eta history oracle fallback j tape.1
    let state := nativeTapeState r predict (queryScore predict history) lam B eta hB j tape.1
    have hprev := hgood.1
    have hcurrent := hgood.2
    have hloc (y : X) : replayAt r lam B eta history oracle fallback records y =
        (fun a => state.1.val (y, a), fun a => state.2.val (y, a)) := ih tape.1 hprev y
    have hscale : (fun y => (replayAt r lam B eta history oracle fallback records y).1) =
        fun y a => state.1.val (y, a) := by
      funext y
      exact congrArg Prod.fst (hloc y)
    have hlength : records.length = j := buildReplayRecords_length r lam B eta history oracle fallback j tape.1
    have hunique (y : X) (p : P) (hp : experimentScore predict state.1.val (queryScore predict history) y tape.2 p =
        treeBestScore (experimentScore predict state.1.val (queryScore predict history) y tape.2)) :
        predict p y = experimentAction predict state.1.val (queryScore predict history) y tape.2 := by
      apply hcurrent y p (experimentWinner predict state.1.val (queryScore predict history) y tape.2)
      exact hp.trans (winner_score_eq_treeBestScore _).symm
    change replayLocalStep r lam B eta history oracle fallback records.length
      (makeReplayRecord (fun y => (replayAt r lam B eta history oracle fallback records y).1) tape.2) x
      (replayAt r lam B eta history oracle fallback records x) = _
    rw [hscale, hlength, hloc]
    exact replayLocalStep_native r predict history oracle horacle fallback lam B eta hB j state tape.2 hunique x

theorem replayAt_build_native_ae (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (history : List (CostExample X K)) (oracle : List (CostExample X K) → ℝ)
    (horacle : ∀ Q, oracle Q = treeBestScore (queryScore predict Q)) (fallback : Fin K)
    (lam B eta : ℝ) (hB : 1 ≤ B) (j : ℕ) :
    ∀ᵐ tape ∂nativeNoiseTapeLaw r D j, ∀ x,
      replayAt r lam B eta history oracle fallback (buildReplayRecords r lam B eta history oracle fallback j tape) x =
        (fun a => (nativeTapeState r predict (queryScore predict history) lam B eta hB j tape).1.val (x, a),
         fun a => (nativeTapeState r predict (queryScore predict history) lam B eta hB j tape).2.val (x, a)) := by
  filter_upwards [nativeTapeGood_ae r D predict (queryScore predict history) lam B eta hB j] with tape htape
  intro x
  exact replayAt_build_native r predict history oracle horacle fallback lam B eta hB j tape htape x
end
end PoissonAudit
