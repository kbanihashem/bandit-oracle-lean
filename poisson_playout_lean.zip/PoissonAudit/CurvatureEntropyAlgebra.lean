module

public import PoissonAudit.Algebra

public section

namespace PoissonAudit

theorem curvature_from_first_order {n sigma lam alpha beta p : ℝ}
    (hsigma : 0 < sigma) (hlam : 0 < lam) (hbeta : 0 ≤ beta) (hp : 0 < p)
    (hfo : lam ≤ n * sigma * alpha) :
    beta / (sigma * p) ≤ (n / lam) * (alpha * beta / p) := by
  have heq : (n / lam) * (alpha * beta / p) = (n * alpha * beta) / (lam * p) := by
    field_simp <;> ring
  rw [heq]
  apply (div_le_div_iff₀ (mul_pos hsigma hp) (mul_pos hlam hp)).mpr
  have h := mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hfo hbeta) hp.le
  convert! h using 1 <;> ring

end PoissonAudit
