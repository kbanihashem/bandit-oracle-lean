module

public import PoissonAudit.InsertedExperiment

public section

open MeasureTheory Set
open scoped BigOperators

namespace PoissonAudit

noncomputable section

@[expose] def coordinateSplitEquiv {n : ℕ} (a : Fin (n + 1)) (U : Type*) [MeasurableSpace U] :
    ((Fin (n + 1) → ℝ) × U) ≃ᵐ ℝ × ((Fin n → ℝ) × U) :=
  (MeasurableEquiv.prodCongr (MeasurableEquiv.piFinSuccAbove (fun _ : Fin (n + 1) => ℝ) a)
    (MeasurableEquiv.refl U)).trans MeasurableEquiv.prodAssoc

theorem coordinateSplitEquiv_fst {n : ℕ} (a : Fin (n + 1)) (U : Type*) [MeasurableSpace U]
    (v : (Fin (n + 1) → ℝ) × U) : (coordinateSplitEquiv a U v).1 = v.1 a := rfl

theorem coordinateSplitEquiv_measurePreserving {U : Type*} [MeasurableSpace U]
    (mu : Measure U) [IsProbabilityMeasure mu] {n : ℕ} (a : Fin (n + 1)) :
    MeasurePreserving (coordinateSplitEquiv a U) ((laplaceMeasure (n + 1)).prod mu)
      (realLaplace.prod ((iidPool realLaplace n).prod mu)) := by
  have hs : MeasurePreserving (MeasurableEquiv.piFinSuccAbove (fun _ : Fin (n + 1) => ℝ) a)
      (laplaceMeasure (n + 1)) (realLaplace.prod (iidPool realLaplace n)) := by
    rw [laplaceMeasure_eq_iid]
    exact splitMark_measurePreserving realLaplace a
  have hid : MeasurePreserving (fun u : U => u) mu mu := ⟨measurable_id, Measure.map_id⟩
  exact (measurePreserving_prodAssoc realLaplace (iidPool realLaplace n) mu).comp (hs.prod hid)

theorem vector_laplace_event_mean_le {U : Type*} [MeasurableSpace U]
    (mu : Measure U) [IsProbabilityMeasure mu] (K : ℕ)
    (E : Set ((Fin K → ℝ) × U)) (hE : MeasurableSet E) (a : Fin K) :
    (∫ v, E.indicator (fun _ => (1 : ℝ)) v * v.1 a ∂(laplaceMeasure K).prod mu) ≤
      2 * ((laplaceMeasure K).prod mu E).toReal * (1 - Real.log ((laplaceMeasure K).prod mu E).toReal) := by
  classical
  cases K with
  | zero => exact Fin.elim0 a
  | succ n =>
    let e := coordinateSplitEquiv a U
    let nu := (iidPool realLaplace n).prod mu
    let E' := e.symm ⁻¹' E
    have hE' : MeasurableSet E' := hE.preimage e.symm.measurable
    have hmp := coordinateSplitEquiv_measurePreserving mu a
    have hback := MeasurePreserving.symm e hmp
    have hprob : (realLaplace.prod nu) E' = (laplaceMeasure (n + 1)).prod mu E := hback.measure_preimage hE.nullMeasurableSet
    have hcoord (v : ℝ × ((Fin n → ℝ) × U)) : (e.symm v).1 a = v.1 := by
      have h := coordinateSplitEquiv_fst a U (e.symm v)
      rw [show coordinateSplitEquiv a U (e.symm v) = v from e.apply_symm_apply v] at h
      exact h.symm
    have hmean : (∫ v, E.indicator (fun _ => (1 : ℝ)) v * v.1 a ∂(laplaceMeasure (n + 1)).prod mu) =
        ∫ v, E'.indicator (fun _ => (1 : ℝ)) v * v.1 ∂realLaplace.prod nu := by
      rw [← hback.integral_comp' (fun v => E.indicator (fun _ => (1 : ℝ)) v * v.1 a)]
      apply integral_congr_ae
      filter_upwards [] with v
      rw [hcoord]
      by_cases h : e.symm v ∈ E <;> simp [E', h]
    rw [hmean]
    have h := laplace_event_mean_le_all nu E' hE'
    rwa [hprob] at h

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X] {K : ℕ}
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]

theorem experimentAlpha_tail (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K) :
    experimentAlpha r D predict sigma S x a ≤ 2 * experimentProbability r D predict sigma S x a *
      (1 - Real.log (experimentProbability r D predict sigma S x a)) := by
  exact vector_laplace_event_mean_le (markedPoolLaw r (contextLaplaceLaw D K)) K
    (experimentActionEvent predict sigma S x a) (measurable_experimentActionEvent predict sigma S x a) a

theorem experimentAlpha_probability_charge (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin K) (sigma : X × Fin K → ℝ) (S : P → ℝ) (x : X) (a : Fin K)
    (q ell : ℝ) (hq : 0 < q) (hpq : experimentProbability r D predict sigma S x a ≤ 2 * q)
    (hell1 : 1 ≤ ell) (hellq : 1 - Real.log q ≤ ell) :
    experimentAlpha r D predict sigma S x a ≤ 4 * q * ell :=
  weak_tail_probability_charge (experimentProbability_nonneg r D predict sigma S x a)
    (experimentProbability_le_one r D predict sigma S x a) hq hpq hell1 hellq
    (experimentAlpha_tail r D predict sigma S x a)

end

end PoissonAudit
