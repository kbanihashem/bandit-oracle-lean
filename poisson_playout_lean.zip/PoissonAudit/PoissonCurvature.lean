module

public import PoissonAudit.ExperimentThresholdProbability

public section

open MeasureTheory Set

namespace PoissonAudit

noncomputable section

variable {X P : Type*} [MeasurableSpace X] [MeasurableSingletonClass X] [Fintype X]
    [Fintype P] [Nonempty P] [LinearOrder P] [MeasurableSpace P] [MeasurableSingletonClass P]
    {n : ℕ}

theorem hasDerivAt_insertedPotential_action (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin (n + 1)) (sigma : X × Fin (n + 1) → ℝ) (S : P → ℝ)
    (x : X) (a : Fin (n + 1)) (hsigma : 0 < sigma (x, a))
    (hE : (actionPolicyGroup predict x a).Nonempty) (hEc : (actionPolicyGroup predict x a)ᶜ.Nonempty)
    (b : ℝ) :
    HasDerivAt (fun s => insertedPotential r D predict sigma (actionPenaltyScore predict S x a s) x)
      (-experimentProbability r D predict sigma (actionPenaltyScore predict S x a b) x a) b := by
  let theta := experimentThreshold predict sigma S x a hE hEc
  have ht : Measurable theta := measurable_experimentThreshold predict sigma S x a hE hEc
  have hd := (hasDerivAt_thresholdPotential (experimentRemainderLaw r D n) theta ht (sigma (x, a)) b hsigma).add_const
    (insertedPotential r D predict sigma S x)
  rw [experimentProbability_eq_thresholdProbability r D predict sigma S x a hsigma hE hEc b]
  convert! hd using 1
  funext s
  have h := insertedPotential_eq_thresholdPotential r D predict sigma S x a hsigma hE hEc s
  change _ = thresholdPotential (experimentRemainderLaw r D n) theta (sigma (x, a)) s + _
  linarith

theorem hasDerivAt_inserted_action_derivative (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin (n + 1)) (sigma : X × Fin (n + 1) → ℝ) (S : P → ℝ)
    (x : X) (a : Fin (n + 1)) (hsigma : 0 < sigma (x, a))
    (hE : (actionPolicyGroup predict x a).Nonempty) (hEc : (actionPolicyGroup predict x a)ᶜ.Nonempty)
    (b : ℝ) :
    HasDerivAt (fun s => -experimentProbability r D predict sigma (actionPenaltyScore predict S x a s) x a)
      (thresholdCurvature (experimentRemainderLaw r D n)
        (experimentThreshold predict sigma S x a hE hEc) (sigma (x, a)) b) b := by
  have hd := (hasDerivAt_thresholdProbability (experimentRemainderLaw r D n)
    (experimentThreshold predict sigma S x a hE hEc)
    (measurable_experimentThreshold predict sigma S x a hE hEc) (sigma (x, a)) b hsigma).neg
  convert! hd using 1
  · funext s
    rw [experimentProbability_eq_thresholdProbability r D predict sigma S x a hsigma hE hEc s]
    rfl
  · ring

theorem insertedPotential_quadratic_remainder (r : NNReal) (D : Measure X) [IsProbabilityMeasure D]
    (predict : P → X → Fin (n + 1)) (sigma : X × Fin (n + 1) → ℝ) (S : P → ℝ)
    (x : X) (a : Fin (n + 1)) (hsigma : 0 < sigma (x, a))
    (hE : (actionPolicyGroup predict x a).Nonempty) (hEc : (actionPolicyGroup predict x a)ᶜ.Nonempty)
    (b : ℝ) (hb : 0 ≤ b) (hbs : b ≤ sigma (x, a)) :
    insertedPotential r D predict sigma (actionPenaltyScore predict S x a b) x -
      insertedPotential r D predict sigma S x + b * experimentProbability r D predict sigma S x a ≤
      (Real.exp 1 - 2) * thresholdCurvature (experimentRemainderLaw r D n)
        (experimentThreshold predict sigma S x a hE hEc) (sigma (x, a)) 0 * b ^ 2 := by
  have hp := experimentProbability_eq_thresholdProbability r D predict sigma S x a hsigma hE hEc 0
  rw [actionPenaltyScore_zero] at hp
  rw [insertedPotential_eq_thresholdPotential r D predict sigma S x a hsigma hE hEc b, hp]
  exact thresholdPotential_quadratic_remainder (experimentRemainderLaw r D n)
    (experimentThreshold predict sigma S x a hE hEc)
    (measurable_experimentThreshold predict sigma S x a hE hEc) (sigma (x, a)) b hsigma hb hbs

end

end PoissonAudit
