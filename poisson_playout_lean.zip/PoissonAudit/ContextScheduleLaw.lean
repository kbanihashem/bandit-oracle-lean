module
public import PoissonAudit.ContextSchedule
public section
open MeasureTheory Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section
variable {X Y O A P : Type*} [MeasurableSpace X] [MeasurableSpace Y] [MeasurableSingletonClass Y] [Fintype Y]
    [MeasurableSpace O] [MeasurableSingletonClass O] [Fintype O]
    [Fintype A] [Fintype P] [Nonempty P]

theorem liftedContextLaw_context_marginal (D : Measure X) [IsProbabilityMeasure D] (f : X → Y) (hf : Measurable f)
    (w : (P → ℝ) → Y → O → ℝ) (hw : ∀ S y o, 0 ≤ w S y o) (hwsum : ∀ S y, ∑ o, w S y o = 1)
    (U : (P → ℝ) → Y → (A → ℝ) → O → P → ℝ) (costs : List (Y → A → ℝ)) (S : P → ℝ) :
    (liftedContextLaw D f w U costs S).map (transcriptContexts costs.length) = iidPool D costs.length := by
  classical
  haveI (cs : List (Y → A → ℝ)) (S' : P → ℝ) : IsProbabilityMeasure (liftedContextLaw D f w U cs S') :=
    (liftedContextLaw_certificate D f hf w hw hwsum U cs S').1
  induction costs generalizing S with
  | nil =>
    change (liftedContextLaw D f w U [] S).map (fun _ => (fun i : Fin 0 => Fin.elim0 i)) = iidPool D 0
    rw [Measure.map_const, measure_univ, one_smul]
    exact (probability_on_subsingleton (iidPool D 0) (fun i : Fin 0 => Fin.elim0 i)).symm
  | cons c cs ih =>
    let phi := @transcriptContexts X O (c :: cs).length
    let tail := @transcriptContexts X O cs.length
    have hphi : Measurable phi := measurable_transcriptContexts _
    have htail : Measurable tail := measurable_transcriptContexts _
    have hcons := measurable_contextVectorCons (X := X) cs.length
    have hbranch (y : Y) (o : O) :
        Measure.map phi (Measure.map (contextTranscriptBranch cs.length o)
          ((D.restrict (f ⁻¹' {y})).prod (liftedContextLaw D f w U cs (U S y (c y) o)))) =
            ((D.restrict (f ⁻¹' {y})).prod (iidPool D cs.length)).map contextVectorCons := by
      have hembed : Measurable (contextTranscriptBranch (X := X) cs.length o) := measurable_contextTranscriptBranch cs.length o
      rw [Measure.map_map hphi hembed]
      change ((D.restrict (f ⁻¹' {y})).prod _).map (contextVectorCons ∘ Prod.map id tail) = _
      rw [← Measure.map_map hcons (measurable_id.prodMap htail), ← Measure.map_prod_map _ _ measurable_id htail,
        Measure.map_id, ih]
    have hinner (y : Y) : (∑ o, ENNReal.ofReal (w S y o) •
        ((D.restrict (f ⁻¹' {y})).prod (iidPool D cs.length)).map contextVectorCons) =
          ((D.restrict (f ⁻¹' {y})).prod (iidPool D cs.length)).map contextVectorCons := by
      rw [← Finset.sum_smul]
      have hs : (∑ o, ENNReal.ofReal (w S y o)) = 1 := by
        rw [← ENNReal.ofReal_sum_of_nonneg (fun o _ => hw S y o), hwsum, ENNReal.ofReal_one]
      rw [hs, one_smul]
    have hprod : (∑ y, D.restrict (f ⁻¹' {y})).prod (iidPool D cs.length) =
        ∑ y, (D.restrict (f ⁻¹' {y})).prod (iidPool D cs.length) := by
      rw [← Measure.sum_fintype, Measure.prod_sum_left, Measure.sum_fintype]
    change (liftedContextLaw D f w U (c :: cs) S).map phi = _
    unfold liftedContextLaw
    rw [Measure.map_finset_sum' hphi.aemeasurable]
    have heq : (∑ y, Measure.map phi (∑ o, ENNReal.ofReal (w S y o) •
        (((D.restrict (f ⁻¹' {y})).prod (liftedContextLaw D f w U cs (U S y (c y) o))).map (contextTranscriptBranch cs.length o)))) =
      ∑ y, ((D.restrict (f ⁻¹' {y})).prod (iidPool D cs.length)).map contextVectorCons := by
      apply Finset.sum_congr rfl
      intro y _
      rw [Measure.map_finset_sum' hphi.aemeasurable]
      simp_rw [Measure.map_smul _ hphi.aemeasurable, hbranch]
      exact hinner y
    rw [heq, ← Measure.map_finset_sum' hcons.aemeasurable, ← hprod, sum_restrict_fibers D f hf]
    exact (contextVectorCons_measurePreserving D cs.length).map_eq
end
end PoissonAudit
