module
public import PoissonAudit.ValueOracleAction
public section
open Set
open scoped BigOperators
namespace PoissonAudit
noncomputable section

@[expose] abbrev CostExample (X : Type*) (K : ℕ) := X × (Fin K → ℝ)
@[expose] def queryScore {X P : Type*} {K : ℕ} (predict : P → X → Fin K) (Q : List (CostExample X K)) (p : P) : ℝ :=
  (Q.map (fun ex => ex.2 (predict p ex.1))).sum

theorem queryScore_append {X P : Type*} {K : ℕ} (predict : P → X → Fin K)
    (Q R : List (CostExample X K)) (p : P) : queryScore predict (Q ++ R) p = queryScore predict Q p + queryScore predict R p := by
  simp [queryScore, List.map_append, List.sum_append]

theorem queryScore_designated {X P : Type*} {K : ℕ} (predict : P → X → Fin K)
    (Q : List (CostExample X K)) (x : X) (v : Fin K → ℝ) (p : P) :
    queryScore predict (Q ++ [(x, v)]) p = queryScore predict Q p + v (predict p x) := by
  simp [queryScore, List.map_append, List.sum_append]

@[expose] def boostedDesignatedQuery {X : Type*} {K : ℕ}
    (Q : List (CostExample X K)) (x : X) (v : Fin K → ℝ) (a : Fin K) : List (CostExample X K) := by
  classical
  exact Q ++ [(x, fun b => v b + if b = a then 1 else 0)]

theorem queryScore_boosted {X P : Type*} {K : ℕ} (predict : P → X → Fin K)
    (Q : List (CostExample X K)) (x : X) (v : Fin K → ℝ) (a : Fin K) :
    queryScore predict (boostedDesignatedQuery Q x v a) =
      actionBoostScore (queryScore predict (Q ++ [(x, v)])) (fun p => predict p x) a := by
  classical
  funext p
  unfold boostedDesignatedQuery actionBoostScore
  rw [queryScore_designated, queryScore_designated]
  ring

@[expose] def actionValueQueries {X : Type*} {K : ℕ} (Q : List (CostExample X K)) (x : X) (v : Fin K → ℝ) :
    List (List (CostExample X K)) := (Q ++ [(x, v)]) :: List.ofFn (boostedDesignatedQuery Q x v)

theorem actionValueQueries_count {X : Type*} {K : ℕ} (Q : List (CostExample X K)) (x : X) (v : Fin K → ℝ) :
    (actionValueQueries Q x v).length = K + 1 := by simp [actionValueQueries]

theorem actionValueQueries_length {X : Type*} {K : ℕ} (Q : List (CostExample X K)) (x : X) (v : Fin K → ℝ)
    (R : List (CostExample X K)) (hR : R ∈ actionValueQueries Q x v) : R.length = Q.length + 1 := by
  classical
  simp only [actionValueQueries, List.mem_cons, List.mem_ofFn] at hR
  rcases hR with rfl | ⟨a, rfl⟩ <;> simp [boostedDesignatedQuery]

variable {X P : Type*} {K : ℕ} [Fintype P] [Nonempty P] [LinearOrder P]

theorem cost_sensitive_value_action (predict : P → X → Fin K) (Q : List (CostExample X K))
    (x : X) (v : Fin K → ℝ) (oracle : List (CostExample X K) → ℝ)
    (horacle : ∀ R, oracle R = treeBestScore (queryScore predict R)) :
    ∃ hgood : ∃ a, oracle (boostedDesignatedQuery Q x v a) = oracle (Q ++ [(x, v)]) + 1,
      ∃ p, queryScore predict (Q ++ [(x, v)]) p = treeBestScore (queryScore predict (Q ++ [(x, v)])) ∧
        predict p x = actionFromValueTable (oracle (Q ++ [(x, v)])) (fun a => oracle (boostedDesignatedQuery Q x v a)) hgood := by
  have hgood : ∃ a, oracle (boostedDesignatedQuery Q x v a) = oracle (Q ++ [(x, v)]) + 1 := by
    obtain ⟨a, ha⟩ := exists_boosted_value_action (queryScore predict (Q ++ [(x, v)])) (fun p => predict p x)
    refine ⟨a, ?_⟩
    rw [horacle, horacle, queryScore_boosted]
    exact ha
  refine ⟨hgood, ?_⟩
  exact exact_value_table_winning_action (queryScore predict (Q ++ [(x, v)])) (fun p => predict p x)
    (oracle (Q ++ [(x, v)])) (fun a => oracle (boostedDesignatedQuery Q x v a)) (horacle _)
      (fun a => by rw [horacle, queryScore_boosted]) hgood
end
end PoissonAudit
