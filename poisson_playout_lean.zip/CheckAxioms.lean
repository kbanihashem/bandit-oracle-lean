module
public import PoissonAudit
public section

#print axioms PoissonAudit.oracle_upper_bound
#print axioms PoissonAudit.manuscript_upper_bound
#print axioms PoissonAudit.manuscript_oracle_round
#print axioms PoissonAudit.manuscript_scalar_feedback
#print axioms PoissonAudit.manuscript_winner
#print axioms PoissonAudit.manuscript_round_budget
#print axioms PoissonAudit.manuscript_online_budget
#print axioms PoissonAudit.executeArraySampler_resource_certificate
#print axioms PoissonAudit.cappedOracleChoice_finite_input
#print axioms PoissonAudit.capped_waiting_time_budget
#print axioms PoissonAudit.initialized_upper_bound
#print axioms PoissonAudit.initializePlan_spec
#print axioms PoissonAudit.ceilingSearch_spec
#print axioms PoissonAudit.totalWork_polynomial
#print axioms PoissonAudit.runWaits_spec
#print axioms PoissonAudit.runWaits_law
#print axioms PoissonAudit.waiting_inputs
#print axioms PoissonAudit.waiting_sampler_law
#print axioms PoissonAudit.waiting_round_resources
#print axioms PoissonAudit.waitingRegret_eq
