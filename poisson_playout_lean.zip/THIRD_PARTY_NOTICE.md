# Third-party proof attribution

The files in `PoissonAudit/Vendor/Isoperimetric/` are the Apache-2.0
formalization by Jonathan Ho, retrieved from Lean Pool commit
`01db1d7049cf9668bda1e9e106875ee1278b43e6`:
https://github.com/Vilin97/lean-pool/tree/01db1d7049cf9668bda1e9e106875ee1278b43e6/LeanPool/Isoperimetric

Original repository: https://github.com/hojonathanho/isoperimetric

Copyright (c) 2026 Jonathan Ho. All rights reserved.
The upstream copyright attribution is reproduced here and the full license is in THIRD_PARTY_LICENSE.txt. Local modifications remove source comments,
change the import path and, where necessary, update compatibility with the
pinned Lean/mathlib toolchain. These are external prerequisite proofs, not
new results proved by this project.
